# Persistent Chat Sessions

This document describes the durable conversation persistence layer added to the Contact Center AI.

---

## What Changed

Previously all chat sessions were held in-process memory and lost on logout, process restart, or TTL expiry. After this change:

- Every conversation is persisted to a **PostgreSQL metadata table** (`conversations`).
- The **LangGraph graph checkpoint** (full turn-by-turn state) is also backed by PostgreSQL via `langgraph-checkpoint-postgres`.
- Users can list their previous chats, resume any of them after re-login, and delete them (soft or permanently).

---

## Environment Variables

Set the following in your `.env` file (or deployment environment):

```env
# Conversation metadata store
# "memory" = in-process dict (dev/test only, lost on restart)
# "postgres" = durable PostgreSQL table (required for production)
CONVERSATION_STORE_BACKEND=postgres
CONVERSATION_STORE_POSTGRES_URL=postgresql://user:password@localhost:5432/contact_center

# LangGraph checkpoint backend
# "memory" = MemorySaver (dev/test only)
# "postgres" = PostgresSaver from langgraph-checkpoint-postgres
CHECKPOINT_BACKEND=postgres
CHECKPOINT_POSTGRES_URL=postgresql://user:password@localhost:5432/contact_center
```

Both URLs can point to the same database. The conversation store uses
`psycopg-pool` (async psycopg3) and the checkpointer uses `psycopg`
(sync psycopg3, called via `asyncio.to_thread`).

**Note:** Set `AUTH_JWT_SECRET` to a fixed stable value so JWT tokens
remain valid after a process restart. Without it, an ephemeral secret
is generated at boot and all tokens become invalid on restart.

```env
AUTH_JWT_SECRET=your-secret-minimum-32-chars
```

---

## New API Endpoints

### `GET /conversations`

List all conversations for the authenticated user.

**Auth:** Login JWT (`Authorization: Bearer <jwt>`)

**Query params:**
| Param | Type | Default | Description |
|---|---|---|---|
| `include_deleted` | bool | false | Also return soft-deleted chats |
| `limit` | int | 50 | Max results (capped at 200) |
| `cursor` | string | — | ISO timestamp for keyset pagination |

**Response:**
```json
{
  "conversations": [
    {
      "conversation_id": "abc123",
      "status": "ACTIVE",
      "title": null,
      "last_user_message_preview": "What is my 401k balance?",
      "current_turn": 4,
      "channel": "web",
      "created_at": "2026-04-29T10:00:00+00:00",
      "last_active_at": "2026-04-29T10:05:00+00:00",
      "ended_at": null,
      "deleted_at": null
    }
  ],
  "total": 1,
  "next_cursor": null
}
```

---

### `POST /conversations/{id}/resume`

Re-open a past conversation after logout/login. Issues a **new session token** without losing graph state.

**Auth:** Login JWT

**Response:**
```json
{
  "conversation_id": "abc123",
  "session_token": "<new_token>",
  "status": "ACTIVE",
  "current_turn": 4,
  "last_active_at": "2026-04-29T10:05:00+00:00"
}
```

After calling this endpoint, use the returned `session_token` as a Bearer token for
`/turns`, `/hitl`, and `/end` as usual.

---

### `DELETE /conversations/{id}`

**Soft delete** — hides the conversation from the default list but preserves all data and checkpoints. Reversible in future via a restore endpoint.

**Auth:** Login JWT

**Response:** `204 No Content`

---

### `DELETE /conversations/{id}/hard`

**Permanent delete** — removes the metadata row, the graph checkpoint, and cleans up vault tokens. Irreversible.

**Auth:** Login JWT

**Response:** `204 No Content`

---

## Re-login / Session Continuity Flow

```
User logs in  →  GET /conversations  →  pick a previous chat
   ↓
POST /conversations/{id}/resume  →  { session_token: "new_tok" }
   ↓
POST /conversations/{id}/turns   (Authorization: Bearer new_tok)
   ↓  (conversation continues from where it left off)
```

---

## Architecture

```
Login JWT (user_id)
      ↓
  API endpoint
      ├─→  ConversationStore.create/update   (psycopg3 async pool)
      │         conversations table  ←→  PostgreSQL
      └─→  LangGraph.invoke(thread_id=conversation_id)
                    ↓
              PostgresSaver.put/get    (psycopg3 sync, in asyncio.to_thread)
                    checkpoint tables ←→  PostgreSQL
```

---

## Database Tables

**`conversations`** — app-layer metadata
- `conversation_id` (PK), `user_id`, `status`, `title`, `last_user_message_preview`
- `current_turn`, `channel`, `session_token_hash` (SHA-256 of token, never plaintext)
- `created_at`, `updated_at`, `last_active_at`, `ended_at`, `deleted_at`

**`conversation_deletion_audit`** — immutable audit log for all deletes

**LangGraph checkpoint tables** — managed by `langgraph-checkpoint-postgres`; tables are created automatically via `PostgresSaver.setup()` at startup.

---

## Local Development (no Postgres)

By default `CONVERSATION_STORE_BACKEND=memory` and `CHECKPOINT_BACKEND=memory`.
No database setup is required. Conversations are held in process memory and lost on restart, which is the existing behaviour.

To enable full persistence locally, start a Postgres instance:
```bash
docker run --rm -p 5432:5432 \
  -e POSTGRES_USER=cc -e POSTGRES_PASSWORD=cc -e POSTGRES_DB=contact_center \
  postgres:16-alpine
```
Then set the env vars above and restart the app.

---

## Backward Compatibility

- All existing endpoints (`/turns`, `/hitl`, `/end`, `GET /conversations/{id}`) are unchanged.
- Active in-memory conversations from before the migration will resume after restart if persistence was enabled before the restart, otherwise they are lost (Option A from the migration plan).
- Response shapes are additive; no existing fields removed.
