"""In-memory implementations of AuthSecretsProvider + OtpChannel.

Seeded from a JSON file at construction time. Plaintext answers are present
in the JSON for human authoring; the provider hashes them on load and never
exposes plaintext after that.
"""

from __future__ import annotations

import hmac
import json
import logging
import secrets
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from agents.auth_agent.v1.evaluator import hash_answer
from auth.base import AuthSecretsProvider, OtpChannel
from schemas.enums import ChallengeType

_log = logging.getLogger("contact_center")


class MemoryAuthSecretsProvider(AuthSecretsProvider):
    """Loads demo accounts from JSON, hashes answers and passwords at load."""

    def __init__(self, accounts_path: str | Path):
        path = Path(accounts_path)
        if not path.exists():
            raise FileNotFoundError(
                f"MemoryAuthSecretsProvider: accounts file not found: {path}"
            )
        with path.open("r", encoding="utf-8") as f:
            raw: dict[str, dict] = json.load(f)

        self._hashed_answers: dict[str, dict[str, str]] = {}
        self._password_hashes: dict[str, str] = {}      # user_id -> sha256
        self._username_to_uid: dict[str, str] = {}
        self._account_contexts: dict[str, dict] = {}

        for user_id, data in raw.items():
            answers = data.get("auth_secrets_plain") or {}
            self._hashed_answers[user_id] = {
                ct: hash_answer(ct, str(val)) for ct, val in answers.items()
            }
            password = data.get("password_plain")
            if password:
                self._password_hashes[user_id] = hash_answer(
                    "PASSWORD", str(password)
                )
            username = data.get("username") or data.get("email") or user_id
            self._username_to_uid[username.lower()] = user_id
            self._account_contexts[user_id] = data.get("account_context") or {}

        _log.info(
            "memory_auth_provider_loaded users=%d path=%s",
            len(raw), path,
        )

    def get_expected_hash(
        self, user_id: str, challenge_type: ChallengeType
    ) -> str | None:
        return self._hashed_answers.get(user_id, {}).get(challenge_type.value)

    def verify_password(self, username: str, password: str) -> str | None:
        uid = self._username_to_uid.get((username or "").strip().lower())
        if uid is None:
            return None
        expected = self._password_hashes.get(uid)
        if not expected:
            return None
        actual = hash_answer("PASSWORD", password)
        return uid if hmac.compare_digest(actual, expected) else None

    def get_account_context(self, user_id: str) -> dict | None:
        return self._account_contexts.get(user_id)


class MemoryOtpChannel(OtpChannel):
    """In-memory OTP issuer with TTL. Generates 6-digit numeric codes."""

    def __init__(self, ttl_seconds: int = 300):
        self._ttl = ttl_seconds
        self._lock = threading.Lock()
        # user_id -> (code, expires_at)
        self._latest: dict[str, tuple[str, datetime]] = {}

    def issue_otp(self, user_id: str, channel: str = "sms") -> tuple[str, int]:
        code = f"{secrets.randbelow(10**6):06d}"
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=self._ttl)
        with self._lock:
            self._latest[user_id] = (code, expires_at)
        _log.info(
            "otp_issued user_id=%s channel=%s ttl=%d",
            user_id, channel, self._ttl,
        )
        return code, self._ttl

    def get_last_otp_for_demo(
        self, user_id: str
    ) -> tuple[str, datetime] | None:
        with self._lock:
            return self._latest.get(user_id)
