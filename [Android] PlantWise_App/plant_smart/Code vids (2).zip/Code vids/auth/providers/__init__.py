"""Auth provider implementations."""
