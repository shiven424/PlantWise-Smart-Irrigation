"""Auth provider abstractions.

Two responsibilities, two interfaces:
- AuthSecretsProvider: returns SHA-256 hashed expected answers and verifies
  passwords for the login endpoint. Plaintext never leaves the provider.
- OtpChannel: issues one-time codes with a TTL and (in production) delivers
  them via SMS / email. The in-memory implementation also lets tests / the
  demo UI fetch the most recently-issued code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from schemas.enums import ChallengeType


class AuthSecretsProvider(ABC):
    """Server-side store of pre-hashed expected challenge answers + passwords."""

    @abstractmethod
    def get_expected_hash(
        self, user_id: str, challenge_type: ChallengeType
    ) -> str | None:
        """Return the SHA-256 hex of the expected normalised answer, or None."""

    @abstractmethod
    def verify_password(self, username: str, password: str) -> str | None:
        """Validate a login. Returns the canonical user_id on success, else None."""

    @abstractmethod
    def get_account_context(self, user_id: str) -> dict | None:
        """Return the seeded CRM/account context for a user (demo only)."""


class OtpChannel(ABC):
    """Issues and tracks one-time codes for ENHANCED auth."""

    @abstractmethod
    def issue_otp(self, user_id: str, channel: str = "sms") -> tuple[str, int]:
        """Generate, store and (in prod) send a fresh OTP.

        Returns (code, ttl_seconds). The code is plaintext for hashing by
        the caller, then discarded.
        """

    @abstractmethod
    def get_last_otp_for_demo(
        self, user_id: str
    ) -> tuple[str, datetime] | None:
        """Debug-only: fetch the most recent OTP for a user (memory impl only)."""
