"""Lazy singletons for the auth secrets provider and OTP channel."""

from __future__ import annotations

import logging
import threading

from auth.base import AuthSecretsProvider, OtpChannel
from config import settings

_log = logging.getLogger("contact_center")
_lock = threading.Lock()
_secrets: AuthSecretsProvider | None = None
_otp: OtpChannel | None = None


def _build_secrets_provider() -> AuthSecretsProvider:
    if settings.auth_secrets_provider == "memory":
        from auth.providers.memory import MemoryAuthSecretsProvider
        return MemoryAuthSecretsProvider(settings.auth_demo_accounts_path)
    raise ValueError(
        f"Unknown auth_secrets_provider={settings.auth_secrets_provider!r}. "
        "Valid options: 'memory'."
    )


def _build_otp_channel() -> OtpChannel:
    if settings.auth_secrets_provider == "memory":
        from auth.providers.memory import MemoryOtpChannel
        return MemoryOtpChannel(ttl_seconds=settings.auth_otp_ttl_seconds)
    raise ValueError(
        f"No OTP channel for provider={settings.auth_secrets_provider!r}."
    )


def secrets_provider() -> AuthSecretsProvider:
    global _secrets
    if _secrets is None:
        with _lock:
            if _secrets is None:
                _secrets = _build_secrets_provider()
                _log.info(
                    "auth_secrets_provider_initialised type=%s",
                    type(_secrets).__name__,
                )
    return _secrets


def otp_channel() -> OtpChannel:
    global _otp
    if _otp is None:
        with _lock:
            if _otp is None:
                _otp = _build_otp_channel()
                _log.info(
                    "auth_otp_channel_initialised type=%s",
                    type(_otp).__name__,
                )
    return _otp


def reset_for_tests() -> None:
    """Test-only: clear cached singletons so the next call rebuilds."""
    global _secrets, _otp
    with _lock:
        _secrets = None
        _otp = None
