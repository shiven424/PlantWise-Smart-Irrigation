"""Pure predicates over GraphState that span auth + classifier + supervisor.

These functions encode shared decisions (e.g. "is this turn a live auth
challenge answer?") in a single place so the classifier bypass and the
supervisor H1 guard cannot drift apart.
"""

from __future__ import annotations

from typing import Any

from schemas.enums import AuthLevel, AuthStatus


def is_auth_verification_turn(state: dict[str, Any]) -> bool:
    """Return True iff the current turn's user input is the answer to a
    live, unsatisfied authentication challenge.

    All four conditions must hold:
      1. ``scratch.pending_auth_challenge`` is a non-empty dict with a
         populated ``expected_hash`` — proves auth_agent actually issued
         a challenge (and not just a default placeholder).
      2. ``auth_status`` is ``PENDING`` — verification has not yet
         succeeded or definitively failed (LOCKED).
      3. ``auth_state.current_level < required_auth_level`` — we still
         owe a verification step.
      4. ``verification_input`` is not None — main.py only sets this on
         turns where a pending challenge existed at turn start, so this
         is the canonical "this turn carries a challenge answer" signal.

    Conversation start (``scratch={}``) fails (1) -> False.
    After successful verification (``auth_status=VERIFIED``) -> False.
    After lockout (``auth_status=LOCKED``) -> False.
    """
    scratch = state.get("scratch") or {}
    pending = scratch.get("pending_auth_challenge")
    if not (isinstance(pending, dict) and pending.get("expected_hash")):
        return False

    if state.get("auth_status") != AuthStatus.PENDING:
        return False

    auth_state = state.get("auth_state")
    current_level = getattr(auth_state, "current_level", AuthLevel.SESSION)
    required_level = state.get("required_auth_level", AuthLevel.SESSION)
    if current_level >= required_level:
        return False

    if state.get("verification_input") is None:
        return False

    return True
