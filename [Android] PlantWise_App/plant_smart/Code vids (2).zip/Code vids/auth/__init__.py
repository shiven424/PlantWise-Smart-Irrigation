"""Auth subsystem: secrets provider, OTP delivery, and JWT utilities."""
