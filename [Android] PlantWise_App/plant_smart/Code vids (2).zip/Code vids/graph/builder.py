import logging

from langgraph.graph import StateGraph, END
from graph.checkpointer import get_checkpointer
from graph.state import GraphState
from schemas.enums import EscalationReason
from schemas.primitives import EscalationContext
from graph.router import (
    route_after_supervisor,
    route_after_synthesizer,
    route_to_tool,
)
from agents.registry import AGENT_REGISTRY
from tools.registry import TOOL_REGISTRY
from tools.invoker import invoke_tool

_log = logging.getLogger("contact_center")


# -- Safe wrappers for parallel branches ---------------------------------------
# If one parallel branch (intent / entity_extraction / rag) throws, the
# other two would be wasted because LangGraph propagates the exception.
# These wrappers catch errors and return a neutral state delta so the
# supervisor can still make a decision with partial information.

def _safe_intent_node(state: GraphState) -> dict:
    """Run intent_agent with error isolation."""
    try:
        return AGENT_REGISTRY["intent_agent"].run(state)
    except Exception as exc:
        _log.error("[graph] intent_agent crashed: %s", exc, exc_info=True)
        return {
            "intent_stack": state.get("intent_stack", []),
            "active_intent_id": state.get("active_intent_id"),
            "slot_gap": state.get("slot_gap", []),
        }


def _safe_entity_node(state: GraphState) -> dict:
    """Run entity_extraction with error isolation."""
    try:
        return AGENT_REGISTRY["entity_extraction"].run(state)
    except Exception as exc:
        _log.error("[graph] entity_extraction crashed: %s", exc, exc_info=True)
        # Fix C4: Return empty contradictions list, NOT the existing
        # state value.  The `operator.add` reducer computes
        # old + new — returning old here would produce old + old,
        # doubling the list on every crash.
        return {
            "entity_memory": state.get("entity_memory", {}),
            "contradictions": [],
        }


def _safe_rag_node(state: GraphState) -> dict:
    """Run rag_agent with error isolation."""
    try:
        return AGENT_REGISTRY["rag_agent"].run(state)
    except Exception as exc:
        _log.error("[graph] rag_agent crashed: %s", exc, exc_info=True)
        return {
            "rag_answer": None,
            "rag_citations": [],
            "rag_confidence": 0.0,
            "rag_caveats": [],
            "rag_verification_passed": False,
            "rag_freshness_warning": False,
            "rag_error": "retrieval_unavailable",
        }


# M1: Safe wrappers for auth_agent and entity_validator.
# Unlike the parallel agents above, these run sequentially after
# supervisor routing.  Without wrappers, a crash in either kills the
# entire graph invocation — the supervisor can't recover gracefully.

def _safe_auth_node(state: GraphState) -> dict:
    """Run auth_agent with error isolation."""
    try:
        return AGENT_REGISTRY["auth_agent"].run(state)
    except Exception as exc:
        _log.error("[graph] auth_agent crashed: %s", exc, exc_info=True)
        return {
            "escalation_requested": True,
            "escalation_context": EscalationContext(
                reason=EscalationReason.SYSTEM_ERROR,
                triggered_by="graph.safe_auth_wrapper",
                client_message="Authentication service is temporarily unavailable. "
                               "Connecting you with a specialist.",
            ),
        }


def _safe_validator_node(state: GraphState) -> dict:
    """Run entity_validator with error isolation."""
    try:
        return AGENT_REGISTRY["entity_validator"].run(state)
    except Exception as exc:
        _log.error("[graph] entity_validator crashed: %s", exc, exc_info=True)
        return {
            "escalation_requested": True,
            "escalation_context": EscalationContext(
                reason=EscalationReason.SYSTEM_ERROR,
                triggered_by="graph.safe_validator_wrapper",
                client_message="Validation service is temporarily unavailable. "
                               "Connecting you with a specialist.",
            ),
        }


# Map agent name -> safe wrapper function for the dispatcher.
# Built lazily here so the dict is defined once at module level.
_DISPATCHER_RUNNERS: dict = {}


def _get_dispatcher_runners() -> dict:
    """Return the name->runner map, populating it on first call."""
    if not _DISPATCHER_RUNNERS:
        _DISPATCHER_RUNNERS.update({
            "intent_agent":      _safe_intent_node,
            "entity_extraction": _safe_entity_node,
            "rag_agent":         _safe_rag_node,
            "auth_agent":        _safe_auth_node,
            "entity_validator":  _safe_validator_node,
        })
    return _DISPATCHER_RUNNERS


def _parallel_dispatcher_node(state: GraphState) -> dict:
    """Run multiple agents sequentially as directed by scratch["supervisor_route"].

    LangGraph 1.1.x does not support Send() from conditional edges, so the
    supervisor's multi-agent routing goes through this node instead.  Each
    agent sees the state updates produced by earlier agents in the same batch.

    IMPORTANT: dict-typed fields with a registered reducer (e.g.
    ``entity_memory`` uses ``_merge_dict`` which honours the DELETE
    sentinel) MUST be merged via that reducer rather than ``dict.update``.
    Otherwise:
      * Sentinels like ``DELETE`` leak into downstream agents (which try
        to call ``.slot_name`` on them and crash), and
      * The sentinels propagate to the checkpointer, which msgpack
        cannot serialize and the whole graph invocation fails.
    """
    from schemas.graph_state import _merge_dict

    # Fields whose reducer is _merge_dict (honours DELETE / orphan tracking).
    # Keep this list in sync with schemas.graph_state.GraphState annotations.
    REDUCER_DICT_FIELDS = {"entity_memory", "validated_entities"}

    scratch = state.get("scratch") or {}
    route = scratch.get("supervisor_route", [])
    if isinstance(route, str):
        route = [route]

    runners = _get_dispatcher_runners()
    current_state = dict(state)
    merged: dict = {}

    for agent_name in route:
        runner = runners.get(agent_name)
        if runner is None:
            _log.warning("[graph] dispatcher: unknown agent %s, skipping", agent_name)
            continue
        try:
            result = runner(current_state)
            for key, new_val in result.items():
                if key in REDUCER_DICT_FIELDS and isinstance(new_val, dict):
                    base = merged.get(key, current_state.get(key) or {})
                    combined = _merge_dict(base, new_val)
                    merged[key] = combined
                    current_state[key] = combined
                else:
                    merged[key] = new_val
                    current_state[key] = new_val
        except Exception as exc:
            _log.error(
                "[graph] dispatcher: agent %s crashed: %s", agent_name, exc, exc_info=True
            )

    return merged


def _tool_router_node(state: GraphState) -> dict:
    """
    Pass-through interrupt point.
    compile(interrupt_before=["tool_router"]) pauses the graph HERE.
    Flow:
    1. Supervisor emits EXECUTE_TRANSACTION
    2. Response Synthesizer renders a processing message
    3. route_after_synthesizer() routes here
    4. Graph pauses before this node
    5. main.py resumes the graph with the same thread_id
    6. route_to_tool() selects the correct tool
    """
    return {}


def _tool_escalate_node(state: GraphState) -> dict:
    """
    Sets escalation_requested when route_to_tool() returns "escalate"
    (no tool exists for the active intent). This prevents an infinite
    synthesizer -> tool_router -> synthesizer cycle by signalling
    route_after_synthesizer() to route to END.
    """
    return {"escalation_requested": True}


def build_graph() -> StateGraph:
    # -- Fail-fast: ensure all required agents loaded -------------------------
    _REQUIRED = [
        "message_classifier", "intent_agent", "entity_extraction", "rag_agent",
        "auth_agent", "entity_validator", "supervisor", "response_synthesizer",
    ]
    missing = [k for k in _REQUIRED if k not in AGENT_REGISTRY]
    if missing:
        raise RuntimeError(
            f"Cannot build graph — missing required agents: {missing}. "
            f"Check agent modules for import errors."
        )

    builder = StateGraph(GraphState)

    # -- Utility nodes --------------------------------------------------------
    builder.add_node("tool_router",      _tool_router_node)
    builder.add_node("tool_escalate",    _tool_escalate_node)
    builder.add_node("parallel_dispatcher",   _parallel_dispatcher_node)

    # -- Agent nodes ----------------------------------------------------------
    builder.add_node("message_classifier",  AGENT_REGISTRY["message_classifier"].run)
    builder.add_node("supervisor",          AGENT_REGISTRY["supervisor"].run)
    builder.add_node("intent_agent",        _safe_intent_node)
    builder.add_node("entity_extraction",   _safe_entity_node)
    builder.add_node("rag_agent",           _safe_rag_node)
    builder.add_node("auth_agent",          _safe_auth_node)
    builder.add_node("entity_validator",    _safe_validator_node)
    builder.add_node("response_synthesizer", AGENT_REGISTRY["response_synthesizer"].run)

    # -- Tool nodes -----------------------------------------------------------
    # Each tool node is a closure that calls invoke_tool(name, state).
    # invoke_tool() centralizes gate enforcement, idempotency-key injection,
    # completed-intent bookkeeping, and the [tool_invoke] trace label so the
    # graph layer never has to know about BaseTool internals.
    for name in TOOL_REGISTRY:
        builder.add_node(
            f"tool_{name}",
            (lambda state, _n=name: invoke_tool(_n, state)),
        )

    # -- Entry point ----------------------------------------------------------
    builder.set_entry_point("message_classifier")

    # -- Edge 1: Classifier -> Supervisor (always) ----------------------------
    # The supervisor handles ALL domains: ESCALATE (hard rule H1),
    # CHITCHAT (policy CHITCHAT_RESPOND), INFORMATIONAL, TRANSACTIONAL.
    builder.add_edge("message_classifier", "supervisor")

    # -- Edge 2: Supervisor -> conditional routing ----------------------------
    # route_after_supervisor reads scratch["supervisor_route"]:
    #   - Single agent name      -> routes directly to that agent node
    #   - List of agent names    -> routes to parallel_dispatcher (LangGraph
    #                               1.1.x does not support Send() from
    #                               conditional edges, so fan-out is handled
    #                               by the dispatcher node instead)
    #   - "response_synthesizer" -> routes to response_synthesizer
    builder.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "intent_agent":         "intent_agent",
            "entity_extraction":    "entity_extraction",
            "rag_agent":            "rag_agent",
            "auth_agent":           "auth_agent",
            "entity_validator":     "entity_validator",
            "parallel_dispatcher":  "parallel_dispatcher",
            "response_synthesizer": "response_synthesizer",
        },
    )

    # -- Edge 3: All specialist agents -> Supervisor (loop back) --------------
    # After each specialist agent (or the dispatcher batch) runs, control
    # returns to the supervisor for the next iteration of the loop.
    builder.add_edge("intent_agent",         "supervisor")
    builder.add_edge("entity_extraction",    "supervisor")
    builder.add_edge("rag_agent",            "supervisor")
    builder.add_edge("auth_agent",           "supervisor")
    builder.add_edge("entity_validator",     "supervisor")
    builder.add_edge("parallel_dispatcher",  "supervisor")

    # -- Edge 4: Tool routing (after HITL resume) -----------------------------
    tool_map = {name: f"tool_{name}" for name in TOOL_REGISTRY}
    tool_map["escalate"] = "tool_escalate"  # sets escalation_requested
    builder.add_conditional_edges(
        "tool_router",
        route_to_tool,
        tool_map,
    )

    # -- Edge 4b: Escalation node -> response_synthesizer ---------------------
    builder.add_edge("tool_escalate", "response_synthesizer")

    # -- Edge 5: All tools -> response_synthesizer -----------------------
    for name in TOOL_REGISTRY:
        builder.add_edge(f"tool_{name}", "response_synthesizer")

    # -- Edge 6: Terminal -----------------------------------------------------
    builder.add_conditional_edges(
        "response_synthesizer",
        route_after_synthesizer,
        {
            "end":             END,
            "tool_router": "tool_router",
        }
    )

    return builder


def compile_graph(checkpointer=None):
    """
    Compiles the graph with checkpointer for multi-turn memory.
    interrupt_before=["tool_router"] pauses execution at the HITL point.
    Resume by calling graph.invoke() again with the same thread_id.
    """
    builder = build_graph()
    return builder.compile(
        checkpointer=checkpointer or get_checkpointer(),
        interrupt_before=["tool_router"],
    )
