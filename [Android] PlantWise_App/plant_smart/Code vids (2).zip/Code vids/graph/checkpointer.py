"""
Checkpointer factory.

Provides a single function to create the appropriate checkpointer for the
graph based on the current environment. Centralises the import so that
``builder.py`` stays focused on graph construction.

In development / testing: MemorySaver (in-memory, no persistence).
In production: swap to a database-backed checkpointer (e.g. SqliteSaver,
PostgresSaver) by changing the factory function.
"""

from __future__ import annotations

import inspect
import threading
from enum import Enum
from typing import Iterable

from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
from pydantic import BaseModel

from schemas import agent_io as _agent_io
from schemas import enums as _enums
from schemas import graph_state as _graph_state
from schemas import primitives as _primitives


def _collect_classes(*modules) -> tuple[tuple[str, str], ...]:
    """Collect (module, class_name) tuples for every Pydantic model and Enum
    declared in the given modules.

    LangGraph's ``JsonPlusSerializer`` allowlist expects entries of the form
    ``(dotted_module_path, class_name)``; passing the parent package alone
    causes every class to be blocked at deserialization.
    """
    seen: set[tuple[str, str]] = set()
    for module in modules:
        for name, obj in inspect.getmembers(module, inspect.isclass):
            # Only register classes actually defined in this module
            if obj.__module__ != module.__name__:
                continue
            if issubclass(obj, (BaseModel, Enum)):
                seen.add((obj.__module__, obj.__name__))
    return tuple(sorted(seen))


# Project-owned classes that travel through the checkpointer.  Each entry is
# ``(dotted_module_path, class_name)`` as required by JsonPlusSerializer.
_ALLOWED_MSGPACK_MODULES: tuple[tuple[str, str], ...] = _collect_classes(
    _primitives,
    _enums,
    _agent_io,
    _graph_state,
)

_postgres_conn = None
_postgres_lock = threading.Lock()


def _build_serializer() -> JsonPlusSerializer:
    """Construct a JsonPlusSerializer that trusts our schema modules."""
    return JsonPlusSerializer(allowed_msgpack_modules=_ALLOWED_MSGPACK_MODULES)


def get_checkpointer(backend: str | None = None, postgres_url: str | None = None):
    """
    Return a LangGraph checkpointer instance.

    Args:
        backend: ``"memory"`` or ``"postgres"``.  When *None* the value is
                 read from ``settings.checkpoint_backend``.
        postgres_url: PostgreSQL DSN.  When *None* the value is read from
                      ``settings.checkpoint_postgres_url``.

    ``MemorySaver`` is returned when ``backend == "memory"`` (default for
    development / test).

    ``PostgresSaver`` (from ``langgraph-checkpoint-postgres``) is returned
    when ``backend == "postgres"``.  The graph is invoked via
    ``asyncio.to_thread`` in *main.py*, so the *synchronous* ``PostgresSaver``
    is the correct choice here.
    """
    from config import settings  # local import avoids circular dependency at module load

    _backend = backend or settings.checkpoint_backend
    _url = postgres_url or settings.checkpoint_postgres_url

    if _backend == "postgres":
        if not _url:
            raise RuntimeError(
                "checkpoint_backend=postgres requires CHECKPOINT_POSTGRES_URL "
                "to be set in the environment."
            )
        try:
            from psycopg import Connection
            from psycopg.rows import dict_row
            from langgraph.checkpoint.postgres import PostgresSaver
        except ImportError as exc:
            raise ImportError(
                "langgraph-checkpoint-postgres and psycopg are required for "
                "the postgres checkpoint backend. "
                "Install with: pip install langgraph-checkpoint-postgres psycopg"
            ) from exc

        global _postgres_conn
        with _postgres_lock:
            if _postgres_conn is None or getattr(_postgres_conn, "closed", False):
                _postgres_conn = Connection.connect(
                    _url,
                    autocommit=True,
                    prepare_threshold=0,
                    row_factory=dict_row,
                )

        saver = PostgresSaver(_postgres_conn, serde=_build_serializer())
        saver.setup()  # idempotent DDL; safe to call on every startup
        return saver

    # Default: in-memory (no persistence across restarts)
    return MemorySaver(serde=_build_serializer())


def close_checkpointer() -> None:
    """Close the shared postgres connection if it is open."""
    global _postgres_conn
    with _postgres_lock:
        if _postgres_conn is not None and not getattr(_postgres_conn, "closed", False):
            _postgres_conn.close()
        _postgres_conn = None

