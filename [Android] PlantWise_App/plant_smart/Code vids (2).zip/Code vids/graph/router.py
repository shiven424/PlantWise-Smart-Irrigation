from graph.state import GraphState, get_active_intent
from schemas.enums import ActionType, MessageDomain, ToolExecutionStatus
from observability.logger import log


def _session_id(state: GraphState) -> str:
    session = state.get("session")
    if session is None:
        return "unknown"
    # Support both Pydantic model (attribute access) and deserialized dict
    return str(
        getattr(session, "session_id", None)
        or (session.get("session_id") if isinstance(session, dict) else None)
        or "unknown"
    )


# -- Supervisor routing (Phase 3) ---------------------------------------------

# Agent names the supervisor is allowed to dispatch to.
# Must match exactly the node names registered in graph/builder.py.
_SUPERVISOR_AGENT_NODES = frozenset({
    "intent_agent",
    "entity_extraction",
    "rag_agent",
    "auth_agent",
    "entity_validator",
})


def route_after_supervisor(state: GraphState) -> str:
    """Read the supervisor's routing decision from scratch.

    The supervisor agent writes one of:
      - ``"synthesizer"``        -> route to response_synthesizer
      - A single agent name (str) -> route to that agent
      - A list of agent names     -> route to parallel_dispatcher node

    LangGraph 1.1.x does not support Send() from conditional edges, so
    multi-agent fan-out goes through the parallel_dispatcher node instead.

    Fail-safe: if scratch has no route, default to ``"response_synthesizer"``.
    """
    session_id = _session_id(state)
    scratch = state.get("scratch") or {}
    route = scratch.get("supervisor_route", "synthesizer")

    # -- Multi-agent dispatch via parallel_dispatcher -------------------------
    if isinstance(route, list):
        safe = [r for r in route if r in _SUPERVISOR_AGENT_NODES]
        if not safe:
            log.warning(
                "router_supervisor_empty_parallel",
                raw=route,
                session_id=session_id,
            )
            return "response_synthesizer"
        log.info(
            "router_supervisor",
            result="parallel_dispatcher",
            agents=safe,
            session_id=session_id,
        )
        return "parallel_dispatcher"

    # -- Single-agent routing -------------------------------------------------
    if route == "synthesizer":
        route = "response_synthesizer"

    if route not in _SUPERVISOR_AGENT_NODES and route != "response_synthesizer":
        log.warning(
            "router_supervisor_invalid_route",
            raw=route,
            session_id=session_id,
        )
        return "response_synthesizer"

    log.info(
        "router_supervisor",
        result=route,
        session_id=session_id,
    )
    return route


# -- DEPRECATED: Pre-supervisor routing functions -----------------------------
# These functions are no longer used in the live graph (the supervisor
# handles all post-classifier routing now).  Kept for backward
# compatibility with existing tests and verification scripts.


def route_after_classifier(state: GraphState) -> str:
    session_id = _session_id(state)

    if state.get("classifier_escalation_flag"):
        log.info("router_classifier", result="escalate_flag", session_id=session_id)
        return "escalate"

    domain = state.get("message_domain")

    if domain is None:
        log.warning(
            "router_classifier_no_domain",
            session_id=session_id,
            message="message_domain is None — defaulting to parallel_dispatch for best-effort handling",
        )
        return "parallel_dispatch"

    if domain == MessageDomain.ESCALATE:
        log.info("router_classifier", result="escalate_domain", session_id=session_id)
        return "escalate"

    if domain == MessageDomain.CHITCHAT:
        log.info("router_classifier", result="chitchat", session_id=session_id)
        return "chitchat"

    log.info("router_classifier", result="parallel_dispatch", domain=str(domain), session_id=session_id)
    return "parallel_dispatch"  # INFORMATIONAL or TRANSACTIONAL


def route_after_action_planner(state: GraphState) -> str:  # DEPRECATED
    plan = state.get("current_action_plan")
    session_id = _session_id(state)

    if not plan:
        log.error(
            "router_action_planner_no_plan",
            session_id=session_id,
            message="Action planner returned no plan - escalating as safe fallback",
        )
        return "escalate"

    action_map = {
        ActionType.ANSWER:              "answer",
        ActionType.COLLECT_SLOT:        "collect_slot",
        ActionType.RETRY_SLOT:          "collect_slot",
        ActionType.CORRECTION_ACK:      "collect_slot",
        ActionType.CLARIFY:             "collect_slot",
        ActionType.INITIATE_AUTH:       "initiate_auth",
        ActionType.AUTH_CHALLENGE:      "initiate_auth",
        ActionType.PROCESS_AUTH:        "initiate_auth",
        ActionType.VALIDATE_ENTITIES:   "validate",
        ActionType.PRESENT_HITL:        "present_hitl",
        ActionType.HITL_CORRECTION:     "validate",
        ActionType.HITL_APPROVED:       "execute",
        ActionType.EXECUTE_TRANSACTION: "execute",
        ActionType.PUSH_INTENT:         "collect_slot",
        ActionType.POP_INTENT:          "collect_slot",
        ActionType.ESCALATE:            "escalate",
        ActionType.HANDLE_ERROR:        "escalate",
        ActionType.CHITCHAT_RESPOND:    "chitchat",
        ActionType.END_SESSION:         "answer",
    }
    result = action_map.get(plan.action_type)
    if result is None:
        log.error(
            "router_action_planner_unmapped",
            action_type=str(plan.action_type),
            session_id=session_id,
            message=f"ActionType {plan.action_type} has no mapping - escalating",
        )
        return "escalate"

    log.info(
        "router_action_planner",
        action_type=str(plan.action_type),
        result=result,
        hard_rule=plan.hard_rule_fired,
        session_id=session_id,
    )
    return result


def route_after_synthesizer(state: GraphState) -> str:
    plan = state.get("current_action_plan")

    if not plan:
        return "end"

    # If escalation has been requested (e.g. tool_router found no
    # matching tool and routed to "escalate"), go to END to avoid
    # an infinite synthesizer -> tool_router -> synthesizer cycle.
    if state.get("escalation_requested"):
        return "end"

    if plan.action_type in (
        ActionType.HITL_APPROVED,
        ActionType.EXECUTE_TRANSACTION,
    ):
        # Tool already ran and produced a result — go to end
        if state.get("transaction_result") is not None:
            return "end"

        # Check tool_exec status — skip if already completed/failed
        tool_exec = state.get("tool_exec")
        if tool_exec:
            # Fix H3: Check in_flight flag first.  If a tool set
            # in_flight=True but crashed before reaching a terminal
            # status, we must NOT re-route to tool_router (which
            # would execute the transaction a second time).  Route to
            # end instead — the first attempt may have already made
            # an irreversible API call.
            in_flight = getattr(tool_exec, "in_flight", False)
            if in_flight:
                log.warning(
                    "router_tool_inflight_guard",
                    message="tool_exec.in_flight is True — tool may have "
                            "partially executed; ending to prevent double execution",
                )
                return "end"

            status = getattr(tool_exec, "status", None)
            if status in (
                ToolExecutionStatus.SUCCEEDED,
                ToolExecutionStatus.FAILED,
                ToolExecutionStatus.CANCELLED,
            ):
                return "end"
            # Fix H6: Guard against infinite tool loop.
            # If tool_exec has a non-terminal but non-None status
            # (e.g. RUNNING, PENDING), the tool already ran once
            # but didn't reach a terminal state.  Escalate instead
            # of looping indefinitely.
            if status is not None:
                log.warning(
                    "router_tool_loop_guard",
                    status=str(status),
                    message="Tool ran but did not reach terminal state; ending",
                )
                return "end"

        return "tool_router"

    return "end"


def route_to_tool(state: GraphState) -> str:
    session_id = _session_id(state)
    intent = get_active_intent(state)

    if not intent:
        log.error(
            "router_tool_no_intent",
            session_id=session_id,
            message="No active intent when routing to tool - escalating",
        )
        return "escalate"
    sub_intent_map = {
        # Retirement — transactional
        "ACCOUNT_BALANCE_INQUIRY": "balance_inquiry",
        "PLAN_LOAN_REQUEST":       "plan_loan",
        "PLAN_LOAN_ELIGIBILITY":   "plan_loan",
        "PLAN_LOAN_STATUS":        "plan_loan",
        "IRA_ROLLOVER":            "escalate",
        "WITHDRAWAL_REQUEST":      "escalate",
        "HARDSHIP_WITHDRAWAL":     "escalate",
        "RMD_CALCULATION":         "rmd_calculator",
        "RMD_SETUP":               "rmd_calculator",
        "BENEFICIARY_UPDATE":      "escalate",
        "BENEFICIARY_INQUIRY":     "escalate",
        "RMD_INQUIRY":             "rmd_calculator",
        "CONTRIBUTION_UPDATE":     "escalate",
        "ROTH_CONVERSION":         "escalate",
        # Retirement — informational (no tool, but map explicitly)
        "CONTRIBUTION_INQUIRY":    "escalate",
        "SEPP_INQUIRY":            "escalate",
        "DISTRIBUTION_OPTIONS":    "escalate",
        # Investment
        "PORTFOLIO_REVIEW":        "escalate",
        "REBALANCING_REQUEST":     "escalate",
        "FUND_INQUIRY":            "escalate",
        "FUND_SWITCH":             "escalate",
        "TRADE_REQUEST":           "escalate",
        "ALLOCATION_CHANGE":       "escalate",
        "RISK_PROFILE_INQUIRY":    "escalate",
        "RISK_PROFILE_UPDATE":     "escalate",
        "DIVIDEND_REINVEST_UPDATE": "escalate",
        # Estate & Trust
        "TRUST_INQUIRY":           "escalate",
        "BENEFICIARY_DESIGNATION": "escalate",
        "TRUST_DISTRIBUTION":      "escalate",
        "TOD_INQUIRY":             "escalate",
        "TOD_UPDATE":              "escalate",
        # Tax
        "TAX_DOCUMENT_REQUEST":    "escalate",
        "WITHHOLDING_INQUIRY":     "escalate",
        "WITHHOLDING_UPDATE":      "escalate",
        "COST_BASIS_INQUIRY":      "escalate",
        # Account Admin
        "ADDRESS_UPDATE":          "escalate",
        "PHONE_UPDATE":            "escalate",
        "EMAIL_UPDATE":            "escalate",
        "STATEMENT_REQUEST":       "escalate",
        "TRANSACTION_HISTORY_INQUIRY": "transaction_history",
        "LINKED_BANK_UPDATE":      "escalate",
    }
    result = sub_intent_map.get(intent.sub_intent)

    if result is None:
        log.error(
            "router_tool_unmapped",
            sub_intent=intent.sub_intent,
            session_id=session_id,
            message=f"sub_intent {intent.sub_intent} has no tool mapping - escalating",
        )
        return "escalate"

    log.info(
        "router_tool",
        sub_intent=intent.sub_intent,
        tool=result,
        session_id=session_id,
    )
    return result
