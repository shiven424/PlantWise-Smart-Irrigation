from __future__ import annotations

"""
Graph state helpers and re-exports.

This module sits between schemas.graph_state (the TypedDict definition)
and all graph-layer code (builder, router, nodes).  It provides:

1. Re-export of GraphState so other modules import from one place.
2. get_active_intent()  — resolve the current top-of-stack intent.
3. compute_slot_gap()   — diff required_slots vs filled entities.
4. initial_state()      — factory that produces a fully-initialised state
                           dict for a new conversation.
"""

from datetime import datetime, timezone

from schemas.enums import AuthLevel, AuthStatus
from schemas.graph_state import GraphState
from schemas.primitives import (
    AuthState,
    HITLState,
    IntentRecord,
    LoopCounters,
    SessionContext,
    ToolExecutionState,
)

_PLAN_LOAN_SUB_INTENTS: frozenset[str] = frozenset({
    "PLAN_LOAN_REQUEST",
    "PLAN_LOAN_ELIGIBILITY",
    "PLAN_LOAN_STATUS",
})

__all__ = [
    "GraphState",
    "get_active_intent",
    "compute_slot_gap",
    "initial_state",
]


# -- Helpers ------------------------------------------------------------------


def get_active_intent(state: GraphState) -> IntentRecord | None:
    """
    Return the active intent from the intent stack.

    The intent stack is ordered newest-first: index 0 is the active head,
    index 1+ are paused intents from earlier PIVOTs.  This matches the
    IntentAgentResponse.primary_must_be_stack_head validator.

    Resolution order:
    1. Find the intent whose intent_id == active_intent_id (most precise).
    2. Fall back to stack[0] — the head / newest intent.
    3. Return None if the stack is empty.
    """
    active_id = state.get("active_intent_id")
    stack: list[IntentRecord] = state.get("intent_stack", [])

    if active_id:
        for intent in stack:          # search forward — head is index 0
            if intent.intent_id == active_id:
                return intent

    # Fallback: head of stack (newest / active intent)
    return stack[0] if stack else None


def _maybe_soft_fill_account_type_inquiries(
    active_sub_intent: str,
    state: GraphState,
    filled: set[str],
) -> None:
    """Single-account certainty + ALL / explicit multi-type asks for inquiries."""
    if active_sub_intent not in {"ACCOUNT_BALANCE_INQUIRY", "TRANSACTION_HISTORY_INQUIRY"}:
        return
    if "account_type" in filled:
        return
    accounts_map = (state.get("account_context") or {}).get("accounts") or {}
    if len(accounts_map) <= 1:
        filled.add("account_type")
        return
    from tools._account_resolution import (
        account_detection_scan_text,
        detect_requested_account_types,
        recent_user_lines_concat,
    )

    msg = state.get("last_user_message") or ""
    scan = account_detection_scan_text(recent_user_lines_concat(state), msg)
    hist_nouns = active_sub_intent == "TRANSACTION_HISTORY_INQUIRY"
    resolved = detect_requested_account_types(scan, accounts_map, include_history_nouns=hist_nouns)
    if resolved is not None:
        filled.add("account_type")


def compute_slot_gap(state: GraphState) -> list[str]:
    """
    Compute which required slots are still unfilled.

    Required slots are sourced from the active intent's required_slots list
    (the canonical source of truth), NOT from state["required_slots"] which
    is a cached copy and may be stale.

    A slot is considered filled if it appears as the slot_name of:
     - any validated entity (post-validation), OR
     - any entity in entity_memory (pre-validation).

    NOTE: ``is_confirmed`` is intentionally NOT checked here.  Entity
    extraction always creates entities with ``is_confirmed=False``.
    Filtering on ``is_confirmed`` would cause infinite COLLECT_SLOT
    loops because freshly extracted slots would never appear filled.
    Quality gating is the entity_validator's responsibility — if a
    low-quality entity is rejected, the planner routes back through
    COLLECT_SLOT for that specific slot via ``_first_correctable_slot``.

    Returns a list preserving the intent's slot ordering (first missing slot
    first, matching the H4 one-question-per-turn rule in policy.py).
    """
    active = get_active_intent(state)
    if not active:
        return []

    filled: set[str] = set()

    # Fix M13: Use dual-access pattern (getattr + dict.get) to handle
    # both Pydantic model and dict-typed entities.  MemorySaver keeps
    # Pydantic objects, but production checkpointers (Sqlite/Postgres)
    # may deserialize entities as plain dicts.
    for entity in state.get("validated_entities", {}).values():
        slot = getattr(entity, "slot_name", None) or (
            entity.get("slot_name") if isinstance(entity, dict) else None
        )
        if slot:
            filled.add(slot)

    for entity in state.get("entity_memory", {}).values():
        slot = getattr(entity, "slot_name", None) or (
            entity.get("slot_name") if isinstance(entity, dict) else None
        )
        if slot:
            filled.add(slot)

    _maybe_soft_fill_account_type_inquiries(active.sub_intent, state, filled)

    # ---------------------------------------------------------------- RMD ----
    # RMD_CALCULATION / RMD_SETUP both require ``date_of_birth`` and
    # ``plan_type``.  Both are usually already known after STRONG auth:
    #
    #   * date_of_birth → ``account_context.owner_dob`` is sourced from
    #     the recordkeeper at login.  Re-asking is bad UX and a security
    #     smell (re-eliciting PII we already vault-tokenised).
    #
    #   * plan_type → unambiguous when the participant has exactly one
    #     account on file, or when the current message names a known
    #     plan-type token (``"401k"``, ``"ira"``, ``"roth"`` ...).
    #
    # We treat these slots as auto-filled in those cases; the tool's
    # internal resolvers (``_get_owner_age`` and ``_get_account_type``)
    # already pull values from ``account_context``.
    if active.sub_intent in {"RMD_CALCULATION", "RMD_SETUP"}:
        ctx = state.get("account_context") or {}
        if "date_of_birth" not in filled:
            dob = ctx.get("owner_dob") or ctx.get("date_of_birth")
            if dob and str(dob).strip():
                filled.add("date_of_birth")
            elif ctx.get("owner_age_years") is not None:
                # Age alone is sufficient — _get_owner_age accepts it.
                filled.add("date_of_birth")
        if "plan_type" not in filled:
            accounts_map = ctx.get("accounts") or {}
            if len(accounts_map) <= 1:
                filled.add("plan_type")
            else:
                import re as _re_rmd
                msg = (state.get("last_user_message") or "").lower()
                _plan_patterns = (
                    r"401\s*\(\s*k\s*\)", r"\b401\s*[-_]?\s*k\b",
                    r"403\s*\(\s*b\s*\)", r"\b403\s*[-_]?\s*b\b",
                    r"\btraditional\s+ira\b", r"\broth\s+ira\b",
                    r"\broth\s*401\s*[-_]?\s*k\b",
                    r"\bira\b", r"\broth\b", r"\bbrokerage\b",
                    r"\bsep\b", r"\bsimple\b",
                )
                if msg and any(_re_rmd.search(p, msg) for p in _plan_patterns):
                    filled.add("plan_type")

    # ---------------------------------------------------------- Plan loan ----
    # Mirror RMD + balance: auto-fill plan_type when unambiguous — either at
    # most one loan-eligible ERISA/DCP account exists, no structured map (flat
    # context fallback in plan_loan tool), or the user already named an
    # account-type token in free text (multi-account disambiguation).
    if active.sub_intent in _PLAN_LOAN_SUB_INTENTS and "plan_type" not in filled:
        from tools.plan_loan.v1.agent import _NON_LOAN_ELIGIBLE_TYPES

        pl_ctx = state.get("account_context") or {}
        pl_accounts = pl_ctx.get("accounts") or {}
        loan_eligible_keys = [
            k
            for k, v in pl_accounts.items()
            if k not in _NON_LOAN_ELIGIBLE_TYPES
            and isinstance(v, dict)
            and v.get("plan_allows_loans", True)
        ]
        if len(loan_eligible_keys) <= 1:
            filled.add("plan_type")
        else:
            import re as _re_plan_loan

            msg_pl = (state.get("last_user_message") or "").lower()
            _loan_plan_patterns = (
                r"401\s*\(\s*k\s*\)", r"\b401\s*[-_]?\s*k\b",
                r"403\s*\(\s*b\s*\)", r"\b403\s*[-_]?\s*b\b",
                r"457\s*\(\s*b\s*\)", r"\b457\s*[-_]?\s*b\b",
                r"\btraditional\s+ira\b", r"\broth\s+ira\b",
                r"\broth\s*401\s*[-_]?\s*k\b",
                r"\bira\b", r"\broth\b", r"\bbrokerage\b",
                r"\bsep\b", r"\bsimple\b",
            )
            if msg_pl and any(_re_plan_loan.search(p, msg_pl) for p in _loan_plan_patterns):
                filled.add("plan_type")

    # Preserve intent ordering — policy uses slot_gap[0] only (H4)
    return [s for s in active.required_slots if s not in filled]


def initial_state(session: SessionContext) -> GraphState:
    """
    Create a fully-initialised GraphState for a new conversation.

    Every field gets a sensible default so the graph can start
    without missing-key errors on first node access.
    """
    now = datetime.now(timezone.utc).isoformat()

    return {
        # -- Session / thread
        "session": session,
        "current_turn": 0,
        "conversation_id": None,
        "created_at": now,
        "updated_at": now,

        # -- Conversation memory
        "message_history": [],
        "last_user_message": None,

        # -- Message classification (flat)
        "message_domain": None,
        "classifier_confidence": 0.0,
        "classifier_escalation_flag": False,
        "classifier_escalation_reason": None,

        # -- Intent
        "intent_stack": [],
        "active_intent_id": None,
        "completed_intent_ids": [],

        # -- Entities
        "entity_memory": {},
        "validated_entities": {},
        "contradictions": [],

        # -- Slot filling
        "required_slots": [],
        "slot_gap": [],
        "last_requested_slot": None,
        "retry_count": 0,
        "correction_count": 0,
        "counters": LoopCounters(),

        # -- Auth
        "auth_state": AuthState(),
        "auth_status": AuthStatus.PENDING,
        "required_auth_level": AuthLevel.SESSION,
        "verification_input": None,
        "fraud_risk_score": 0.0,
        "device_fingerprint": None,

        # -- Validation / Compliance
        "validation_status": None,
        "violations": [],
        "hitl_disclosures": [],

        # -- RAG (flat)
        "rag_answer": None,
        "rag_citations": [],
        "rag_confidence": None,    # None = RAG not yet run this turn
        "rag_caveats": [],
        "rag_verification_passed": False,
        "rag_freshness_warning": False,
        "rag_error": None,

        # -- Action plan
        "current_action_plan": None,
        "policy_path": None,
        "planner_reasoning": None,

        # -- Escalation
        "escalation_requested": False,
        "escalation_context": None,

        # -- HITL
        "hitl": HITLState(),

        # -- Tool execution
        "tool_exec": ToolExecutionState(),

        # -- Account / session context (populated at turn start by main.py)
        # account_context: static account data fetched from CRM/core banking API.
        # auth_token:       vault dereference token for the authenticated session.
        # Neither contains raw PII — they are API-level references only.
        "account_context": {},
        "auth_token": "",

        # -- User profile (loaded once at session start from profile store)
        "user_profile": {},

        # -- Transaction result (written by tools after execution)
        "transaction_result": None,

        # -- Scratchpad
        "scratch": {},

        # -- Output
        "last_synthesized_response": None,
    }
