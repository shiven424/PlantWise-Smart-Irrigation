"""PostgreSQL-backed conversation store using psycopg3 (async)."""

from __future__ import annotations

from datetime import datetime, timezone

from observability.logger import log as _log

from conversation_store.base import BaseConversationStore
from conversation_store.models import ConversationRecord, ConversationStatus

# Schema DDL applied at startup (idempotent).
_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id     TEXT        PRIMARY KEY,
    user_id             TEXT        NOT NULL,
    status              TEXT        NOT NULL DEFAULT 'ACTIVE',
    title               TEXT,
    last_user_message_preview TEXT,
    current_turn        INTEGER     NOT NULL DEFAULT 0,
    channel             TEXT        NOT NULL DEFAULT 'web',
    session_token_hash  TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at            TIMESTAMPTZ,
    deleted_at          TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_conversations_user_active
    ON conversations (user_id, last_active_at DESC)
    WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_conversations_user_all
    ON conversations (user_id, last_active_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversations_status
    ON conversations (status, last_active_at DESC);
CREATE TABLE IF NOT EXISTS conversation_deletion_audit (
    id              BIGSERIAL   PRIMARY KEY,
    conversation_id TEXT        NOT NULL,
    user_id         TEXT        NOT NULL,
    delete_mode     TEXT        NOT NULL,
    deleted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_deletion_audit_conversation
    ON conversation_deletion_audit (conversation_id);
CREATE INDEX IF NOT EXISTS idx_deletion_audit_user
    ON conversation_deletion_audit (user_id, deleted_at DESC);
"""


def _row_to_record(row: dict) -> ConversationRecord:
    return ConversationRecord(
        conversation_id=row["conversation_id"],
        user_id=row["user_id"],
        status=ConversationStatus(row["status"]),
        title=row.get("title"),
        last_user_message_preview=row.get("last_user_message_preview"),
        current_turn=row.get("current_turn") or 0,
        channel=row.get("channel") or "web",
        session_token_hash=row.get("session_token_hash"),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        last_active_at=row["last_active_at"],
        ended_at=row.get("ended_at"),
        deleted_at=row.get("deleted_at"),
    )


class PostgresConversationStore(BaseConversationStore):
    """Conversation store backed by a PostgreSQL database.

    Uses psycopg3 async pool for non-blocking I/O from the FastAPI
    event loop.
    """

    def __init__(self, dsn: str) -> None:
        self._dsn = dsn
        self._pool = None

    async def setup(self) -> None:
        """Create tables and open the connection pool."""
        try:
            from psycopg_pool import AsyncConnectionPool  # type: ignore[import]
        except ImportError as exc:
            raise ImportError(
                "psycopg-pool is required for PostgresConversationStore. "
                "Install it with: pip install 'psycopg-pool'"
            ) from exc

        self._pool = AsyncConnectionPool(
            self._dsn,
            min_size=1,
            max_size=10,
            open=False,
        )
        await self._pool.open(wait=True)

        # Apply schema (idempotent)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                # Execute each statement individually to avoid psycopg
                # multi-statement parsing issues.
                for stmt in _SCHEMA_SQL.strip().split(";"):
                    stmt = stmt.strip()
                    if stmt:
                        await cur.execute(stmt)
            await conn.commit()
        _log.info("PostgresConversationStore initialised")

    async def create(self, record: ConversationRecord) -> None:
        self._require_pool()
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    INSERT INTO conversations (
                        conversation_id, user_id, status, title,
                        last_user_message_preview, current_turn, channel,
                        session_token_hash, created_at, updated_at,
                        last_active_at
                    ) VALUES (
                        %s, %s, %s, %s,
                        %s, %s, %s,
                        %s, %s, %s,
                        %s
                    )
                    ON CONFLICT (conversation_id) DO NOTHING
                    """,
                    (
                        record.conversation_id, record.user_id,
                        record.status.value, record.title,
                        record.last_user_message_preview,
                        record.current_turn, record.channel,
                        record.session_token_hash,
                        record.created_at, record.updated_at,
                        record.last_active_at,
                    ),
                )
            await conn.commit()

    async def get(
        self,
        conversation_id: str,
        user_id: str | None = None,
    ) -> ConversationRecord | None:
        self._require_pool()
        from psycopg.rows import dict_row
        async with self._pool.connection() as conn:
            async with conn.cursor(row_factory=dict_row) as cur:
                await cur.execute(
                    "SELECT * FROM conversations WHERE conversation_id = %s",
                    (conversation_id,),
                )
                row = await cur.fetchone()
        if row is None:
            return None
        if user_id is not None and row["user_id"] != user_id:
            return None
        return _row_to_record(row)

    async def list_by_user(
        self,
        user_id: str,
        *,
        include_deleted: bool = False,
        limit: int = 50,
        cursor: str | None = None,
    ) -> list[ConversationRecord]:
        self._require_pool()
        limit = min(limit, 200)
        params: list = [user_id]
        clauses = ["user_id = %s"]
        if not include_deleted:
            clauses.append("deleted_at IS NULL")
        if cursor:
            try:
                cursor_dt = datetime.fromisoformat(cursor)
                clauses.append("last_active_at < %s")
                params.append(cursor_dt)
            except ValueError:
                pass
        where = " AND ".join(clauses)
        params.append(limit)
        sql = f"SELECT * FROM conversations WHERE {where} ORDER BY last_active_at DESC LIMIT %s"

        from psycopg.rows import dict_row
        async with self._pool.connection() as conn:
            async with conn.cursor(row_factory=dict_row) as cur:
                await cur.execute(sql, params)
                rows = await cur.fetchall()
        return [_row_to_record(r) for r in rows]

    async def update_activity(
        self,
        conversation_id: str,
        *,
        turn: int,
        preview: str | None,
        status: ConversationStatus = ConversationStatus.ACTIVE,
        session_token_hash: str | None = None,
    ) -> None:
        self._require_pool()
        now = datetime.now(timezone.utc)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE conversations SET
                        current_turn = %s,
                        status = %s,
                        last_active_at = %s,
                        updated_at = %s,
                        last_user_message_preview = COALESCE(%s, last_user_message_preview),
                        session_token_hash = COALESCE(%s, session_token_hash)
                    WHERE conversation_id = %s
                    """,
                    (
                        turn, status.value, now, now,
                        preview, session_token_hash,
                        conversation_id,
                    ),
                )
            await conn.commit()

    async def mark_ended(self, conversation_id: str) -> None:
        self._require_pool()
        now = datetime.now(timezone.utc)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE conversations
                    SET status = 'ENDED', ended_at = %s, updated_at = %s
                    WHERE conversation_id = %s
                      AND status != 'SOFT_DELETED'
                    """,
                    (now, now, conversation_id),
                )
            await conn.commit()

    async def soft_delete(self, conversation_id: str, user_id: str) -> bool:
        self._require_pool()
        now = datetime.now(timezone.utc)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE conversations
                    SET status = 'SOFT_DELETED', deleted_at = %s, updated_at = %s
                    WHERE conversation_id = %s
                      AND user_id = %s
                      AND deleted_at IS NULL
                    """,
                    (now, now, conversation_id, user_id),
                )
                updated = cur.rowcount
                if updated:
                    await cur.execute(
                        """
                        INSERT INTO conversation_deletion_audit
                            (conversation_id, user_id, delete_mode)
                        VALUES (%s, %s, 'soft')
                        """,
                        (conversation_id, user_id),
                    )
            await conn.commit()
        return bool(updated)

    async def restore_soft_delete(self, conversation_id: str, user_id: str) -> bool:
        self._require_pool()
        now = datetime.now(timezone.utc)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE conversations SET
                        deleted_at = NULL,
                        status = CASE
                            WHEN ended_at IS NOT NULL THEN 'ENDED'
                            ELSE 'ACTIVE'
                        END,
                        last_active_at = %s,
                        updated_at = %s
                    WHERE conversation_id = %s
                      AND user_id = %s
                      AND deleted_at IS NOT NULL
                    """,
                    (now, now, conversation_id, user_id),
                )
                updated = cur.rowcount
            await conn.commit()
        return bool(updated)

    async def hard_delete(self, conversation_id: str, user_id: str) -> bool:
        self._require_pool()
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                # Audit before deletion so the record exists after row removal
                await cur.execute(
                    """
                    INSERT INTO conversation_deletion_audit
                        (conversation_id, user_id, delete_mode)
                    SELECT %s, %s, 'hard'
                    FROM conversations
                    WHERE conversation_id = %s AND user_id = %s
                    """,
                    (conversation_id, user_id, conversation_id, user_id),
                )
                await cur.execute(
                    "DELETE FROM conversations WHERE conversation_id = %s AND user_id = %s",
                    (conversation_id, user_id),
                )
                deleted = cur.rowcount
            await conn.commit()
        return bool(deleted)

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    def _require_pool(self) -> None:
        if self._pool is None:
            raise RuntimeError(
                "PostgresConversationStore.setup() must be called before use."
            )
