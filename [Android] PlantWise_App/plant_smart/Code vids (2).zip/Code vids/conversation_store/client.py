"""Lazy singleton factory for the conversation store.

Usage:
    from conversation_store.client import conversation_store

    # Call setup() once at app startup before using.
    await conversation_store.setup()
"""

from __future__ import annotations

from observability.logger import log as _log

from config import settings
from conversation_store.base import BaseConversationStore

_store: BaseConversationStore | None = None


def _build_store() -> BaseConversationStore:
    backend = getattr(settings, "conversation_store_backend", "memory")
    if backend == "postgres":
        dsn = getattr(settings, "conversation_store_postgres_url", "")
        if not dsn:
            raise RuntimeError(
                "conversation_store_backend=postgres requires "
                "CONVERSATION_STORE_POSTGRES_URL to be set."
            )
        from conversation_store.postgres import PostgresConversationStore
        _log.info("conversation_store_provider", backend="postgres")
        return PostgresConversationStore(dsn)

    # Default: in-memory (dev / test)
    from conversation_store.memory import MemoryConversationStore
    _log.info("conversation_store_provider", backend="memory")
    return MemoryConversationStore()


class _LazyStore:
    """Proxy that builds the real store on first attribute access."""

    def _get(self) -> BaseConversationStore:
        global _store
        if _store is None:
            _store = _build_store()
        return _store

    def __getattr__(self, item):
        return getattr(self._get(), item)


conversation_store: BaseConversationStore = _LazyStore()  # type: ignore[assignment]


def set_conversation_store(store: BaseConversationStore) -> None:
    """Override the store instance (test helper)."""
    global _store
    _store = store
