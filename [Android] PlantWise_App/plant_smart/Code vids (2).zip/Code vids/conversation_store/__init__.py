"""Conversation persistence store.

Provides durable storage for conversation metadata so chats survive
logout/login and process restarts.

Backends:
  memory   — in-process dict; suitable for tests and single-process dev.
  postgres — psycopg3-backed table; required for production persistence.
"""

from conversation_store.models import ConversationRecord, ConversationStatus
from conversation_store.base import BaseConversationStore

__all__ = [
    "BaseConversationStore",
    "ConversationRecord",
    "ConversationStatus",
]
