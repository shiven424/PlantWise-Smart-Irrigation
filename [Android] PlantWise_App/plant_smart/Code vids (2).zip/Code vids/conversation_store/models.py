"""Data models for the conversation store."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class ConversationStatus(str, Enum):
    ACTIVE = "ACTIVE"
    ENDED = "ENDED"
    SOFT_DELETED = "SOFT_DELETED"


@dataclass
class ConversationRecord:
    """Persistent metadata for a single conversation thread.

    This is the app-layer row that complements the LangGraph
    checkpoint stored separately by the Postgres checkpointer.
    The ``conversation_id`` is the LangGraph ``thread_id``.
    """

    conversation_id: str
    user_id: str
    status: ConversationStatus = ConversationStatus.ACTIVE
    title: str | None = None
    last_user_message_preview: str | None = None
    current_turn: int = 0
    channel: str = "web"
    session_token_hash: str | None = None
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    updated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    last_active_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    ended_at: datetime | None = None
    deleted_at: datetime | None = None
