-- Persistent conversation metadata store
-- Run once at app startup (idempotent; CREATE IF NOT EXISTS everywhere)
-- Compatible with PostgreSQL 13+

-- Main conversations table
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id     TEXT        PRIMARY KEY,
    user_id             TEXT        NOT NULL,
    status              TEXT        NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE|ENDED|SOFT_DELETED
    title               TEXT,
    last_user_message_preview TEXT,
    current_turn        INTEGER     NOT NULL DEFAULT 0,
    channel             TEXT        NOT NULL DEFAULT 'web',
    session_token_hash  TEXT,       -- hex-encoded SHA-256 of current session_token
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at            TIMESTAMPTZ,
    deleted_at          TIMESTAMPTZ
);

-- Fast user history listing (most-recently-active first, excluding deleted)
CREATE INDEX IF NOT EXISTS idx_conversations_user_active
    ON conversations (user_id, last_active_at DESC)
    WHERE deleted_at IS NULL;

-- Listing including soft-deleted for admin/restore queries
CREATE INDEX IF NOT EXISTS idx_conversations_user_all
    ON conversations (user_id, last_active_at DESC);

-- Status-based operational queries (cleanup, monitoring)
CREATE INDEX IF NOT EXISTS idx_conversations_status
    ON conversations (status, last_active_at DESC);

-- Deletion audit trail (immutable append-only)
CREATE TABLE IF NOT EXISTS conversation_deletion_audit (
    id              BIGSERIAL   PRIMARY KEY,
    conversation_id TEXT        NOT NULL,
    user_id         TEXT        NOT NULL,
    delete_mode     TEXT        NOT NULL,   -- 'soft' | 'hard'
    deleted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_deletion_audit_conversation
    ON conversation_deletion_audit (conversation_id);

CREATE INDEX IF NOT EXISTS idx_deletion_audit_user
    ON conversation_deletion_audit (user_id, deleted_at DESC);
