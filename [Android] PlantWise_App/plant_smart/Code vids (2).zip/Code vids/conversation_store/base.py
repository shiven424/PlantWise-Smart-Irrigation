"""Abstract base class for conversation persistence providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from conversation_store.models import ConversationRecord, ConversationStatus


class BaseConversationStore(ABC):
    """Every conversation store backend must implement these methods."""

    @abstractmethod
    async def setup(self) -> None:
        """One-time initialisation (create tables, run migrations).

        Must be idempotent — safe to call on every startup.
        """

    @abstractmethod
    async def create(self, record: ConversationRecord) -> None:
        """Persist a new conversation row."""

    @abstractmethod
    async def get(
        self,
        conversation_id: str,
        user_id: str | None = None,
    ) -> ConversationRecord | None:
        """Return the conversation record, or None if not found.

        When ``user_id`` is provided the store MUST enforce ownership
        and return None for conversations belonging to other users.
        """

    @abstractmethod
    async def list_by_user(
        self,
        user_id: str,
        *,
        include_deleted: bool = False,
        limit: int = 50,
        cursor: str | None = None,
    ) -> list[ConversationRecord]:
        """Return conversations owned by ``user_id``.

        Results are ordered most-recently-active first.  ``cursor``
        is an opaque ISO timestamp used for keyset pagination.
        """

    @abstractmethod
    async def update_activity(
        self,
        conversation_id: str,
        *,
        turn: int,
        preview: str | None,
        status: ConversationStatus = ConversationStatus.ACTIVE,
        session_token_hash: str | None = None,
    ) -> None:
        """Update mutable fields after each turn."""

    @abstractmethod
    async def mark_ended(self, conversation_id: str) -> None:
        """Mark the conversation as ENDED."""

    @abstractmethod
    async def soft_delete(self, conversation_id: str, user_id: str) -> bool:
        """Soft-delete: sets status=SOFT_DELETED, records deleted_at.

        Returns True if the row was updated, False if not found or
        already deleted / not owned by user_id.
        """

    @abstractmethod
    async def restore_soft_delete(self, conversation_id: str, user_id: str) -> bool:
        """Undo soft-delete: clears deleted_at; status ENDED if ended_at set else ACTIVE."""

    @abstractmethod
    async def hard_delete(self, conversation_id: str, user_id: str) -> bool:
        """Hard-delete: removes the metadata row permanently.

        Returns True if the row was deleted, False if not found.
        Caller is responsible for removing graph checkpoints separately.
        """

    @abstractmethod
    async def close(self) -> None:
        """Release any connection pool or resources."""
