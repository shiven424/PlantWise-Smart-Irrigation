"""In-memory conversation store.

Suitable for unit tests and single-process development where no
PostgreSQL instance is available.  Data is lost on process restart.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from conversation_store.base import BaseConversationStore
from conversation_store.models import ConversationRecord, ConversationStatus


class MemoryConversationStore(BaseConversationStore):
    """Thread-safe (asyncio-safe) in-memory store."""

    def __init__(self) -> None:
        self._records: dict[str, ConversationRecord] = {}
        self._lock = asyncio.Lock()

    async def setup(self) -> None:
        pass  # nothing to set up

    async def create(self, record: ConversationRecord) -> None:
        async with self._lock:
            self._records[record.conversation_id] = record

    async def get(
        self,
        conversation_id: str,
        user_id: str | None = None,
    ) -> ConversationRecord | None:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None:
                return None
            if user_id is not None and rec.user_id != user_id:
                return None
            return rec

    async def list_by_user(
        self,
        user_id: str,
        *,
        include_deleted: bool = False,
        limit: int = 50,
        cursor: str | None = None,
    ) -> list[ConversationRecord]:
        async with self._lock:
            results = [
                r for r in self._records.values()
                if r.user_id == user_id
                and (include_deleted or r.deleted_at is None)
            ]
        results.sort(key=lambda r: r.last_active_at, reverse=True)
        if cursor:
            try:
                cursor_dt = datetime.fromisoformat(cursor)
                results = [r for r in results if r.last_active_at < cursor_dt]
            except ValueError:
                pass
        return results[:limit]

    async def update_activity(
        self,
        conversation_id: str,
        *,
        turn: int,
        preview: str | None,
        status: ConversationStatus = ConversationStatus.ACTIVE,
        session_token_hash: str | None = None,
    ) -> None:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None:
                return
            now = datetime.now(timezone.utc)
            rec.current_turn = turn
            rec.last_user_message_preview = preview or rec.last_user_message_preview
            rec.status = status
            rec.last_active_at = now
            rec.updated_at = now
            if session_token_hash is not None:
                rec.session_token_hash = session_token_hash

    async def mark_ended(self, conversation_id: str) -> None:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None:
                return
            now = datetime.now(timezone.utc)
            rec.status = ConversationStatus.ENDED
            rec.ended_at = now
            rec.updated_at = now

    async def soft_delete(self, conversation_id: str, user_id: str) -> bool:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None or rec.user_id != user_id:
                return False
            if rec.deleted_at is not None:
                return False
            now = datetime.now(timezone.utc)
            rec.status = ConversationStatus.SOFT_DELETED
            rec.deleted_at = now
            rec.updated_at = now
            return True

    async def restore_soft_delete(self, conversation_id: str, user_id: str) -> bool:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None or rec.user_id != user_id:
                return False
            if rec.deleted_at is None:
                return False
            now = datetime.now(timezone.utc)
            rec.deleted_at = None
            rec.status = (
                ConversationStatus.ENDED if rec.ended_at else ConversationStatus.ACTIVE
            )
            rec.updated_at = now
            rec.last_active_at = now
            return True

    async def hard_delete(self, conversation_id: str, user_id: str) -> bool:
        async with self._lock:
            rec = self._records.get(conversation_id)
            if rec is None or rec.user_id != user_id:
                return False
            del self._records[conversation_id]
            return True

    async def close(self) -> None:
        pass
