"""
Observability - Metrics Collector

In-Memory metrics for development and testing.

"""
from __future__ import annotations

import threading
import statistics
from collections import defaultdict, deque
from typing import Any

from agents.action_planner.v1 import summary

from agents.supervisor.v1 import summary

_MAX_HISTOGRAM_SIZE: int=10_000

class MetricsCollector:
    """Thread-safe in-memory metrics collector.

    Stores counters, histograms, and gauges in memory. All mutations are protected by a single
    lock so concurrent agent threads don't corrupt the data structures.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counters: dict[str, int] = defaultdict(int)
        self._histograms: dict[str, deque[float]] = {}
        self._gauges: dict[str, Any] = {}

    def increment(self, metric: str, labels: dict[str, str] | None = None) -> None:
        """Increment a counter metric by 1."""
        key = self._make_key(metric, labels)
        with self._lock:
            self._counters[key] += 1

    def observe(self, metric:str, value:float, labels: dict[str, str] | None = None) -> None:
        """Record a single observation in a histogram metric.
        Each histogram key is capped at _MAX_HISTOGRAM_SIZE observations.
        When the cap is exceeded, the oldest observation is discarded to prevent unbounded memory growth.
        """
        key = self._make_key(metric, labels)
        with self._lock:
            if key not in self._histograms:
                self._histograms[key] = deque(maxlen=_MAX_HISTOGRAM_SIZE)
            self._histograms[key].append(value)

    def gauge(self, metric:str, value:float, labels: dict[str, str] | None = None) -> None:
        """Set a gauge metric to a specific value."""
        key = self._make_key(metric, labels)
        with self._lock:
            self._gauges[key] = value

    # -- Domain -specific convinence methods -------------------------------------------------
    def record_conversation_start(self, channel:str) -> None:
        self.increment("conversations_started", {"channel": channel})

    def record_conversation_end(self, channel:str) -> None:
        self.increment("conversations_ended", {"channel": channel})

    def record_turn_latency(self, duration_ms: float) -> None:
        self.observe("turn_latency_ms", duration_ms)

    def record_agent_latency(self, agent:str, duration_ms: float) -> None:
        self.observe("agent_latency_ms", duration_ms, {"agent": agent})

    def record_rag_confidence(self, confidence: float, domain:str) -> None:
        self.observe("rag_confidence", confidence, {"domain": domain})
        try:
            from config import settings
            threshold = settings.min_rag_confidence
        except Exception:
            threshold = 0.7  # default threshold if config is not available  
        if confidence < threshold:
            self.increment("rag_low_confidence", {"domain": domain})   
        
    def record_escalation(self, reason:str, triggered_by:str) -> None:
        self.increment("escalations", {"reason": reason})
        self.increment("escalations_triggered_by", {"triggered_by": triggered_by})
    
    def record_auth_attempt(self, *, success:bool) -> None:
        outcome = "success" if success else "failure"
        self.increment("auth_attempts", {"outcome": outcome})

    def record_hitl_decision(self, *, approved:bool) -> None:
        decision = "approved" if approved else "rejected"
        self.increment("hitl_decisions", {"decision": decision})
    
    def record_validation_result(self, status:str) -> None:
        self.increment("validation_results", {"status": status})

    def record_tool_call(self, tool:str, *, success:bool) -> None:
        outcome = "success" if success else "failure"
        self.increment("tool_calls", {"tool": tool, "outcome": outcome})
    
    def record_vault_operation(self, operation: str) -> None:
        self.increment("vault_operations", {"operation": operation})

    def record_active_conversations(self, count: int) -> None:
        self.gauge("active_conversations", float(count))

    # -- Aggregated snapshots -------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a snapshot of all collected metrics with basic aggregations."""
        with self._lock:
            hist_summary: dict[str, dict[str, float]] = {}
            for key, values in self._histograms.items():
                if not values:
                    continue
                sorted_vals = sorted(values)
                n = len(sorted_vals)
                hist_summary[key] = {
                    "count": n,
                    "mean": round(statistics.mean(sorted_vals), 4),
                    "p50": round(sorted_vals[min(int(n * 0.50), n-1)], 4),
                    "p95": round(sorted_vals[min(int(n * 0.95), n-1)], 4),
                    "p99": round(sorted_vals[min(int(n * 0.99), n-1)], 4),
                    "min": round(sorted_vals[0], 4),
                    "max": round(sorted_vals[-1], 4),
                }
            
            return {
                "counters": dict(self._counters),
                "histograms": hist_summary,
                "gauges": dict(self._gauges),
            }

    # -- Internal helpers -------------------------------------------------

    def reset(self) -> None:
        """Clear all collected metrics (test convenience)."""
        with self._lock:
            self._counters.clear()
            self._histograms.clear()
            self._gauges.clear()

    @staticmethod
    def _make_key(metric: str, labels: dict[str, str] | None) -> str:
        """Create a unique key for a metric + label combination."""
        if not labels:
            return metric
        tag = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{metric}|{tag}"
    
# -- Module-level singleton -------------------------------------------------

metrics = MetricsCollector()