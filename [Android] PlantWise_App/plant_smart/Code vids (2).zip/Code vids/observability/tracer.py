"""
Observability – Tracer

Provides:
- ``init_tracer()``  – Initialises LangSmith / external tracing if configured.
- ``trace_agent()``  – Decorator that logs latency and key I/O for any ``agent.run()``.
- ``Span``           – Lightweight context manager for timing arbitrary blocks.

All tracing is **optional** – when no tracing env-vars are set, the
decorator and span become thin no-ops that only write to the structured
logger.
"""

from __future__ import annotations

import inspect
import os
import time
import threading
import uuid
import contextvars

from contextlib import contextmanager
from functools import wraps
from typing import Any, Generator

from observability.logger import log


# ============================================================
# LangSmith / external tracing bootstrap
# ============================================================

_tracer_initialised = False
_tracer_lock = threading.Lock()


def init_tracer() -> None:
    """Initialise external tracing backend if configured.

    Currently supports **LangSmith** (LANGCHAIN_TRACING_V2=true).
    Called once during FastAPI lifespan startup.
    """
    global _tracer_initialised
    if _tracer_initialised:
        return

    with _tracer_lock:
        if _tracer_initialised:
            return

        if os.getenv("LANGCHAIN_TRACING_V2", "").lower() == "true":
            os.environ.setdefault("LANGCHAIN_TRACING_V2", "true")
            project = os.getenv("LANGCHAIN_PROJECT", "contact-center-ai")
            log.info("tracing_enabled", provider="langsmith", project=project)
        else:
            log.info("tracing_disabled")

        _tracer_initialised = True


# ============================================================
# Span – lightweight timing context manager
# ============================================================

class Span:
    """Lightweight timing context manager for arbitrary code blocks.

    Usage::

        with Span("kb_vector_search", session_id=sid) as s:
            results = vector_store.search(query)
        print(s.duration_ms)  # elapsed time in milliseconds

    Nested spans are supported — each records its own independent timing.
    """

    __slots__ = ("name", "span_id", "start", "duration_ms", "_extra")

    def __init__(self, name: str, **extra: Any) -> None:
        self.name = name
        self.span_id = uuid.uuid4().hex[:12]
        self.start: float = 0.0
        self.duration_ms: float = 0.0
        self._extra = extra

    def __enter__(self) -> "Span":
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[override]
        self.duration_ms = (time.perf_counter() - self.start) * 1000
        level = "error" if exc_type else "info"

        payload: dict[str, Any] = {
            "span": self.name,
            "span_id": self.span_id,
            "duration_ms": round(self.duration_ms, 2),
            **self._extra,
        }

        if exc_type:
            payload["error"] = str(exc_val)

        getattr(log, level)("span_end", **payload)


@contextmanager
def span(name: str, **extra: Any) -> Generator[Span, None, None]:
    """Functional wrapper around ``Span`` for use with ``with`` statements."""
    s = Span(name, **extra)
    with s:
        yield s


# ============================================================
# trace_agent – decorator for agent.run() methods
# ============================================================

def trace_agent(agent_name: str):
    """Decorator that wraps an ``agent.run(state)`` call with timing and logging.

    Logs the agent name, session_id, turn number, wall-clock duration,
    and the keys present in the returned state-delta dict.

    Supports both sync and async ``run()`` methods.
    """

    def _extract_context(state):
        session_obj = state.get("session")
        session_id = (
            str(session_obj.session_id)
            if hasattr(session_obj, "session_id")
            else "unknown"
        )
        turn = state.get("current_turn", 0)
        return session_id, turn

    def _log_success(session_id, turn, start, result):
        duration_ms = (time.perf_counter() - start) * 1000
        log.info(
            "agent_trace",
            agent=agent_name,
            session_id=session_id,
            turn=turn,
            duration_ms=round(duration_ms, 2),
            output_keys=list(result.keys()) if isinstance(result, dict) else [],
        )

        try:
            from observability.metrics import metrics

            metrics.record_agent_latency(agent_name, duration_ms)
        except Exception as _metrics_exc:
            log.debug(
                "metrics_record_failed",
                agent=agent_name,
                error=str(_metrics_exc),
            )

        return result

    def _log_error(session_id, turn, start, exc):
        duration_ms = (time.perf_counter() - start) * 1000
        log.error(
            "agent_trace_error",
            agent=agent_name,
            session_id=session_id,
            turn=turn,
            duration_ms=round(duration_ms, 2),
            error=str(exc),
        )

    def decorator(func):
        if inspect.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(self, state, *args, **kwargs):
                session_id, turn = _extract_context(state)
                start = time.perf_counter()
                try:
                    result = await func(self, state, *args, **kwargs)
                    return _log_success(session_id, turn, start, result)
                except Exception as exc:
                    _log_error(session_id, turn, start, exc)
                    raise

            return async_wrapper

        @wraps(func)
        def wrapper(self, state, *args, **kwargs):
            session_id, turn = _extract_context(state)
            start = time.perf_counter()
            try:
                result = func(self, state, *args, **kwargs)
                return _log_success(session_id, turn, start, result)
            except Exception as exc:
                _log_error(session_id, turn, start, exc)
                raise

        return wrapper

    return decorator


# ============================================================
# Async-safe trace context (contextvars)
# ============================================================

_trace_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "trace_id",
    default=None,
)


def get_trace_id() -> str:
    """Return the current trace ID, creating one if absent."""
    tid = _trace_id_var.get()
    if not tid:
        tid = uuid.uuid4().hex[:16]
        _trace_id_var.set(tid)
    return tid


def set_trace_id(trace_id: str) -> None:
    """Set the trace ID for the current context (e.g. from X-Request-ID)."""
    _trace_id_var.set(trace_id)


def clear_trace_id() -> None:
    """Clear the trace ID for the current context."""
    _trace_id_var.set(None)