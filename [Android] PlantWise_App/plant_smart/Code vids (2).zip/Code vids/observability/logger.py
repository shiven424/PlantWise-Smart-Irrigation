from __future__ import annotations

"""
Minimal structured logger stub.

Replace with a proper structured-logging implementation
(e.g. structlog) when the observability layer is built out.
"""

import logging
import re

_logger = logging.getLogger("contact_center")

# Keys that MUST be redacted to prevent PII leakage in logs.
_PII_KEYS: frozenset[str] = frozenset({
    # Explicit PII values
    "ssn", "raw_value", "date_of_birth", "dob", "account_number",
    "phone", "phone_number", "email", "email_address", "address",
    "tax_id", "bank_account_number", "bank_routing_number",
    "full_name", "beneficiary_name", "beneficiary_dob",
    "policy_number", "employer_name", "expected_hash",
    "pii_value", "display_value", "masked_value",
    # Correlation / reference keys
    "vault_token",
    # Response bodies that may contain PII
    "raw_response", "snippet", "response_text",
})


# C2: Regex patterns for PII that can appear in arbitrary string values.
# Compiled once at module load for performance.
_PII_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # SSN: 123-45-6789 or 123456789
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "***SSN***"),
    (re.compile(r"\b\d{9}\b"), "***SSN***"),
    # Date of birth: MM/DD/YYYY, MM-DD-YYYY, YYYY-MM-DD
    (re.compile(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{4}\b"), "***DOB***"),
    # Email
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), "***EMAIL***"),
    # US phone: (555) 867-5309, 555-867-5309, +1 555 867 5309
    (re.compile(r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"), "***PHONE***"),
    # Account numbers: 8-17 digit sequences (after SSN check, so 9-digit already caught)
    (re.compile(r"\b\d{10,17}\b"), "***ACCT***"),
]


def _scrub_value(text: str) -> str:
    """Apply regex-based PII redaction to a string value."""
    for pattern, replacement in _PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


class _StructuredLog:
    """Thin wrapper that emits key=value pairs alongside a message."""

    @staticmethod
    def _scrub(key: str, value: object) -> object:
        """Redact values whose key matches a known PII field name.

        Also applies regex-based PII scanning to string values so that
        PII embedded in free-text fields (e.g. user messages, error
        strings) is redacted regardless of the key name.

        Recursively scrubs nested dicts, lists, and Pydantic models so
        that PII buried in complex structures is never emitted to logs.
        """
        if isinstance(value, dict):
            return {k: _StructuredLog._scrub(k, v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return type(value)(_StructuredLog._scrub(key, item) for item in value)

        # Fix 149: Recurse into Pydantic models - their __repr__ exposes
        # vault_token and other sensitive fields if not scrubbed.
        if hasattr(value, "model_dump") and callable(value.model_dump):
            return _StructuredLog._scrub(key, value.model_dump())
        if key.lower() in _PII_KEYS:
            return "***REDACTED***"
        # C2: Regex-based value scanning for PII patterns in strings
        if isinstance(value, str) and len(value) >= 7:
            return _scrub_value(value)
        return value

    @staticmethod
    def _sanitize(text: str) -> str:
        """Strip newlines / carriage returns to prevent log injection."""
        return text.replace("\n", "\\n").replace("\r", "\\r")

    def _fmt(self, event: str, **kw: object) -> str:
        # M10: Inject trace_id for log correlation across agents/turns
        from observability.tracer import get_trace_id

        trace_id = get_trace_id()
        safe_event = self._sanitize(str(event))
        pairs = " ".join(
            f"{self._sanitize(str(k))}={self._sanitize(str(self._scrub(k, v)))}"
            for k, v in kw.items()
        )
        prefix = f"[{safe_event}] trace_id={trace_id}"
        return f"{prefix} {pairs}" if pairs else prefix

    def info(self, event: str, **kw: object) -> None:
        _logger.info(self._fmt(event, **kw))

    def warning(self, event: str, **kw: object) -> None:
        _logger.warning(self._fmt(event, **kw))

    def error(self, event: str, **kw: object) -> None:
        _logger.error(self._fmt(event, **kw))

    def debug(self, event: str, **kw: object) -> None:
        _logger.debug(self._fmt(event, **kw))

    def exception(self, event: str, **kw: object) -> None:
        _logger.exception(self._fmt(event, **kw))


log = _StructuredLog()
