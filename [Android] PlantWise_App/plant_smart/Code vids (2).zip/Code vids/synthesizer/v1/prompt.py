"""Response Synthesizer v1 – LLM prompts for Layer 1 (opening frame).

Layer 1 is the only LLM-generated component of the response.
It produces a short, tone-matched opening sentence that sets the
conversational context before the template-driven core content.

Layer 2 (core content) comes from JSON templates — no LLM involvement.
Layer 3 (compliance tail) comes from the compliance library — verbatim, NEVER modified.
"""

from __future__ import annotations

from schemas.enums import ActionType
from schemas.primitives import ActionPlan

OPENING_FRAME_SYSTEM_PROMPT = (
    "You are a professional, empathetic customer service assistant for a "
    "retirement and investment contact center. "
    "Generate a SHORT opening sentence (1-2 sentences) that acknowledges "
    "the customer and sets the tone for the response that follows.\n\n"
    "Rules:\n"
    "- Match the requested TONE exactly (PROFESSIONAL, EMPATHETIC, or GENTLE).\n"
    "- Do NOT include any regulatory information, numbers, or account details.\n"
    "- Do NOT give financial or tax advice.\n"
    "- Do NOT repeat the core content — this is just the opening frame.\n"
    "- Be concise and natural. Maximum 2 sentences.\n"
    "- Respond with the opening text ONLY — no JSON, no quotes, no preamble."
)

_ACTION_CONTEXT = {
    ActionType.ANSWER: "providing an informational answer",
    ActionType.COLLECT_SLOT: "asking for a missing piece of information",
    ActionType.RETRY_SLOT: "re-asking for information that wasn't clear",
    ActionType.CORRECTION_ACK: "acknowledging a correction",
    ActionType.CLARIFY: "asking for clarification about their request",
    ActionType.INITIATE_AUTH: "requesting identity verification",
    ActionType.AUTH_CHALLENGE: "presenting an authentication challenge",
    ActionType.PROCESS_AUTH: "processing authentication",
    ActionType.VALIDATE_ENTITIES: "confirming details before proceeding",
    ActionType.PRESENT_HITL: "presenting a transaction summary for review",
    ActionType.HITL_CORRECTION: "processing a correction to the transaction",
    ActionType.HITL_APPROVED: "confirming the transaction is approved",
    ActionType.EXECUTE_TRANSACTION: "confirming a completed transaction",
    ActionType.ESCALATE: "transferring to a specialist",
    ActionType.CHITCHAT_RESPOND: "responding to casual conversation",
    ActionType.END_SESSION: "closing the conversation",
    ActionType.PUSH_INTENT: "switching to a new request",
    ActionType.POP_INTENT: "returning to a previous request",
    ActionType.HANDLE_ERROR: "handling an unexpected issue",
}


def build_opening_frame_prompt(
    plan: ActionPlan,
    last_message: str,
    user_profile: dict | None = None,
    *,
    action_context_override: str | None = None,
) -> str:
    """Build the user-prompt for the Layer 1 LLM call."""
    tone = plan.response_directive.tone
    action_ctx = action_context_override or _ACTION_CONTEXT.get(
        plan.action_type, "responding to the customer"
    )
    hints = plan.response_directive.content_hints

    parts = [
        f"Tone: {tone}",
        f"Context: You are {action_ctx}.",
        f"Customer's last message: \"{last_message}\"",
    ]
    if hints:
        parts.append(f"Additional context: {'; '.join(hints)}")

    # Inject user profile context for personalised greetings
    if user_profile:
        from user_profile.base import sanitize_profile_field
        profile_parts: list[str] = []
        name = sanitize_profile_field(
            user_profile.get("display_name") or user_profile.get("preferred_greeting")
        )
        if name:
            profile_parts.append(f"Customer name: {name}")
        style = sanitize_profile_field(user_profile.get("communication_style"))
        if style and style != "professional":
            profile_parts.append(f"Preferred communication style: {style}")
        txn_count = user_profile.get("past_transaction_count", 0)
        if txn_count > 0:
            profile_parts.append(f"Returning customer ({txn_count} prior transactions)")
        if profile_parts:
            parts.append("Customer profile: " + "; ".join(profile_parts))

    return "\n".join(parts)
