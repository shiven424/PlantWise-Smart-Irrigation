"""Response Synthesizer v1 — 3-layer response assembly.

    Layer 1 (LLM):      Short tone-matched opening frame.
    Layer 2 (Template): Core content from JSON templates + validated entities.
    Layer 3 (Verbatim): Compliance disclosures from compliance library — NEVER modified.

Write-ownership:
    last_synthesized_response
"""

from __future__ import annotations

import json
from pathlib import Path

from agents.base import BaseAgent
from graph.state import GraphState, get_active_intent
from llm.client import call_llm_text
from observability.logger import log
from observability.tracer import trace_agent
from schemas.enums import ActionType
from schemas.primitives import (
    ActionPlan,
    EntityRecord,
    HITLDisclosureItem,
    ResponseDirective,
)
from schemas.agent_io import SynthesizerResponse
from synthesizer.v1.prompt import (
    OPENING_FRAME_SYSTEM_PROMPT,
    build_opening_frame_prompt,
)

# Hint strings for Layer-1 LLM when EXECUTE_TRANSACTION is informational (no money movement).
_READ_ONLY_EXECUTE_LLM_HINTS: dict[str, str] = {
    "balance": (
        "sharing a read-only account summary after verification "
        "(no withdrawal, trade, or money movement occurred)"
    ),
    "rmd": (
        "sharing an illustrative RMD figure from verified records "
        "(no distribution scheduled or processed)"
    ),
    "rmd_not_required": (
        "explaining that no RMD is currently due from this account based on age "
        "or account type—illustrative check only; no distribution scheduled "
        "or processed"
    ),
    "loan_eligibility": (
        "checking plan loan borrowing limits after verification "
        "(no loan originated or disbursed)"
    ),
    "loan_status": (
        "reviewing existing plan loan records after verification "
        "(no repayment or disbursement processed)"
    ),
    "loan_preview": (
        "showing an amortization preview for a possible plan loan "
        "(not booked or final until the member confirms)"
    ),
    "transactions": (
        "sharing a read-only summary of posted account activity "
        "(no disbursement processed and no advisory recommendation)"
    ),
}

_READ_ONLY_STATIC_OPENING: dict[str, str] = {
    "balance": (
        "Thanks for waiting — here's your account summary with the "
        "latest figures we can show you right now."
    ),
    "rmd": (
        "Thanks for waiting — here's an estimate of your required minimum "
        "distribution based on what's on file."
    ),
    "rmd_not_required": (
        "Here's what applies to required minimum distributions for your account "
        "right now — you're not scheduled to take an RMD from this account yet."
    ),
    "loan_eligibility": (
        "Here's what we can tell you about plan loan limits and eligibility "
        "under your plan right now."
    ),
    "loan_status": (
        "Here's a summary of your existing plan loan activity on file."
    ),
    "loan_preview": (
        "Here's a preview of how this loan could look — you can still review "
        "or cancel before anything is finalized."
    ),
    "transactions": (
        "Here's a recap of recent account activity recorded on file "
        "after verifying it's you."
    ),
}


# — Template & Compliance Library Loaders ————————————————————————————————————

_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
_COMPLIANCE_DIR = Path(__file__).resolve().parent.parent / "compliance_library"


# — Agent ————————————————————————————————————————————————————————————————————

class ResponseSynthesizerAgent(BaseAgent):
    name = "response_synthesizer"
    version = "1.0.0"

    def __init__(self) -> None:
        self._template_cache: dict[str, dict] = {}
        self._compliance_cache: dict[str, dict] = {}

    def _load_template(self, template_id: str) -> dict:
        """Load and cache a JSON template by template_id.

        Raises RuntimeError if the template file is missing, since
        templates drive the core content layer and a missing file
        would produce empty or incoherent responses.
        """
        if template_id in self._template_cache:
            return self._template_cache[template_id]
        path = _TEMPLATES_DIR / f"{template_id}.json"
        if not path.exists():
            log.error(
                "synthesizer_template_missing",
                template_id=template_id,
                path=str(path),
            )
            raise RuntimeError(
                f"Required synthesizer template '{template_id}' not found at {path}. "
                f"Add the template file or fix the template_id in the action plan."
            )
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        self._template_cache[template_id] = data
        return data

    def _load_all_compliance(self) -> dict[str, dict]:
        """Load and cache all compliance library JSON files."""
        if self._compliance_cache:
            return self._compliance_cache
        for path in sorted(_COMPLIANCE_DIR.glob("*.json")):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            for key, entry in data.items():
                if key.startswith("_"):
                    continue
                if not isinstance(entry, dict) or "text" not in entry:
                    raise ValueError(
                        f"Invalid compliance entry '{key}' in {path.name}: "
                        f"must be a dict with a 'text' field.  "
                        f"Keys present: {list(entry.keys()) if isinstance(entry, dict) else 'N/A'}"
                    )
                self._compliance_cache[key] = entry
        return self._compliance_cache

    @trace_agent("response_synthesizer")
    def run(self, state: GraphState) -> dict:
        plan: ActionPlan | None = state.get("current_action_plan")
        session = state.get("session")
        session_id = str(session.session_id) if session else "unknown"

        if not plan:
            log.error("synthesizer_no_plan", session_id=session_id)
            return self._fallback_response(ActionType.HANDLE_ERROR)

        read_only_kind: str | None = None
        execute_ctx: str | None = None
        if plan.action_type == ActionType.EXECUTE_TRANSACTION:
            txr = state.get("transaction_result")
            if isinstance(txr, dict):
                read_only_kind = self._read_only_execute_kind(txr)
                if read_only_kind:
                    execute_ctx = _READ_ONLY_EXECUTE_LLM_HINTS.get(read_only_kind)

        # — Layer 1: LLM opening frame ————————————————————————————————————————
        history = state.get("message_history", [])
        last_msg = history[-1].get("content", "") if history else ""
        user_profile = state.get("user_profile", {})
        opening = self._generate_opening(
            plan,
            last_msg,
            session_id,
            user_profile,
            execute_context_override=execute_ctx,
            read_only_kind=read_only_kind,
        )

        # — Layer 2: Template-driven core content ————————————————————————————
        core = self._build_core_content(state, plan)

        # — Layer 3: Compliance tails (verbatim) —————————————————————————————
        tail_ids = plan.response_directive.compliance_tail_ids or []
        compliance_tail, appended_ids = self._build_compliance_tail(tail_ids)

        # — Assemble full_message ————————————————————————————————————————————
        parts = [p for p in [opening, core, compliance_tail] if p]
        full_message = "\n\n".join(parts) if parts else opening or "How can I help you?"

        log.info(
            "synthesizer_response",
            action_type=plan.action_type.value,
            opening_len=len(opening),
            core_len=len(core),
            tail_ids=appended_ids,
            session_id=session_id,
        )

        # Validate through schema — catches empty full_message and
        # ensures the three layers are properly assembled.
        try:
            validated = SynthesizerResponse(
                opening_frame=opening,
                core_content=core,
                compliance_tail=compliance_tail,
                full_message=full_message,
                action_type=plan.action_type,
                disclosures_appended=appended_ids,
            )
            response_data = validated.model_dump()
            response_data["action_type"] = validated.action_type.value
        except Exception as exc:
            log.warning(
                "synthesizer_validation_fallback",
                error=str(exc),
                session_id=session_id,
            )
            response_data = {
                "opening_frame": opening,
                "core_content": core,
                "compliance_tail": compliance_tail,
                "full_message": full_message,
                "action_type": plan.action_type.value,
                "disclosures_appended": appended_ids,
            }

        return {
            "last_synthesized_response": response_data,
        }

    # — Layer 1: Opening Frame ————————————————————————————————————————————————

    def _generate_opening(
        self,
        plan: ActionPlan,
        last_message: str,
        session_id: str,
        user_profile: dict | None = None,
        *,
        execute_context_override: str | None = None,
        read_only_kind: str | None = None,
    ) -> str:
        """Generate a tone-matched opening sentence via LLM."""
        fallback = self._static_opening(
            plan,
            execute_context_override=execute_context_override,
            read_only_kind=read_only_kind,
        )
        try:
            text = call_llm_text(
                system_prompt=OPENING_FRAME_SYSTEM_PROMPT,
                user_prompt=build_opening_frame_prompt(
                    plan,
                    last_message,
                    user_profile,
                    action_context_override=execute_context_override,
                ),
                fallback=fallback,
                max_tokens=150,
                temperature=0.3,
            ).strip()
            return text if text else fallback
        except Exception:
            log.warning("synthesizer_llm_fallback", session_id=session_id)
            return fallback

    @staticmethod
    def _static_opening(
        plan: ActionPlan,
        *,
        execute_context_override: str | None = None,
        read_only_kind: str | None = None,
    ) -> str:
        """Deterministic fallback when LLM is unavailable."""
        tone = plan.response_directive.tone
        at = plan.action_type
        if at == ActionType.ESCALATE:
            return "I understand this is important to you. Let me connect you with a specialist who can help."
        if at == ActionType.CHITCHAT_RESPOND:
            return "Thanks for chatting!"
        if at in (ActionType.COLLECT_SLOT, ActionType.RETRY_SLOT, ActionType.CLARIFY):
            return "I need a bit more information to proceed."
        if at == ActionType.ANSWER:
            return "Here's what I found for you."
        if at == ActionType.PRESENT_HITL:
            return "Please review the details below before I proceed."
        if at == ActionType.EXECUTE_TRANSACTION:
            if read_only_kind and read_only_kind in _READ_ONLY_STATIC_OPENING:
                return _READ_ONLY_STATIC_OPENING[read_only_kind]
            if execute_context_override:
                return (
                    "Thanks for waiting — here are the details we can share "
                    "from your verified information."
                )
            return "Here are the details of your request."
        if at == ActionType.END_SESSION:
            return "Thank you for contacting us today."
        if at in (ActionType.INITIATE_AUTH, ActionType.AUTH_CHALLENGE):
            return "For your security, I need to verify your identity."
        if at == ActionType.PROCESS_AUTH:
            return "Thank you for verifying your identity."
        if tone == "EMPATHETIC":
            return "I understand. Let me help you with that."
        return "Let me help you with that."

    # — Layer 2: Core Content —————————————————————————————————————————————————

    def _build_core_content(self, state: GraphState, plan: ActionPlan) -> str:
        """Build template-driven core content based on action type.

        Fix 153: Catches RuntimeError from missing template files so the
        synthesizer can still produce a response instead of crashing.
        """
        try:
            return self._build_core_content_inner(state, plan)
        except RuntimeError as exc:
            log.error(
                "synthesizer_template_error",
                action_type=plan.action_type.value,
                error=str(exc),
            )
            return (
                "I have the information ready but encountered a formatting issue. "
                "A specialist can provide you with the complete details."
            )

    def _build_core_content_inner(self, state: GraphState, plan: ActionPlan) -> str:
        """Inner implementation of core content building."""
        at = plan.action_type
        directive = plan.response_directive

        if at == ActionType.ANSWER:
            return self._core_informational(state)

        if at in (ActionType.COLLECT_SLOT, ActionType.RETRY_SLOT, ActionType.CLARIFY):
            return self._core_slot_collection(state, plan)

        if at == ActionType.PRESENT_HITL:
            return self._core_hitl(state)

        if at in (ActionType.EXECUTE_TRANSACTION, ActionType.HITL_APPROVED):
            return self._core_transaction_complete(state)

        if at == ActionType.ESCALATE:
            return self._core_escalation(state, plan)

        if at == ActionType.CHITCHAT_RESPOND:
            # content_hints are guidance for the Layer 1 opening-frame LLM
            # (e.g. "Re-anchor to active intent: ..."), NOT customer-facing
            # text. Returning them here leaks internal directives into the
            # response. Layer 1 produces the actual chitchat reply.
            return ""

        if at == ActionType.END_SESSION:
            return "If you need anything else in the future, don't hesitate to reach out."

        if at in (ActionType.INITIATE_AUTH, ActionType.AUTH_CHALLENGE):
            return self._core_auth(state)

        if at == ActionType.PROCESS_AUTH:
            # Auth just succeeded — acknowledge cleanly. The auth_agent has
            # already cleared pending_auth_challenge, so _core_auth would
            # return the generic INITIATE_AUTH fallback here, which is wrong.
            return (
                "Thank you, your identity has been verified. "
                "How would you like to proceed?"
            )

        if at == ActionType.HITL_CORRECTION:
            return "I've noted your corrections. Let me update the details."

        if at == ActionType.CORRECTION_ACK:
            return "Got it, I've updated that for you."

        # Fix M20: Handle internal routing action types that can reach
        # the synthesizer.  These produce brief acknowledgment messages
        # instead of blank core content.
        if at == ActionType.VALIDATE_ENTITIES:
            return "I'm verifying the details you provided."

        if at in (ActionType.PUSH_INTENT, ActionType.POP_INTENT):
            return "Let me adjust our focus based on your request."

        if at == ActionType.HANDLE_ERROR:
            return (
                "I encountered an issue processing your request. "
                "Let me connect you with a specialist who can help."
            )

        return ""

    def _core_informational(self, state: GraphState) -> str:
        """Informational answer using RAG response."""
        rag_answer = state.get("rag_answer") or ""
        citations = state.get("rag_citations", [])

        if not rag_answer:
            return (
                "I don't have enough information to answer that question "
                "accurately right now. Let me connect you with a specialist "
                "who can help."
            )

        parts = []
        if rag_answer:
            parts.append(rag_answer)

        if citations:
            cite_lines = []
            for c in citations[:5]:
                cite_text = c.document_name
                if c.section:
                    cite_text += f", {c.section}"
                if c.page:
                    cite_text += f" (p. {c.page})"
                cite_lines.append(f"• {cite_text}")
            if cite_lines:
                parts.append("Sources:\n" + "\n".join(cite_lines))

        return "\n\n".join(parts) if parts else ""

    def _core_slot_collection(self, state: GraphState, plan: ActionPlan) -> str:
        """Slot collection prompt from template."""
        target_slot = plan.target_slot
        if not target_slot:
            return "Could you please provide more details about your request?"

        template = self._load_template("slot_collection")
        slot_prompts = template.get("slot_prompts", {})
        slot_info = slot_prompts.get(target_slot)

        if slot_info:
            parts = []
            ctx = slot_info.get("context", "")
            question = slot_info.get("question", "")
            examples = slot_info.get("examples", "")

            # Multi-account enrichment: when collecting ``account_type``
            # for ACCOUNT_BALANCE_INQUIRY, replace the generic example list
            # with the user's actual on-file accounts so the prompt is
            # specific and answerable.
            if target_slot == "account_type":
                acct_ctx = state.get("account_context") or {}
                available = acct_ctx.get("available_account_types") or list(
                    (acct_ctx.get("accounts") or {}).keys()
                )
                if available:
                    pretty = ", ".join(self._humanize_account_type(t) for t in available)
                    active_i = get_active_intent(state)
                    sub_ix = getattr(active_i, "sub_intent", None) if active_i else None
                    if sub_ix == "TRANSACTION_HISTORY_INQUIRY":
                        question = (
                            "Which account would you like to see transactions for? "
                            f"You have {pretty} on file."
                        )
                    else:
                        question = (
                            "Which account would you like to check? "
                            f"You have a {pretty} account on file."
                        )
                    examples = ""

            # Multi-account enrichment for RMD flows: same UX as balance (list
            # on-file retirement accounts instead of generic plan-type examples).
            if target_slot == "plan_type":
                active_i = get_active_intent(state)
                sub_intent = getattr(active_i, "sub_intent", None) if active_i else None
                if sub_intent in {"RMD_CALCULATION", "RMD_SETUP"}:
                    ac_ct = state.get("account_context") or {}
                    avail_pt = ac_ct.get("available_account_types") or list(
                        (ac_ct.get("accounts") or {}).keys()
                    )
                    if len(avail_pt) > 1:
                        pretty_pt = ", ".join(
                            self._humanize_account_type(str(t).upper())
                            for t in avail_pt
                        )
                        question = (
                            "Which retirement account should we use? "
                            f"You have a {pretty_pt} account on file."
                        )
                        examples = ""
                elif sub_intent in {
                    "PLAN_LOAN_REQUEST",
                    "PLAN_LOAN_ELIGIBILITY",
                    "PLAN_LOAN_STATUS",
                }:
                    # List loan-eligible DCP accounts (same gate as PlanLoanTool).
                    from tools.plan_loan.v1.agent import (
                        _NON_LOAN_ELIGIBLE_TYPES as _LOAN_EXCL,
                    )

                    ac_ct = state.get("account_context") or {}
                    accounts = ac_ct.get("accounts") or {}
                    loan_eligible_keys = [
                        k
                        for k, v in accounts.items()
                        if k not in _LOAN_EXCL
                        and isinstance(v, dict)
                        and v.get("plan_allows_loans", True)
                    ]
                    if len(loan_eligible_keys) > 1:
                        pretty_ln = ", ".join(
                            self._humanize_account_type(str(k).upper())
                            for k in loan_eligible_keys
                        )
                        question = (
                            "Which account would you like to borrow from? "
                            f"On file you have: {pretty_ln} "
                            "(participant loans are only available from certain plan types)."
                        )
                        examples = ""

            if ctx:
                parts.append(ctx)
            if question:
                parts.append(question)
            if examples:
                parts.append(examples)
            return " ".join(parts)

        # Fallback for unmapped slots
        display_name = target_slot.replace("_", " ")
        fallback_t = template.get("fallback_prompt", {})
        fallback_q = fallback_t.get("question", "Could you please provide the {slot_name_display}?")
        return fallback_q.replace("{slot_name_display}", display_name).replace("{{slot_name_display}}", display_name)

    @staticmethod
    def _humanize_account_type(t: str) -> str:
        """Map canonical account_type codes to a human-readable label."""
        return {
            "401K": "401(k)",
            "ROTH_401K": "Roth 401(k)",
            "TRADITIONAL_IRA": "Traditional IRA",
            "ROTH_IRA": "Roth IRA",
            "403B": "403(b)",
            "457B": "457(b)",
            "SEP_IRA": "SEP IRA",
            "SIMPLE_IRA": "SIMPLE IRA",
            "BROKERAGE": "Brokerage",
            "TRUST": "Trust",
            "CUSTODIAL": "Custodial",
            "JOINT": "Joint",
            "PENSION": "Pension",
            "PROFIT_SHARING": "Profit-Sharing",
        }.get(t.upper(), t.replace("_", " ").title())

    def _core_hitl(self, state: GraphState) -> str:
        """HITL confirmation screen from template + validated entities."""
        entities: dict[str, EntityRecord] = state.get("validated_entities", {})
        disclosures: list[HITLDisclosureItem] = state.get("hitl_disclosures", [])

        # Scope the confirmation card to slots the *active* intent actually
        # needs.  Without this, entities left over in entity_memory from a
        # prior intent (e.g. account_type=BROKERAGE captured during a
        # balance inquiry that happened just before a pivot to RMD) would
        # surface in the HITL summary and mislead the customer about what
        # is being executed.  Only relevant slot/ambient entries that
        # belong to the active intent's required_slots are rendered.
        active_intent = get_active_intent(state)
        allowed_slots: set[str] | None = (
            set(active_intent.required_slots) if active_intent else None
        )

        parts = ["**Please Review and Confirm Your Request**\n"]

        # Entity summary
        if entities:
            rendered: list[tuple[str, str]] = []
            for key, entity in entities.items():
                slot = entity.slot_name or key
                if allowed_slots is not None and slot not in allowed_slots:
                    continue
                display_name = slot.replace("_", " ").title()
                value = entity.display_value or "(pending)"
                rendered.append((display_name, value))

            if rendered:
                parts.append("**Transaction Details:**")
                for display_name, value in rendered:
                    parts.append(f"  • {display_name}: {value}")

        # Warnings / disclosures
        if disclosures:
            parts.append("\n**Important Notices:**")
            for d in disclosures:
                ack_marker = " [Acknowledgment required]" if d.requires_ack else ""
                parts.append(f"  ⚠ {d.display_text}{ack_marker}")

        parts.append("\nPlease confirm to proceed, or let me know if you'd like to make changes.")
        return "\n".join(parts)

    @staticmethod
    def _read_only_execute_kind(tx_result: dict) -> str | None:
        """Classify informational execute results (no completed money movement)."""
        st = str(tx_result.get("status", "")).upper()
        if st in {"FAILED", "ERROR", "REJECTED", "CANCELLED", "CANCELED"}:
            return None
        if tx_result.get("success") is False:
            return None
        op = str(tx_result.get("operation", "")).upper()
        if op.startswith("BALANCE_INQUIRY"):
            return "balance"
        if op.startswith("TRANSACTION_HISTORY"):
            return "transactions"
        if op == "RMD_CALCULATION":
            if tx_result.get("rmd_required") is False:
                return "rmd_not_required"
            return "rmd"
        if op == "ELIGIBILITY":
            return "loan_eligibility"
        if op == "STATUS":
            return "loan_status"
        if op == "INITIATE" and st == "PREVIEW":
            return "loan_preview"
        return None

    @staticmethod
    def _read_only_failure_heading(tx_result: dict) -> str | None:
        """Customer-facing failure title for read-only / estimate tools."""
        op = str(tx_result.get("operation", "")).upper()
        if op.startswith("BALANCE_INQUIRY"):
            return "**We couldn't retrieve your balance**\n"
        if op.startswith("TRANSACTION_HISTORY"):
            return "**We couldn't retrieve your transactions**\n"
        if op == "RMD_CALCULATION":
            return "**We couldn't complete your RMD estimate**\n"
        if op == "ELIGIBILITY":
            return "**We couldn't check loan eligibility**\n"
        if op == "STATUS":
            return "**We couldn't retrieve your loan details**\n"
        if op == "INITIATE":
            return "**We couldn't finalize your plan loan**\n"
        return None

    @staticmethod
    def _append_whitelisted_fields(
        parts: list[str],
        data: dict,
        *,
        whitelist: set[str],
        skip: frozenset[str],
    ) -> None:
        for key, value in data.items():
            if key in skip:
                continue
            if key not in whitelist:
                continue
            if value in (None, "", []):
                continue
            display_key = key.replace("_", " ").title()
            parts.append(f"**{display_key}:** {value}")

    @staticmethod
    def _fmt_currency_us(value) -> str:
        """US-style dollar string for synthesized tables ($1,234.56)."""
        if value is None:
            return "—"
        try:
            n = float(value)
            return f"${n:,.2f}"
        except (TypeError, ValueError):
            return str(value).replace("|", "/")

    @staticmethod
    def _transaction_rows_markdown(rows: list | None) -> str:
        if not rows:
            return "_No transactions matched this window on file._"
        hdr = "| Date | Type | Description | Amount | Balance | Reference |"
        sep = "|------|------|-------------|-------:|--------:|-----------|"

        def _cell(val) -> str:
            s = str(val if val is not None else "").replace("|", "/").replace("\n", " ")
            return s

        lines = [hdr, sep]
        for r in rows:
            if not isinstance(r, dict):
                continue
            lines.append(
                f"| {_cell(r.get('date'))} | {_cell(r.get('type'))} | "
                f"{_cell(r.get('description'))} "
                f"| {ResponseSynthesizerAgent._fmt_currency_us(r.get('amount'))} "
                f"| {ResponseSynthesizerAgent._fmt_currency_us(r.get('running_balance'))} "
                f"| {_cell(r.get('reference_id'))} |"
            )
        return "\n".join(lines)

    def _format_transaction_history(self, tx: dict, whitelist: set[str]) -> str:
        op_u = str(tx.get("operation", "")).upper()
        accounts_list = tx.get("accounts")
        if op_u == "TRANSACTION_HISTORY_MULTI" and isinstance(accounts_list, list) and accounts_list:
            n = tx.get("account_count", len(accounts_list))
            parts_multi = ["**Transaction history**\n"]
            ci = tx.get("combined_total_inflow")
            co = tx.get("combined_total_outflow")
            if ci is not None or co is not None:
                ci_disp = ResponseSynthesizerAgent._fmt_currency_us(ci)
                co_disp = ResponseSynthesizerAgent._fmt_currency_us(co)
                parts_multi.append(
                    "Totals across retrieved accounts "
                    f"(inflows **{ci_disp}**, outflows **{co_disp}**).\n"
                )
            parts_multi.append(f"**Your accounts ({n})**\n")

            for acct in accounts_list:
                if not isinstance(acct, dict):
                    continue
                label = str(acct.get("account_type", "")).replace("_", " ").strip()
                disp = acct.get("account_display") or ""
                head = label + (f" — {disp}" if disp else "")
                parts_multi.append(f"\n**{head or 'Account'}**\n")
                ps = acct.get("period_start")
                pe = acct.get("period_end")
                if ps and pe:
                    parts_multi.append(
                        f"Window: **{ps}** through **{pe}**.\n"
                    )
                cnt = acct.get("transaction_count")
                if cnt is not None:
                    parts_multi.append(
                        f"Showing **{cnt}** row(s) (caps may apply).\n"
                    )
                parts_multi.append(self._transaction_rows_markdown(acct.get("transactions")))
                parts_multi.append("")
            errs = tx.get("partial_errors")
            if isinstance(errs, list) and errs:
                parts_multi.append("**Notes**")
                for e in errs[:12]:
                    if e:
                        parts_multi.append(f"  • {e}")
            return "\n".join(parts_multi).strip()

        _skip_tx = frozenset({
            "confirmation_number",
            "status",
            "success",
            "operation",
            "errors",
            "partial_errors",
            "transactions",
        })
        intro = "**Transaction history**\n\nPosted activity on file "
        ps = tx.get("period_start")
        pe = tx.get("period_end")
        if ps and pe:
            intro += f"for **{ps}** through **{pe}**.\n\n"
        else:
            intro += "for the retrieved window.\n\n"
        parts_one = [intro]
        for key in ("transaction_count", "plan_name"):
            val = tx.get(key)
            if val in (None, ""):
                continue
            if key not in whitelist:
                continue
            parts_one.append(
                f"**{key.replace('_', ' ').title()}:** {val}",
            )
        parts_one.append("")
        parts_one.append(self._transaction_rows_markdown(tx.get("transactions")))
        for key, value in tx.items():
            if key in _skip_tx or key in (
                "transaction_count",
                "plan_name",
                "period_start",
                "period_end",
                "account_type",
                "account_display",
                "as_of",
            ):
                continue
            if key not in whitelist:
                continue
            if value in (None, "", []):
                continue
            parts_one.append(
                f"**{key.replace('_', ' ').title()}:** {value}",
            )
        return "\n".join(parts_one)

    def _format_rmd_estimate(self, tx: dict, whitelist: set[str]) -> str:
        rmd_needed = tx.get("rmd_required") is True
        intro_required = (
            "Illustrative figures from your verified records. "
            "No distribution has been scheduled or processed.\n"
        )
        intro_not_required = (
            "**No RMD is due from this account right now**\n\n"
            "Based on your age or this account type, you aren't required to "
            "take a minimum distribution yet. The details below summarize what "
            "we used for this illustration. Nothing has been scheduled or "
            "processed.\n"
        )
        intro = intro_required if rmd_needed else intro_not_required

        if tx.get("multi_account") and isinstance(tx.get("per_account"), list):
            parts = ["**RMD estimate**\n"]
            if rmd_needed:
                parts.append(
                    "Per-account RMD illustration. Combined totals include only "
                    "accounts where an RMD currently applies.\n"
                )
            else:
                parts.append(
                    "Per-account illustration. None of these accounts currently "
                    "requires an RMD; figures show why.\n"
                )
            per = tx["per_account"]
            acct_n = len(per)
            parts.append(f"**Retirement accounts ({acct_n})**")
            for row in per:
                if not isinstance(row, dict):
                    continue
                label = str(row.get("account_type", "Account")).replace("_", " ")
                disp = row.get("account_display", "")
                header = f"{label}" + (f" ({disp})" if disp else "")
                parts.append(f"\n• {header}")
                for k in (
                    "rmd_required",
                    "rmd_amount",
                    "remaining_rmd",
                    "penalty_if_missed",
                    "prior_year_end_balance",
                    "tax_year",
                    "owner_age",
                    "first_rmd_year",
                    "reason",
                ):
                    v = row.get(k)
                    if v in (None, "", 0, 0.0) and k not in (
                        "rmd_required",
                        "rmd_amount",
                        "remaining_rmd",
                    ):
                        continue
                    parts.append(f"   {k.replace('_', ' ').title()}: {v}")
            cr = tx.get("combined_rmd_amount")
            crm = tx.get("combined_remaining_rmd")
            if cr is not None or crm is not None:
                parts.append("")
                if cr is not None:
                    parts.append(f"**Combined RMD amount:** {cr}")
                if crm is not None:
                    parts.append(f"**Combined remaining RMD:** {crm}")
            errs = tx.get("errors")
            if isinstance(errs, list) and errs:
                parts.append("\n**Notes**")
                for e in errs[:12]:
                    if e:
                        parts.append(f"  • {e}")
            return "\n".join(parts)

        _skip_r = frozenset({
            "success",
            "status",
            "operation",
            "errors",
            "partial_errors",
            "multi_account",
            "per_account",
            "combined_rmd_amount",
            "combined_remaining_rmd",
            "account_count",
        })
        parts_one = ["**RMD estimate**\n"]
        parts_one.append(intro)
        self._append_whitelisted_fields(parts_one, tx, whitelist=whitelist, skip=_skip_r)
        return "\n".join(parts_one)

    def _format_loan_eligibility(self, tx: dict, whitelist: set[str]) -> str:
        intro = (
            "Borrowing limits from plan rules and IRC 72(p). "
            "Nothing has been lent or disbursed yet.\n"
        )
        _skip = frozenset({
            "success", "status", "operation", "errors", "partial_errors",
        })
        parts = ["**Loan eligibility**\n", intro]
        self._append_whitelisted_fields(parts, tx, whitelist=whitelist, skip=_skip)
        return "\n".join(parts)

    @staticmethod
    def _format_loan_row(loan: dict) -> list[str]:
        order = (
            "loan_id",
            "loan_type",
            "status",
            "principal_amount",
            "outstanding_balance",
            "monthly_payment",
            "interest_rate",
            "term_months",
            "payments_made",
            "payments_remaining",
            "first_payment_date",
            "maturity_date",
        )
        lines: list[str] = []
        for k in order:
            if k not in loan:
                continue
            v = loan.get(k)
            if v in (None, ""):
                continue
            lines.append(f"   {k.replace('_', ' ').title()}: {v}")
        return lines

    def _format_loan_status(self, tx: dict) -> str:
        parts = ["**Your plan loans**\n"]
        parts.append(
            "Loan activity on file after verification. "
            "No payment or disbursement was processed in this session.\n"
        )
        if tx.get("message"):
            parts.append(str(tx["message"]))
        loans = tx.get("loans")
        if isinstance(loans, list) and loans:
            for i, loan in enumerate(loans, start=1):
                if not isinstance(loan, dict):
                    continue
                parts.append(f"\n**Loan {i}**")
                parts.extend(self._format_loan_row(loan))
        ad = tx.get("account_display")
        pt = tx.get("plan_type")
        if ad:
            parts.append(f"\n**Account:** {ad}")
        if pt:
            parts.append(f"**Plan type:** {pt.replace('_', ' ')}")
        if tx.get("loan_count") is not None:
            parts.append(f"**Loan count:** {tx['loan_count']}")
        return "\n".join(parts)

    def _format_loan_preview(self, tx: dict, whitelist: set[str]) -> str:
        intro = (
            "Estimated payment schedule for planning only. "
            "The loan is not final until you confirm.\n"
        )
        _skip = frozenset({
            "success", "status", "operation", "errors", "partial_errors",
        })
        parts = ["**Loan preview**\n", intro]
        self._append_whitelisted_fields(parts, tx, whitelist=whitelist, skip=_skip)
        return "\n".join(parts)

    def _core_transaction_complete(self, state: GraphState) -> str:
        """Transaction completion with result details."""
        tx_result = state.get("transaction_result")
        if not tx_result:
            return "Your request has been submitted for processing."

        # Status-aware rendering: a FAILED tool execution must NOT be
        # presented to the customer as "Transaction Completed".  Render a
        # failure message instead, with the tool's reason if provided.
        status_raw = ""
        reason = ""
        if isinstance(tx_result, dict):
            status_raw = str(tx_result.get("status", "")).upper()
            # Tools may surface failure detail under any of these keys;
            # ``errors`` is the standard list-shape produced by BaseTool
            # ``_failure()`` helpers (e.g. balance_inquiry's
            # "You don't have a 403B account on file. Available accounts: ...").
            errors_field = tx_result.get("errors")
            if isinstance(errors_field, (list, tuple)):
                errors_joined = " ".join(str(e) for e in errors_field if e)
            else:
                errors_joined = str(errors_field) if errors_field else ""
            reason = (
                tx_result.get("reason")
                or tx_result.get("error")
                or tx_result.get("message")
                or errors_joined
                or ""
            )
        if status_raw in {"FAILED", "ERROR", "REJECTED", "CANCELLED", "CANCELED"}:
            spec_head = (
                self._read_only_failure_heading(tx_result)
                if isinstance(tx_result, dict)
                else None
            )
            head = spec_head or "**Transaction Could Not Be Completed**\n"
            parts = [head]
            parts.append(f"Status: {status_raw.title()}")
            if reason:
                parts.append(f"Reason: {reason}")
            parts.append(
                "I'm sorry for the inconvenience. Let me connect you with a "
                "specialist who can help resolve this, or you may provide "
                "any missing details and we can try again."
            )
            return "\n".join(parts)

        # Whitelist of keys safe to display to the customer.
        # Tools may include internal data (latency, API IDs, debug info)
        # that must never reach the customer-facing response.
        # Fix 142: Aligned with actual tool transaction_result keys.
        _DISPLAY_WHITELIST = {
            # — Common ————————————————————————————————————————————————————————
            "confirmation_number", "status", "amount", "effective_date",
            "account_type", "plan_type", "plan_name", "operation",
            # — Balance inquiry ———————————————————————————————————————————————
            "total_balance", "vested_balance", "unvested_balance",
            "vested_percentage", "ytd_contributions", "ytd_employer_match",
            "employer_match_remaining", "outstanding_loan_balance", "as_of",
            # — Transaction history ———————————————————————————————————————————
            "transactions", "period_start", "period_end", "transaction_count",
            "combined_total_inflow", "combined_total_outflow",
            "combined_inflow", "combined_outflow", "accounts", "partial_errors",
            # — Withdrawal ————————————————————————————————————————————————————
            "gross_amount", "net_disbursement", "federal_withholding",
            "state_withholding", "early_withdrawal_penalty",
            "delivery_method", "distribution_type", "penalty_applies",
            "estimated_arrival_days",
            # — Plan loan —————————————————————————————————————————————————————
            "principal_amount", "interest_rate", "term_months",
            "loan_term_months", "monthly_payment", "first_payment_date",
            "maturity_date", "total_interest", "total_repayment",
            "loan_type", "eligible", "max_loan_amount",
            "irc_72p_limit", "rejection_reason", "highest_loan_balance_12m",
            "plan_allows_loans", "loan_count", "message", "account_display",
            "loan_id", "payments_made", "payments_remaining",
            "outstanding_balance",
            # — RMD calculator ————————————————————————————————————————————————
            "rmd_amount", "rmd_required", "remaining_rmd", "owner_age",
            "tax_year", "distribution_period", "prior_year_end_balance",
            "ytd_distributions", "penalty_if_missed", "first_rmd_year",
            "rmd_start_age", "penalty_rate", "rmd_deadline_passed", "reason",
            "combined_rmd_amount", "combined_remaining_rmd", "account_count",
            # — IRA rollover ——————————————————————————————————————————————————
            "rollover_amount", "rollover_type",
            "source_account_type", "destination_account_type",
            "target_account_type", "tax_event",
            "estimated_completion_days",
            # — Beneficiary manager ———————————————————————————————————————————
            "beneficiary_name", "beneficiary_share", "beneficiary_count",
            "primary_percentage_total", "contingent_percentage_total",
            "spousal_consent_required",
            # — Legacy / payment ——————————————————————————————————————————————
            "payment_method", "next_payment_date", "new_balance",
            "distribution_code",
        }

        rok = (
            self._read_only_execute_kind(tx_result)
            if isinstance(tx_result, dict)
            else None
        )

        if rok in ("rmd", "rmd_not_required") and isinstance(tx_result, dict):
            return self._format_rmd_estimate(tx_result, _DISPLAY_WHITELIST)
        if rok == "loan_eligibility" and isinstance(tx_result, dict):
            return self._format_loan_eligibility(tx_result, _DISPLAY_WHITELIST)
        if rok == "loan_status" and isinstance(tx_result, dict):
            return self._format_loan_status(tx_result)
        if rok == "loan_preview" and isinstance(tx_result, dict):
            return self._format_loan_preview(tx_result, _DISPLAY_WHITELIST)

        if rok == "transactions" and isinstance(tx_result, dict):
            return self._format_transaction_history(tx_result, _DISPLAY_WHITELIST)

        if rok == "balance" and isinstance(tx_result, dict):
            # Multi-account balance aggregate: friendly overview wording.
            accounts_list = tx_result.get("accounts")
            if isinstance(accounts_list, list) and accounts_list:
                count = tx_result.get("account_count", len(accounts_list))
                combined = tx_result.get("combined_total_balance")
                parts_bs = ["**Account overview**\n"]
                parts_bs.append(
                    "Here's a consolidated view of the accounts you asked about.\n"
                )
                parts_bs.append(f"**Your accounts ({count})**")
                for acct in accounts_list:
                    if not isinstance(acct, dict):
                        continue
                    a_type = acct.get("account_type", "")
                    a_disp = acct.get("account_display", "")
                    header = " ".join(x for x in (a_type, a_disp) if x).strip()
                    parts_bs.append(f"\n• {header or 'Account'}")
                    for k in (
                        "plan_name", "total_balance", "vested_balance",
                        "vested_percentage", "as_of",
                    ):
                        v = acct.get(k)
                        if v in (None, "", 0) and k not in ("total_balance", "vested_balance"):
                            continue
                        parts_bs.append(f"   {k.replace('_', ' ').title()}: {v}")
                if combined is not None:
                    parts_bs.append(f"\n**Combined balances:** {combined}")
                return "\n".join(parts_bs)

            # Single-account snapshot
            _skip_bs = frozenset({
                "confirmation_number",
                "status",
                "success",
                "operation",
                "errors",
                "partial_errors",
            })
            parts_one = ["**Account overview**\n"]
            parts_one.append(
                "Here are the balances and plan figures on record after verifying it's you.\n"
            )
            for key, value in tx_result.items():
                if key in _skip_bs:
                    continue
                if key not in _DISPLAY_WHITELIST:
                    continue
                display_key = key.replace("_", " ").title()
                parts_one.append(f"**{display_key}:** {value}")
            return "\n".join(parts_one)

        if (
            isinstance(tx_result, dict)
            and str(tx_result.get("operation", "")).upper() == "INITIATE"
            and tx_result.get("success") is True
            and str(tx_result.get("status", "")).upper() == "COMPLETED"
        ):
            parts = ["**Plan loan finalized**\n"]
            parts.append(
                "Your plan loan request was recorded. "
                "What follows is a read-only summary of the borrower record "
                "(amount, repayment, and identifiers). "
                "No further action is taken in this reply.\n"
            )
        else:
            parts = ["**Confirmation summary**\n"]
            parts.append(
                "Here's a concise read-only summary of what we processed "
                "from your verified request.\n"
            )

        if isinstance(tx_result, dict):
            conf = tx_result.get("confirmation_number", "")
            if conf:
                parts.append(f"Confirmation Number: {conf}")
            status_val = tx_result.get("status", "")
            if status_val:
                parts.append(f"Status: {status_val}")

            # Include only whitelisted summary fields (non-balance tooling)
            for key, value in tx_result.items():
                if key in ("confirmation_number", "status"):
                    continue
                if key not in _DISPLAY_WHITELIST:
                    continue
                display_key = key.replace("_", " ").title()
                parts.append(f"{display_key}: {value}")
        return "\n".join(parts)

    def _core_escalation(self, state: GraphState, plan: ActionPlan) -> str:
        """Escalation message."""
        ctx = plan.escalation_context or state.get("escalation_context")
        if ctx:
            return (
                "I'm going to connect you with a specialist who can better "
                "assist you with this matter. They'll have the full context "
                "of our conversation."
            )
        return (
            "Let me connect you with a team member who can help "
            "you further with this request."
        )

    def _core_auth(self, state: GraphState) -> str:
        """Auth challenge from template."""
        scratch = state.get("scratch", {})
        challenge = scratch.get("pending_auth_challenge")
        if challenge and isinstance(challenge, dict):
            ctype = challenge.get("challenge_type", "")
            template = self._load_template("auth_challenge")
            variants = template.get("variants", {})
            variant = variants.get(ctype, {})
            return variant.get("prompt_text", "Please verify your identity to continue.")
        return "For your security, I need to verify your identity before proceeding."

    # — Layer 3: Compliance Tail ——————————————————————————————————————————————

    def _build_compliance_tail(
        self, tail_ids: list[str]
    ) -> tuple[str, list[str]]:
        """Load verbatim compliance disclosures. Returns (text, appended_ids)."""
        if not tail_ids:
            return "", []

        library = self._load_all_compliance()
        texts: list[str] = []
        appended: list[str] = []

        for tid in tail_ids:
            entry = library.get(tid)
            if entry:
                texts.append(entry["text"])
                appended.append(tid)
            else:
                log.warning("synthesizer_missing_disclosure", disclosure_id=tid)

        return "\n\n".join(texts), appended

    # — Fallback ——————————————————————————————————————————————————————————————

    def _fallback_response(self, action_type: ActionType) -> dict:
        """Safe fallback when the planner provided no action plan."""
        return {
            "last_synthesized_response": {
                "opening_frame": "I apologize for the inconvenience.",
                "core_content": "Let me connect you with a specialist who can help.",
                "compliance_tail": "",
                "full_message": "I apologize for the inconvenience.\n\nLet me connect you with a specialist who can help.",
                "action_type": action_type.value,
                "disclosures_appended": [],
            },
        }

    def health_check(self) -> bool:
        # Verify templates directory exists and has at least one template
        return _TEMPLATES_DIR.exists() and any(_TEMPLATES_DIR.glob("*.json"))
