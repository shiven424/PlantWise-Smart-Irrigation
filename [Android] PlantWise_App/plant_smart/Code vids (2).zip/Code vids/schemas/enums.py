from __future__ import annotations

"""
Central enums used across the contact-center agent system.

This module contains:
 - conversation/message classification enums
 - entity typing enums
 - authentication / validation enums
 - planner action enums
 - escalation enums
 - tool execution lifecycle enums

These enums are shared across:
 - graph orchestration
 - agent request/response contracts
 - graph state
 - planner / router logic
"""

from enum import Enum


# ==============================================================================
# Conversation / message classification
# ==============================================================================

class MessageDomain(str, Enum):
    """
    High-level classification of the customer's latest message.
    """
    INFORMATIONAL = "INFORMATIONAL"
    TRANSACTIONAL = "TRANSACTIONAL"
    CHITCHAT = "CHITCHAT"
    ESCALATE = "ESCALATE"


# ==============================================================================
# Entity typing
# ==============================================================================

class EntityType(str, Enum):
    """
    Supported extracted entity types across all service domains.
    """

    # ---------- Money / Numeric ----------
    DOLLAR_AMOUNT = "DOLLAR_AMOUNT"
    PERCENTAGE = "PERCENTAGE"
    COVERAGE_AMOUNT = "COVERAGE_AMOUNT"
    PREMIUM_AMOUNT = "PREMIUM_AMOUNT"
    ORDER_QUANTITY = "ORDER_QUANTITY"
    ORDER_PRICE = "ORDER_PRICE"
    BENEFICIARY_PERCENTAGE = "BENEFICIARY_PERCENTAGE"
    INVESTMENT_PRODUCT = "INVESTMENT_PRODUCT"

    # ---------- Accounts / Instruments ----------
    ACCOUNT_TYPE = "ACCOUNT_TYPE"
    ACCOUNT_NUMBER = "ACCOUNT_NUMBER"
    FUND_NAME = "FUND_NAME"
    TICKER_SYMBOL = "TICKER_SYMBOL"
    PORTFOLIO_ALLOCATION = "PORTFOLIO_ALLOCATION"
    LOT_SELECTION_METHOD = "LOT_SELECTION_METHOD"
    ORDER_TYPE = "ORDER_TYPE"

    # ---------- Dates / Time ----------
    DATE = "DATE"
    DATE_RANGE = "DATE_RANGE"
    TAX_YEAR = "TAX_YEAR"
    AGE = "AGE"
    TERM_MONTHS = "TERM_MONTHS"

    # ---------- Personal Identifiers (PII) ----------
    FULL_NAME = "FULL_NAME"
    SSN = "SSN"
    DATE_OF_BIRTH = "DATE_OF_BIRTH"
    TAX_ID = "TAX_ID"
    PHONE_NUMBER = "PHONE_NUMBER"
    EMAIL_ADDRESS = "EMAIL_ADDRESS"
    ADDRESS = "ADDRESS"

    # ---------- Retirement Specific ----------
    PLAN_TYPE = "PLAN_TYPE"
    CONTRIBUTION_AMOUNT = "CONTRIBUTION_AMOUNT"
    CONTRIBUTION_YEAR = "CONTRIBUTION_YEAR"
    WITHDRAWAL_AMOUNT = "WITHDRAWAL_AMOUNT"
    LOAN_AMOUNT = "LOAN_AMOUNT"
    ROLLOVER_AMOUNT = "ROLLOVER_AMOUNT"
    ROLLOVER_TYPE = "ROLLOVER_TYPE"
    WITHHOLDING_PERCENT = "WITHHOLDING_PERCENT"
    DISTRIBUTION_TYPE = "DISTRIBUTION_TYPE"
    RMD_AGE = "RMD_AGE"
    REPAYMENT_TERM = "REPAYMENT_TERM"
    VESTED_BALANCE = "VESTED_BALANCE"
    DELIVERY_METHOD = "DELIVERY_METHOD"
    WITHHOLDING_TYPE = "WITHHOLDING_TYPE"

    # ---------- Beneficiaries / Trust ----------
    BENEFICIARY_NAME = "BENEFICIARY_NAME"
    BENEFICIARY_RELATION = "BENEFICIARY_RELATION"
    BENEFICIARY_DOB = "BENEFICIARY_DOB"
    BENEFICIARY_TYPE = "BENEFICIARY_TYPE"
    TRUST_NAME = "TRUST_NAME"

    # ---------- Risk / Preferences ----------
    RISK_TOLERANCE = "RISK_TOLERANCE"
    INVESTMENT_HORIZON = "INVESTMENT_HORIZON"
    REBALANCE_FREQUENCY = "REBALANCE_FREQUENCY"

    # ---------- Scheduling / Frequency ----------
    DISTRIBUTION_FREQUENCY = "DISTRIBUTION_FREQUENCY"
    DOCUMENT_TYPE = "DOCUMENT_TYPE"
    REINVEST_OPTION = "REINVEST_OPTION"

    # ---------- Insurance / Policy ----------
    POLICY_NUMBER = "POLICY_NUMBER"

    # ---------- Other ----------
    BANK_ACCOUNT_NUMBER = "BANK_ACCOUNT_NUMBER"
    BANK_ROUTING_NUMBER = "BANK_ROUTING_NUMBER"
    EMPLOYER_NAME = "EMPLOYER_NAME"
    STATE = "STATE"
    COUNTRY = "COUNTRY"


# Entity types treated as PII / highly sensitive by system policy.
PII_ENTITY_TYPES: set[EntityType] = {
    EntityType.ACCOUNT_NUMBER,
    EntityType.SSN,
    EntityType.DATE_OF_BIRTH,
    EntityType.ADDRESS,
    EntityType.PHONE_NUMBER,
    EntityType.EMAIL_ADDRESS,
    EntityType.TAX_ID,
    EntityType.BENEFICIARY_NAME,
    EntityType.BENEFICIARY_DOB,
    EntityType.BANK_ACCOUNT_NUMBER,
    EntityType.BANK_ROUTING_NUMBER,
    EntityType.FULL_NAME,
    EntityType.POLICY_NUMBER,
    EntityType.EMPLOYER_NAME,
}


# ==============================================================================
# Service / intent classification
# ==============================================================================

class ServiceDomain(str, Enum):
    """
    Broad service area for the detected intent.
    """
    INVESTMENT_MANAGEMENT = "INVESTMENT_MANAGEMENT"
    RETIREMENT_SERVICES = "RETIREMENT_SERVICES"
    TAX_PLANNING = "TAX_PLANNING"
    ESTATE_AND_TRUST = "ESTATE_AND_TRUST"
    INSURANCE_AND_ANNUITY = "INSURANCE_AND_ANNUITY"
    BROKERAGE_AND_TRADING = "BROKERAGE_AND_TRADING"
    FINANCIAL_PLANNING = "FINANCIAL_PLANNING"
    ACCOUNT_ADMINISTRATION = "ACCOUNT_ADMINISTRATION"
    COMPLIANCE_REGULATORY = "COMPLIANCE_REGULATORY"
    CROSS_DOMAIN = "CROSS_DOMAIN"


class IntentChangeType(str, Enum):
    """
    How the active intent changed relative to earlier turns.
    """
    NEW = "NEW"
    REFINEMENT = "REFINEMENT"
    PIVOT = "PIVOT"
    CORRECTION = "CORRECTION"
    RESUME = "RESUME"


# ==============================================================================
# Authentication / validation
# ==============================================================================

class AuthLevel(int, Enum):
    """
    Required or achieved authentication level.
    """
    SESSION = 1
    SOFT = 2
    STRONG = 3
    ENHANCED = 4


class AuthStatus(str, Enum):
    """
    Current authentication status.
    """
    VERIFIED = "VERIFIED"
    PENDING = "PENDING"
    FAILED = "FAILED"
    LOCKED = "LOCKED"


class ChallengeType(str, Enum):
    """
    Supported authentication challenge types.
    """
    LAST_4_SSN = "LAST_4_SSN"
    DATE_OF_BIRTH = "DATE_OF_BIRTH"
    ACCOUNT_LAST4 = "ACCOUNT_LAST4"
    MOTHER_MAIDEN = "MOTHER_MAIDEN"
    ZIP_CODE = "ZIP_CODE"
    ONE_TIME_CODE = "ONE_TIME_CODE"
    BIOMETRIC = "BIOMETRIC"


class ValidationSeverity(str, Enum):
    """
    Severity level for validation violations.
    """
    BLOCKING = "BLOCKING"
    WARNING = "WARNING"
    INFORMATIONAL = "INFORMATIONAL"


class ValidationStatus(str, Enum):
    """
    Overall validation result status.
    """
    PASSED = "PASSED"
    FAILED = "FAILED"
    INCOMPLETE = "INCOMPLETE"
    WARNING = "WARNING"


# ==============================================================================
# Tool execution lifecycle
# ==============================================================================

class ToolExecutionStatus(str, Enum):
    """
    Lifecycle of a transactional tool/tool execution.
    """
    READY_TO_EXECUTE = "READY_TO_EXECUTE"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


# ==============================================================================
# Planner action types
# ==============================================================================

class ActionType(str, Enum):
    """
    Action planner outputs one of these action types to drive the next graph step.
    """
    CLARIFY = "CLARIFY"
    CHITCHAT_RESPOND = "CHITCHAT_RESPOND"
    END_SESSION = "END_SESSION"
    INITIATE_AUTH = "INITIATE_AUTH"
    AUTH_CHALLENGE = "AUTH_CHALLENGE"
    PROCESS_AUTH = "PROCESS_AUTH"
    ANSWER = "ANSWER"
    COLLECT_SLOT = "COLLECT_SLOT"
    VALIDATE_ENTITIES = "VALIDATE_ENTITIES"
    PRESENT_HITL = "PRESENT_HITL"
    HITL_CORRECTION = "HITL_CORRECTION"
    HITL_APPROVED = "HITL_APPROVED"
    EXECUTE_TRANSACTION = "EXECUTE_TRANSACTION"
    PUSH_INTENT = "PUSH_INTENT"
    POP_INTENT = "POP_INTENT"
    CORRECTION_ACK = "CORRECTION_ACK"
    ESCALATE = "ESCALATE"
    HANDLE_ERROR = "HANDLE_ERROR"
    RETRY_SLOT = "RETRY_SLOT"


# ==============================================================================
# Escalation reasons
# ==============================================================================

class EscalationReason(str, Enum):
    """
    Specific reasons why the workflow escalates to human handling or fallback.
    """
    DISTRESS_SIGNAL = "DISTRESS_SIGNAL"
    FINANCIAL_ADVICE = "FINANCIAL_ADVICE"
    LOW_RAG_CONFIDENCE = "LOW_RAG_CONFIDENCE"
    AUTH_LOCKED = "AUTH_LOCKED"
    AUTH_MISCONFIGURED = "AUTH_MISCONFIGURED"
    BLOCKING_VIOLATION = "BLOCKING_VIOLATION"
    COMPLAINT = "COMPLAINT"
    LEGAL_THREAT = "LEGAL_THREAT"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    TAX_ADVICE = "TAX_ADVICE"
    MAX_RETRIES = "MAX_RETRIES"
    MAX_CORRECTIONS = "MAX_CORRECTIONS"
    CLIENT_REQUESTED = "CLIENT_REQUESTED"
