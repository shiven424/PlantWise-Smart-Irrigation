"""Shared keyword -> EscalationReason mapping utilities.

Single source of truth used by:
  - supervisor/v1/hard_rules.py        (H1 classifier reason mapping)
  - intent_agent/v1/agent.py           (_map_escalation_reason)

Keeps both paths in sync and prevents silent divergence when keywords
or escalation reasons are added/removed.
"""

from __future__ import annotations

import re

from schemas.enums import EscalationReason


# -- Keyword -> EscalationReason table (order matters - first match wins) ------

KEYWORD_REASON_MAP: list[tuple[str, EscalationReason]] = [
    ("distress",      EscalationReason.DISTRESS_SIGNAL),
    ("suicide",       EscalationReason.DISTRESS_SIGNAL),
    ("harm",          EscalationReason.DISTRESS_SIGNAL),
    ("complaint",     EscalationReason.COMPLAINT),
    ("legal",         EscalationReason.LEGAL_THREAT),
    ("lawsuit",       EscalationReason.LEGAL_THREAT),
    ("tax",           EscalationReason.TAX_ADVICE),
    ("invest",        EscalationReason.FINANCIAL_ADVICE),
    ("advice",        EscalationReason.FINANCIAL_ADVICE),
    ("recommend",     EscalationReason.FINANCIAL_ADVICE),
    ("human",         EscalationReason.CLIENT_REQUESTED),
    ("person",        EscalationReason.CLIENT_REQUESTED),
    ("live agent",    EscalationReason.CLIENT_REQUESTED),
    ("real agent",    EscalationReason.CLIENT_REQUESTED),
    ("human agent",   EscalationReason.CLIENT_REQUESTED),
]

# -- Sub-intent IDs -> EscalationReason (used by intent_agent) ----------------

SUB_INTENT_REASON_MAP: dict[str, EscalationReason] = {
    "PERSONALISED_ADVICE":    EscalationReason.FINANCIAL_ADVICE,
    "COMPLAINT":              EscalationReason.COMPLAINT,
    "TAX_STRATEGY_ADVICE":    EscalationReason.TAX_ADVICE,
    "ESTATE_PLANNING_ADVICE": EscalationReason.FINANCIAL_ADVICE,
    "FRAUD_REPORT":           EscalationReason.LEGAL_THREAT,
    "RETIREMENT_PLANNING":    EscalationReason.FINANCIAL_ADVICE,
}


def keyword_to_escalation_reason(
    reason_str: str,
    *,
    default: EscalationReason = EscalationReason.CLIENT_REQUESTED,
    word_boundary: bool = True,
) -> EscalationReason:
    """Map a free-text reason string to an EscalationReason enum.

    Args:
        reason_str: The string to scan for keywords.
        default: Returned when no keyword matches.
        word_boundary: If True, uses letter-based boundary matching to
            prevent false positives (e.g. "tax" matching "syntax").
            If False, uses plain substring matching.
    """
    if not reason_str:
        return default

    lower = reason_str.lower()
    for keyword, reason in KEYWORD_REASON_MAP:
        if " " in keyword:
            # Multi-word phrases: plain substring match is safe
            if keyword in lower:
                return reason
        elif word_boundary:
            # (?<![a-z]) / (?![a-z]) ensures the keyword is not embedded
            # inside a larger word, but still matches across underscores.
            if re.search(rf"(?<![a-z]){re.escape(keyword)}(?![a-z])", lower):
                return reason
        else:
            if keyword in lower:
                return reason
    return default
