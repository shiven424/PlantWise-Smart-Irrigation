from __future__ import annotations

"""
Primitive shared models used across the contact-center AI system.

This module contains:
 - common strict base model
 - authentication primitives
 - business / validation primitives
 - entity and intent records
 - planner summary objects
 - HITL and tool execution state models

These models are used by:
 - schemas/agent_io.py
 - schemas/graph_state.py
 - agents/*
 - graph orchestration
"""

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from schemas.enums import (
    ActionType,
    AuthLevel,
    AuthStatus,
    ChallengeType,
    EntityType,
    EscalationReason,
    IntentChangeType,
    MessageDomain,
    ServiceDomain,
    ValidationSeverity,
    ValidationStatus,
    ToolExecutionStatus,
)


# ==============================================================================
# Base model
# ==============================================================================

class StrictBase(BaseModel):
    """
    Strict base model for all shared schemas.

    Behavior:
     - Forbids unknown fields (`extra="forbid"`)
     - Validates assignment after object creation
    """
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


# ==============================================================================
# Authentication primitives
# ==============================================================================

class AuthState(StrictBase):
    """
    Current authentication state for the active session.
    """
    current_level: AuthLevel = AuthLevel.SESSION
    is_locked: bool = False
    failed_attempts: int = 0
    last_challenge_type: str | None = None
    verified_at: datetime | None = None


class AuthVerificationInput(StrictBase):
    """
    User-provided authentication challenge response.
    """
    challenge_type: str
    raw_response: str
    attempt_number: int
    timestamp: datetime


class AuthChallenge(StrictBase):
    """
    Authentication challenge presented to the user.
    """
    challenge_type: ChallengeType
    prompt_text: str
    expected_hash: str = ""
    max_attempts: int
    expires_at: datetime | None = None

    @model_validator(mode="after")
    def prompt_text_must_be_question(self) -> "AuthChallenge":
        if self.prompt_text and not self.prompt_text.endswith("?"):
            import logging
            logging.getLogger("contact_center").warning(
                "[auth_challenge] prompt_text does not end with '?' - "
                "auto-appending.  Original: %r",
                self.prompt_text,
            )
            object.__setattr__(self, "prompt_text", self.prompt_text.rstrip("?.!;:") + "?")
        return self


class AuthVerificationResult(StrictBase):
    """
    Result of evaluating a user's authentication response.
    """
    challenge_type: str
    passed: bool
    combined_score: float


# ==============================================================================
# Business / account / session context
# ==============================================================================

class AccountContext(StrictBase):
    """
    Account-level contextual information used for validation and decisioning.
    """
    account_type: str
    vested_balance: float
    account_age_days: int
    owner_age_years: float
    is_active: bool
    plan_rules: dict[str, Any] = Field(default_factory=dict)


class BusinessRule(StrictBase):
    """
    A single business/regulatory rule used by validation logic.
    """
    rule_id: str
    category: str
    severity: ValidationSeverity
    description: str
    regulatory_ref: str


class SessionContext(StrictBase):
    """
    Session-level metadata for the current customer conversation.
    """
    session_id: UUID
    user_id: str | None = None
    channel: str
    client_tier: str = "STANDARD"
    locale: str = "en-US"
    started_at: datetime


# ==============================================================================
# Retrieval / citation / validation artifacts
# ==============================================================================

class SourceCitation(StrictBase):
    """
    Lightweight citation object used by RAG responses.

    This model is intentionally lean for checkpoint safety:
    it stores only metadata and short snippets, not full chunks.
    """
    document_name: str
    section: str
    page: int | None = None
    snippet: str | None = None
    chunk_id: str | None = None
    relevance_score: float = 0.0
    freshness_date: datetime | None = None


class ValidationViolation(StrictBase):
    """
    Describes a validation or compliance violation produced by the validator.
    """
    rule_id: str
    regulatory_ref: str
    severity: ValidationSeverity
    category: str
    violated_entity: str | None = None   # entity_id str, or None when rule is entity-agnostic
    customer_message: str
    suggested_fix: str | None = None
    correctable: bool = False


class HITLDisclosureItem(StrictBase):
    """
    Human-in-the-loop disclosure or acknowledgment item that may need to be shown
    to the customer before execution continues.
    """
    disclosure_id: str
    category: str
    display_text: str
    requires_ack: bool = True


# ==============================================================================
# Response / escalation planning
# ==============================================================================

# Valid tone values used by the action planner and synthesizer.
Tone = Literal["EMPATHETIC", "PROFESSIONAL", "GENTLE", "URGENT"]


class ResponseDirective(StrictBase):
    """
    Output guidance for the synthesizer:
    tone, templates, hints, compliance tails.
    """
    tone: Tone
    template_id: str | None = None
    content_hints: list[str] = Field(default_factory=list)
    compliance_tail_ids: list[str] = Field(default_factory=list)


class EscalationContext(StrictBase):
    """
    Context explaining why escalation was triggered.
    """
    reason: EscalationReason
    triggered_by: str
    client_message: str = ""
    carry_context: bool = True


class ActionPlan(StrictBase):
    """
    Action chosen by the Action Planner for the current turn.
    """
    action_type: ActionType
    target_slot: str | None = None
    response_directive: ResponseDirective
    state_delta: dict[str, Any] = Field(default_factory=dict)
    escalation_context: EscalationContext | None = None
    hard_rule_fired: str | None = None


# ==============================================================================
# Entity / intent records
# ==============================================================================

class EntityRecord(StrictBase):
    """
    Canonical entity record stored in graph state.

    Notes:
     - `raw_value` may contain unnormalized content
     - `display_value` is safe for user-facing or masked display
     - `vault_token` should be used for sensitive PII values where applicable
    """
    entity_id: UUID
    entity_type: EntityType
    is_pii: bool
    slot_name: str | None = None
    ambient_key: str | None = None
    raw_value: Any | None = Field(default=None, exclude=True)  # ✓ Prevents PII serialization
    display_value: str | None = None
    vault_token: str | None = None
    confidence: float = 0.0
    turn_confirmed: int | None = None
    is_confirmed: bool = False
    source_text: str | None = None
    contradicts: UUID | None = None


class IntentRecord(StrictBase):
    """
    Canonical intent record stored in graph state.

    Tracks:
     - the active/paused intent
     - service domain
     - auth requirement
     - required slots
    """
    intent_id: str
    service_domain: ServiceDomain
    sub_intent: str
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    change_type: IntentChangeType = IntentChangeType.NEW
    requires_auth_level: AuthLevel = AuthLevel.SESSION
    is_transactional: bool = False
    escalation_flag: bool = False
    required_slots: list[str] = Field(default_factory=list)
    paused_at_turn: int | None = None
    turn_number: int = 0


# ==============================================================================
# Planner summary
# ==============================================================================

class AgentOutputSummary(StrictBase):
    """
    Compact summary of upstream agent outputs passed into the Supervisor.

    This keeps the supervisor context lean while still preserving the most important
    orchestration signals.
    """
    classifier_domain: MessageDomain
    classifier_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    classifier_escalation: bool = False

    intent_id: str | None = None
    intent_escalation: bool = False

    slot_gap: list[str] = Field(default_factory=list)

    auth_level: AuthLevel = AuthLevel.SESSION
    auth_locked: bool = False
    auth_status: AuthStatus = AuthStatus.PENDING

    validation_status: ValidationStatus | None = None
    has_blocking_violations: bool = False
    violations: list[ValidationViolation] = Field(default_factory=list)

    rag_confidence: float | None = None
    rag_answer_available: bool = False

    hitl_pending: bool = False
    last_message: str = ""

    correction_count: int = 0
    retry_count: int = 0

    contradictions: list[str] = Field(default_factory=list)


# ==============================================================================
# Graph runtime helper states
# ==============================================================================

class LoopCounters(StrictBase):
    """
    Retry counters used to limit loops and enforce safe fallback/escalation.
    """
    slot_fill_attempts: int = 0
    clarification_attempts: int = 0
    confirmation_attempts: int = 0
    auth_attempts: int = 0


class HITLState(StrictBase):
    """
    Tracks the state of human-in-the-loop confirmation flow.
    """
    pending: bool = False
    pending_since: datetime | None = None    # UTC timestamp when HITL was presented
    attempt_count: int = 0
    max_attempts: int = 2
    confirm_keys: list[str] = Field(default_factory=list)
    last_prompt: str | None = None
    last_confirmed: bool | None = None
    last_corrections: dict[str, Any] = Field(default_factory=dict)


class ToolExecutionState(StrictBase):
    """
    Tracks tool/tool execution lifecycle for transactional requests.
    """
    in_flight: bool = False
    tool_agent_name: str | None = None
    tool_request_id: str | None = None
    idempotency_key: str | None = None
    status: ToolExecutionStatus | None = None
    receipt_id: str | None = None
    error_message: str | None = None
    last_updated_at: datetime | None = None
    result_payload: dict[str, Any] = Field(default_factory=dict)
