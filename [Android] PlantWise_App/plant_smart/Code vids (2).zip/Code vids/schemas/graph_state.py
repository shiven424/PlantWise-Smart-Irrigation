from __future__ import annotations

"""
GraphState - single source of truth for LangGraph conversation state.

Design decisions:
 - TypedDict (not Pydantic) so LangGraph can do partial-dict merges natively.
   Nodes return only the keys they changed; LangGraph handles the rest.
 - total=False makes every key optional in partial updates.
 - Annotated reducers (operator.add, _merge_dict) control how list/dict
   fields accumulate across node returns.
 - Message-classifier and RAG fields are stored FLAT (no embedded
   agent-response objects) to break the circular import with agent_io.
"""

import contextvars
import operator
import threading
from typing import Annotated, Any, TypedDict

from schemas.enums import (
    AuthLevel,
    AuthStatus,
    MessageDomain,
    ValidationStatus,
)
from schemas.primitives import (
    ActionPlan,
    AuthState,
    EntityRecord,
    EscalationContext,
    HITLDisclosureItem,
    HITLState,
    IntentRecord,
    LoopCounters,
    SessionContext,
    SourceCitation,
    ToolExecutionState,
    ValidationViolation,
)


# -- Orphaned vault token tracker ----------------------------------------------
# When _merge_dict overwrites an entity whose value contains a vault token,
# the old token becomes unreachable.  We track these per-conversation so
# _cleanup_vault_tokens() in main.py can delete them from the vault.#
# THREADING SAFETY NOTE (Fix H1):
# # • ``threading.Lock`` protects the shared ``_ORPHANED_VAULT_TOKENS`` dict
# against concurrent OS-thread writes.  This is correct because
# ``asyncio.to_thread()`` runs each graph invocation in its own thread.
# # • LangGraph's StateGraph.invoke() is synchronous and single-threaded
# within a single invocation - reducers (_merge_dict) are never called
# from multiple threads for the SAME graph run.
# # • ``contextvars.ContextVar`` (_reducer_conv_id) isolates the per-task
# conversation ID across concurrent asyncio tasks / threads.
# # • If LangGraph ever parallelises reducer calls within a single
# invocation, this assumption must be revisited.
_orphan_lock = threading.Lock()
_ORPHANED_VAULT_TOKENS: dict[str, list[str]] = {}  # conv_id -> [token, ...]

# Fix 147+155: Use contextvars.ContextVar instead of threading.local so
# the conversation_id is correctly scoped per asyncio task, not per OS
# thread.  asyncio.to_thread() copies the current context into the
# worker thread, so each concurrent graph invocation sees its own
# conversation_id - preventing cross-conversation token contamination.
_reducer_conv_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "reducer_conv_id", default="__global__",
)


def set_reducer_conversation_id(conversation_id: str) -> None:
    """Set the conversation_id for the current context's reducer calls."""
    _reducer_conv_id.set(conversation_id)


def _get_reducer_conversation_id() -> str:
    """Get the current context's conversation_id, or '__global__' fallback."""
    return _reducer_conv_id.get()


def get_orphaned_tokens(conversation_id: str) -> list[str]:
    """Return (and leave in place) orphaned vault tokens for a conversation."""
    with _orphan_lock:
        return list(_ORPHANED_VAULT_TOKENS.get(conversation_id, []))


def clear_orphaned_tokens(conversation_id: str) -> None:
    """Remove the orphaned-token list for a conversation after cleanup."""
    with _orphan_lock:
        _ORPHANED_VAULT_TOKENS.pop(conversation_id, None)


def _track_orphaned_token(conversation_id: str, token: str) -> None:
    """Record a single orphaned vault token."""
    with _orphan_lock:
        _ORPHANED_VAULT_TOKENS.setdefault(conversation_id, []).append(token)


# -- Reducers ------------------------------------------------------------------

# Sentinel value an agent may return inside a dict-typed reducer field
# to *delete* a key from the merged result.  Use sparingly — primarily
# intent_agent uses this to purge stale, non-PII slot entities from
# entity_memory when a NEW or PIVOT intent enters.  Without an explicit
# delete sentinel, _merge_dict can only add or overwrite keys (None is
# already treated as "skip" to prevent accidental wipes — see Fix C1).
class _DeleteSentinel:
    __slots__ = ()
    def __repr__(self) -> str:  # pragma: no cover — debugging aid
        return "<DELETE>"

DELETE = _DeleteSentinel()


def _merge_dict(old: dict, new: dict) -> dict:
    """Shallow-merge reducer: new keys overwrite old keys.

    When an old value being overwritten carries a vault token, it is
    recorded in _ORPHANED_VAULT_TOKENS so the cleanup routine can
    delete it from the vault provider.

    A value of ``DELETE`` removes the key from the merged result.
    """
    merged = dict(old or {})
    for key, new_val in (new or {}).items():
        # Fix C1: Reject None overwrites - an agent returning
        # {"entity_memory": {"account_number": None}} must NOT wipe
        # a previously-extracted EntityRecord.
        if new_val is None:
            continue
        # Explicit delete sentinel — used by intent_agent to purge stale
        # slot entities on intent transitions.  Vault token tracking still
        # runs so any token on the deleted entity is properly orphaned.
        if isinstance(new_val, _DeleteSentinel):
            old_val = merged.get(key)
            if old_val is not None:
                old_token = getattr(old_val, "vault_token", None)
                if old_token and isinstance(old_token, str) and (
                    old_token.startswith("vault:") or old_token.startswith("VAULT-")
                ):
                    _track_orphaned_token(
                        _get_reducer_conversation_id(), old_token,
                    )
                merged.pop(key, None)
            continue
        old_val = merged.get(key)
        if old_val is not None and old_val is not new_val:
            # Check if old value has a vault token that would be orphaned
            old_token = getattr(old_val, "vault_token", None)
            if old_token and isinstance(old_token, str) and (
                old_token.startswith("vault:") or old_token.startswith("VAULT-")
            ):
                new_token = getattr(new_val, "vault_token", None)
                if old_token != new_token:
                    # Fix 147: Use thread-local conversation_id set by main.py
                    # before each graph invocation, with "__global__" fallback.
                    _track_orphaned_token(
                        _get_reducer_conversation_id(), old_token,
                    )
        merged[key] = new_val
    return merged


def _append_messages(
    old: list[dict[str, str]], new: list[dict[str, str]]
) -> list[dict[str, str]]:
    """Append-only message history reducer with positional deduplication.

    Only ``main.py`` (the entry-point) should write to this field.
    If an agent accidentally returns ``message_history``, the guard
    below detects it and returns ``old`` unchanged - preventing silent
    message loss.

    Dedup key includes the message index so that intentionally repeated
    messages (e.g. user sends the same question twice across turns) are
    preserved while exact same list re-submissions are still rejected.
    """
    old = old or []
    new = new or []
    if not new:
        return old

    # Guard: if ``new`` is a superset or re-submission of ``old`` (an agent
    # accidentally returned the full message_history), ignore the update.
    # Only main.py should append incremental entries (1-2 messages at a time).
    # Detection: ``new`` contains ALL of ``old`` as a prefix AND adds more
    # entries than a legitimate per-turn append (max 2: user + assistant).
    if len(old) > 0 and len(new) >= len(old):
        prefix_match = all(
            old[i].get("role", "") == new[i].get("role", "") and old[i].get("content", "") == new[i].get("content", "")
            for i in range(len(old))
        )
        if prefix_match:
            # ``new`` is a superset of ``old`` - extract only the tail.
            new = new[len(old):]
            if not new:
                return old

    result = list(old)
    existing_len = len(result)
    seen = {(i, m.get("role", ""), m.get("content", "")) for i, m in enumerate(result)}
    for idx, msg in enumerate(new):
        key = (existing_len + idx, msg.get("role", ""), msg.get("content", ""))
        if key not in seen:
            result.append(msg)
            seen.add(key)
    return result


class GraphState(TypedDict, total=False):
    """
    LangGraph conversation state.

    TypedDict with total=False allows nodes to return partial updates;
    LangGraph merges them using the annotated reducers or last-write-wins.
    """

    # -- Session / thread ------------------------------------------------------
    session: SessionContext
    current_turn: int
    conversation_id: str | None          # ISO-safe; avoids UUID serialisation edge-cases
    created_at: str                       # ISO-8601 timestamp string
    updated_at: str

    # -- Conversation memory ---------------------------------------------------
    message_history: Annotated[list[dict[str, str]], _append_messages]
    last_user_message: str | None

    # -- Message classification (flat - avoids circular import) ----------------
    message_domain: MessageDomain | None
    classifier_confidence: float
    # classifier_escalation_flag: set by classifier, read by action planner
    # to build AgentOutputSummary.classifier_escalation.  Distinct from
    # escalation_requested which is the graph-wide escalation signal.
    classifier_escalation_flag: bool
    classifier_escalation_reason: str | None

    # -- Intent ----------------------------------------------------------------
    intent_stack: list[IntentRecord]
    active_intent_id: str | None
    # Intent IDs whose transactional execution has already completed in this
    # conversation.  Used by the supervisor policy to avoid re-executing a
    # read-only inquiry (e.g. balance) on follow-up chitchat like "Ok thanks".
    completed_intent_ids: list[str]

    # -- Entities --------------------------------------------------------------
    entity_memory: Annotated[dict[str, EntityRecord], _merge_dict]
    validated_entities: dict[str, EntityRecord]
    contradictions: Annotated[list[str], operator.add]

    # -- Slot filling ----------------------------------------------------------
    required_slots: list[str]
    slot_gap: list[str]
    last_requested_slot: str | None
    retry_count: int
    correction_count: int
    counters: LoopCounters

    # -- Auth ------------------------------------------------------------------
    auth_state: AuthState
    auth_status: AuthStatus
    required_auth_level: AuthLevel
    # User's typed answer to a pending auth challenge. Populated by main.py
    # at the start of a turn whenever an AuthChallenge is pending; cleared
    # by the auth agent after evaluation.
    verification_input: str | None
    # Optional fraud / device signals supplied by the API gateway.
    fraud_risk_score: float
    device_fingerprint: str | None

    # -- Validation / Compliance -----------------------------------------------
    validation_status: ValidationStatus | None
    violations: list[ValidationViolation]
    hitl_disclosures: list[HITLDisclosureItem]

    # -- RAG (flat - avoids circular import) -----------------------------------
    rag_answer: str | None
    rag_citations: list[SourceCitation]
    rag_confidence: float | None    # None = RAG not yet run; 0.0 = ran, zero confidence
    rag_caveats: list[str]
    rag_verification_passed: bool
    rag_freshness_warning: bool
    rag_error: str | None           # Non-None when KB init or pipeline failed

    # -- Action plan -----------------------------------------------------------
    current_action_plan: ActionPlan | None
    policy_path: str | None
    planner_reasoning: str | None

    # -- Escalation ------------------------------------------------------------
    escalation_requested: bool
    escalation_context: EscalationContext | None

    # -- HITL ------------------------------------------------------------------
    hitl: HITLState

    # -- Tool execution --------------------------------------------------------
    tool_exec: ToolExecutionState
    # -- Account / session context ---------------------------------------------
    # Populated at the start of each turn by main.py / the API gateway.
    # account_context holds static CRM data (balances, plan type, owner_age, etc.)
    # auth_token is the vault dereference token for the authenticated session.
    # Neither field may hold raw PII values.
    account_context: dict[str, Any]
    auth_token: str

    # -- User profile (loaded once at session start, read-only) ---------------
    # Cross-session user profile from the profile store.  Contains
    # display_name, recent_intents, default_entities, etc.  Never raw PII.
    user_profile: dict[str, Any]

    # -- Scratchpad (must be safe, no raw PII) ---------------------------------
    scratch: Annotated[dict[str, Any], _merge_dict]

    # -- Transaction result (written by tools) ----------------------------
    transaction_result: dict[str, Any] | None

    # -- Output ----------------------------------------------------------------
    last_synthesized_response: dict[str, Any] | None
