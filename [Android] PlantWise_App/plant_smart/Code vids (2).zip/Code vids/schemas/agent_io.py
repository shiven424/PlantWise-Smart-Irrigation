from __future__ import annotations

"""
Agent Input/Output Contracts
----------------------------

This module defines the request/response Pydantic models used by every
specialist agent in the system. These contracts form the "API boundary"
between the orchestrator (LangGraph nodes) and the remote/local agent logic.

IMPORTANT:
 - Do not modify these models arbitrarily.
 - All agents must strictly follow these contracts for predictable routing,
   planning, and LangGraph state merging.
"""

import re
from datetime import date, datetime
from uuid import UUID

from pydantic import Field, model_validator

from schemas.enums import (
    AuthLevel,
    AuthStatus,
    MessageDomain,
    PII_ENTITY_TYPES,
    ServiceDomain,
    ValidationSeverity,
    ValidationStatus,
    ActionType,
)

from schemas.primitives import (
    StrictBase,
    ActionPlan,
    AgentOutputSummary,
    AuthChallenge,
    AuthState,
    EntityRecord,
    HITLDisclosureItem,
    IntentRecord,
    SessionContext,
    SourceCitation,
    ValidationViolation,
    EscalationContext,
)

# ==============================================================================
# MESSAGE CLASSIFIER
# ==============================================================================

class MessageClassifierRequest(StrictBase):
    """
    Input to Message Classifier Agent.

    The classifier determines the high-level message domain:
      - INFORMATIONAL
      - TRANSACTIONAL
      - CHITCHAT
      - ESCALATE

    It may also flag safety/escalation cases.
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    message: str = Field(min_length=1, max_length=5000)
    recent_history: list[dict[str, str]] = Field(default_factory=list, max_length=6)

    @model_validator(mode="after")
    def history_roles_valid(self) -> "MessageClassifierRequest":
        valid_roles = {"user", "assistant"}
        for entry in self.recent_history:
            if entry.get("role") not in valid_roles:
                raise ValueError(
                    f"recent_history entry has invalid role: {entry.get('role')}. "
                    f"Valid roles: {valid_roles}"
                )
        return self


class MessageClassifierResponse(StrictBase):
    """
    Output from Message Classifier Agent.

    The classifier MUST set:
      - domain (MessageDomain)
    """
    domain: MessageDomain
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    escalation_flag: bool = False
    escalation_reason: str | None = None
    reasoning: str | None = None

    @model_validator(mode="after")
    def escalation_reason_required(self) -> "MessageClassifierResponse":
        # Auto-promote: ESCALATE domain always implies escalation_flag
        is_escalate_domain = self.domain == MessageDomain.ESCALATE
        if is_escalate_domain and not self.escalation_flag:
            object.__setattr__(self, "escalation_flag", True)
        if is_escalate_domain and not self.escalation_reason:
            object.__setattr__(self, "escalation_reason", "domain is ESCALATE")
        # After auto-promotion, enforce the invariant
        if self.escalation_flag and not self.escalation_reason:
            raise ValueError(
                "escalation_flag is True but escalation_reason is not set. "
                "Provide a reason when flagging for escalation."
            )
        return self


# ==============================================================================
# INTENT AGENT
# ==============================================================================

class IntentAgentRequest(StrictBase):
    """
    Input to Intent Agent.

    Provides:
      - user message
      - existing intent stack
      - extracted entities (minimal context)
      - message domain from classifier
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    message: str = Field(min_length=1)
    current_intents: list[IntentRecord] = Field(default_factory=list)
    entity_context: dict[str, str] = Field(default_factory=dict)
    message_domain: MessageDomain

    @model_validator(mode="after")
    def only_classify_non_escalate(self) -> "IntentAgentRequest":
        if self.message_domain == MessageDomain.ESCALATE:
            raise ValueError(
                "IntentAgent should not receive ESCALATE messages. "
                "Graph router must skip intent classification for escalation."
            )
        return self


class IntentAgentResponse(StrictBase):
    """
    Output from Intent Agent.

    Produces:
      - updated intent stack
      - primary intent
      - optional escalation signals
    """
    intent_stack: list[IntentRecord] = Field(min_length=1)
    escalation_flag: bool = False
    escalation_reason: str | None = None
    primary_intent: IntentRecord

    @model_validator(mode="after")
    def primary_must_be_stack_head(self) -> "IntentAgentResponse":
        if self.intent_stack and self.intent_stack[0].intent_id != self.primary_intent.intent_id:
            raise ValueError(
                f"primary_intent.intent_id ({self.primary_intent.intent_id}) "
                f"does not match intent_stack[0].intent_id ({self.intent_stack[0].intent_id}). "
                f"Primary intent must always be the head of the stack."
            )
        if self.escalation_flag and not self.escalation_reason:
            raise ValueError(
                "escalation_reason is required when escalation_flag=True."
            )
        return self


# ==============================================================================
# ENTITY EXTRACTION AGENT
# ==============================================================================

class EntityExtractionRequest(StrictBase):
    """
    Input to Entity Extraction Agent.

    Includes:
      - message
      - required slot names
      - preexisting extracted entities
      - active intent ID
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    message: str = Field(min_length=1)
    required_slots: list[str] = Field(default_factory=list)
    existing_entities: dict[str, EntityRecord] = Field(default_factory=dict)
    intent_id: str | None = None


class EntityExtractionResponse(StrictBase):
    """
    Output from Entity Extraction Agent.

    Produces:
      - extracted_entities
      - contradiction_flags
      - slots_filled / slots_still_missing
    """
    extracted_entities: list[EntityRecord] = Field(default_factory=list)
    contradiction_flags: list[UUID] = Field(default_factory=list)
    slots_filled: list[str] = Field(default_factory=list)
    slots_still_missing: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def all_pii_must_be_vaulted(self) -> "EntityExtractionResponse":
        for entity in self.extracted_entities:
            if entity.entity_type in PII_ENTITY_TYPES:
                if not entity.vault_token:
                    raise ValueError(
                        f"PII entity '{entity.entity_type.value}' (id={entity.entity_id}) "
                        f"must have a vault_token. PII cannot exist in state unvaulted."
                    )
                if entity.raw_value is not None:
                    raise ValueError(
                        f"PII entity '{entity.entity_type.value}' (id={entity.entity_id}) "
                        f"still has raw_value set. PII raw values must be cleared after vaulting."
                    )
        return self


# ==============================================================================
# RAG AGENT
# ==============================================================================

class RAGAgentRequest(StrictBase):
    """
    Input to RAG Agent.

    Contains:
      - question
      - optional entity context
      - service domain for filtered retrieval
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    question: str = Field(min_length=1)
    entity_context: dict[str, str] = Field(default_factory=dict)
    service_domain: ServiceDomain | None = None
    current_date: date = Field(default_factory=date.today)
    max_chunks: int = Field(default=10, ge=1, le=25)
    require_citation: bool = True
    min_confidence: float = Field(default=0.70, ge=0.0, le=1.0)


class RAGAgentResponse(StrictBase):
    """
    Output from RAG Agent.

    Produces:
      - grounded answer
      - citations
      - rag_confidence score
      - caveats and verification metadata
    """
    answer: str | None = None
    citations: list[SourceCitation] = Field(default_factory=list)
    rag_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    required_caveats: list[str] = Field(default_factory=list)
    verification_passed: bool = False
    freshness_warning: bool = False

    @model_validator(mode="after")
    def confidence_answer_consistency(self) -> "RAGAgentResponse":
        if self.rag_confidence >= 0.70 and self.answer and not self.citations:
            raise ValueError(
                "A confident answer (rag_confidence >= 0.70) must have at least "
                "one citation. Either add citations or lower the confidence score."
            )
        # NOTE: Low-confidence answers (< 0.70) are allowed here.
        # The Action Planner's H8 hard rule handles escalation for low-confidence
        # RAG results. Blocking at the schema level would prevent the RAG agent
        # from returning partial-confidence answers that H8 can triage.
        return self


# ==============================================================================
# AUTH AGENT
# ==============================================================================

class AuthAgentRequest(StrictBase):
    """
    Input to Auth Agent.

    Determines:
      - whether authentication is required
      - next challenge step
      - validates challenge responses
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    current_auth_state: AuthState
    required_level: AuthLevel
    verification_input: str | None = None
    fraud_risk_score: float = Field(default=0.0, ge=0.0, le=1.0)
    device_fingerprint: str | None = None

    @model_validator(mode="after")
    def locked_should_not_reach_agent(self) -> "AuthAgentRequest":
        # NOTE: Locked sessions are normally caught by Action Planner H2b
        # before reaching AuthAgent. However, the AuthAgent itself also
        # handles locked state gracefully (returns escalation result).
        # We log a warning instead of raising, so defense-in-depth works
        # correctly if schema validation is ever enabled at runtime.
        if self.current_auth_state.is_locked:
            import logging
            logging.getLogger("contact_center").warning(
                "[auth_request_locked_session] AuthAgentRequest received for a "
                "locked session. H2b should have caught this upstream."
            )
        return self


class AuthAgentResponse(StrictBase):
    """
    Output from Auth Agent.

    Produces:
      - updated auth_state
      - optional challenge
      - optional verification result (\"PASS\" or \"FAIL\")
      - optional escalation context
    """
    status: AuthStatus
    updated_auth_state: AuthState
    challenge: AuthChallenge | None = None
    verification_result: str | None = None
    escalation_context: EscalationContext | None = None

    @model_validator(mode="after")
    def status_constraints(self) -> "AuthAgentResponse":
        if self.status == AuthStatus.PENDING and not self.challenge:
            raise ValueError(
                "AuthStatus.PENDING requires challenge to be set. "
                "Issue a challenge question before returning PENDING."
            )
        if self.status == AuthStatus.LOCKED and not self.escalation_context:
            raise ValueError(
                "AuthStatus.LOCKED requires escalation_context. "
                "Provide AUTH_LOCKED reason and triggered_by='auth_agent'."
            )
        if self.status == AuthStatus.VERIFIED and self.updated_auth_state.is_locked:
            raise ValueError(
                "Cannot return VERIFIED status with is_locked=True. Contradiction."
            )
        return self


# ==============================================================================
# ENTITY VALIDATOR
# ==============================================================================

class EntityValidatorRequest(StrictBase):
    """
    Input to Entity Validator Agent.

    Validator enforces business rules & regulatory constraints.
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    entities: dict[str, EntityRecord] = Field(default_factory=dict)
    applicable_rules: list[str] = Field(default_factory=list)
    account_context: dict = Field(default_factory=dict)
    intent_id: str = ""
    current_date: date = Field(default_factory=date.today)

    @model_validator(mode="after")
    def entities_not_empty(self) -> "EntityValidatorRequest":
        if not self.entities:
            raise ValueError(
                "EntityValidatorRequest.entities is empty. "
                "Validator should only be called when entity_memory has entries."
            )
        return self


class EntityValidatorResponse(StrictBase):
    """
    Output from Entity Validator Agent.

    Produces:
      - validation_status
      - violations
      - validated_entities
      - HITL disclosures
      - remaining missing slots
    """
    validation_status: ValidationStatus
    violations: list[ValidationViolation] = Field(default_factory=list)
    validated_entities: dict[str, EntityRecord] = Field(default_factory=dict)
    hitl_disclosures: list[HITLDisclosureItem] = Field(default_factory=list)
    missing_required_slots: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def failed_status_requires_reason(self) -> "EntityValidatorResponse":
        if self.validation_status == ValidationStatus.FAILED:
            has_blocking = any(
                v.severity == ValidationSeverity.BLOCKING for v in self.violations
            )
            if not has_blocking and not self.missing_required_slots:
                raise ValueError(
                    "ValidationStatus.FAILED requires either a BLOCKING violation "
                    "or missing_required_slots. Provide at least one."
                )
        if self.validation_status == ValidationStatus.PASSED and self.violations:
            blocking = [v for v in self.violations if v.severity == ValidationSeverity.BLOCKING]
            if blocking:
                raise ValueError(
                    f"ValidationStatus.PASSED cannot have BLOCKING violations. "
                    f"Found: {[v.rule_id for v in blocking]}"
                )
        return self


# ==============================================================================
# ACTION PLANNER
# ==============================================================================

class ActionPlannerRequest(StrictBase):
    """
    Input to Action Planner Agent.

    Contains:
      - extracted agent summary (AgentOutputSummary)
      - full intent stack
      - slot_gap
      - HITL state
      - retry/correction counters
    """
    session_id: UUID
    current_turn: int = Field(ge=0)
    message: str = ""
    agent_summary: AgentOutputSummary
    intent_stack: list[IntentRecord] = Field(default_factory=list)
    auth_state: AuthState
    slot_gap: list[str] = Field(default_factory=list)
    hitl_pending: bool = False
    retry_count: int = Field(default=0, ge=0)
    correction_count: int = Field(default=0, ge=0)


class ActionPlannerResponse(StrictBase):
    """
    Output from Action Planner Agent.

    Produces:
      - action plan (ActionPlan)
      - optional hard_rule_fired
      - optional policy_path for debugging/tracing
      - optional reasoning
    """
    action_plan: ActionPlan
    hard_rule_fired: str | None = None
    policy_path: str | None = None
    reasoning: str | None = None

    @model_validator(mode="after")
    def hard_rule_format(self) -> "ActionPlannerResponse":
        # Fix M11: Tighten validation to only accept H1-H8 with
        # optional lowercase suffix (e.g. H2a, H2b), not any
        # string starting with "H".
        if self.hard_rule_fired:
            if not re.fullmatch(r"H[1-8][a-z]?", self.hard_rule_fired):
                raise ValueError(
                    f"hard_rule_fired must be 'H1'...'H8' (with optional suffix) "
                    f"or None, got {self.hard_rule_fired!r}."
                )
        return self


# ==============================================================================
# RESPONSE SYNTHESIZER
# ==============================================================================

class SynthesizerRequest(StrictBase):
    """
    Input to Response Synthesizer Agent.

    Produces final natural-language response based on:
      - action plan
      - validated entities
      - RAG answer
      - HITL disclosures
      - transaction result (for completed transactions)
    """
    session_id: UUID
    current_turn: int
    action_plan: ActionPlan
    rag_answer: str | None = None
    validated_entities: dict[str, EntityRecord] = Field(default_factory=dict)
    hitl_disclosures: list[HITLDisclosureItem] = Field(default_factory=list)
    session_context: SessionContext
    transaction_result: dict | None = None  # populated by tools

    @model_validator(mode="after")
    def answer_required_for_answer_action(self) -> "SynthesizerRequest":
        if self.action_plan.action_type == ActionType.ANSWER and not self.rag_answer:
            # H8 should have escalated before reaching here.  If it didn't,
            # we fall back to a safe canned response so the customer is never
            # left without a reply.  This is a *defensive safety net*; the
            # root cause (missing rag_answer for ANSWER action) should be
            # investigated via the error log below.
            import logging
            logging.getLogger("contact_center").error(
                "[synthesizer_request] ANSWER action reached synthesizer "
                "without rag_answer - H8 should have escalated.  "
                "Falling back to safe canned response so the user is not "
                "left without a reply."
            )
            object.__setattr__(self, "rag_answer",
                "I don't have enough verified information to answer that question "
                "accurately. Let me connect you with a specialist who can help.")
        return self


class SynthesizerResponse(StrictBase):
    """
    Output from Response Synthesizer Agent.

    The orchestrator reads:
      - full_message (final displayed text)
      - action_type
    """
    opening_frame: str
    core_content: str
    compliance_tail: str
    full_message: str
    action_type: ActionType
    disclosures_appended: list[str] = Field(default_factory=list)

    # NOTE: Validator ordering matters.  Pydantic v2 runs @model_validator(mode="after")
    # in definition order.  full_message_assembly MUST be defined before
    # full_message_not_empty so assembly happens first.

    @model_validator(mode="after")
    def full_message_assembly(self) -> "SynthesizerResponse":
        """Auto-assemble full_message from the three layers (L1 + L2 + L3).
        Runs first so full_message_not_empty can validate the result.
        Uses object.__setattr__ to bypass validate_assignment recursion.
        """
        parts = [p for p in [self.opening_frame, self.core_content, self.compliance_tail] if p]
        expected = "\n\n".join(parts)
        if self.full_message != expected:
            object.__setattr__(self, "full_message", expected)
        return self

    @model_validator(mode="after")
    def full_message_not_empty(self) -> "SynthesizerResponse":
        if not self.full_message or not self.full_message.strip():
            raise ValueError(
                "full_message must be non-empty. The synthesizer must always "
                "produce a displayable customer response."
            )
        return self


# ==============================================================================
# TRANSACTION EXECUTION (TOOLS)
# ==============================================================================

class TransactionExecutionRequest(StrictBase):
    """
    Input to a transactional tool/tool.

    Contains:
      - confirmed_entities
      - auth_state (must meet required level)
      - idempotency_key to avoid duplicate execution
    """
    session_id: UUID
    current_turn: int
    intent: IntentRecord
    confirmed_entities: dict[str, EntityRecord] = Field(default_factory=dict)
    auth_state: AuthState
    idempotency_key: str


class TransactionExecutionResponse(StrictBase):
    """
    Output from a transactional tool/tool.

    Produces:
      - success flag
      - status string (business-level)
      - receipt_id if successful
      - error messages if failed
      - message_to_customer for synthesizer use
    """
    success: bool
    status: str
    receipt_id: str | None = None
    message_to_customer: str | None = None
    errors: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def success_errors_consistency(self) -> "TransactionExecutionResponse":
        if not self.success and not self.errors:
            raise ValueError(
                "success=False requires at least one entry in errors. "
                "Provide an error description when the transaction fails."
            )
        if self.success and self.errors:
            raise ValueError(
                "success=True must not have errors. "
                f"Got errors: {self.errors}"
            )
        return self
