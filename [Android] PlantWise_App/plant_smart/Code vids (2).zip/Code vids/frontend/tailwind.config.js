/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "sans-serif",
        ],
        mono: [
          "JetBrains Mono",
          "Fira Code",
          "ui-monospace",
          "SFMono-Regular",
          "monospace",
        ],
      },
      colors: {
        // Agentic-AI palette. The legacy `ey-*` keys are remapped onto the
        // new dark theme so existing components inherit the new look
        // without a wholesale class rewrite.
        agent: {
          bg: "#0A0B14",
          surface: "#11131F",
          "surface-2": "#161929",
          border: "#262A3E",
          "border-soft": "#1C2030",
          muted: "#8A8FA8",
          subtle: "#5A5F78",
          text: "#E6E8F2",
          "text-soft": "#B4B8CC",
          accent: "#22D3EE",
          "accent-2": "#818CF8",
          "accent-3": "#C084FC",
          good: "#34D399",
          warn: "#FBBF24",
          bad: "#F87171",
        },
        ey: {
          yellow: "#22D3EE",
          "yellow-400": "#67E8F9",
          gray: {
            900: "#E6E8F2",
            700: "#B4B8CC",
            500: "#8A8FA8",
            300: "#262A3E",
            200: "#1C2030",
            100: "#11131F",
          },
        },
      },
      backgroundImage: {
        "agent-radial":
          "radial-gradient(circle at 20% 0%, rgba(129,140,248,0.18) 0%, transparent 45%), radial-gradient(circle at 80% 100%, rgba(34,211,238,0.14) 0%, transparent 50%), linear-gradient(180deg, #0A0B14 0%, #07080F 100%)",
        "agent-gradient":
          "linear-gradient(135deg, #22D3EE 0%, #818CF8 50%, #C084FC 100%)",
        "agent-glass":
          "linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)",
      },
      boxShadow: {
        glow: "0 0 24px -4px rgba(34,211,238,0.45)",
        "glow-indigo": "0 0 24px -4px rgba(129,140,248,0.45)",
        "glow-purple": "0 0 24px -4px rgba(192,132,252,0.45)",
        card: "0 8px 24px -8px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)",
      },
      keyframes: {
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "pulse-glow": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(34,211,238,0.4)" },
          "50%": { boxShadow: "0 0 0 8px rgba(34,211,238,0)" },
        },
        "fade-in-up": {
          "0%": { opacity: "0", transform: "translateY(6px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "gradient-shift": {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        "thinking-bounce": {
          "0%, 80%, 100%": { transform: "translateY(0)", opacity: "0.4" },
          "40%": { transform: "translateY(-4px)", opacity: "1" },
        },
      },
      animation: {
        shimmer: "shimmer 2.4s linear infinite",
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
        "fade-in-up": "fade-in-up 220ms ease-out both",
        "gradient-shift": "gradient-shift 6s ease-in-out infinite",
        "thinking-bounce": "thinking-bounce 1.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};