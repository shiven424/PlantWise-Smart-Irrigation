# Contact Center AI - Frontend

Vite + React 18 + TypeScript + Tailwind CSS UI for the multi-agent
LangGraph backend defined in the parent project.

## Stack

- **Vite 5** - dev server & build tooling
- **React 18** + TypeScript (strict)
- **Tailwind CSS 3** with dark-mode support
- **lucide-react** for icons

## Backend integration

The UI is built directly against the FastAPI surface in `../main.py`:

| Endpoint | UI usage |
| --- | --- |
| `POST /conversations` | `SessionSetup` form on first load |
| `POST /conversations/{id}/turns` | every user message in the chat |
| `POST /conversations/{id}/hitl` | the orange HITL panel (approve / corrections) |
| `POST /conversations/{id}/end` | "End conversation" button in the sidebar |
| `GET  /conversations/{id}` | reserved for future state polling |
| `GET  /health`, `/ready` | top-of-page health banner |

All authenticated requests carry the `session_token` returned by
`POST /conversations` as `Authorization: Bearer <token>`, matching the
`_validate_session_token` check in `main.py`.

The Vite dev server runs on **port 3000** (hard-coded in `vite.config.ts`)
because that is the only origin allowed by `settings.allowed_origins` in
`config.py`. Vite proxies `/conversations`, `/health`, and `/ready` to
`http://localhost:8000`, so no CORS workaround is needed.

## Running locally

```bash
# 1. Start the backend (in the project root)
pip install -r requirements.txt
python main.py            # listens on :8000

# 2. Start the frontend (in this directory)
cd frontend
npm install
npm run dev               # opens http://localhost:3000
```

## Configuration

Copy `.env.example` to `.env` to override the backend URL:

```bash
VITE_BACKEND_URL=http://localhost:8000   # used by the dev proxy
VITE_API_BASE_URL=                       # leave blank for dev (uses proxy)
```

In production builds, set `VITE_API_BASE_URL` to the absolute URL of the
deployed backend.

## Project layout

```
frontend/
  src/
    api/client.ts            # typed fetch wrapper around the FastAPI endpoints
    hooks/useConversation.ts # session + chat state machine
    types/api.ts             # TS mirrors of Pydantic models in schemas/
    components/
      SessionSetup.tsx       # start-conversation form
      ChatWindow.tsx         # transcript + composer + HITL/escalation panels
      MessageBubble.tsx      # message renderer (user / assistant / system)
      Composer.tsx           # auto-grow textarea
      HitlPanel.tsx          # approve / request corrections UI
      EscalationBanner.tsx   # human-handoff banner
      StatusSidebar.tsx      # auth, intent, slot-gap, controls
      BackendHealthBanner.tsx# /health + /ready monitor
    App.tsx
    main.tsx
    index.css
```

## Features

- Session setup with channel / tier / locale / non-PII account context
- Auto-scrolling chat with action-type and disclosure badges per assistant turn
- Human-in-the-loop confirmation flow (approve or submit slot corrections)
- Live status sidebar: auth status, active intent + confidence, missing slots,
  policy path, turn counter, elapsed timer
- Backend health/readiness banner with periodic re-check
- Escalation banner when the supervisor escalates to a human
- Light / dark theme toggle (persisted in `localStorage`)
- Keyboard-friendly composer (Enter to send, Shift+Enter for newline)
