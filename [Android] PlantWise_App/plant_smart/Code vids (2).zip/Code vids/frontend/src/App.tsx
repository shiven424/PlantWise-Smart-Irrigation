import { ConversationProvider } from "./context/ConversationContext";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ChatShell } from "./components/ChatShell";
import { Login } from "./components/Login";

function Gate() {
  const { isLoggedIn } = useAuth();
  if (!isLoggedIn) return <Login />;
  return (
    <ConversationProvider>
      <ChatShell />
    </ConversationProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Gate />
    </AuthProvider>
  );
}
