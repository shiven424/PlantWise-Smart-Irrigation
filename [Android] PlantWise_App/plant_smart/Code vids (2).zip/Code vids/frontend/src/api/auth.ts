/**
 * Auth API client.
 *
 * Handles /auth/login and stores the resulting JWT in localStorage. The
 * stored token is consumed by `api/client.ts` for all calls that require
 * a logged-in user (currently: POST /conversations, GET /demo/last_otp).
 *
 * Per-conversation `session_token`s remain unchanged — they are still
 * tracked in `client.ts` and used for /turns, /hitl, /end requests.
 */
import type { LoginRequest, LoginResponse } from "../types/api";

const BASE = import.meta.env.VITE_API_BASE ?? "";

const TOKEN_KEY = "ccai.auth.token";
const USER_KEY = "ccai.auth.user_id";
const USERNAME_KEY = "ccai.auth.username";
const EXPIRES_KEY = "ccai.auth.expires_at";

/** Custom event dispatched whenever the auth state changes. */
export const AUTH_CHANGED_EVENT = "ccai:auth-changed";

/** JWT payload `preferred_username` (set at login); no signature verification — display only. */
function readPreferredUsernameFromToken(token: string | null): string | null {
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length < 2) return null;
    const mid = parts[1];
    const base64 = mid.replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
    const payload = JSON.parse(atob(padded)) as Record<string, unknown>;
    const pn = payload.preferred_username;
    return typeof pn === "string" && pn.trim() ? pn.trim() : null;
  } catch {
    return null;
  }
}

export interface AuthSnapshot {
  token: string | null;
  userId: string | null;
  /** Username from the login form — shown in the UI; may differ from `user_id` in tokens. */
  username: string | null;
  expiresAt: number | null;
}

export function getAuth(): AuthSnapshot {
  const token = localStorage.getItem(TOKEN_KEY);
  const storedName = localStorage.getItem(USERNAME_KEY);
  return {
    token,
    userId: localStorage.getItem(USER_KEY),
    username: storedName?.trim()
      ? storedName.trim()
      : readPreferredUsernameFromToken(token),
    expiresAt: Number(localStorage.getItem(EXPIRES_KEY) || "") || null,
  };
}

export function isLoggedIn(): boolean {
  const { token, expiresAt } = getAuth();
  if (!token) return false;
  if (expiresAt && Date.now() >= expiresAt) return false;
  return true;
}

export function clearAuth(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem(USERNAME_KEY);
  localStorage.removeItem(EXPIRES_KEY);
  window.dispatchEvent(new CustomEvent(AUTH_CHANGED_EVENT));
}

export async function login(req: LoginRequest): Promise<LoginResponse> {
  const res = await fetch(`${BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(body.detail || `Login failed (HTTP ${res.status})`);
  }
  const body: LoginResponse = await res.json();
  const displayUsername = (
    typeof body.username === "string"
      ? body.username
      : req.username
  ).trim();
  localStorage.setItem(TOKEN_KEY, body.access_token);
  localStorage.setItem(USER_KEY, body.user_id);
  if (displayUsername) {
    localStorage.setItem(USERNAME_KEY, displayUsername);
  } else {
    localStorage.removeItem(USERNAME_KEY);
  }
  // expires_in is in seconds; convert to absolute epoch ms.
  localStorage.setItem(
    EXPIRES_KEY,
    String(Date.now() + body.expires_in * 1000),
  );
  window.dispatchEvent(new CustomEvent(AUTH_CHANGED_EVENT));
  return body;
}

export function logout(): void {
  clearAuth();
}

/** Returns the auth header to attach to JWT-protected requests. */
export function authHeader(): Record<string, string> {
  const { token } = getAuth();
  return token ? { Authorization: `Bearer ${token}` } : {};
}
