import type {
  StartConversationRequest,
  StartConversationResponse,
  TurnRequest,
  TurnResponse,
  HITLRequest,
  ConversationSnapshot,
  HealthResponse,
  ConversationListResponse,
  RestoreConversationResponse,
  ResumeConversationResponse,
} from "../types/api";
import { authHeader, clearAuth } from "./auth";

const BASE = import.meta.env.VITE_API_BASE ?? "";

const REQUEST_TIMEOUT_MS = 30_000; // 30 seconds
const MAX_RETRIES = 2; // up to 2 retries (3 total attempts)
const RETRY_BASE_MS = 500; // exponential backoff base

/** M6: Per-conversation session tokens received from /conversations */
const sessionTokens = new Map<string, string>();

/** Remove a session token when it is no longer valid. */
export function clearSessionToken(conversationId: string): void {
  sessionTokens.delete(conversationId);
}

function authHeaders(conversationId: string): Record<string, string> {
  const token = sessionTokens.get(conversationId);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function isRetryableStatus(status: number): boolean {
  return status === 429 || status === 502 || status === 503 || status === 504;
}

/**
 * Core fetch wrapper with timeout, retry/backoff, and selective 401 handling.
 *
 * @param logoutOn401 - When true (default), a 401 triggers `clearAuth()` so the
 *   AuthProvider routes back to Login.  Set to false for endpoints that use a
 *   per-conversation session_token rather than the login JWT — a session-token
 *   failure should NOT sign the user out of the application.
 */
async function request<T>(
  path: string,
  options: RequestInit = {},
  retriesLeft: number = MAX_RETRIES,
  logoutOn401 = true,
): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const res = await fetch(path, {
      ...options,
      headers: { "Content-Type": "application/json", ...options.headers },
      signal: controller.signal,
    });

    if (!res.ok) {
      if (res.status === 401 && logoutOn401) {
        clearAuth();
      }
      if (isRetryableStatus(res.status) && retriesLeft > 0) {
        const delay = RETRY_BASE_MS * Math.pow(2, MAX_RETRIES - retriesLeft);
        await new Promise((r) => setTimeout(r, delay));
        return request<T>(path, options, retriesLeft - 1, logoutOn401);
      }
      const body = await res.json().catch(() => ({ detail: res.statusText }));
      throw new Error(body.detail || `HTTP ${res.status}`);
    }

    // 204 No Content — no body to parse
    if (res.status === 204) return undefined as T;

    return res.json();
  } catch (err: unknown) {
    if (err instanceof DOMException && err.name === "AbortError") {
      if (retriesLeft > 0) {
        const delay = RETRY_BASE_MS * Math.pow(2, MAX_RETRIES - retriesLeft);
        await new Promise((r) => setTimeout(r, delay));
        return request<T>(path, options, retriesLeft - 1, logoutOn401);
      }
      throw new Error("Request timed out. Please check your connection and try again.");
    }
    if (err instanceof TypeError && retriesLeft > 0) {
      const delay = RETRY_BASE_MS * Math.pow(2, MAX_RETRIES - retriesLeft);
      await new Promise((r) => setTimeout(r, delay));
      return request<T>(path, options, retriesLeft - 1, logoutOn401);
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

export const api = {
  // — Existing conversation endpoints (session-token auth) —————————————————

  async startConversation(data: StartConversationRequest = {}): Promise<StartConversationResponse> {
    const resp = await request<StartConversationResponse>(`${BASE}/conversations`, {
      method: "POST",
      headers: authHeader(),
      body: JSON.stringify(data),
    });
    sessionTokens.set(resp.conversation_id, resp.session_token);
    return resp;
  },

  sendTurn(conversationId: string, data: TurnRequest): Promise<TurnResponse> {
    return request(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/turns`,
      { method: "POST", headers: authHeaders(conversationId), body: JSON.stringify(data) },
      MAX_RETRIES,
      /* logoutOn401 */ false,   // session-token 401 ≠ JWT expiry
    );
  },

  sendHITL(conversationId: string, data: HITLRequest): Promise<TurnResponse> {
    return request(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/hitl`,
      { method: "POST", headers: authHeaders(conversationId), body: JSON.stringify(data) },
      MAX_RETRIES,
      false,
    );
  },

  endConversation(conversationId: string): Promise<TurnResponse> {
    const result = request<TurnResponse>(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/end`,
      { method: "POST", headers: authHeaders(conversationId) },
      MAX_RETRIES,
      false,
    );
    result.finally(() => sessionTokens.delete(conversationId));
    return result;
  },

  getConversation(conversationId: string): Promise<ConversationSnapshot> {
    return request(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}`,
      { headers: authHeaders(conversationId) },
      MAX_RETRIES,
      false,
    );
  },

  // — History endpoints (login-JWT auth) ——————————————————————————————————

  listConversations(opts: {
    includeDeleted?: boolean;
    limit?: number;
    cursor?: string | null;
  } = {}): Promise<ConversationListResponse> {
    const params = new URLSearchParams();
    if (opts.includeDeleted) params.set("include_deleted", "true");
    if (opts.limit != null) params.set("limit", String(opts.limit));
    if (opts.cursor) params.set("cursor", opts.cursor);
    const qs = params.toString();
    return request(
      `${BASE}/conversations${qs ? `?${qs}` : ""}`,
      { method: "GET", headers: authHeader() },
    );
  },

  async resumeConversation(conversationId: string): Promise<ResumeConversationResponse> {
    const resp = await request<ResumeConversationResponse>(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/resume`,
      { method: "POST", headers: authHeader() },
    );
    // Store the new session token so subsequent turn/hitl/end calls succeed
    sessionTokens.set(resp.conversation_id, resp.session_token);
    return resp;
  },

  restoreConversation(conversationId: string): Promise<RestoreConversationResponse> {
    return request<RestoreConversationResponse>(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/restore`,
      { method: "POST", headers: authHeader() },
    );
  },

  softDeleteConversation(conversationId: string): Promise<void> {
    const result = request<void>(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}`,
      { method: "DELETE", headers: authHeader() },
    );
    result.finally(() => sessionTokens.delete(conversationId));
    return result;
  },

  hardDeleteConversation(conversationId: string): Promise<void> {
    const result = request<void>(
      `${BASE}/conversations/${encodeURIComponent(conversationId)}/hard`,
      { method: "DELETE", headers: authHeader() },
    );
    result.finally(() => sessionTokens.delete(conversationId));
    return result;
  },

  // — Utility ————————————————————————————————————————————————————————————

  healthCheck(): Promise<HealthResponse> {
    return request(`${BASE}/health`);
  },

  readyCheck(): Promise<HealthResponse> {
    return request(`${BASE}/ready`);
  },
};
