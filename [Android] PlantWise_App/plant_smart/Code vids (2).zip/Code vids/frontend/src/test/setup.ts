// Vitest + jsdom global setup
import "@testing-library/react";
