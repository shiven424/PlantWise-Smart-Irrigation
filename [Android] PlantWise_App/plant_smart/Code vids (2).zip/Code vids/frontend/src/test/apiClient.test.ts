/**
 * Unit tests for the API client layer — new history/resume/delete methods.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// We use fetch mocking via vi.stubGlobal

const makeConvItem = (id: string) => ({
  conversation_id: id,
  status: "ACTIVE",
  title: null,
  last_user_message_preview: "test",
  current_turn: 1,
  channel: "web",
  created_at: new Date().toISOString(),
  last_active_at: new Date().toISOString(),
  ended_at: null,
  deleted_at: null,
});

function mockFetch(status: number, body: unknown) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok: status >= 200 && status < 300,
      status,
      json: async () => body,
    })),
  );
}

beforeEach(() => {
  // Stub localStorage so authHeader() works
  const storage: Record<string, string> = {};
  vi.stubGlobal("localStorage", {
    getItem: (k: string) => storage[k] ?? null,
    setItem: (k: string, v: string) => { storage[k] = v; },
    removeItem: (k: string) => { delete storage[k]; },
  });
  // Put a fake token so authHeader() returns a bearer header
  localStorage.setItem("ccai.auth.token", "test-jwt");
  localStorage.setItem("ccai.auth.expires_at", String(Date.now() + 900_000));
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("api.listConversations", () => {
  it("calls GET /conversations with JWT header", async () => {
    const listResp = { conversations: [makeConvItem("c1")], total: 1, next_cursor: null };
    mockFetch(200, listResp);

    const { api } = await import("../api/client");
    const result = await api.listConversations();
    expect(result.conversations).toHaveLength(1);
    expect(result.conversations[0].conversation_id).toBe("c1");

    const fetchMock = vi.mocked(fetch);
    const [, opts] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect((opts.headers as Record<string, string>)["Authorization"]).toMatch(/^Bearer /);
  });

  it("passes limit and cursor query params", async () => {
    mockFetch(200, { conversations: [], total: 0, next_cursor: null });
    const { api } = await import("../api/client");
    await api.listConversations({ limit: 10, cursor: "2024-01-01T00:00:00Z" });

    const [url] = vi.mocked(fetch).mock.calls[0] as [string, RequestInit];
    expect(url).toContain("limit=10");
    expect(url).toContain("cursor=");
  });
});

describe("api.resumeConversation", () => {
  it("calls POST /conversations/{id}/resume and stores session token", async () => {
    mockFetch(200, {
      conversation_id: "conv-999",
      session_token: "new-session-tok",
      status: "ACTIVE",
      current_turn: 3,
      last_active_at: new Date().toISOString(),
    });

    const { api } = await import("../api/client");
    const result = await api.resumeConversation("conv-999");
    expect(result.session_token).toBe("new-session-tok");
    expect(result.current_turn).toBe(3);
  });
});

describe("api.softDeleteConversation", () => {
  it("calls DELETE /conversations/{id} (not /hard)", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({ ok: true, status: 204, json: async () => undefined })),
    );
    const { api } = await import("../api/client");
    await api.softDeleteConversation("conv-del");

    const [url, opts] = vi.mocked(fetch).mock.calls[0] as [string, RequestInit];
    expect(url).toMatch(/\/conversations\/conv-del$/);
    expect(opts.method).toBe("DELETE");
  });
});

describe("api.hardDeleteConversation", () => {
  it("calls DELETE /conversations/{id}/hard", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({ ok: true, status: 204, json: async () => undefined })),
    );
    const { api } = await import("../api/client");
    await api.hardDeleteConversation("conv-perm");

    const [url, opts] = vi.mocked(fetch).mock.calls[0] as [string, RequestInit];
    expect(url).toMatch(/\/conversations\/conv-perm\/hard$/);
    expect(opts.method).toBe("DELETE");
  });
});

describe("401 handling", () => {
  it("clears auth on 401 from JWT endpoint (listConversations)", async () => {
    mockFetch(401, { detail: "Unauthorized" });
    vi.stubGlobal("dispatchEvent", vi.fn());

    const { api } = await import("../api/client");
    await expect(api.listConversations()).rejects.toThrow();
    // clearAuth dispatches AUTH_CHANGED_EVENT — check localStorage was cleared
    expect(localStorage.getItem("ccai.auth.token")).toBeNull();
  });

  it("does NOT clear auth on 401 from turn endpoint (session-token 401)", async () => {
    mockFetch(401, { detail: "Invalid session token" });
    vi.stubGlobal("dispatchEvent", vi.fn());

    const { api } = await import("../api/client");
    // sendTurn uses logoutOn401=false
    await expect(api.sendTurn("conv-x", { message: "hi" })).rejects.toThrow();
    // JWT token must still be present
    expect(localStorage.getItem("ccai.auth.token")).toBe("test-jwt");
  });
});
