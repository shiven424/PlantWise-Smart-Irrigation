import {
  createContext,
  useContext,
  useReducer,
  type ReactNode,
  type Dispatch,
} from "react";
import type {
  ChatMessage,
  ConversationStatus,
  TurnResponse,
  ConversationListItem,
  ResumeMessageHistoryEntry,
  SynthesizedResponse,
  TurnMetadata,
} from "../types/api";

// — State ————————————————————————————————————————————————————————————————————

export interface ConversationState {
  // Active thread
  conversationId: string | null;
  status: ConversationStatus;
  messages: ChatMessage[];
  turn: number;
  error: string | null;
  loading: boolean;

  // Persistent chat history list
  historyList: ConversationListItem[];
  historyLoading: boolean;
  historyError: string | null;
  historyCursor: string | null;         // cursor for next page load
  historyHasMore: boolean;

  // Delete inflight tracking per conversation id
  deleteInFlight: Record<string, "soft" | "hard">;
}

const initialState: ConversationState = {
  conversationId: null,
  status: "idle",
  messages: [],
  turn: 0,
  error: null,
  loading: false,

  historyList: [],
  historyLoading: false,
  historyError: null,
  historyCursor: null,
  historyHasMore: false,

  deleteInFlight: {},
};

// — Actions ————————————————————————————————————————————————————————————————————

type Action =
  // Active thread actions
  | { type: "START"; conversationId: string; welcomeMessage: string }
  | {
      type: "RESUME_CONVERSATION";
      conversationId: string;
      turn: number;
      history: ResumeMessageHistoryEntry[];
    }
  | { type: "SEND_MESSAGE"; message: string }
  | { type: "RECEIVE_RESPONSE"; response: TurnResponse }
  | { type: "HITL_SENT" }
  | { type: "SET_ERROR"; error: string }
  | { type: "CLEAR_ERROR" }
  | { type: "END_CONVERSATION"; farewellMessage?: string }
  | { type: "RESET" }

  // History list actions
  | { type: "HISTORY_LOAD_START" }
  | { type: "HISTORY_LOAD_SUCCESS"; items: ConversationListItem[]; cursor: string | null; hasMore: boolean }
  | { type: "HISTORY_LOAD_FAILURE"; error: string }
  | { type: "HISTORY_APPEND_PAGE"; items: ConversationListItem[]; cursor: string | null; hasMore: boolean }
  | { type: "HISTORY_PREPEND_ITEM"; item: ConversationListItem }
  | { type: "HISTORY_UPDATE_ITEM"; conversationId: string; patch: Partial<ConversationListItem> }

  // Delete actions
  | { type: "DELETE_START"; conversationId: string; mode: "soft" | "hard" }
  | { type: "DELETE_SUCCESS_SOFT"; conversationId: string }
  | { type: "DELETE_SUCCESS_HARD"; conversationId: string }
  | { type: "DELETE_FAILURE"; conversationId: string };

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function deriveStatus(response: TurnResponse): ConversationStatus {
  if (response.escalation) return "escalated";
  if (response.hitl_pending) return "hitl_pending";
  if (response.action_type === "END_SESSION") return "ended";
  return "active";
}

function clearDeleteInFlight(
  map: Record<string, "soft" | "hard">,
  id: string,
): Record<string, "soft" | "hard"> {
  const next = { ...map };
  delete next[id];
  return next;
}

function reducer(state: ConversationState, action: Action): ConversationState {
  switch (action.type) {

    // — Active thread ————————————————————————————————————————————————————————

    case "START":
      return {
        ...state,
        conversationId: action.conversationId,
        status: "active",
        turn: 0,
        error: null,
        loading: false,
        messages: [
          {
            id: uid(),
            role: "assistant",
            content: action.welcomeMessage,
            timestamp: Date.now(),
          },
        ],
      };

    case "RESUME_CONVERSATION":
      return {
        ...state,
        conversationId: action.conversationId,
        status: "active",
        turn: action.turn,
        error: null,
        loading: false,
        messages: action.history.map((m, idx) => {
          const base: ChatMessage = {
            id: uid(),
            role: m.role,
            content: m.content,
            timestamp: Date.now() - (action.history.length - idx),
          };
          if (m.role !== "assistant") return base;

          let response: SynthesizedResponse | undefined;
          if (m.response_json) {
            try {
              response = JSON.parse(m.response_json) as SynthesizedResponse;
            } catch {
              /* ignore malformed persisted JSON */
            }
          }
          let metadata: TurnMetadata | undefined;
          if (m.metadata_json) {
            try {
              metadata = JSON.parse(m.metadata_json) as TurnMetadata;
            } catch {
              /* ignore */
            }
          }
          return {
            ...base,
            action_type: m.action_type ?? null,
            response: response ?? null,
            metadata,
          };
        }),
      };

    case "SEND_MESSAGE":
      return {
        ...state,
        loading: true,
        error: null,
        messages: [
          ...state.messages,
          {
            id: uid(),
            role: "user",
            content: action.message,
            timestamp: Date.now(),
          },
        ],
      };

    case "RECEIVE_RESPONSE": {
      const r = action.response;
      const content =
        r.response?.full_message ?? r.response?.core_content ?? "";
      return {
        ...state,
        loading: false,
        turn: r.turn,
        status: deriveStatus(r),
        messages: [
          ...state.messages,
          {
            id: uid(),
            role: "assistant",
            content,
            action_type: r.action_type,
            response: r.response,
            metadata: r.metadata,
            escalation: r.escalation,
            hitl_pending: r.hitl_pending,
            timestamp: Date.now(),
          },
        ],
      };
    }

    case "HITL_SENT":
      return { ...state, loading: true, error: null };

    case "SET_ERROR":
      return { ...state, loading: false, error: action.error, status: "error" };

    case "CLEAR_ERROR":
      return {
        ...state,
        error: null,
        status: state.conversationId ? "active" : "idle",
      };

    case "END_CONVERSATION": {
      const msgs = action.farewellMessage
        ? [
            ...state.messages,
            {
              id: uid(),
              role: "assistant" as const,
              content: action.farewellMessage,
              action_type: "END_SESSION",
              timestamp: Date.now(),
            },
          ]
        : state.messages;
      return { ...state, loading: false, status: "ended", messages: msgs };
    }

    case "RESET":
      return {
        ...initialState,
        // Preserve history list so the panel stays populated after resetting active chat
        historyList: state.historyList,
        historyLoading: state.historyLoading,
        historyError: state.historyError,
        historyCursor: state.historyCursor,
        historyHasMore: state.historyHasMore,
        deleteInFlight: state.deleteInFlight,
      };

    // — History list ————————————————————————————————————————————————————————

    case "HISTORY_LOAD_START":
      return { ...state, historyLoading: true, historyError: null };

    case "HISTORY_LOAD_SUCCESS":
      return {
        ...state,
        historyLoading: false,
        historyError: null,
        historyList: action.items,
        historyCursor: action.cursor,
        historyHasMore: action.hasMore,
      };

    case "HISTORY_LOAD_FAILURE":
      return { ...state, historyLoading: false, historyError: action.error };

    case "HISTORY_APPEND_PAGE":
      return {
        ...state,
        historyLoading: false,
        historyList: [...state.historyList, ...action.items],
        historyCursor: action.cursor,
        historyHasMore: action.hasMore,
      };

    case "HISTORY_PREPEND_ITEM":
      return {
        ...state,
        historyList: [action.item, ...state.historyList.filter(
          (c) => c.conversation_id !== action.item.conversation_id,
        )],
      };

    case "HISTORY_UPDATE_ITEM":
      return {
        ...state,
        historyList: state.historyList.map((c) =>
          c.conversation_id === action.conversationId
            ? { ...c, ...action.patch }
            : c,
        ),
      };

    // — Delete ——————————————————————————————————————————————————————————————

    case "DELETE_START":
      return {
        ...state,
        deleteInFlight: { ...state.deleteInFlight, [action.conversationId]: action.mode },
      };

    case "DELETE_SUCCESS_SOFT": {
      const mapped = state.historyList.map((c) =>
          c.conversation_id === action.conversationId
            ? { ...c, status: "SOFT_DELETED" as const, deleted_at: new Date().toISOString() }
            : c,
        );

      return {
        ...state,
        deleteInFlight: clearDeleteInFlight(state.deleteInFlight, action.conversationId),
        historyList: mapped,
        // If deleted the active conversation, reset to idle
        conversationId: state.conversationId === action.conversationId ? null : state.conversationId,
        status: state.conversationId === action.conversationId ? "idle" : state.status,
        messages: state.conversationId === action.conversationId ? [] : state.messages,
      };
    }

    case "DELETE_SUCCESS_HARD":
      return {
        ...state,
        deleteInFlight: clearDeleteInFlight(state.deleteInFlight, action.conversationId),
        historyList: state.historyList.filter(
          (c) => c.conversation_id !== action.conversationId,
        ),
        conversationId: state.conversationId === action.conversationId ? null : state.conversationId,
        status: state.conversationId === action.conversationId ? "idle" : state.status,
        messages: state.conversationId === action.conversationId ? [] : state.messages,
      };

    case "DELETE_FAILURE":
      return {
        ...state,
        deleteInFlight: clearDeleteInFlight(state.deleteInFlight, action.conversationId),
      };

    default:
      return state;
  }
}

// — Context ————————————————————————————————————————————————————————————————————

const StateCtx = createContext<ConversationState>(initialState);
const DispatchCtx = createContext<Dispatch<Action>>(() => {});

export function ConversationProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <StateCtx.Provider value={state}>
      <DispatchCtx.Provider value={dispatch}>{children}</DispatchCtx.Provider>
    </StateCtx.Provider>
  );
}

export function useConversationState() {
  return useContext(StateCtx);
}

export function useConversationDispatch() {
  return useContext(DispatchCtx);
}
