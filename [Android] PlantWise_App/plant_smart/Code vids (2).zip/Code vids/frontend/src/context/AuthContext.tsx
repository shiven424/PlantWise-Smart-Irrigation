import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  AUTH_CHANGED_EVENT,
  getAuth,
  isLoggedIn as readIsLoggedIn,
  login as apiLogin,
  logout as apiLogout,
} from "../api/auth";

interface AuthContextValue {
  userId: string | null;
  /** Login handle for display (who signed in). */
  username: string | null;
  isLoggedIn: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthCtx = createContext<AuthContextValue>({
  userId: null,
  username: null,
  isLoggedIn: false,
  login: async () => {},
  logout: () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState(() => {
    const a = getAuth();
    return {
      userId: a.userId,
      username: a.username,
      isLoggedIn: readIsLoggedIn(),
    };
  });

  useEffect(() => {
    const refresh = () => {
      const a = getAuth();
      setSnapshot({
        userId: a.userId,
        username: a.username,
        isLoggedIn: readIsLoggedIn(),
      });
    };
    window.addEventListener(AUTH_CHANGED_EVENT, refresh);
    // Also handle multi-tab logout via the storage event.
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(AUTH_CHANGED_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    await apiLogin({ username, password });
    const a = getAuth();
    setSnapshot({
      userId: a.userId,
      username: a.username,
      isLoggedIn: readIsLoggedIn(),
    });
  }, []);

  const logout = useCallback(() => apiLogout(), []);

  const value = useMemo(
    () => ({ ...snapshot, login, logout }),
    [snapshot, login, logout],
  );

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  return useContext(AuthCtx);
}
