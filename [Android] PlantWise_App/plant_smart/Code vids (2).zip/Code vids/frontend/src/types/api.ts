// TypeScript types mirroring backend Pydantic models (schemas/enums.py, schemas/agent_io.py, main.py)

// — Enums ————————————————————————————————————————————————————————————————————

export enum ActionType {
  CLARIFY = "CLARIFY",
  CHITCHAT_RESPOND = "CHITCHAT_RESPOND",
  END_SESSION = "END_SESSION",
  INITIATE_AUTH = "INITIATE_AUTH",
  AUTH_CHALLENGE = "AUTH_CHALLENGE",
  PROCESS_AUTH = "PROCESS_AUTH",
  ANSWER = "ANSWER",
  COLLECT_SLOT = "COLLECT_SLOT",
  VALIDATE_ENTITIES = "VALIDATE_ENTITIES",
  PRESENT_HITL = "PRESENT_HITL",
  HITL_CORRECTION = "HITL_CORRECTION",
  HITL_APPROVED = "HITL_APPROVED",
  EXECUTE_TRANSACTION = "EXECUTE_TRANSACTION",
  PUSH_INTENT = "PUSH_INTENT",
  POP_INTENT = "POP_INTENT",
  CORRECTION_ACK = "CORRECTION_ACK",
  ESCALATE = "ESCALATE",
  HANDLE_ERROR = "HANDLE_ERROR",
  RETRY_SLOT = "RETRY_SLOT",
}

export enum AuthStatus {
  VERIFIED = "VERIFIED",
  PENDING = "PENDING",
  FAILED = "FAILED",
  LOCKED = "LOCKED",
}

export enum EscalationReason {
  DISTRESS_SIGNAL = "DISTRESS_SIGNAL",
  FINANCIAL_ADVICE = "FINANCIAL_ADVICE",
  LOW_RAG_CONFIDENCE = "LOW_RAG_CONFIDENCE",
  AUTH_LOCKED = "AUTH_LOCKED",
  BLOCKING_VIOLATION = "BLOCKING_VIOLATION",
  COMPLAINT = "COMPLAINT",
  LEGAL_THREAT = "LEGAL_THREAT",
  OUT_OF_SCOPE = "OUT_OF_SCOPE",
  SYSTEM_ERROR = "SYSTEM_ERROR",
  TAX_ADVICE = "TAX_ADVICE",
  MAX_RETRIES = "MAX_RETRIES",
  MAX_CORRECTIONS = "MAX_CORRECTIONS",
  CLIENT_REQUESTED = "CLIENT_REQUESTED",
}

// — API Request Types ————————————————————————————————————————————————————————

export interface StartConversationRequest {
  /** @deprecated Server now derives user_id from the bearer JWT and ignores this field. */
  user_id?: string;
  channel?: string;
  client_tier?: string;
  locale?: string;
  /** Non-auth CRM context only. Keys starting with `auth_` are stripped server-side. */
  account_context?: Record<string, unknown>;
  auth_token?: string;
  fraud_risk_score?: number;
  device_fingerprint?: string | null;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  user_id: string;
  /** Login handle from server (preferred); optional for older backends. */
  username?: string;
  access_token: string;
  expires_in: number;
  token_type: string;
}

export interface TurnRequest {
  message: string;
}

export interface HITLRequest {
  approved: boolean;
  corrections?: Record<string, unknown>;
}

// — API Response Types ———————————————————————————————————————————————————————

export interface StartConversationResponse {
  conversation_id: string;
  session_token: string;
  message: string;
}

export interface SynthesizedResponse {
  opening_frame?: string;
  core_content?: string;
  compliance_tail?: string;
  full_message?: string;
  action_type?: string;
  disclosures_appended?: string[];
}

export interface ActiveIntent {
  intent_id: string;
  sub_intent?: string;
  service_domain: string;
  confidence: number;
}

export interface EscalationInfo {
  reason: string;
  triggered_by: string;
  carry_context: boolean;
}

/** Drives TransactionResult banners for EXECUTE / HITL completion turns. */
export type TransactionUiOutcome = "failure" | "success" | "informational";

export interface TurnMetadata {
  rag_confidence?: number | null;
  rag_error?: boolean;
  auth_status?: string;
  slot_gap?: string[];
  active_intent?: ActiveIntent | null;
  policy_path?: string | null;
  /** Populated after transactional tools resolve (plan loan, balance, etc.). */
  transaction_ui_outcome?: TransactionUiOutcome | null;
  /** Slot name -> current value, populated when HITL is pending so the
   *  frontend can render an editable correction form. */
  editable_slots?: Record<string, string>;
}

export interface TurnResponse {
  conversation_id: string;
  turn: number;
  action_type: string | null;
  response: SynthesizedResponse | null;
  hitl_pending: boolean;
  escalation: EscalationInfo | null;
  metadata: TurnMetadata;
}

export interface ConversationSnapshot {
  conversation_id: string;
  turn: number;
  intent: string | null;
  auth_status: string | null;
  hitl_pending: boolean;
  last_response: Record<string, unknown> | null;
}

export interface HealthResponse {
  status: string;
  timestamp: string;
}

// — Conversation History API Types ————————————————————————————————————————————
// Mirrors the backend ConversationListItem / ConversationListResponse /
// ResumeConversationResponse Pydantic models in main.py.

/** Backend-side lifecycle status of a persisted conversation. */
export type BackendConversationStatus = "ACTIVE" | "ENDED" | "SOFT_DELETED";

/** One entry in the paginated history list returned by GET /conversations. */
export interface ConversationListItem {
  conversation_id: string;
  status: BackendConversationStatus;
  title: string | null;
  last_user_message_preview: string | null;
  current_turn: number;
  channel: string;
  created_at: string;   // ISO timestamp
  last_active_at: string;
  ended_at: string | null;
  deleted_at: string | null;
}

/** Paginated list response from GET /conversations. */
export interface ConversationListResponse {
  conversations: ConversationListItem[];
  total: number;
  /** ISO timestamp cursor for the next page; null when no further pages. */
  next_cursor: string | null;
}

/** Response from POST /conversations/{id}/restore. */
export interface RestoreConversationResponse {
  conversation_id: string;
  status: "ACTIVE" | "ENDED";
}

/** One row in POST /conversations/{id}/resume message_history (all string values). */
export interface ResumeMessageHistoryEntry {
  role: "user" | "assistant";
  content: string;
  /** Present on assistant turns when the server persisted structured UI state. */
  action_type?: string;
  /** JSON-encoded SynthesizedResponse-shaped object. */
  response_json?: string;
  /** JSON with fields like auth_status, slot_gap for action cards. */
  metadata_json?: string;
}

/** Response from POST /conversations/{id}/resume. */
export interface ResumeConversationResponse {
  conversation_id: string;
  /** New session_token to use for /turns, /hitl, /end on this conversation. */
  session_token: string;
  status: BackendConversationStatus;
  current_turn: number;
  last_active_at: string;
  message_history: ResumeMessageHistoryEntry[];
}

// — UI State Types ————————————————————————————————————————————————————————————

export type ConversationStatus =
  | "idle"
  | "active"
  | "hitl_pending"
  | "escalated"
  | "ended"
  | "error";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  action_type?: string | null;
  response?: SynthesizedResponse | null;
  metadata?: TurnMetadata;
  escalation?: EscalationInfo | null;
  hitl_pending?: boolean;
  timestamp: number;
}