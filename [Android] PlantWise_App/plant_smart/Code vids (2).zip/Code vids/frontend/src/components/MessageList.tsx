import { useEffect, useRef } from "react";
import { Sparkles } from "lucide-react";
import { useConversationState } from "../context/ConversationContext";
import { MessageBubble } from "./MessageBubble";

export function MessageList() {
  const { messages, loading } = useConversationState();
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, loading]);

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        {messages.map((msg) => (
          <div key={msg.id} className="animate-fade-in-up">
            <MessageBubble message={msg} />
          </div>
        ))}
        {loading && <ThinkingIndicator />}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}

function ThinkingIndicator() {
  return (
    <div className="flex items-start gap-3 animate-fade-in-up">
      <div className="relative w-8 h-8 flex-shrink-0">
        <div className="absolute inset-0 rounded-full bg-agent-gradient blur opacity-50 animate-pulse" />
        <div className="relative w-8 h-8 rounded-full bg-agent-gradient flex items-center justify-center shadow-glow">
          <Sparkles className="w-4 h-4 text-agent-bg" strokeWidth={2.5} />
        </div>
      </div>
      <div className="glass rounded-2xl rounded-tl-sm px-4 py-3 shadow-card overflow-hidden relative">
        <div className="absolute inset-0 shimmer-bg animate-shimmer pointer-events-none" />
        <div className="relative flex items-center gap-2.5">
          <div className="flex gap-1">
            <span className="w-1.5 h-1.5 bg-agent-accent rounded-full animate-thinking-bounce" style={{ animationDelay: "0ms" }} />
            <span className="w-1.5 h-1.5 bg-agent-accent-2 rounded-full animate-thinking-bounce" style={{ animationDelay: "150ms" }} />
            <span className="w-1.5 h-1.5 bg-agent-accent-3 rounded-full animate-thinking-bounce" style={{ animationDelay: "300ms" }} />
          </div>
          <span className="text-xs text-agent-text-soft font-medium">Reasoning…</span>
        </div>
      </div>
    </div>
  );
}
