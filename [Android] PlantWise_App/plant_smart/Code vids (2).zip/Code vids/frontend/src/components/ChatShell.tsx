import { useEffect, useState } from "react";
import { Sparkles, Wallet, Calculator, PiggyBank, ArrowRight } from "lucide-react";
import { Header } from "./Header";
import { MessageList } from "./MessageList";
import { InputBar } from "./InputBar";
import { MetadataPanel } from "./MetadataPanel";
import { ConversationHistoryPanel } from "./ConversationHistoryPanel";
import { useConversation } from "../hooks/useConversation";

const DEMO_ACCOUNT_CONTEXT = {};

export function ChatShell() {
  const { status, messages, startConversation, loadHistory } = useConversation();
  const [showMeta, setShowMeta] = useState(false);
  const [showHistory, setShowHistory] = useState(true);  // default open on desktop

  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");

  // Load conversation history once on mount (after login, when ConversationProvider is alive)
  useEffect(() => {
    loadHistory();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNewChat = () => {
    startConversation({ account_context: DEMO_ACCOUNT_CONTEXT });
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* History sidebar — desktop always visible; hide on mobile when closed */}
      {showHistory && (
        <ConversationHistoryPanel
          onClose={() => setShowHistory(false)}
          onNewChat={handleNewChat}
        />
      )}

      {/* Main chat area */}
      <div className="flex flex-col flex-1 min-w-0">
        <Header
          onToggleMeta={() => setShowMeta((p) => !p)}
          showMeta={showMeta}
          onToggleHistory={() => setShowHistory((p) => !p)}
          showHistory={showHistory}
        />

        {status === "idle" ? (
          <Welcome onStart={handleNewChat} />
        ) : (
          <>
            <MessageList />
            <InputBar />
          </>
        )}
      </div>

      {showMeta && lastAssistant && <MetadataPanel message={lastAssistant} />}
    </div>
  );
}

function Welcome({ onStart }: { onStart: () => void }) {
  const { startConversation, sendMessage, conversationId } = useConversation();

  const quickPrompts = [
    { label: "Account Balance", message: "What is my current account balance?", icon: Wallet },
    { label: "Plan Loan", message: "I need to take a loan from my retirement plan", icon: PiggyBank },
    { label: "RMD Calculation", message: "Can you calculate my required minimum distribution?", icon: Calculator },
  ];

  const handleQuickPrompt = async (msg: string) => {
    try {
      if (!conversationId) {
        const newId = await startConversation({ account_context: DEMO_ACCOUNT_CONTEXT });
        if (newId) await sendMessage(msg, newId);
      } else {
        await sendMessage(msg);
      }
    } catch (err) {
      console.error("[QuickPrompt] Failed to send message:", err);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-6 py-12 animate-fade-in-up">
        <div className="text-center space-y-5 mb-10">
          <div className="relative w-20 h-20 mx-auto">
            <div className="absolute inset-0 rounded-3xl bg-agent-gradient blur-xl opacity-40 animate-pulse" />
            <div className="relative w-20 h-20 rounded-3xl bg-agent-gradient flex items-center justify-center shadow-glow">
              <Sparkles className="w-10 h-10 text-agent-bg" strokeWidth={2.5} />
            </div>
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">
              Hi! How can I help you <span className="text-gradient">today?</span>
            </h2>
            <p className="text-agent-text-soft max-w-lg mx-auto">
              I'm Aegis — an agentic AI for retirement, wealth & plan-administration support. I orchestrate
              specialised tools, verify your identity, and confirm every transaction before it's executed.
            </p>
          </div>

          <button
            onClick={onStart}
            className="group inline-flex items-center gap-2 px-5 py-2.5 bg-agent-gradient bg-[length:200%_200%] animate-gradient-shift text-agent-bg font-semibold rounded-xl shadow-glow hover:shadow-glow-indigo transition-all"
          >
            Start a new conversation
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>

        <div>
          <p className="text-xs text-agent-text-soft mb-1 text-center font-medium">
            Supported workflows
          </p>
          <p className="text-[11px] text-agent-muted mb-4 text-center max-w-md mx-auto leading-relaxed">
            These are the live tools today—tap one to open a conversation with the same request.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-3xl mx-auto">
            {quickPrompts.map((s) => {
              const Icon = s.icon;
              return (
                <button
                  key={s.label}
                  onClick={() => handleQuickPrompt(s.message)}
                  className="group glass rounded-xl p-4 text-left hover:border-agent-accent/40 hover:shadow-glow transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-agent-surface-2 border border-agent-border flex items-center justify-center text-agent-accent group-hover:bg-agent-accent/10 transition-colors flex-shrink-0">
                      <Icon className="w-4.5 h-4.5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-agent-text">{s.label}</p>
                      <p className="text-xs text-agent-muted mt-0.5 line-clamp-2">{s.message}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
