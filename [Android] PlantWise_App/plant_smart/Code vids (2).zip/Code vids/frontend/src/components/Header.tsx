import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Hourglass,
  Home,
  Power,
  RotateCcw,
  LogOut,
  Sparkles,
  PanelRightOpen,
  PanelRightClose,
  PanelLeftOpen,
  PanelLeftClose,
} from "lucide-react";
import { useConversation } from "../hooks/useConversation";
import { useAuth } from "../context/AuthContext";

interface Props {
  onToggleMeta: () => void;
  showMeta: boolean;
  onToggleHistory: () => void;
  showHistory: boolean;
}

function displayUserLabel(username: string | null, userId: string | null): string {
  const u = (username?.trim() || userId || "").trim();
  return u;
}

function userAvatarInitials(label: string): string {
  const parts = label.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return label.slice(0, 2).toUpperCase();
}

export function Header({ onToggleMeta, showMeta, onToggleHistory, showHistory }: Props) {
  const { status, conversationId, turn, endConversation, reset } = useConversation();
  const { userId, username, logout } = useAuth();
  const who = displayUserLabel(username, userId);
  const initials = who ? userAvatarInitials(who) : "";
  const showHome =
    status !== "idle" && status !== "ended" && status !== "error";

  return (
    <header className="px-5 py-3 flex items-center justify-between gap-4 z-10 bg-transparent">
      {/* Left: history toggle + branding */}
      <div className="flex items-center gap-3 min-w-0">
        {/* History sidebar toggle */}
        <button
          onClick={onToggleHistory}
          title={showHistory ? "Hide conversation history" : "Show conversation history"}
          className={`p-2 rounded-lg text-sm transition-all ${
            showHistory
              ? "bg-agent-accent-2/15 text-agent-accent-2 shadow-glow-indigo"
              : "text-agent-muted hover:text-agent-text hover:bg-agent-surface-2"
          }`}
        >
          {showHistory
            ? <PanelLeftClose className="w-4 h-4" />
            : <PanelLeftOpen className="w-4 h-4" />}
        </button>

        {showHome && (
          <button
            type="button"
            onClick={() => reset()}
            title="Home — welcome & quick prompts"
            className="p-2 rounded-lg text-sm text-agent-muted hover:text-agent-text hover:bg-agent-surface-2 transition-all"
          >
            <Home className="w-4 h-4" />
          </button>
        )}

        <div className="relative w-9 h-9 flex-shrink-0">
          <div className="absolute inset-0 rounded-xl bg-agent-gradient blur opacity-50" />
          <div className="relative w-9 h-9 rounded-xl bg-agent-gradient flex items-center justify-center shadow-glow">
            <Sparkles className="w-4.5 h-4.5 text-agent-bg" strokeWidth={2.5} />
          </div>
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-semibold tracking-tight">
              <span className="text-gradient">Aegis</span>
              <span className="text-agent-text"> Agentic AI</span>
            </h1>
            <span className="hidden sm:inline-flex items-center gap-1 text-[9px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-agent-accent/10 text-agent-accent border border-agent-accent/30">
              <span className="w-1 h-1 rounded-full bg-agent-accent animate-pulse" />
              live
            </span>
          </div>
          {conversationId && (
            <p className="text-[10px] text-agent-muted font-mono truncate">
              {conversationId.slice(0, 8)}… · turn {turn}
            </p>
          )}
        </div>
      </div>

      {/* Center: status */}
      {status !== "idle" && <StatusPill status={status} />}

      {/* Right: actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleMeta}
          title="Toggle inspector"
          className={`p-2 rounded-lg text-sm transition-all ${
            showMeta
              ? "bg-agent-accent/15 text-agent-accent shadow-glow"
              : "text-agent-muted hover:text-agent-text hover:bg-agent-surface-2"
          }`}
        >
          {showMeta ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
        </button>

        {status !== "idle" && status !== "ended" && (
          <button
            onClick={endConversation}
            className="px-3 py-1.5 text-xs text-agent-text-soft border border-agent-border rounded-lg hover:bg-agent-bad/10 hover:border-agent-bad/40 hover:text-agent-bad transition-colors flex items-center gap-1.5"
          >
            <Power className="w-3.5 h-3.5" /> End
          </button>
        )}

        {(status === "ended" || status === "error") && (
          <button
            onClick={reset}
            className="px-3 py-1.5 text-xs bg-agent-gradient text-agent-bg font-semibold rounded-lg shadow-glow hover:shadow-glow-indigo transition-all flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" /> New chat
          </button>
        )}

        {userId && who && (
          <div className="flex items-center gap-2 pl-3 border-l border-agent-border">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-agent-surface-2 border border-agent-border flex items-center justify-center text-[11px] font-semibold text-agent-accent uppercase">
                {initials}
              </div>
              <span className="hidden sm:inline text-xs text-agent-text-soft font-mono" title={who}>
                {who}
              </span>
            </div>
            <button
              onClick={logout}
              className="p-1.5 text-agent-muted hover:text-agent-text hover:bg-agent-surface-2 rounded transition-colors"
              title="Sign out"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

function StatusPill({ status }: { status: string }) {
  const cfg: Record<string, { label: string; color: string; icon: typeof Activity }> = {
    active: { label: "Active", color: "text-agent-good border-agent-good/40 bg-agent-good/10", icon: Activity },
    hitl_pending: { label: "Awaiting Confirmation", color: "text-agent-accent-3 border-agent-accent-3/40 bg-agent-accent-3/10", icon: Hourglass },
    escalated: { label: "Escalated", color: "text-agent-bad border-agent-bad/40 bg-agent-bad/10", icon: AlertTriangle },
    ended: { label: "Session Ended", color: "text-agent-muted border-agent-border bg-agent-surface-2", icon: CheckCircle2 },
    error: { label: "Error", color: "text-agent-bad border-agent-bad/40 bg-agent-bad/10", icon: AlertTriangle },
  };
  const c = cfg[status] ?? cfg.active;
  const Icon = c.icon;
  return (
    <div className={`hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full border text-[11px] font-medium uppercase tracking-wider ${c.color}`}>
      <Icon className="w-3 h-3" />
      {c.label}
    </div>
  );
}
