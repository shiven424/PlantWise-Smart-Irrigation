import { useState, useRef, useEffect, type FormEvent } from "react";
import { Send, AlertCircle } from "lucide-react";
import { useConversation } from "../hooks/useConversation";

export function InputBar() {
  const { status, loading, sendMessage, error } = useConversation();
  const [text, setText] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const disabled =
    loading || status === "hitl_pending" || status === "escalated" || status === "ended";

  // Auto-send pending demo message after conversation starts
  const { conversationId } = useConversation();
  const pendingRef = useRef(false);
  useEffect(() => {
    if (pendingRef.current) return;
    const pending = sessionStorage.getItem("pendingDemoMessage");
    if (pending && conversationId && !loading) {
      pendingRef.current = true;
      sessionStorage.removeItem("pendingDemoMessage");
      sendMessage(pending);
    }
  }, [conversationId, loading, sendMessage]);

  useEffect(() => {
    if (!disabled) inputRef.current?.focus();
  }, [disabled, loading]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed || disabled) return;
    setText("");
    sendMessage(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const statusHint = (): string | null => {
    if (status === "hitl_pending") return "Awaiting your confirmation above";
    if (status === "escalated") return "Conversation escalated to a specialist";
    if (status === "ended") return "Conversation has ended";
    return null;
  };

  const hint = statusHint();

  return (
    <div className="px-4 py-3 bg-transparent">
      <div className="max-w-3xl mx-auto">
        {error && (
          <div className="mb-2 px-3 py-2 bg-agent-bad/10 border border-agent-bad/30 rounded-lg text-sm text-agent-bad flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}
        {hint && (
          <div className="mb-2 text-xs text-agent-muted text-center uppercase tracking-wider">
            {hint}
          </div>
        )}
        <form onSubmit={handleSubmit} className="relative">
          <textarea
            ref={inputRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={disabled}
            rows={1}
            placeholder={disabled ? "" : "Ask Aegis anything…"}
            className="w-full resize-none rounded-2xl bg-agent-surface-2 border border-agent-border px-4 py-3 pr-14 text-sm text-agent-text placeholder-agent-subtle focus:outline-none focus:border-agent-accent/50 focus:ring-2 focus:ring-agent-accent/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          />
          <button
            type="submit"
            disabled={disabled || !text.trim()}
            className="absolute right-2 bottom-2 w-9 h-9 flex items-center justify-center bg-agent-gradient text-agent-bg rounded-xl shadow-glow hover:shadow-glow-indigo disabled:opacity-30 disabled:cursor-not-allowed disabled:shadow-none transition-all"
            title="Send (Enter)"
          >
            <Send className="w-4 h-4" strokeWidth={2.5} />
          </button>
        </form>
        <p className="mt-1.5 text-[10px] text-agent-subtle text-center">
          Press <kbd className="px-1 py-0.5 rounded bg-agent-surface-2 border border-agent-border font-mono">Enter</kbd> to send · <kbd className="px-1 py-0.5 rounded bg-agent-surface-2 border border-agent-border font-mono">Shift + Enter</kbd> for new line
        </p>
      </div>
    </div>
  );
}
