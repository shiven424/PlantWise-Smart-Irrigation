import { Component, type ReactNode } from "react";
import type { ChatMessage } from "../types/api";
import { ActionType } from "../types/api";
import { Markdown } from "../lib/markdown";
import { AnswerCard } from "./actions/AnswerCard";
import { SlotCollector } from "./actions/SlotCollector";
import { AuthChallenge } from "./actions/AuthChallenge";
import { HITLConfirmation } from "./actions/HITLConfirmation";
import { TransactionResult } from "./actions/TransactionResult";
import { EscalationNotice } from "./actions/EscalationNotice";
import { ErrorMessage } from "./actions/ErrorMessage";

interface Props {
  message: ChatMessage;
}

// — Error Boundary — prevents a crash in one action card from breaking
//   the entire chat UI. Falls back to the plain ErrorMessage component.
interface EBState {
  hasError: boolean;
}

class ActionErrorBoundary extends Component<
  { children: ReactNode; message: ChatMessage },
  EBState
> {
  constructor(props: { children: ReactNode; message: ChatMessage }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): EBState {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.error("[ActionRenderer] Render error caught by boundary:", error);
  }

  render() {
    if (this.state.hasError) {
      return <ErrorMessage message={this.props.message} />;
    }
    return this.props.children;
  }
}

export function ActionRenderer({ message }: Props) {
  return (
    <ActionErrorBoundary message={message}>
      <ActionContent message={message} />
    </ActionErrorBoundary>
  );
}

function ActionContent({ message }: Props) {
  const at = message.action_type as ActionType | null | undefined;

  switch (at) {
    case ActionType.ANSWER:
      return <AnswerCard message={message} />;

    case ActionType.COLLECT_SLOT:
    case ActionType.RETRY_SLOT:
    case ActionType.CLARIFY:
      return <SlotCollector message={message} />;

    case ActionType.INITIATE_AUTH:
    case ActionType.AUTH_CHALLENGE:
    case ActionType.PROCESS_AUTH:
      return <AuthChallenge message={message} />;

    case ActionType.PRESENT_HITL:
      return <HITLConfirmation message={message} />;

    case ActionType.HITL_APPROVED:
    case ActionType.EXECUTE_TRANSACTION:
    case ActionType.CORRECTION_ACK:
      return <TransactionResult message={message} />;

    case ActionType.ESCALATE:
      return <EscalationNotice message={message} />;

    case ActionType.HANDLE_ERROR:
      return <ErrorMessage message={message} />;

    // For all other types (CHITCHAT_RESPOND, END_SESSION, VALIDATE_ENTITIES,
    // PUSH_INTENT, POP_INTENT, HITL_CORRECTION) — render plain text
    default:
      return <DefaultMessage message={message} />;
  }
}

function DefaultMessage({ message }: Props) {
  const response = message.response;

  return (
    <div className="space-y-2">
      {response?.opening_frame && (
        <p className="text-sm text-agent-muted italic">{response.opening_frame}</p>
      )}
      <Markdown text={response?.core_content ?? message.content} />
      {response?.compliance_tail && (
        <p className="text-xs text-agent-muted mt-2 border-t border-agent-border pt-2">
          {response.compliance_tail}
        </p>
      )}
    </div>
  );
}
