import { useState, type FormEvent } from "react";
import { Sparkles, ShieldCheck, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export function Login() {
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(username.trim(), password);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="pointer-events-none absolute -top-32 -left-32 w-96 h-96 rounded-full bg-agent-accent-2/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-agent-accent/20 blur-3xl" />

      <div className="w-full max-w-md space-y-6 relative animate-fade-in-up">
        <div className="text-center space-y-3">
          <div className="relative w-16 h-16 mx-auto">
            <div className="absolute inset-0 rounded-2xl bg-agent-gradient blur-md opacity-60" />
            <div className="relative w-16 h-16 rounded-2xl bg-agent-gradient flex items-center justify-center shadow-glow">
              <Sparkles className="w-8 h-8 text-agent-bg" strokeWidth={2.5} />
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              <span className="text-gradient">Aegis</span>
              <span className="text-agent-text"> · Agentic AI</span>
            </h1>
            <p className="text-sm text-agent-muted mt-1">
              Multi-agent contact-center for retirement &amp; wealth services
            </p>
          </div>
        </div>

        <form onSubmit={onSubmit} className="glass-strong rounded-2xl p-6 space-y-4 shadow-card">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-agent-muted">
            <ShieldCheck className="w-3.5 h-3.5" /> Secure Sign-In
          </div>

          <div>
            <label htmlFor="username" className="block text-xs font-medium text-agent-text-soft mb-1.5">
              Username
            </label>
            <input
              id="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-agent-surface-2 border border-agent-border rounded-lg text-agent-text placeholder-agent-subtle focus:outline-none focus:border-agent-accent/60 focus:ring-2 focus:ring-agent-accent/20 transition-all"
              placeholder="username"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-xs font-medium text-agent-text-soft mb-1.5">
              Password
            </label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-agent-surface-2 border border-agent-border rounded-lg text-agent-text placeholder-agent-subtle focus:outline-none focus:border-agent-accent/60 focus:ring-2 focus:ring-agent-accent/20 transition-all"
              placeholder="••••••••"
            />
          </div>

          {error && (
            <div className="text-sm text-agent-bad bg-agent-bad/10 border border-agent-bad/30 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="group w-full px-4 py-2.5 bg-agent-gradient bg-[length:200%_200%] animate-gradient-shift text-agent-bg font-semibold rounded-lg shadow-glow hover:shadow-glow-indigo disabled:opacity-60 transition-all flex items-center justify-center gap-2"
          >
            {loading ? "Signing in…" : "Sign in"}
            {!loading && (
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
