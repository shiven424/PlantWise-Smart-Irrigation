import { Sparkles, User } from "lucide-react";
import type { ChatMessage } from "../types/api";
import { ActionRenderer } from "./ActionRenderer";

interface Props {
  message: ChatMessage;
}

export function MessageBubble({ message }: Props) {
  const isUser = message.role === "user";

  return (
    <div className={`flex items-start gap-3 ${isUser ? "ml-auto flex-row-reverse" : ""}`}>
      {/* Avatar */}
      {isUser ? (
        <div className="w-8 h-8 rounded-full bg-agent-surface-2 border border-agent-border flex items-center justify-center flex-shrink-0">
          <User className="w-4 h-4 text-agent-text-soft" />
        </div>
      ) : (
        <div className="relative w-8 h-8 flex-shrink-0">
          <div className="absolute inset-0 rounded-full bg-agent-gradient blur opacity-50" />
          <div className="relative w-8 h-8 rounded-full bg-agent-gradient flex items-center justify-center shadow-glow">
            <Sparkles className="w-4 h-4 text-agent-bg" strokeWidth={2.5} />
          </div>
        </div>
      )}

      {/* Bubble */}
      <div
        className={`max-w-[85%] ${
          isUser
            ? "rounded-2xl rounded-tr-sm px-4 py-2.5 bg-gradient-to-br from-agent-accent-2/30 to-agent-accent/15 border border-agent-accent-2/30 text-agent-text shadow-card"
            : "rounded-2xl rounded-tl-sm px-4 py-3 glass shadow-card text-agent-text"
        }`}
      >
        {isUser ? (
          <p className="whitespace-pre-wrap leading-relaxed text-sm">{message.content}</p>
        ) : (
          <ActionRenderer message={message} />
        )}
      </div>
    </div>
  );
}
