import type { ChatMessage } from "../types/api";

interface Props {
  message: ChatMessage;
}

export function MetadataPanel({ message }: Props) {
  const meta = message.metadata;
  const response = message.response;

  if (!meta) {
    return (
      <aside className="w-80 border-l border-agent-border/60 glass p-4 overflow-y-auto flex-shrink-0">
        <p className="text-sm text-agent-muted">No metadata available</p>
      </aside>
    );
  }

  return (
    <aside className="w-80 border-l border-agent-border/60 glass p-4 overflow-y-auto flex-shrink-0">
      <h3 className="text-[10px] font-semibold text-agent-muted uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
        <span className="w-1 h-1 rounded-full bg-agent-accent animate-pulse" />
        Agent Inspector
      </h3>

      <div className="space-y-4">
        {message.action_type && (
          <Section title="Action Type">
            <Badge color="accent">{message.action_type}</Badge>
          </Section>
        )}

        {meta.active_intent && (
          <Section title="Active Intent">
            <div className="space-y-1">
              <Row label="Intent" value={meta.active_intent.intent_id} />
              {meta.active_intent.sub_intent && (
                <Row label="Sub-intent" value={meta.active_intent.sub_intent} />
              )}
              <Row label="Domain" value={meta.active_intent.service_domain} />
              <Row
                label="Confidence"
                value={
                  meta.active_intent.confidence != null
                    ? `${(meta.active_intent.confidence * 100).toFixed(0)}%`
                    : "N/A"
                }
              />
            </div>
          </Section>
        )}

        <Section title="Auth Status">
          <Badge
            color={
              meta.auth_status === "VERIFIED"
                ? "good"
                : meta.auth_status === "LOCKED"
                ? "bad"
                : "warn"
            }
          >
            {meta.auth_status ?? "N/A"}
          </Badge>
        </Section>

        {meta.rag_confidence != null && (
          <Section title="RAG">
            <Row
              label="Confidence"
              value={`${(meta.rag_confidence * 100).toFixed(0)}%`}
            />
            {meta.rag_error && (
              <span className="text-xs text-agent-bad">RAG error occurred</span>
            )}
          </Section>
        )}

        {meta.policy_path && (
          <Section title="Policy Path">
            <Badge color="indigo">{meta.policy_path}</Badge>
          </Section>
        )}

        {meta.slot_gap && meta.slot_gap.length > 0 && (
          <Section title="Missing Slots">
            <div className="flex flex-wrap gap-1">
              {meta.slot_gap.map((s) => (
                <span
                  key={s}
                  className="text-[10px] bg-agent-warn/10 text-agent-warn px-1.5 py-0.5 rounded border border-agent-warn/30"
                >
                  {s}
                </span>
              ))}
            </div>
          </Section>
        )}

        {message.escalation && (
          <Section title="Escalation">
            <Row label="Reason" value={message.escalation.reason} />
            <Row label="By" value={message.escalation.triggered_by} />
          </Section>
        )}

        {message.hitl_pending && (
          <Section title="HITL">
            <Badge color="purple">Pending confirmation</Badge>
          </Section>
        )}

        {response && (
          <Section title="Response Structure">
            <div className="space-y-1 text-[10px]">
              <Row label="Opening" value={response.opening_frame ? "✓" : "—"} />
              <Row
                label="Core"
                value={response.core_content ? `${response.core_content.length} chars` : "—"}
              />
              <Row label="Compliance" value={response.compliance_tail ? "✓" : "—"} />
              <Row
                label="Disclosures"
                value={`${response.disclosures_appended?.length ?? 0}`}
              />
            </div>
          </Section>
        )}
      </div>
    </aside>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-[10px] font-semibold text-agent-muted uppercase tracking-[0.18em] mb-1.5">
        {title}
      </p>
      {children}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center text-xs gap-2">
      <span className="text-agent-muted">{label}</span>
      <span className="text-agent-text font-mono text-[11px] truncate" title={value}>
        {value}
      </span>
    </div>
  );
}

function Badge({
  children,
  color = "gray",
}: {
  children: React.ReactNode;
  color?: "gray" | "good" | "bad" | "warn" | "indigo" | "purple" | "accent";
}) {
  const colors: Record<string, string> = {
    gray: "bg-agent-surface-2 text-agent-text-soft border-agent-border",
    good: "bg-agent-good/10 text-agent-good border-agent-good/30",
    bad: "bg-agent-bad/10 text-agent-bad border-agent-bad/30",
    warn: "bg-agent-warn/10 text-agent-warn border-agent-warn/30",
    indigo: "bg-agent-accent-2/10 text-agent-accent-2 border-agent-accent-2/30",
    purple: "bg-agent-accent-3/10 text-agent-accent-3 border-agent-accent-3/30",
    accent: "bg-agent-accent/10 text-agent-accent border-agent-accent/30",
  };

  return (
    <span className={`text-[11px] px-2 py-0.5 rounded-md font-mono border ${colors[color]}`}>
      {children}
    </span>
  );
}
