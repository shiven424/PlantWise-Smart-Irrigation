import { Lock } from "lucide-react";
import type { ChatMessage } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function AuthChallenge({ message }: Props) {
  const response = message.response;
  const authStatus =
    message.action_type === "INITIATE_AUTH"
      ? "PENDING"
      : (message.metadata?.auth_status ?? "PENDING");

  const statusColor =
    authStatus === "VERIFIED"
      ? "text-agent-good border-agent-good/30 bg-agent-good/10"
      : authStatus === "LOCKED"
      ? "text-agent-bad border-agent-bad/30 bg-agent-bad/10"
      : authStatus === "FAILED"
      ? "text-orange-400 border-orange-400/30 bg-orange-400/10"
      : "text-agent-warn border-agent-warn/30 bg-agent-warn/10";

  return (
    <div className="space-y-3">
      <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[10px] font-medium uppercase tracking-wider ${statusColor}`}>
        <span className="w-1 h-1 rounded-full bg-current" />
        Authentication: {authStatus}
      </div>

      {response?.opening_frame && (
        <p className="text-sm text-agent-muted italic">{response.opening_frame}</p>
      )}

      <div className="rounded-xl border border-agent-accent-2/30 bg-gradient-to-br from-agent-accent-2/10 to-agent-accent/5 p-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-agent-accent-2/15 flex items-center justify-center flex-shrink-0 shadow-glow-indigo">
            <Lock className="w-4.5 h-4.5 text-agent-accent-2" />
          </div>
          <div className="text-sm text-agent-text min-w-0">
            <Markdown text={response?.core_content ?? message.content} />
          </div>
        </div>
      </div>

      <p className="text-xs text-agent-muted">
        Type your response in the chat below to verify your identity.
      </p>

      {response?.compliance_tail && (
        <p className="text-xs text-agent-muted border-t border-agent-border pt-2 mt-2">
          {response.compliance_tail}
        </p>
      )}
    </div>
  );
}
