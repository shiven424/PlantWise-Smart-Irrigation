import type { ChatMessage } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function SlotCollector({ message }: Props) {
  const response = message.response;
  const slotGap = message.metadata?.slot_gap ?? [];

  return (
    <div className="space-y-3">
      {response?.opening_frame && (
        <p className="text-sm text-agent-muted italic">{response.opening_frame}</p>
      )}

      <Markdown text={response?.core_content ?? message.content} />

      {slotGap.length > 0 && (
        <div className="rounded-lg border border-agent-warn/30 bg-agent-warn/5 p-3">
          <p className="text-[10px] font-semibold text-agent-warn mb-1.5 uppercase tracking-wider">
            Information needed
          </p>
          <div className="flex flex-wrap gap-1.5">
            {slotGap.map((slot) => (
              <span
                key={slot}
                className="px-2 py-0.5 text-[11px] bg-agent-warn/10 text-agent-warn rounded-full border border-agent-warn/30"
              >
                {slot.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        </div>
      )}

      {response?.compliance_tail && (
        <p className="text-xs text-agent-muted border-t border-agent-border pt-2 mt-2">
          {response.compliance_tail}
        </p>
      )}
    </div>
  );
}
