import { useState } from "react";
import { ChevronDown, ChevronUp, BookOpen } from "lucide-react";
import type { ChatMessage } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function AnswerCard({ message }: Props) {
  const [showCitations, setShowCitations] = useState(false);
  const response = message.response;
  const meta = message.metadata;
  const confidence = meta?.rag_confidence ?? 0;

  return (
    <div className="space-y-3">
      {response?.opening_frame && (
        <p className="text-sm text-agent-muted italic">{response.opening_frame}</p>
      )}

      <Markdown text={response?.core_content ?? message.content} />

      {confidence > 0 && (
        <div className="flex items-center gap-3 pt-1">
          <div className="flex items-center gap-1.5">
            <div
              className={`w-2 h-2 rounded-full ${
                confidence >= 0.85
                  ? "bg-agent-good shadow-[0_0_8px] shadow-agent-good/60"
                  : confidence >= 0.7
                  ? "bg-agent-warn shadow-[0_0_8px] shadow-agent-warn/60"
                  : "bg-agent-bad shadow-[0_0_8px] shadow-agent-bad/60"
              }`}
            />
            <span className="text-[11px] text-agent-muted uppercase tracking-wider">
              Confidence {(confidence * 100).toFixed(0)}%
            </span>
          </div>
          <button
            onClick={() => setShowCitations((p) => !p)}
            className="text-[11px] text-agent-accent hover:text-agent-accent-2 inline-flex items-center gap-1 transition-colors"
          >
            <BookOpen className="w-3 h-3" />
            {showCitations ? "Hide sources" : "View sources"}
            {showCitations ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      )}

      {showCitations && (
        <div className="bg-agent-surface-2 border border-agent-border rounded-lg p-3 text-xs space-y-1">
          <p className="font-medium text-agent-text">Sources</p>
          <p className="text-agent-muted">
            Citations are embedded in the backend RAG response. Open the inspector for full source details.
          </p>
        </div>
      )}

      {response?.compliance_tail && (
        <div className="text-xs text-agent-muted border-t border-agent-border pt-2 mt-2">
          {response.compliance_tail}
        </div>
      )}

      {response?.disclosures_appended && response.disclosures_appended.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {response.disclosures_appended.map((d) => (
            <span
              key={d}
              className="text-[10px] bg-agent-accent-2/10 text-agent-accent-2 border border-agent-accent-2/30 px-1.5 py-0.5 rounded"
            >
              {d.replace(/_/g, " ")}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
