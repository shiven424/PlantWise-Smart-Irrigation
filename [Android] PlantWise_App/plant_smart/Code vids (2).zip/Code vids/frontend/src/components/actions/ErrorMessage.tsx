import { XCircle } from "lucide-react";
import type { ChatMessage } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function ErrorMessage({ message }: Props) {
  const response = message.response;

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-agent-bad/40 bg-gradient-to-br from-agent-bad/10 to-agent-bad/5 p-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-agent-bad/15 flex items-center justify-center flex-shrink-0">
            <XCircle className="w-4.5 h-4.5 text-agent-bad" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-sm text-agent-bad mb-1">Something went wrong</p>
            <div className="text-sm text-agent-text-soft">
              <Markdown text={response?.core_content ?? message.content} />
            </div>
          </div>
        </div>
      </div>

      <p className="text-xs text-agent-muted">
        You can try rephrasing your request or ask to speak with a specialist.
      </p>
    </div>
  );
}
