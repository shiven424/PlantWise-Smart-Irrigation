import { AlertTriangle, ArrowUpRight } from "lucide-react";
import type { ChatMessage } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function EscalationNotice({ message }: Props) {
  const response = message.response;
  const esc = message.escalation;
  const reason = esc?.reason ?? "UNKNOWN";

  const isUrgent = ["DISTRESS_SIGNAL", "LEGAL_THREAT", "AUTH_LOCKED"].includes(reason);
  const palette = isUrgent
    ? "border-agent-bad/40 bg-gradient-to-br from-agent-bad/10 to-agent-bad/5"
    : "border-agent-warn/40 bg-gradient-to-br from-agent-warn/10 to-agent-warn/5";
  const iconColor = isUrgent ? "text-agent-bad" : "text-agent-warn";
  const labelColor = isUrgent ? "text-agent-bad" : "text-agent-warn";

  return (
    <div className="space-y-3">
      <div className={`rounded-xl border p-4 ${palette}`}>
        <div className="flex items-start gap-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 bg-current/10 ${iconColor}`}>
            <AlertTriangle className="w-4.5 h-4.5" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <ArrowUpRight className={`w-4 h-4 ${labelColor}`} />
              <p className={`font-semibold text-sm ${labelColor}`}>
                Escalation: {reason.replace(/_/g, " ")}
              </p>
            </div>
            <div className="text-sm text-agent-text">
              <Markdown text={response?.core_content ?? message.content} />
            </div>
            {esc?.triggered_by && (
              <p className="text-[11px] text-agent-muted mt-2 font-mono">
                Triggered by: {esc.triggered_by}
              </p>
            )}
          </div>
        </div>
      </div>

      {response?.compliance_tail && (
        <p className="text-xs text-agent-muted border-t border-agent-border pt-2">
          {response.compliance_tail}
        </p>
      )}
    </div>
  );
}
