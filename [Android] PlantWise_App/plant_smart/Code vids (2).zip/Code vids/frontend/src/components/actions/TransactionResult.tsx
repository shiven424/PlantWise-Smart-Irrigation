import { AlertTriangle, CheckCircle2 } from "lucide-react";
import type { ChatMessage, TransactionUiOutcome } from "../../types/api";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

/** Core markdown headings emitted by synthesizer for read-only / estimate flows */
const INFO_HEADINGS = [
  "**Account overview**",
  "**Transaction history**",
  "**RMD estimate**",
  "**Loan eligibility**",
  "**Your plan loans**",
  "**Loan preview**",
  "**Plan loan finalized**",
  "**Confirmation summary**",
] as const;

const INFO_BADGE_LABEL: Record<(typeof INFO_HEADINGS)[number], string> = {
  "**Account overview**": "Account overview",
  "**Transaction history**": "Transaction history",
  "**RMD estimate**": "RMD estimate",
  "**Loan eligibility**": "Loan eligibility",
  "**Your plan loans**": "Plan loans",
  "**Loan preview**": "Loan preview",
  "**Plan loan finalized**": "Plan loan finalized",
  "**Confirmation summary**": "Confirmation summary",
};

const INFO_DEFAULT_SUB: Record<(typeof INFO_HEADINGS)[number], string> = {
  "**Account overview**": "Here's a secure summary of your balances and plan details.",
  "**Transaction history**":
    "Read-only recap of recorded account activity shown after verifying your identity.",
  "**RMD estimate**": "Illustrative required minimum distribution from your verified records.",
  "**Loan eligibility**": "Borrowing limits and eligibility — nothing has been disbursed yet.",
  "**Your plan loans**": "Existing loan records on file — no change was made.",
  "**Loan preview**": "Estimated payment schedule for planning — not finalized until you confirm.",
  "**Plan loan finalized**":
    "Your loan record and repayment figures are summarized below for your records.",
  "**Confirmation summary**":
    "Read-only recap of what we processed from your verified request.",
};

function matchInfoHeading(core: string | undefined): (typeof INFO_HEADINGS)[number] | null {
  if (!core) return null;
  const t = core.trimStart();
  for (const h of INFO_HEADINGS) {
    if (t.startsWith(h) || t.includes("\n" + h + "\n")) {
      return h;
    }
  }
  return null;
}

function resolveTxOutcome(message: ChatMessage): TransactionUiOutcome | null {
  const explicit = message.metadata?.transaction_ui_outcome;
  if (explicit === "failure" || explicit === "success" || explicit === "informational") {
    return explicit;
  }
  const core = message.response?.core_content ?? message.content ?? "";
  if (
    /\*\*Transaction Could Not Be Completed\*\*/i.test(core) ||
    /\*\*We couldn't finalize your plan loan\*\*/i.test(core)
  ) {
    return "failure";
  }
  if (/^\*?\*?Status:\*?\*?\s*Failed\b/im.test(core)) return "failure";
  return null;
}

function loanRelatedSubIntent(meta: ChatMessage["metadata"]): boolean {
  const s = meta?.active_intent?.sub_intent ?? "";
  return typeof s === "string" && s.includes("PLAN_LOAN");
}

export function TransactionResult({ message }: Props) {
  const response = message.response;
  const core = response?.core_content ?? message.content ?? "";
  const headingMatch = matchInfoHeading(core);
  const txOutcome = resolveTxOutcome(message);
  const isLoanTopic = loanRelatedSubIntent(message.metadata);

  let variant: "success" | "failure" | "neutral" = "success";
  let badgeTitle =
    headingMatch ? INFO_BADGE_LABEL[headingMatch] : "Request summary";
  let badgeSubtitle =
    response?.opening_frame ??
    (headingMatch ? INFO_DEFAULT_SUB[headingMatch] : "");

  if (txOutcome === "failure") {
    variant = "failure";
    badgeTitle = isLoanTopic ? "Loan request not completed" : "Request not completed";
    badgeSubtitle =
      response?.opening_frame ??
      "Review the outcome below — no disbursement occurred if the status is failed.";
  } else if (headingMatch) {
    variant = "success";
    badgeSubtitle = response?.opening_frame ?? INFO_DEFAULT_SUB[headingMatch];
  } else if (txOutcome === "success") {
    variant = "success";
    badgeTitle = isLoanTopic ? "Plan loan finalized" : "Confirmation summary";
    badgeSubtitle =
      response?.opening_frame ??
      "Read-only recap of verified details from your request.";
  } else {
    variant = "neutral";
    badgeTitle = "Update";
    badgeSubtitle =
      response?.opening_frame ??
      "Details from your verified request appear below.";
  }

  const shell =
    variant === "failure"
      ? "rounded-xl border border-agent-warn/45 bg-gradient-to-br from-agent-warn/10 to-agent-surface-2 p-4"
      : variant === "neutral"
        ? "rounded-xl border border-agent-border bg-agent-surface-2/80 p-4"
        : "rounded-xl border border-agent-good/40 bg-gradient-to-br from-agent-good/10 to-agent-accent/5 p-4";

  const Icon = variant === "failure" ? AlertTriangle : CheckCircle2;
  const iconWrap =
    variant === "failure"
      ? "w-10 h-10 rounded-xl bg-agent-warn/15 flex items-center justify-center flex-shrink-0 shadow-[0_0_24px_-4px] shadow-agent-warn/50 text-agent-warn"
      : variant === "neutral"
        ? "w-10 h-10 rounded-xl bg-agent-accent-2/10 flex items-center justify-center flex-shrink-0 text-agent-accent-2"
        : "w-10 h-10 rounded-xl bg-agent-good/15 flex items-center justify-center flex-shrink-0 shadow-[0_0_24px_-4px] shadow-agent-good/60 text-agent-good";

  const disclosureTone =
    variant === "failure"
      ? "text-[10px] bg-agent-warn/10 text-agent-warn px-1.5 py-0.5 rounded border border-agent-warn/30"
      : "text-[10px] bg-agent-good/10 text-agent-good px-1.5 py-0.5 rounded border border-agent-good/30";

  return (
    <div className="space-y-3">
      <div className={shell}>
        <div className="flex items-center gap-3">
          <div className={iconWrap}>
            <Icon className="w-6 h-6" strokeWidth={variant === "failure" ? 2.2 : 2.5} />
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-agent-text text-sm">{badgeTitle}</p>
            {badgeSubtitle ? (
              <p className="text-xs text-agent-text-soft mt-0.5">{badgeSubtitle}</p>
            ) : null}
          </div>
        </div>
      </div>

      <div className="text-sm text-agent-text">
        <Markdown text={response?.core_content ?? message.content} />
      </div>

      {response?.compliance_tail && (
        <div className="text-xs text-agent-muted border-t border-agent-border pt-2 mt-2 bg-agent-surface-2 rounded-lg p-3">
          {response.compliance_tail}
        </div>
      )}

      {response?.disclosures_appended && response.disclosures_appended.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {response.disclosures_appended.map((d) => (
            <span key={d} className={disclosureTone}>
              {d.replace(/_/g, " ")}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
