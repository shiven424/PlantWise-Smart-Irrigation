import { useState } from "react";
import { ShieldCheck, Pencil, Check, X } from "lucide-react";
import type { ChatMessage } from "../../types/api";
import { useConversation } from "../../hooks/useConversation";
import { Markdown } from "../../lib/markdown";

interface Props {
  message: ChatMessage;
}

export function HITLConfirmation({ message }: Props) {
  const { sendHITL, loading, status } = useConversation();
  const [editing, setEditing] = useState(false);
  const [corrections, setCorrections] = useState<Record<string, string>>({});
  const response = message.response;
  const isActive = message.hitl_pending && status === "hitl_pending";
  // Prefer ``editable_slots`` (the slots backing this confirmation,
  // populated when HITL is pending) over ``slot_gap`` (which is empty
  // by definition once validation has passed).
  const editableEntries = Object.entries(message.metadata?.editable_slots ?? {});
  const editableSlots: string[] =
    editableEntries.length > 0
      ? editableEntries.map(([k]) => k)
      : (message.metadata?.slot_gap ?? []);
  const initialValues: Record<string, string> = Object.fromEntries(editableEntries);

  const handleApprove = () => sendHITL({ approved: true });

  const handleCorrect = () => {
    if (editing) {
      // Submit only slots whose value differs from the original (so we
      // don't "correct" a field with the same value the system already
      // has) and that aren't blank.
      const changes: Record<string, string> = {};
      for (const [k, v] of Object.entries(corrections)) {
        const trimmed = v.trim();
        if (trimmed && trimmed !== (initialValues[k] ?? "")) {
          changes[k] = trimmed;
        }
      }
      sendHITL({ approved: false, corrections: changes });
      setEditing(false);
    } else {
      // Pre-populate the form with the current values so the user can
      // edit in place rather than re-typing from scratch.
      setCorrections({ ...initialValues });
      setEditing(true);
    }
  };

  return (
    <div className="space-y-3">
      {response?.opening_frame && (
        <p className="text-sm text-agent-muted italic">{response.opening_frame}</p>
      )}

      <div className="rounded-xl border border-agent-accent-3/40 bg-gradient-to-br from-agent-accent-3/10 to-agent-accent-2/5 p-4 shadow-glow-purple">
        <div className="flex items-center gap-2 mb-3 pb-2 border-b border-agent-accent-3/20">
          <div className="w-7 h-7 rounded-lg bg-agent-accent-3/15 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4 text-agent-accent-3" />
          </div>
          <span className="text-xs font-semibold text-agent-accent-3 uppercase tracking-wider">
            Confirm to Proceed
          </span>
          {isActive && (
            <span className="ml-auto inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-agent-accent-3/15 text-agent-accent-3">
              <span className="w-1 h-1 rounded-full bg-agent-accent-3 animate-pulse" />
              awaiting
            </span>
          )}
        </div>
        <div className="text-sm text-agent-text">
          <Markdown text={response?.core_content ?? message.content} />
        </div>
      </div>

      {editing && (
        <div className="bg-agent-surface-2 border border-agent-border rounded-xl p-4 space-y-3">
          <p className="text-xs font-semibold text-agent-text uppercase tracking-wider">
            Edit details
          </p>
          {(editableSlots.length > 0 ? editableSlots : ["correction"]).map((slot) => (
            <div key={slot}>
              <label className="block text-[11px] text-agent-muted mb-1 uppercase tracking-wider">
                {slot.replace(/_/g, " ")}
              </label>
              <input
                type="text"
                value={corrections[slot] ?? ""}
                onChange={(e) =>
                  setCorrections((prev) => ({ ...prev, [slot]: e.target.value }))
                }
                className="w-full px-3 py-2 text-sm bg-agent-bg border border-agent-border rounded-lg text-agent-text placeholder-agent-subtle focus:outline-none focus:border-agent-accent/60 focus:ring-2 focus:ring-agent-accent/20"
                placeholder={initialValues[slot] ?? `New ${slot.replace(/_/g, " ")}`}
              />
            </div>
          ))}
          <p className="text-[11px] text-agent-muted">
            Change any field above and click <strong>Submit Corrections</strong>. Leave a field blank to keep its current value.
          </p>
        </div>
      )}

      {isActive && (
        <div className="flex gap-2">
          <button
            onClick={handleApprove}
            disabled={loading}
            className="flex-1 px-4 py-2.5 bg-agent-good text-agent-bg text-sm font-semibold rounded-lg hover:bg-agent-good/90 hover:shadow-[0_0_24px_-4px] hover:shadow-agent-good/60 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" strokeWidth={3} /> Approve
          </button>
          <button
            onClick={handleCorrect}
            disabled={loading}
            className="flex-1 px-4 py-2.5 bg-agent-surface-2 border border-agent-border text-agent-text text-sm font-medium rounded-lg hover:border-agent-accent/40 hover:bg-agent-surface disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          >
            {editing ? <><Check className="w-4 h-4" /> Submit Corrections</> : <><Pencil className="w-4 h-4" /> Edit & Correct</>}
          </button>
          {editing && (
            <button
              onClick={() => { setEditing(false); setCorrections({}); }}
              disabled={loading}
              className="px-3 py-2.5 bg-agent-surface-2 border border-agent-border text-agent-muted text-sm rounded-lg hover:text-agent-bad hover:border-agent-bad/40 disabled:opacity-50 transition-all"
              title="Cancel edit"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {response?.compliance_tail && (
        <p className="text-xs text-agent-muted border-t border-agent-border pt-2">
          {response.compliance_tail}
        </p>
      )}
    </div>
  );
}
