import { useEffect, useMemo, useRef, useState } from "react";
import {
  MessageSquare,
  Plus,
  Trash2,
  Play,
  Loader2,
  AlertCircle,
  ChevronDown,
  ChevronRight,
  Archive,
  X,
  Undo2,
} from "lucide-react";
import { useConversation } from "../hooks/useConversation";
import type { ConversationListItem } from "../types/api";
import { formatConversationalDateTime } from "../lib/formatTemporal";

interface Props {
  onClose?: () => void;
  onNewChat: () => void;
}

export function ConversationHistoryPanel({ onClose, onNewChat }: Props) {
  const {
    historyList,
    historyLoading,
    historyError,
    historyHasMore,
    deleteInFlight,
    conversationId: activeId,
    loadMoreHistory,
    resumeConversation,
    restoreHiddenConversation,
  } = useConversation();

  const [pendingDelete, setPendingDelete] = useState<ConversationListItem | null>(null);
  const [hiddenOpen, setHiddenOpen] = useState(false);

  const { visibleConversations, hiddenConversations } = useMemo(() => {
    const visible: ConversationListItem[] = [];
    const hidden: ConversationListItem[] = [];
    for (const item of historyList) {
      if (item.status === "SOFT_DELETED") hidden.push(item);
      else visible.push(item);
    }
    return { visibleConversations: visible, hiddenConversations: hidden };
  }, [historyList]);

  useEffect(() => {
    if (hiddenConversations.length === 0) setHiddenOpen(false);
  }, [hiddenConversations.length]);

  // Infinite scroll trigger
  const loaderRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!loaderRef.current || !historyHasMore) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMoreHistory();
      },
      { threshold: 0.1 },
    );
    obs.observe(loaderRef.current);
    return () => obs.disconnect();
  }, [historyHasMore, loadMoreHistory]);

  return (
    <>
      {/* Panel */}
      <aside className="w-72 flex flex-col flex-shrink-0 border-r border-agent-border/60 glass overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-agent-border/40">
          <h2 className="text-[10px] font-semibold text-agent-muted uppercase tracking-[0.2em] flex items-center gap-2">
            <span className="w-1 h-1 rounded-full bg-agent-accent-2" />
            Conversations
          </h2>
          <div className="flex items-center gap-1">
            <button
              onClick={onNewChat}
              title="Start new conversation"
              className="p-1.5 rounded-lg text-agent-muted hover:text-agent-text hover:bg-agent-surface-2 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
            {onClose && (
              <button
                onClick={onClose}
                title="Close panel"
                className="p-1.5 rounded-lg text-agent-muted hover:text-agent-text hover:bg-agent-surface-2 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-2 px-2 space-y-1">
          {/* Initial loading skeleton */}
          {historyLoading && historyList.length === 0 && (
            <div className="space-y-2 px-1 pt-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="h-14 rounded-xl bg-agent-surface-2 border border-agent-border/40 shimmer-bg animate-shimmer"
                />
              ))}
            </div>
          )}

          {/* Error state */}
          {historyError && (
            <div className="mx-1 p-3 rounded-xl bg-agent-bad/10 border border-agent-bad/30 flex items-start gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-agent-bad flex-shrink-0 mt-0.5" />
              <p className="text-xs text-agent-bad">{historyError}</p>
            </div>
          )}

          {/* Empty state */}
          {!historyLoading &&
            !historyError &&
            historyList.length === 0 && (
              <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
                <MessageSquare className="w-8 h-8 text-agent-muted opacity-40" />
                <p className="text-xs text-agent-muted max-w-[180px]">
                  No previous chats yet. Start a conversation to see it here.
                </p>
              </div>
            )}

          {!historyLoading &&
            !historyError &&
            visibleConversations.length === 0 &&
            hiddenConversations.length > 0 && (
              <p className="text-[11px] text-agent-muted text-center px-3 py-4 leading-relaxed">
                Visible chats will appear here. Hidden conversations are in the section below.
              </p>
            )}

          {/* Main conversation list */}
          {visibleConversations.map((item) => (
            <ConversationRow
              key={item.conversation_id}
              item={item}
              isActive={item.conversation_id === activeId}
              isDeleting={!!deleteInFlight[item.conversation_id]}
              onResume={() => resumeConversation(item.conversation_id)}
              onRestore={() => restoreHiddenConversation(item.conversation_id)}
              onDelete={() => setPendingDelete(item)}
              statusDetail="full"
            />
          ))}

          {/* Hidden — archive-style */}
          {hiddenConversations.length > 0 && (
            <div className="mt-2 pt-2 border-t border-agent-border/50">
              <button
                type="button"
                onClick={() => setHiddenOpen((o) => !o)}
                className="w-full flex items-center gap-2 px-2 py-2 rounded-lg text-left text-agent-text-soft hover:bg-agent-surface-2 hover:text-agent-text transition-colors mb-1"
              >
                {hiddenOpen ? (
                  <ChevronDown className="w-4 h-4 text-agent-muted flex-shrink-0" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-agent-muted flex-shrink-0" />
                )}
                <Archive className="w-4 h-4 text-agent-muted flex-shrink-0" />
                <span className="text-xs font-medium flex-1 min-w-0">
                  Hidden
                </span>
                <span className="text-[10px] font-mono tabular-nums px-2 py-0.5 rounded-md bg-agent-surface-2 border border-agent-border text-agent-muted">
                  {hiddenConversations.length}
                </span>
              </button>
              {hiddenOpen && (
                <div className="space-y-1 pl-1 border-l border-agent-border/40 ml-4">
                  {hiddenConversations.map((item) => (
                    <ConversationRow
                      key={item.conversation_id}
                      item={item}
                      isActive={item.conversation_id === activeId}
                      isDeleting={!!deleteInFlight[item.conversation_id]}
                      onResume={() => resumeConversation(item.conversation_id)}
                      onRestore={() => restoreHiddenConversation(item.conversation_id)}
                      onDelete={() => setPendingDelete(item)}
                      statusDetail="minimal"
                    />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Load-more sentinel */}
          {historyHasMore && (
            <div ref={loaderRef} className="flex justify-center py-3">
              {historyLoading ? (
                <Loader2 className="w-4 h-4 text-agent-muted animate-spin" />
              ) : (
                <button
                  onClick={loadMoreHistory}
                  className="flex items-center gap-1.5 text-xs text-agent-muted hover:text-agent-text transition-colors"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                  Load more
                </button>
              )}
            </div>
          )}
        </div>
      </aside>

      {/* Delete modal rendered outside the scrollable container */}
      {pendingDelete && (
        <DeleteConversationModal
          item={pendingDelete}
          onClose={() => setPendingDelete(null)}
        />
      )}
    </>
  );
}

// — Conversation row ————————————————————————————————————————————————————————

interface RowProps {
  item: ConversationListItem;
  isActive: boolean;
  isDeleting: boolean;
  onResume: () => void;
  onRestore: () => void;
  onDelete: () => void;
  /** In archive section omit redundant lifecycle pill. */
  statusDetail?: "full" | "minimal";
}

function ConversationRow({
  item,
  isActive,
  isDeleting,
  onResume,
  onRestore,
  onDelete,
  statusDetail = "full",
}: RowProps) {
  const title =
    item.last_user_message_preview?.slice(0, 45) ??
    `Conversation · turn ${item.current_turn}`;

  const relativeTime = formatRelative(item.last_active_at);
  const isHidden = item.status === "SOFT_DELETED";

  const statusColor: Record<string, string> = {
    ACTIVE: "bg-agent-good text-agent-good",
    ENDED: "bg-agent-muted text-agent-muted",
    SOFT_DELETED: "bg-agent-bad text-agent-bad",
  };
  const sc = statusColor[item.status] ?? statusColor.ACTIVE;

  return (
    <div
      className={`group relative flex items-start gap-2.5 rounded-xl px-3 py-2.5 transition-all
        ${isHidden ? "cursor-default opacity-80" : "cursor-pointer"}
        ${isActive
          ? "bg-agent-accent/10 border border-agent-accent/30 shadow-glow"
          : "hover:bg-agent-surface-2 border border-transparent hover:border-agent-border/60"
        }
        ${isDeleting ? "opacity-50 pointer-events-none" : ""}
      `}
      onClick={() => {
        if (!isHidden && !isActive) onResume();
      }}
      title={isHidden ? `${title} (hidden — unhide from toolbar)` : title}
    >
      {/* Icon */}
      <div
        className={`w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center mt-0.5
          ${isActive ? "bg-agent-accent/20 text-agent-accent" : "bg-agent-surface-2 border border-agent-border text-agent-muted"}`}
      >
        {isDeleting
          ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
          : <MessageSquare className="w-3.5 h-3.5" />}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-medium truncate ${isActive ? "text-agent-text" : "text-agent-text-soft"}`}>
          {title}
        </p>
        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
          {statusDetail === "full" && (
            <span className={`inline-flex items-center gap-1 text-[9px] uppercase tracking-wider font-mono ${sc}`}>
              <span className={`w-1 h-1 rounded-full ${sc.split(" ")[0]}`} />
              {item.status === "SOFT_DELETED" ? "hidden" : item.status.toLowerCase()}
            </span>
          )}
          {statusDetail === "minimal" && isHidden && (
            <span className="inline-flex items-center gap-1 text-[9px] text-agent-muted font-mono">
              hidden
            </span>
          )}
          <span className="text-[9px] text-agent-muted font-mono">{relativeTime}</span>
        </div>
      </div>

      {/* Actions (visible on hover) */}
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-auto flex-shrink-0">
        {isHidden ? (
          <button
            onClick={(e) => { e.stopPropagation(); void onRestore(); }}
            title="Unhide conversation"
            className="p-1 rounded-md text-agent-muted hover:text-agent-good hover:bg-agent-good/10 transition-colors"
          >
            <Undo2 className="w-3 h-3" />
          </button>
        ) : (
          <button
            onClick={(e) => { e.stopPropagation(); if (!isActive) onResume(); }}
            title={isActive ? "Currently active" : "Resume"}
            className="p-1 rounded-md text-agent-muted hover:text-agent-accent hover:bg-agent-accent/10 transition-colors"
          >
            <Play className="w-3 h-3" />
          </button>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          title={isHidden ? "Remove permanently" : "Delete"}
          className="p-1 rounded-md text-agent-muted hover:text-agent-bad hover:bg-agent-bad/10 transition-colors"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

// — Delete modal (colocated for simplicity, also exported as standalone) ————

interface DeleteModalProps {
  item: ConversationListItem;
  onClose: () => void;
}

export function DeleteConversationModal({ item, onClose }: DeleteModalProps) {
  const { softDeleteConversation, hardDeleteConversation, deleteInFlight } = useConversation();
  const inFlight = deleteInFlight[item.conversation_id];
  const alreadyHidden = item.status === "SOFT_DELETED";

  const preview =
    item.last_user_message_preview?.slice(0, 60) ??
    item.conversation_id.slice(0, 12);

  const handleSoft = async () => {
    try {
      await softDeleteConversation(item.conversation_id);
      onClose();
    } catch {
      // error surfaced by hook
    }
  };

  const handleHard = async () => {
    try {
      await hardDeleteConversation(item.conversation_id);
      onClose();
    } catch {
      // error surfaced by hook
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-agent-bg/70 backdrop-blur-sm" />

      {/* Dialog */}
      <div
        className="relative w-full max-w-sm glass-strong rounded-2xl shadow-card p-6 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl bg-agent-bad/10 border border-agent-bad/30 flex items-center justify-center flex-shrink-0">
            <Trash2 className="w-4.5 h-4.5 text-agent-bad" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-agent-text">Delete conversation?</h3>
            <p className="text-xs text-agent-muted mt-0.5 break-all line-clamp-2">{preview}</p>
          </div>
        </div>

        {/* Option descriptions */}
        <div className="space-y-2 mb-5">
          {!alreadyHidden && (
            <OptionCard
              title="Hide from list"
              description="Soft delete — conversation is hidden but recoverable. Your chat history is preserved."
              recommended
            />
          )}
          <OptionCard
            title="Delete permanently"
            description="Hard delete — removes all data and chat history. This cannot be undone."
            danger
          />
        </div>

        {/* Actions */}
        <div className={alreadyHidden ? "grid grid-cols-1 gap-2" : "grid grid-cols-2 gap-2"}>
          <button
            onClick={onClose}
            disabled={!!inFlight}
            className="px-4 py-2 text-xs font-medium text-agent-text-soft border border-agent-border rounded-xl hover:bg-agent-surface-2 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          {!alreadyHidden && (
            <button
              onClick={handleSoft}
              disabled={!!inFlight}
              className="px-4 py-2 text-xs font-semibold bg-agent-surface-2 border border-agent-border text-agent-text rounded-xl hover:border-agent-accent/40 hover:text-agent-accent transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              {inFlight === "soft" ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
              Hide
            </button>
          )}
        </div>

        <button
          onClick={handleHard}
          disabled={!!inFlight}
          className="mt-2 w-full px-4 py-2 text-xs font-semibold rounded-xl border border-agent-bad/30 text-agent-bad bg-agent-bad/5 hover:bg-agent-bad/10 transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
        >
          {inFlight === "hard" ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
          Delete permanently
        </button>
      </div>
    </div>
  );
}

function OptionCard({
  title,
  description,
  recommended,
  danger,
}: {
  title: string;
  description: string;
  recommended?: boolean;
  danger?: boolean;
}) {
  return (
    <div
      className={`rounded-xl p-3 border text-left ${
        danger
          ? "border-agent-bad/20 bg-agent-bad/5"
          : "border-agent-border/60 bg-agent-surface-2"
      }`}
    >
      <div className="flex items-center gap-2 mb-0.5">
        <p className={`text-xs font-medium ${danger ? "text-agent-bad" : "text-agent-text"}`}>
          {title}
        </p>
        {recommended && (
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-agent-good/10 border border-agent-good/30 text-agent-good uppercase tracking-wider">
            recommended
          </span>
        )}
      </div>
      <p className={`text-[11px] ${danger ? "text-agent-bad/70" : "text-agent-muted"}`}>
        {description}
      </p>
    </div>
  );
}

// — Helpers ————————————————————————————————————————————————————————————————

function formatRelative(isoString: string): string {
  try {
    const diff = Date.now() - new Date(isoString).getTime();
    const minutes = Math.floor(diff / 60_000);
    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    return formatConversationalDateTime(isoString);
  } catch {
    return "";
  }
}
