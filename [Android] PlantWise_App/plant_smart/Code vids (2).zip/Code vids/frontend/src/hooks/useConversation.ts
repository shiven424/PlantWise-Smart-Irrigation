import { useCallback } from "react";
import { api } from "../api/client";
import {
  useConversationState,
  useConversationDispatch,
} from "../context/ConversationContext";
import type { ConversationListItem, StartConversationRequest, HITLRequest } from "../types/api";

const HISTORY_PAGE_SIZE = 30;

export function useConversation() {
  const state = useConversationState();
  const dispatch = useConversationDispatch();

  // — Active thread actions ————————————————————————————————————————————————

  const startConversation = useCallback(
    async (req: StartConversationRequest = {}): Promise<string | null> => {
      try {
        const res = await api.startConversation(req);
        dispatch({
          type: "START",
          conversationId: res.conversation_id,
          welcomeMessage: res.message,
        });
        // Add the new conversation to the top of the history list
        const now = new Date().toISOString();
        const newItem: ConversationListItem = {
          conversation_id: res.conversation_id,
          status: "ACTIVE",
          title: null,
          last_user_message_preview: null,
          current_turn: 0,
          channel: req.channel ?? "web",
          created_at: now,
          last_active_at: now,
          ended_at: null,
          deleted_at: null,
        };
        dispatch({ type: "HISTORY_PREPEND_ITEM", item: newItem });
        return res.conversation_id;
      } catch (err: unknown) {
        dispatch({
          type: "SET_ERROR",
          error: err instanceof Error ? err.message : "Failed to start conversation",
        });
        return null;
      }
    },
    [dispatch],
  );

  const sendMessage = useCallback(
    async (message: string, overrideConversationId?: string) => {
      const cid = overrideConversationId ?? state.conversationId;
      if (!cid) return;
      dispatch({ type: "SEND_MESSAGE", message });
      try {
        const res = await api.sendTurn(cid, { message });
        dispatch({ type: "RECEIVE_RESPONSE", response: res });
        // Update preview text in history list
        dispatch({
          type: "HISTORY_UPDATE_ITEM",
          conversationId: cid,
          patch: {
            last_user_message_preview: message.slice(0, 120),
            current_turn: res.turn,
            last_active_at: new Date().toISOString(),
          },
        });
      } catch (err: unknown) {
        dispatch({
          type: "SET_ERROR",
          error: err instanceof Error ? err.message : "Failed to send message",
        });
      }
    },
    [state.conversationId, dispatch],
  );

  const sendHITL = useCallback(
    async (data: HITLRequest) => {
      if (!state.conversationId) return;
      dispatch({ type: "HITL_SENT" });
      try {
        const res = await api.sendHITL(state.conversationId, data);
        dispatch({ type: "RECEIVE_RESPONSE", response: res });
      } catch (err: unknown) {
        dispatch({
          type: "SET_ERROR",
          error: err instanceof Error ? err.message : "Failed to send HITL response",
        });
      }
    },
    [state.conversationId, dispatch],
  );

  const endConversation = useCallback(async () => {
    if (!state.conversationId) return;
    const cid = state.conversationId;
    try {
      const res = await api.endConversation(cid);
      const farewell = res.response?.full_message ?? "Session ended.";
      dispatch({ type: "END_CONVERSATION", farewellMessage: farewell });
      dispatch({
        type: "HISTORY_UPDATE_ITEM",
        conversationId: cid,
        patch: { status: "ENDED", ended_at: new Date().toISOString() },
      });
    } catch {
      dispatch({ type: "END_CONVERSATION" });
    }
  }, [state.conversationId, dispatch]);

  const reset = useCallback(() => {
    dispatch({ type: "RESET" });
  }, [dispatch]);

  // — History actions ———————————————————————————————————————————————————————

  const loadHistory = useCallback(async () => {
    dispatch({ type: "HISTORY_LOAD_START" });
    try {
      const res = await api.listConversations({
        limit: HISTORY_PAGE_SIZE,
        includeDeleted: true,
      });
      dispatch({
        type: "HISTORY_LOAD_SUCCESS",
        items: res.conversations,
        cursor: res.next_cursor,
        hasMore: res.next_cursor != null,
      });
    } catch (err: unknown) {
      dispatch({
        type: "HISTORY_LOAD_FAILURE",
        error: err instanceof Error ? err.message : "Failed to load history",
      });
    }
  }, [dispatch]);

  const loadMoreHistory = useCallback(async () => {
    if (!state.historyHasMore || state.historyLoading || !state.historyCursor) return;
    dispatch({ type: "HISTORY_LOAD_START" });
    try {
      const res = await api.listConversations({
        limit: HISTORY_PAGE_SIZE,
        cursor: state.historyCursor,
        includeDeleted: true,
      });
      dispatch({
        type: "HISTORY_APPEND_PAGE",
        items: res.conversations,
        cursor: res.next_cursor,
        hasMore: res.next_cursor != null,
      });
    } catch {
      dispatch({ type: "HISTORY_LOAD_FAILURE", error: "Failed to load more" });
    }
  }, [state.historyHasMore, state.historyLoading, state.historyCursor, dispatch]);

  const resumeConversation = useCallback(
    async (conversationId: string) => {
      try {
        const res = await api.resumeConversation(conversationId);
        dispatch({
          type: "RESUME_CONVERSATION",
          conversationId: res.conversation_id,
          turn: res.current_turn,
          history: res.message_history ?? [],
        });
        dispatch({
          type: "HISTORY_UPDATE_ITEM",
          conversationId: res.conversation_id,
          patch: { status: "ACTIVE", last_active_at: new Date().toISOString() },
        });
        return true;
      } catch (err: unknown) {
        dispatch({
          type: "SET_ERROR",
          error: err instanceof Error ? err.message : "Failed to resume conversation",
        });
        return false;
      }
    },
    [dispatch],
  );

  const softDeleteConversation = useCallback(
    async (conversationId: string) => {
      dispatch({ type: "DELETE_START", conversationId, mode: "soft" });
      try {
        await api.softDeleteConversation(conversationId);
        dispatch({ type: "DELETE_SUCCESS_SOFT", conversationId });
      } catch (err: unknown) {
        dispatch({ type: "DELETE_FAILURE", conversationId });
        throw err;
      }
    },
    [dispatch],
  );

  const hardDeleteConversation = useCallback(
    async (conversationId: string) => {
      dispatch({ type: "DELETE_START", conversationId, mode: "hard" });
      try {
        await api.hardDeleteConversation(conversationId);
        dispatch({ type: "DELETE_SUCCESS_HARD", conversationId });
      } catch (err: unknown) {
        dispatch({ type: "DELETE_FAILURE", conversationId });
        throw err;
      }
    },
    [dispatch],
  );

  const restoreHiddenConversation = useCallback(
    async (conversationId: string) => {
      try {
        const res = await api.restoreConversation(conversationId);
        dispatch({
          type: "HISTORY_UPDATE_ITEM",
          conversationId,
          patch: {
            status: res.status,
            deleted_at: null,
            last_active_at: new Date().toISOString(),
          },
        });
        return true;
      } catch (err: unknown) {
        dispatch({
          type: "SET_ERROR",
          error: err instanceof Error ? err.message : "Could not restore conversation",
        });
        return false;
      }
    },
    [dispatch],
  );

  return {
    // Active thread state
    ...state,

    // Active thread actions
    startConversation,
    sendMessage,
    sendHITL,
    endConversation,
    reset,

    // History actions
    loadHistory,
    loadMoreHistory,
    resumeConversation,
    softDeleteConversation,
    hardDeleteConversation,
    restoreHiddenConversation,
  };
}
