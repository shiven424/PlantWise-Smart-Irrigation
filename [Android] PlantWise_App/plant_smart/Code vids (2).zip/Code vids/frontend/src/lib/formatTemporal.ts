/**
 * Display formatting for timestamps and calendar dates surfaced in finance copy.
 *
 * Backend tools often emit ISO-8601 (RFC3339) strings (e.g. balance `as_of`,
 * loan `first_payment_date`). We normalize at render time so chat and UI stay
 * consistent without adding heavy markdown dependencies.
 *
 * Operational / recordkeeper-style fields use UTC so balances and schedule
 * dates match sourced data regardless of viewer locale quirks.
 *
 * Locale is fixed to `en-US` so timestamps read the same in every browser/region.
 */
const DISPLAY_LOCALE = "en-US";

const ISO_DATETIME_RE =
  /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})/g;

/** `YYYY-MM-DD` not preceded/followed by another digit — avoids touching UUIDs etc. */
const ISO_CALENDAR_DATE_RE = /(?<![0-9])(\d{4}-\d{2}-\d{2})(?![0-9T])/g;

/** Explicit fields avoid engines that reject `timeZoneName` paired with `dateStyle`/`timeStyle`. */
const FINANCE_DT_OPTIONS: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
  timeZone: "UTC",
  timeZoneName: "short",
};

const FINANCE_DATE_OPTIONS: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
  timeZone: "UTC",
};

function tryFormatInstant(iso: string): string | null {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return new Intl.DateTimeFormat(DISPLAY_LOCALE, FINANCE_DT_OPTIONS).format(d);
}

/** Calendar date `YYYY-MM-DD` interpreted as a UTC civil date (not local midnight). */
function tryFormatCalendarYmd(ymd: string): string | null {
  const m = ymd.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const day = Number(m[3]);
  const d = new Date(Date.UTC(y, mo - 1, day));
  if (Number.isNaN(d.getTime())) return null;
  return new Intl.DateTimeFormat(DISPLAY_LOCALE, FINANCE_DATE_OPTIONS).format(d);
}

export function formatFinanceDateTimeUtc(isoWithTime: string): string {
  return tryFormatInstant(isoWithTime) ?? isoWithTime;
}

export function formatFinanceDateUtc(ymd: string): string {
  return tryFormatCalendarYmd(ymd) ?? ymd;
}

/**
 * Replace ISO datetimes and plain `YYYY-MM-DD` tokens in free text (e.g. markdown)
 * with locale-aware but UTC-based finance display strings.
 */
export function formatTemporalTokensInPlainText(src: string): string {
  let out = src.replace(ISO_DATETIME_RE, (tok) => tryFormatInstant(tok) ?? tok);
  out = out.replace(ISO_CALENDAR_DATE_RE, (ymd) => tryFormatCalendarYmd(ymd) ?? ymd);
  return out;
}

/** Matches finance-style ordering; local timezone for "last active" timestamps. */
const CONVERSATIONAL_DT_OPTIONS: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
};

export function formatConversationalDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return new Intl.DateTimeFormat(DISPLAY_LOCALE, CONVERSATIONAL_DT_OPTIONS).format(d);
}
