import { describe, expect, it } from "vitest";
import {
  formatFinanceDateTimeUtc,
  formatFinanceDateUtc,
  formatTemporalTokensInPlainText,
} from "./formatTemporal";

describe("formatTemporalTokensInPlainText", () => {
  it("replaces RFC3339 UTC datetimes", () => {
    const raw = "**As Of:** 2026-05-03T14:18:02.529934+00:00";
    const out = formatTemporalTokensInPlainText(raw);
    expect(out).not.toContain("T14:18:02");
    expect(out).not.toMatch(/529934/);
    expect(out).toMatch(/2026/);
  });

  it("replaces plain YYYY-MM-DD calendar dates", () => {
    const raw = "**First Payment Date:** 2030-06-15";
    const out = formatTemporalTokensInPlainText(raw);
    expect(out).not.toContain("2030-06-15");
    expect(out).toContain("2030");
  });

  it("leaves non-ISO text unchanged", () => {
    const raw = "**Amount:** 1500.0";
    expect(formatTemporalTokensInPlainText(raw)).toBe(raw);
  });
});

describe("formatFinanceDateTimeUtc", () => {
  it("accepts Z suffix", () => {
    const s = formatFinanceDateTimeUtc("2026-05-03T14:18:02Z");
    expect(s).not.toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:/);
  });
});

describe("formatFinanceDateUtc", () => {
  it("formats civil date", () => {
    const s = formatFinanceDateUtc("2030-01-02");
    expect(s).not.toBe("2030-01-02");
  });
});
