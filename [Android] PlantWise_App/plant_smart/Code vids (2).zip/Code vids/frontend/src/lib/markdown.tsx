import type { ReactNode } from "react";
import { formatTemporalTokensInPlainText } from "./formatTemporal";

/**
 * Lightweight markdown renderer for synthesizer output:
 *   - **bold** / *italic* / `code`
 *   - bullets (• / - / *)
 *   - single-line headings line = **Title only**
 *   - GitHub-flavour pipe tables (| col | … with alignment row below)
 */

export function Markdown({ text, className = "" }: { text: string; className?: string }) {
  if (!text) return null;
  const normalized = formatTemporalTokensInPlainText(text);
  const blocks = parseBlocks(normalized);
  return (
    <div className={`md-content space-y-2 ${className}`}>
      {blocks.map((b, i) => renderBlock(b, i))}
    </div>
  );
}

type Block =
  | { kind: "p"; text: string }
  | { kind: "ul"; items: string[] }
  | { kind: "h"; text: string }
  | { kind: "table"; header: string[]; rows: string[][] };

function splitPipeRow(line: string): string[] | null {
  let s = line.trim();
  if (!s.includes("|")) return null;
  if (s.startsWith("|")) s = s.slice(1);
  if (s.endsWith("|")) s = s.slice(0, -1);
  const cells = s.split("|").map((c) => c.trim());
  if (cells.length < 2) return null;
  return cells;
}

function looksLikePipeDataRow(line: string): boolean {
  return splitPipeRow(line) !== null;
}

function isMarkdownTableSeparator(line: string): boolean {
  const cells = splitPipeRow(line.trim());
  if (!cells || cells.length < 2) return false;
  return cells.every((c) => {
    const t = c.trim().replace(/\s/g, "");
    return /^:?-{2,}:?$/.test(t);
  });
}

function normalizeRowWidths(headerLen: number, row: string[]): string[] {
  const out = row.slice(0, headerLen);
  while (out.length < headerLen) out.push("");
  return out.slice(0, headerLen);
}

function tryConsumePipeTable(lines: string[], start: number): { block: Block; nextLine: number } | null {
  if (start >= lines.length || start + 1 >= lines.length) return null;

  const headerCells = splitPipeRow(lines[start]);
  if (!headerCells || headerCells.length < 2) return null;
  if (!isMarkdownTableSeparator(lines[start + 1])) return null;

  const headerLen = headerCells.length;
  const rows: string[][] = [];
  let j = start + 2;
  for (; j < lines.length; j++) {
    const raw = lines[j];
    if (raw.trim() === "") break;
    if (!looksLikePipeDataRow(raw)) break;
    const cells = splitPipeRow(raw)!;
    rows.push(normalizeRowWidths(headerLen, cells));
  }

  return {
    block: {
      kind: "table",
      header: normalizeRowWidths(headerLen, headerCells),
      rows,
    },
    nextLine: j,
  };
}

function parseBlocks(input: string): Block[] {
  const lines = input.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let para: string[] = [];
  let list: string[] = [];
  let idx = 0;

  const flushPara = () => {
    if (!para.length) return;
    const joined = para.join("\n").trim();
    if (joined) {
      const m = joined.match(/^\*\*(.+)\*\*$/);
      if (m) blocks.push({ kind: "h", text: m[1] });
      else blocks.push({ kind: "p", text: joined });
    }
    para = [];
  };

  const flushList = () => {
    if (list.length) {
      blocks.push({ kind: "ul", items: list });
      list = [];
    }
  };

  while (idx < lines.length) {
    const raw = lines[idx];
    const line = raw.replace(/\s+$/, "");
    const bullet = line.match(/^\s*(?:[•\-*]|\u2022)\s+(.*)$/);

    if (line.trim() === "") {
      flushPara();
      flushList();
      idx++;
      continue;
    }

    const table = tryConsumePipeTable(lines, idx);
    if (table) {
      flushPara();
      flushList();
      blocks.push(table.block);
      idx = table.nextLine;
      continue;
    }

    if (bullet) {
      flushPara();
      list.push(bullet[1]);
      idx++;
      continue;
    }

    const mdHeading = line.match(/^(#{1,3})\s+(.+)$/);
    if (mdHeading && mdHeading[2]) {
      flushPara();
      flushList();
      blocks.push({ kind: "h", text: mdHeading[2].trim() });
      idx++;
      continue;
    }

    flushList();
    para.push(line);
    idx++;
  }

  flushPara();
  flushList();
  return blocks;
}

function headerNormalize(h: string): string {
  return h.trim().toLowerCase().replace(/\s+/g, " ");
}

function renderBlock(block: Block, idx: number): ReactNode {
  switch (block.kind) {
    case "table": {
      const rightAlignHeaders = new Set(["amount", "balance", "price", "total", "%"]);
      const alignForCol = (h: string) =>
        rightAlignHeaders.has(headerNormalize(h)) ||
        /\b(amount|balance|qty|quantity|fee|credit|debit)\b/i.test(headerNormalize(h))
          ? "text-right"
          : "text-left";

      return (
        <div
          key={idx}
          className="overflow-x-auto rounded-lg border border-agent-border/50 bg-agent-surface-2/30 my-2 -mx-0.5"
        >
          <table className="w-full min-w-[560px] border-collapse text-[12px] leading-snug">
            <thead>
              <tr className="border-b border-agent-border/60 bg-agent-surface-2/95">
                {block.header.map((h, i) => (
                  <th
                    key={i}
                    scope="col"
                    className={`px-2.5 py-2 font-semibold text-agent-text-soft uppercase tracking-wide text-[10px] ${alignForCol(
                      h,
                    )} whitespace-nowrap`}
                  >
                    {renderInline(h)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-agent-border/35">
              {block.rows.map((row, ri) => (
                <tr
                  key={ri}
                  className={
                    ri % 2 === 0
                      ? "bg-transparent hover:bg-agent-surface-2/40"
                      : "bg-agent-surface-2/15 hover:bg-agent-surface-2/50"
                  }
                >
                  {row.map((cell, ci) => {
                    const hdr = block.header[ci] ?? "";
                    const num =
                      alignForCol(hdr) === "text-right" ? " font-mono tabular-nums" : "";
                    return (
                      <td
                        key={ci}
                        className={`px-2.5 py-2 text-agent-text ${alignForCol(hdr)}${num} align-top max-w-[14rem]`}
                      >
                        <span className="break-words">{renderInline(cell)}</span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }
    case "h":
      return (
        <p key={idx} className="font-semibold text-white text-[0.95rem] mt-1">
          {renderInline(block.text)}
        </p>
      );
    case "ul":
      return (
        <ul key={idx}>
          {block.items.map((it, i) => (
            <li key={i}>{renderInline(it)}</li>
          ))}
        </ul>
      );
    case "p":
    default:
      return (
        <p key={idx} className="whitespace-pre-wrap leading-relaxed">
          {renderInline(block.text)}
        </p>
      );
  }
}

function renderInline(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\*\*[^*\n]+\*\*|`[^`\n]+`|\*[^*\n]+\*|_[^_\n]+_)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let key = 0;

  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("**")) {
      const inner = tok.slice(2, -2);
      out.push(<strong key={key++}>{renderInline(inner)}</strong>);
    } else if (tok.startsWith("`")) {
      out.push(<code key={key++}>{tok.slice(1, -1)}</code>);
    } else if (tok.startsWith("*")) {
      out.push(<em key={key++}>{renderInline(tok.slice(1, -1))}</em>);
    } else if (tok.startsWith("_")) {
      out.push(<em key={key++}>{renderInline(tok.slice(1, -1))}</em>);
    }
    last = m.index + tok.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}
