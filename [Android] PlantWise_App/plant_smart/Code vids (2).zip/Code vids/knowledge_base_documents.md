# Knowledge Base Documents for Contact Center AI

> [!IMPORTANT]
> Your `knowledge_base/documents/` directory is **currently empty**. This is the single most critical gap in your system — the RAG agent, indexer, embedder, and vector store infrastructure are all built and ready, but have **zero documents to serve**. Below is a comprehensive list of documents you should ingest, organized by priority and domain.

---

## System Overview

Your codebase is a **multi-agent Contact Center AI for financial services** (retirement plans, RMDs, plan loans). It uses:

- **LangGraph** for orchestration with a supervisor-driven agentic loop
- **RAG pipeline** (ChromaDB + SentenceTransformer + hybrid retrieval)
- **8 specialist agents** + **3 tools** for transactional execution
- **Regulatory module** with hardcoded IRS limits, rollover matrix, and RMD tables
- **PII vault** (HashiCorp / AWS Secrets Manager) for sensitive data
- **Compliance library** with disclosure JSON files for retirement, investment, estate, and tax

---

## 📋 Priority 1: Core Regulatory & Compliance (MUST HAVE)

These documents are **directly referenced in your code** via `regulatory/`, `synthesizer/compliance_library/`, and the RAG agent.

### 1. IRS Publication 590-A (Contributions to IRAs)
| Field | Value |
|-------|-------|
| **Why** | Your `rollover_matrix.py` explicitly cites "IRS Publication 590-A (2024), Table 1". The IRA rollover tool and entity validator depend on these rules. |
| **Link** | [https://www.irs.gov/publications/p590a](https://www.irs.gov/publications/p590a) |
| **Format** | PDF / HTML |
| **Chunking** | `structured` — section/subsection-aware splitting |
| **Domains** | `RETIREMENT_SERVICES`, `TAX_PLANNING` |

### 2. IRS Publication 590-B (Distributions from IRAs)
| Field | Value |
|-------|-------|
| **Why** | Covers RMD rules, early withdrawal penalties, and distribution options — directly tied to your `rmd_calculator` tool and `uniform_lifetime_table.py`. |
| **Link** | [https://www.irs.gov/publications/p590b](https://www.irs.gov/publications/p590b) |
| **Format** | PDF / HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES`, `TAX_PLANNING` |

### 3. IRS Publication 575 (Pension and Annuity Income)
| Field | Value |
|-------|-------|
| **Why** | Explicitly cited in `rollover_matrix.py` header. Covers pension rollovers, profit-sharing distributions. |
| **Link** | [https://www.irs.gov/publications/p575](https://www.irs.gov/publications/p575) |
| **Format** | PDF / HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES` |

### 4. IRS Notice 2024-80 (2025 Retirement Plan Limits)
| Field | Value |
|-------|-------|
| **Why** | Your `irs_limits.py` references "IRS Notice 2024-80" for 2025 contribution/benefit limits. Provides authoritative backing for the hardcoded values. |
| **Link** | [https://www.irs.gov/pub/irs-drop/n-24-80.pdf](https://www.irs.gov/pub/irs-drop/n-24-80.pdf) |
| **Format** | PDF |
| **Chunking** | `sliding_window` |
| **Domains** | `RETIREMENT_SERVICES`, `TAX_PLANNING` |

### 5. SECURE Act 2.0 Summary (2022)
| Field | Value |
|-------|-------|
| **Why** | Referenced throughout your code: RMD age change (72→73→75), penalty reduction (50%→25%), super catch-up contributions (age 60-63). |
| **Link** | [https://www.congress.gov/bill/117th-congress/house-bill/2954](https://www.congress.gov/bill/117th-congress/house-bill/2954) |
| **Alt Link** | [https://www.irs.gov/retirement-plans/secure-2-0-act-of-2022](https://www.irs.gov/retirement-plans/secure-2-0-act-of-2022) |
| **Format** | PDF / HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES`, `COMPLIANCE_REGULATORY` |

### 6. IRS Rev. Proc. 2023-34 (2024 Contribution/Benefit Limits)
| Field | Value |
|-------|-------|
| **Why** | Cited in `irs_limits.py` header as the source for prior-year limits. Useful for historical lookups. |
| **Link** | [https://www.irs.gov/pub/irs-drop/rp-23-34.pdf](https://www.irs.gov/pub/irs-drop/rp-23-34.pdf) |
| **Format** | PDF |
| **Chunking** | `sliding_window` |
| **Domains** | `RETIREMENT_SERVICES` |

---

## 📋 Priority 2: Plan-Specific Documents (HIGH VALUE)

These power the transactional tools and the informational RAG answers.

### 7. Summary Plan Description (SPD) — 401(k)) Plan
| Field | Value |
|-------|-------|
| **Why** | The entity validator and plan loan agent need plan-specific rules (loan limits, vesting schedules, hardship withdrawal criteria). |
| **Where to Get** | Create a template or use your employer's actual SPD. No public link — this is plan-specific. |
| **Template** | [https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/summary-plan-description](https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/summary-plan-description) |
| **Format** | PDF |
| **Chunking** | `structured` — Q&A / section-aware |
| **Domains** | `RETIREMENT_SERVICES` |

### 8. 401(k) Plan Loan Policy Document
| Field | Value |
|-------|-------|
| **Why** | Your `plan_loan` tool validates loan amounts against `401K_LOAN_MAX` ($50,000) and 50%-of-vested-balance limit from IRC 72(p). |
| **Link** | [https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-loans](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-loans) |
| **Format** | HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES` |

### 9. Hardship Withdrawal Criteria Guide
| Field | Value |
|-------|-------|
| **Why** | `HARDSHIP_WITHDRAWAL` intents are escalated to a specialist. Safe harbor criteria should be documented for the RAG agent to answer eligibility questions. |
| **Link** | [https://www.irs.gov/retirement-plans/hardships-early-withdrawals-and-loans](https://www.irs.gov/retirement-plans/hardships-early-withdrawals-and-loans) |
| **Format** | HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES` |

### 10. RMD Calculation Guide & FAQ
| Field | Value |
|-------|-------|
| **Why** | Your `rmd_calculator` tool and `uniform_lifetime_table.py` directly implement RMD calculations. The RAG agent needs this for informational queries. |
| **Link** | [https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-required-minimum-distributions](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-required-minimum-distributions) |
| **Format** | HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES`, `TAX_PLANNING` |

---

## 📋 Priority 3: Rollover & Beneficiary Documents (MEDIUM-HIGH)

### 11. IRA Rollover Guide (IRS Publication 590-A, Table 1)
| Field | Value |
|-------|-------|
| **Why** | `IRA_ROLLOVER` intents are escalated to a specialist. The RAG agent still needs rollover rules to answer informational questions like "Can I roll my 401k into a Roth IRA?" |
| **Link** | [https://www.irs.gov/pub/irs-tege/rollover_chart.pdf](https://www.irs.gov/pub/irs-tege/rollover_chart.pdf) |
| **Format** | PDF |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES` |

### 12. Beneficiary Designation Rules
| Field | Value |
|-------|-------|
| **Why** | Beneficiary intents (`BENEFICIARY_UPDATE`, `BENEFICIARY_INQUIRY`, `BENEFICIARY_DESIGNATION`) are escalated to a specialist. The RAG agent needs this to answer informational beneficiary questions. |
| **Link** | [https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-beneficiary-designations](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-beneficiary-designations) |
| **Format** | HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES`, `ESTATE_AND_TRUST` |

### 13. IRS Rev. Rul. 2014-9 (Direct Rollover Rules)
| Field | Value |
|-------|-------|
| **Why** | Cited in `rollover_matrix.py`: governs `direct_only` vs. 60-day indirect rollover eligibility. |
| **Link** | [https://www.irs.gov/pub/irs-drop/rr-14-09.pdf](https://www.irs.gov/pub/irs-drop/rr-14-09.pdf) |
| **Format** | PDF |
| **Chunking** | `sliding_window` |
| **Domains** | `RETIREMENT_SERVICES` |

---

## 📋 Priority 4: Tax & Withholding Documents (MEDIUM)

### 14. IRS Publication 15-T (Federal Income Tax Withholding Methods)
| Field | Value |
|-------|-------|
| **Why** | Your system handles `WITHHOLDING_INQUIRY` and `WITHHOLDING_UPDATE` intents. `irs_limits.py` has `ELIGIBLE_ROLLOVER_WITHHOLDING` (20%) and `NON_PERIODIC_WITHHOLDING` (10%). |
| **Link** | [https://www.irs.gov/publications/p15t](https://www.irs.gov/publications/p15t) |
| **Format** | PDF |
| **Chunking** | `structured` |
| **Domains** | `TAX_PLANNING` |

### 15. Form 1099-R Instructions
| Field | Value |
|-------|-------|
| **Why** | Needed for `TAX_DOCUMENT_REQUEST` intent. Covers distribution reporting. |
| **Link** | [https://www.irs.gov/forms-pubs/about-form-1099-r](https://www.irs.gov/forms-pubs/about-form-1099-r) |
| **Format** | PDF / HTML |
| **Chunking** | `structured` |
| **Domains** | `TAX_PLANNING` |

### 16. IRC Section 72(t) — Early Withdrawal Exceptions (SEPP)
| Field | Value |
|-------|-------|
| **Why** | Your system maps `SEPP_INQUIRY` intent (currently escalates). Adding this doc enables RAG to answer these questions instead. |
| **Link** | [https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-substantially-equal-periodic-payments](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-substantially-equal-periodic-payments) |
| **Format** | HTML |
| **Chunking** | `structured` |
| **Domains** | `RETIREMENT_SERVICES`, `TAX_PLANNING` |

---

## 📋 Priority 5: Estate, Trust & Investment Documents (MEDIUM)

### 17. Estate Planning & Trust Distribution Guide
| Field | Value |
|-------|-------|
| **Why** | Supports `TRUST_INQUIRY`, `TRUST_DISTRIBUTION`, `TOD_INQUIRY`, `TOD_UPDATE` intents (all escalated). Your `estate_disclosures.json` compliance file already references estate-specific disclosures. |
| **Link** | Custom-authored or from plan provider |
| **Reference** | [https://www.irs.gov/businesses/small-businesses-self-employed/frequently-asked-questions-on-estate-taxes](https://www.irs.gov/businesses/small-businesses-self-employed/frequently-asked-questions-on-estate-taxes) |
| **Domains** | `ESTATE_AND_TRUST` |

### 18. Investment Fund Prospectus / Fee Schedule
| Field | Value |
|-------|-------|
| **Why** | Supports `FUND_INQUIRY`, `FUND_SWITCH`, `PORTFOLIO_REVIEW` intents. Your `investment_disclosures.json` compliance file needs backings. |
| **Where to Get** | From your investment platform (e.g., Fidelity, Vanguard fund prospectuses) |
| **Domains** | `INVESTMENT_MANAGEMENT` |

### 19. Cost Basis Reporting Guide
| Field | Value |
|-------|-------|
| **Why** | Supports `COST_BASIS_INQUIRY` intent. |
| **Link** | [https://www.irs.gov/pub/irs-pdf/p550.pdf](https://www.irs.gov/pub/irs-pdf/p550.pdf) (IRS Publication 550) |
| **Domains** | `TAX_PLANNING`, `INVESTMENT_MANAGEMENT` |

---

## 📋 Priority 6: Internal Operations Documents (NICE TO HAVE)

### 20. Customer FAQ / Help Center Content
| Field | Value |
|-------|-------|
| **Why** | Catch-all for `INFORMATIONAL` queries that don't match specific regulatory docs. Covers common customer questions. |
| **Where to Get** | Create from customer support logs, existing FAQ pages |
| **Chunking** | `structured` — Q&A format |
| **Domains** | `CROSS_DOMAIN` |

### 21. Account Administration Procedures
| Field | Value |
|-------|-------|
| **Why** | Supports `ADDRESS_UPDATE`, `PHONE_UPDATE`, `EMAIL_UPDATE`, `STATEMENT_REQUEST`, `TRANSACTION_HISTORY`, `LINKED_BANK_UPDATE` intents (all currently escalate). |
| **Where to Get** | Internal operations manual |
| **Domains** | `ACCOUNT_ADMINISTRATION` |

### 22. Privacy Policy & Data Handling Guide
| Field | Value |
|-------|-------|
| **Why** | Your system handles PII via vault tokens and has a comprehensive PII entity type set. A privacy policy document helps the RAG agent answer data-handling questions. |
| **Where to Get** | Company-specific privacy policy |
| **Domains** | `COMPLIANCE_REGULATORY` |

---

## 🗂️ Metadata Configuration

Your indexer expects a `knowledge_base/documents/document_metadata.json` file. Here's a template:

```json
{
  "documents": [
    {
      "document_name": "irs_pub_590a",
      "path": "irs_pub_590a.pdf",
      "format": "pdf",
      "doc_type": "regulation",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES", "TAX_PLANNING"]
    },
    {
      "document_name": "irs_pub_590b",
      "path": "irs_pub_590b.pdf",
      "format": "pdf",
      "doc_type": "regulation",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES", "TAX_PLANNING"]
    },
    {
      "document_name": "irs_pub_575",
      "path": "irs_pub_575.pdf",
      "format": "pdf",
      "doc_type": "regulation",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES"]
    },
    {
      "document_name": "irs_notice_2024_80",
      "path": "irs_notice_2024_80.pdf",
      "format": "pdf",
      "doc_type": "notice",
      "source_authority": "IRS",
      "freshness_date": "2024-11-01",
      "chunking_strategy": "sliding_window",
      "service_domains": ["RETIREMENT_SERVICES", "TAX_PLANNING"]
    },
    {
      "document_name": "secure_act_2_summary",
      "path": "secure_act_2_summary.pdf",
      "format": "pdf",
      "doc_type": "legislation",
      "source_authority": "Congress",
      "freshness_date": "2022-12-29",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES", "COMPLIANCE_REGULATORY"]
    },
    {
      "document_name": "rmd_faq",
      "path": "rmd_faq.txt",
      "format": "txt",
      "doc_type": "faq",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES", "TAX_PLANNING"]
    },
    {
      "document_name": "rollover_chart",
      "path": "rollover_chart.pdf",
      "format": "pdf",
      "doc_type": "reference",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES"]
    },
    {
      "document_name": "plan_loan_faq",
      "path": "plan_loan_faq.txt",
      "format": "txt",
      "doc_type": "faq",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES"]
    },
    {
      "document_name": "hardship_withdrawal_guide",
      "path": "hardship_withdrawal_guide.txt",
      "format": "txt",
      "doc_type": "guide",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES"]
    },
    {
      "document_name": "beneficiary_faq",
      "path": "beneficiary_faq.txt",
      "format": "txt",
      "doc_type": "faq",
      "source_authority": "IRS",
      "freshness_date": "2024-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES", "ESTATE_AND_TRUST"]
    },
    {
      "document_name": "summary_plan_description",
      "path": "spd_401k.pdf",
      "format": "pdf",
      "doc_type": "plan_document",
      "source_authority": "Plan Sponsor",
      "freshness_date": "2025-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["RETIREMENT_SERVICES"]
    },
    {
      "document_name": "customer_faq",
      "path": "customer_faq.txt",
      "format": "txt",
      "doc_type": "faq",
      "source_authority": "Internal",
      "freshness_date": "2025-01-01",
      "chunking_strategy": "structured",
      "service_domains": ["CROSS_DOMAIN"]
    }
  ]
}
```

---

## 📊 Coverage Gap Analysis

Here's how documents map to your existing sub-intents and which are currently **escalating unnecessarily due to missing KB docs**:

| Sub-Intent | Current Route | Required Doc | Gap? |
|---|---|---|---|
| `401K_BALANCE_INQUIRY` | `balance_inquiry` ✅ | SPD, Customer FAQ | ⚠️ Partial |
| `PLAN_LOAN_REQUEST` | `plan_loan` ✅ | Plan Loan FAQ, SPD | ⚠️ Partial |
| `IRA_ROLLOVER` | Escalates ⚠️ | Pub 590-A, Rollover Chart | ❌ Missing |
| `WITHDRAWAL_REQUEST` | Escalates ⚠️ | Pub 590-B, Hardship Guide | ❌ Missing |
| `RMD_CALCULATION` | `rmd_calculator` ✅ | RMD FAQ, Pub 590-B | ❌ Missing |
| `BENEFICIARY_UPDATE` | Escalates ⚠️ | Beneficiary FAQ | ❌ Missing |
| `CONTRIBUTION_INQUIRY` | Escalates ⚠️ | Pub 590-A, IRS Notice | ❌ Missing |
| `SEPP_INQUIRY` | Escalates ⚠️ | IRC 72(t) FAQ | ❌ Missing |
| `DISTRIBUTION_OPTIONS` | Escalates ⚠️ | Pub 590-B | ❌ Missing |
| `TAX_DOCUMENT_REQUEST` | Escalates ⚠️ | Form 1099-R | ❌ Missing |
| `WITHHOLDING_INQUIRY` | Escalates ⚠️ | Pub 15-T | ❌ Missing |
| `COST_BASIS_INQUIRY` | Escalates ⚠️ | Pub 550 | ❌ Missing |
| `PORTFOLIO_REVIEW` | Escalates ⚠️ | Fund Prospectus | ❌ Missing |
| `TRUST_INQUIRY` | Escalates ⚠️ | Estate Guide | ❌ Missing |
| All Account Admin | Escalates ⚠️ | Admin Procedures | ❌ Missing |

> [!TIP]
> Start with **Priority 1** documents (items 1-6). These directly support your 6 active tools and will reduce RAG escalations significantly. The IRS documents are all freely available as PDFs from irs.gov.

---

## 🔗 Quick Access Links (All Documents)

| # | Document | Link |
|---|----------|------|
| 1 | IRS Pub 590-A | [irs.gov/publications/p590a](https://www.irs.gov/publications/p590a) |
| 2 | IRS Pub 590-B | [irs.gov/publications/p590b](https://www.irs.gov/publications/p590b) |
| 3 | IRS Pub 575 | [irs.gov/publications/p575](https://www.irs.gov/publications/p575) |
| 4 | IRS Notice 2024-80 | [irs.gov/pub/irs-drop/n-24-80.pdf](https://www.irs.gov/pub/irs-drop/n-24-80.pdf) |
| 5 | SECURE Act 2.0 | [irs.gov/retirement-plans/secure-2-0-act-of-2022](https://www.irs.gov/retirement-plans/secure-2-0-act-of-2022) |
| 6 | Rev Proc 2023-34 | [irs.gov/pub/irs-drop/rp-23-34.pdf](https://www.irs.gov/pub/irs-drop/rp-23-34.pdf) |
| 7 | SPD Template (DOL) | [dol.gov/.../summary-plan-description](https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/summary-plan-description) |
| 8 | Plan Loan FAQ | [irs.gov/.../loans](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-loans) |
| 9 | Hardship Withdrawal | [irs.gov/.../hardships-early-withdrawals-and-loans](https://www.irs.gov/retirement-plans/hardships-early-withdrawals-and-loans) |
| 10 | RMD FAQ | [irs.gov/.../required-minimum-distributions](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-required-minimum-distributions) |
| 11 | Rollover Chart | [irs.gov/pub/irs-tege/rollover_chart.pdf](https://www.irs.gov/pub/irs-tege/rollover_chart.pdf) |
| 12 | Beneficiary FAQ | [irs.gov/.../beneficiary-designations](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-beneficiary-designations) |
| 13 | Rev Rul 2014-9 | [irs.gov/pub/irs-drop/rr-14-09.pdf](https://www.irs.gov/pub/irs-drop/rr-14-09.pdf) |
| 14 | IRS Pub 15-T | [irs.gov/publications/p15t](https://www.irs.gov/publications/p15t) |
| 15 | Form 1099-R Info | [irs.gov/forms-pubs/about-form-1099-r](https://www.irs.gov/forms-pubs/about-form-1099-r) |
| 16 | IRC 72(t) / SEPP | [irs.gov/.../substantially-equal-periodic-payments](https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-substantially-equal-periodic-payments) |
| 17 | Estate Tax FAQ | [irs.gov/.../estate-taxes](https://www.irs.gov/businesses/small-businesses-self-employed/frequently-asked-questions-on-estate-taxes) |
| 18 | Fund Prospectus | Provider-specific (Fidelity, Vanguard, etc.) |
| 19 | IRS Pub 550 | [irs.gov/pub/irs-pdf/p550.pdf](https://www.irs.gov/pub/irs-pdf/p550.pdf) |

---

## ⚡ Next Steps

1. **Download Priority 1 docs** (6 IRS publications) — all free PDFs
2. **Place files** in `knowledge_base/documents/`
3. **Create** `knowledge_base/documents/document_metadata.json` using the template above
4. **Run the indexer**: `from knowledge_base.indexer import Indexer; Indexer().index_all()`
5. **Verify** with a test query through the RAG agent
