"""
Mock Disbursement API - simulates ACH / wire disbursement services.

Used by tools:
  - WithdrawalTool         -> submit_withdrawal()
  - IRARolloverTool        -> submit_distribution() (indirect rollover generates a cheque/ACH)
  - RMDCalculatorTool      -> submit_rmd_distribution()

Design:
  - In-memory transaction log.
  - Thread-safe via threading.Lock.
  - Deterministic: returns predictable confirmation numbers and amounts.
  - Applies federal withholding logic (IRC 3405) and early withdrawal
    penalties (IRC 72(t)) - matches the regulatory/irs_limits.py constants.
  - Raises domain-specific errors (DisbursementRejectedError, etc.).

Withholding Rules (per IRS):
  - Eligible rollover distribution: 20% mandatory withholding (IRC 3405(c))
  - Non-periodic distribution (regular withdrawal): 10% default (IRC 3405(b))
  - Direct rollover: 0% withholding (trustee-to-trustee, no distribution)
  - Early withdrawal (under age 59.5): 10% additional penalty (IRC 72(t))
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Any


# =============================================================================
# Exceptions
# =============================================================================

class DisbursementRejectedError(Exception):
    """Raised when the disbursement request is rejected by the platform."""


class InvalidRoutingNumberError(Exception):
    """Raised when the ABA routing number fails validation."""


class DuplicateRequestError(Exception):
    """Raised when an idempotency key has already been used."""


class AuthorizationError(Exception):
    """Raised when auth_token is missing or invalid."""


# =============================================================================
# Withholding / Penalty Constants (mirror regulatory/irs_limits.py)
# =============================================================================

ELIGIBLE_ROLLOVER_WITHHOLDING = 0.20    # IRC 3405(c) - mandatory 20%
NON_PERIODIC_WITHHOLDING = 0.10         # IRC 3405(b) - default 10%
EARLY_WITHDRAWAL_PENALTY = 0.10         # IRC 72(t)(1) - 10% additional tax
EARLY_WITHDRAWAL_AGE = 59.5             # IRC 72(t) - penalty-free threshold


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class WithholdingBreakdown:
    gross_amount: float
    federal_withholding: float
    state_withholding: float
    early_withdrawal_penalty: float
    net_disbursement: float
    withholding_rate: float
    penalty_applies: bool


@dataclass
class DisbursementRecord:
    transaction_id: str
    account_number_last4: str
    disbursement_type: str          # WITHDRAWAL, RMD, ROLLOVER_DISTRIBUTION, HARDSHIP
    delivery_method: str            # ACH, WIRE, CHECK
    gross_amount: float
    federal_withholding: float
    state_withholding: float
    early_withdrawal_penalty: float
    net_disbursement: float
    bank_account_last4: str | None = None
    bank_routing_last4: str | None = None
    status: str = "SUBMITTED"       # SUBMITTED, PROCESSING, COMPLETED, FAILED
    idempotency_key: str | None = None
    submitted_at: str = ""
    estimated_arrival: str = ""

    def __post_init__(self):
        if not self.submitted_at:
            self.submitted_at = datetime.now(timezone.utc).isoformat()


# =============================================================================
# Mock Disbursement API
# =============================================================================

class MockDisbursementAPI:
    """
    Thread-safe in-memory mock for the disbursement / payment platform.

    All amounts are in dollars (not cents) at the API boundary; internal
    storage uses dollars for readability.  Tools may work in cents
    internally and convert before calling.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._transactions: dict[str, DisbursementRecord] = {}
        self._idempotency_keys: set[str] = set()
        self._audit_log: list[dict[str, Any]] = []

    # -- Helpers ----------------------------------------------------------------

    def _require_auth(self, auth_token: str) -> None:
        if not auth_token:
            raise AuthorizationError("auth_token is required for disbursement")

    def _validate_routing(self, routing_number: str) -> None:
        """Basic ABA routing number validation (9 digits + checksum)."""
        if not routing_number or len(routing_number) != 9 or not routing_number.isdigit():
            raise InvalidRoutingNumberError(
                f"Invalid ABA routing number: must be exactly 9 digits"
            )
        # ABA checksum: 3(d1+d4+d7) + 7(d2+d5+d8) + (d3+d6+d9) mod 10 == 0
        digits = [int(c) for c in routing_number]
        checksum = (
            3 * (digits[0] + digits[3] + digits[6])
            + 7 * (digits[1] + digits[4] + digits[7])
            + (digits[2] + digits[5] + digits[8])
        )
        if checksum % 10 != 0:
            raise InvalidRoutingNumberError(
                f"ABA routing number failed checksum validation"
            )

    def _check_idempotency(self, idempotency_key: str | None) -> None:
        if idempotency_key and idempotency_key in self._idempotency_keys:
            raise DuplicateRequestError(
                f"Disbursement with idempotency key {idempotency_key!r} already submitted"
            )

    def _log(self, operation: str, **details: Any) -> None:
        self._audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            **details,
        })

    # -- Withholding Calculation ------------------------------------------------

    @staticmethod
    def calculate_withholding(
        gross_amount: float,
        disbursement_type: str,
        owner_age: float,
        custom_withholding_rate: float | None = None,
        state_withholding_rate: float = 0.0,
    ) -> WithholdingBreakdown:
        """
        Calculate federal/state withholding and early withdrawal penalty.

        Args:
            gross_amount: Total pre-tax distribution amount.
            disbursement_type: WITHDRAWAL, RMD, ROLLOVER_DISTRIBUTION, HARDSHIP.
            owner_age: Account owner's current age.
            custom_withholding_rate: Override the default federal rate (opt-out option).
            state_withholding_rate: State tax withholding rate (varies by state).

        Returns:
            WithholdingBreakdown with all amounts computed.
        """
        # Determine federal withholding rate
        if disbursement_type == "ROLLOVER_DISTRIBUTION":
            fed_rate = ELIGIBLE_ROLLOVER_WITHHOLDING    # Mandatory 20%
        elif custom_withholding_rate is not None:
            fed_rate = max(0.0, min(1.0, custom_withholding_rate))
        else:
            fed_rate = NON_PERIODIC_WITHHOLDING         # Default 10%

        # RMDs are non-periodic - use standard rate unless custom specified
        if disbursement_type == "RMD" and custom_withholding_rate is None:
            fed_rate = NON_PERIODIC_WITHHOLDING

        # H5: Use Decimal for precision - avoids accumulated rounding errors
        _TWO = Decimal("0.01")
        gross = Decimal(str(gross_amount))
        fed_dec = Decimal(str(fed_rate))
        state_dec = Decimal(str(state_withholding_rate))

        federal = float((gross * fed_dec).quantize(_TWO, rounding=ROUND_HALF_UP))
        state = float((gross * state_dec).quantize(_TWO, rounding=ROUND_HALF_UP))

        # Early withdrawal penalty - only RMDs are exempt per IRC 72(t)
        # Hardship distributions ARE subject to the 10% penalty.
        penalty_applies = (
            owner_age < EARLY_WITHDRAWAL_AGE
            and disbursement_type != "RMD"
        )
        penalty_dec = Decimal(str(EARLY_WITHDRAWAL_PENALTY))
        penalty = float(
            (gross * penalty_dec).quantize(_TWO, rounding=ROUND_HALF_UP)
        ) if penalty_applies else 0.0

        net = float(
            (gross - Decimal(str(federal)) - Decimal(str(state)) - Decimal(str(penalty)))
            .quantize(_TWO, rounding=ROUND_HALF_UP)
        )

        return WithholdingBreakdown(
            gross_amount=gross_amount,
            federal_withholding=federal,
            state_withholding=state,
            early_withdrawal_penalty=penalty,
            net_disbursement=max(net, 0.0),
            withholding_rate=fed_rate,
            penalty_applies=penalty_applies,
        )

    # -- Submit ACH Withdrawal --------------------------------------------------

    def submit_ach(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        state_withholding_rate: float = 0.0,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Submit an ACH disbursement (withdrawal, RMD distribution, etc.).

        Used by: WithdrawalTool, RMDCalculatorTool

        Args:
            account_number: Raw (dereferenced) account number.
            bank_routing_number: 9-digit ABA routing number.
            bank_account_number: Destination bank account number.
            amount: Gross distribution amount in dollars.
            auth_token: Session auth token.
            disbursement_type: WITHDRAWAL | RMD | ROLLOVER_DISTRIBUTION | HARDSHIP.
            owner_age: Owner's age (for penalty calculation).
            custom_withholding_rate: Override federal withholding rate.
            state_withholding_rate: State withholding rate.
            idempotency_key: Prevents duplicate submissions.

        Returns:
            {
                "transaction_id": str,
                "confirmation_number": str,
                "gross_amount": float,
                "federal_withholding": float,
                "state_withholding": float,
                "early_withdrawal_penalty": float,
                "net_disbursement": float,
                "delivery_method": "ACH",
                "estimated_arrival_days": int,
                "status": "SUBMITTED",
                "submitted_at": str,
            }
        """
        self._require_auth(auth_token)
        self._validate_routing(bank_routing_number)
        self._check_idempotency(idempotency_key)

        if amount <= 0:
            raise DisbursementRejectedError("Disbursement amount must be positive")

        wh = self.calculate_withholding(
            gross_amount=amount,
            disbursement_type=disbursement_type,
            owner_age=owner_age,
            custom_withholding_rate=custom_withholding_rate,
            state_withholding_rate=state_withholding_rate,
        )

        txn_id = f"TXN-{uuid.uuid4().hex[:10].upper()}"
        confirmation = f"DSB-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now(timezone.utc)

        record = DisbursementRecord(
            transaction_id=txn_id,
            account_number_last4=account_number[-4:] if len(account_number) >= 4 else "****",
            disbursement_type=disbursement_type,
            delivery_method="ACH",
            gross_amount=wh.gross_amount,
            federal_withholding=wh.federal_withholding,
            state_withholding=wh.state_withholding,
            early_withdrawal_penalty=wh.early_withdrawal_penalty,
            net_disbursement=wh.net_disbursement,
            bank_account_last4=bank_account_number[-4:] if len(bank_account_number) >= 4 else "****",
            bank_routing_last4=bank_routing_number[-4:],
            status="SUBMITTED",
            idempotency_key=idempotency_key,
            submitted_at=now.isoformat(),
        )

        with self._lock:
            self._transactions[txn_id] = record
            if idempotency_key:
                self._idempotency_keys.add(idempotency_key)

            self._log(
                "submit_ach",
                transaction_id=txn_id,
                disbursement_type=disbursement_type,
                gross_amount=amount,
                net_disbursement=wh.net_disbursement,
                penalty_applies=wh.penalty_applies,
            )

        return {
            "transaction_id": txn_id,
            "confirmation_number": confirmation,
            "gross_amount": wh.gross_amount,
            "federal_withholding": wh.federal_withholding,
            "state_withholding": wh.state_withholding,
            "early_withdrawal_penalty": wh.early_withdrawal_penalty,
            "net_disbursement": wh.net_disbursement,
            "delivery_method": "ACH",
            "estimated_arrival_days": 3,
            "status": "SUBMITTED",
            "submitted_at": now.isoformat(),
        }

    # -- Submit Wire Transfer ---------------------------------------------------

    def submit_wire(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Submit a wire transfer disbursement.

        Same as submit_ach but with delivery_method="WIRE" and 1-day estimated arrival.
        """
        self._require_auth(auth_token)
        self._validate_routing(bank_routing_number)
        self._check_idempotency(idempotency_key)

        if amount <= 0:
            raise DisbursementRejectedError("Disbursement amount must be positive")

        wh = self.calculate_withholding(
            gross_amount=amount,
            disbursement_type=disbursement_type,
            owner_age=owner_age,
            custom_withholding_rate=custom_withholding_rate,
        )

        txn_id = f"TXN-{uuid.uuid4().hex[:10].upper()}"
        confirmation = f"WIR-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now(timezone.utc)

        record = DisbursementRecord(
            transaction_id=txn_id,
            account_number_last4=account_number[-4:] if len(account_number) >= 4 else "****",
            disbursement_type=disbursement_type,
            delivery_method="WIRE",
            gross_amount=wh.gross_amount,
            federal_withholding=wh.federal_withholding,
            state_withholding=wh.state_withholding,
            early_withdrawal_penalty=wh.early_withdrawal_penalty,
            net_disbursement=wh.net_disbursement,
            bank_account_last4=bank_account_number[-4:] if len(bank_account_number) >= 4 else "****",
            bank_routing_last4=bank_routing_number[-4:],
            status="SUBMITTED",
            idempotency_key=idempotency_key,
            submitted_at=now.isoformat(),
        )

        with self._lock:
            self._transactions[txn_id] = record
            if idempotency_key:
                self._idempotency_keys.add(idempotency_key)

            self._log(
                "submit_wire",
                transaction_id=txn_id,
                gross_amount=amount,
                net_disbursement=wh.net_disbursement,
            )

        return {
            "transaction_id": txn_id,
            "confirmation_number": confirmation,
            "gross_amount": wh.gross_amount,
            "federal_withholding": wh.federal_withholding,
            "state_withholding": wh.state_withholding,
            "early_withdrawal_penalty": wh.early_withdrawal_penalty,
            "net_disbursement": wh.net_disbursement,
            "delivery_method": "WIRE",
            "estimated_arrival_days": 1,
            "status": "SUBMITTED",
            "submitted_at": now.isoformat(),
        }

    # -- Submit Check -----------------------------------------------------------

    def submit_check(
        self,
        account_number: str,
        mailing_address: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Submit a check disbursement mailed to the account holder.

        Used for: indirect rollovers, participants without linked bank accounts.
        """
        self._require_auth(auth_token)
        self._check_idempotency(idempotency_key)

        if amount <= 0:
            raise DisbursementRejectedError("Disbursement amount must be positive")

        wh = self.calculate_withholding(
            gross_amount=amount,
            disbursement_type=disbursement_type,
            owner_age=owner_age,
            custom_withholding_rate=custom_withholding_rate,
        )

        txn_id = f"TXN-{uuid.uuid4().hex[:10].upper()}"
        confirmation = f"CHK-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now(timezone.utc)

        record = DisbursementRecord(
            transaction_id=txn_id,
            account_number_last4=account_number[-4:] if len(account_number) >= 4 else "****",
            disbursement_type=disbursement_type,
            delivery_method="CHECK",
            gross_amount=wh.gross_amount,
            federal_withholding=wh.federal_withholding,
            state_withholding=wh.state_withholding,
            early_withdrawal_penalty=wh.early_withdrawal_penalty,
            net_disbursement=wh.net_disbursement,
            status="SUBMITTED",
            idempotency_key=idempotency_key,
            submitted_at=now.isoformat(),
        )

        with self._lock:
            self._transactions[txn_id] = record
            if idempotency_key:
                self._idempotency_keys.add(idempotency_key)

            self._log(
                "submit_check",
                transaction_id=txn_id,
                gross_amount=amount,
                net_disbursement=wh.net_disbursement,
            )

        return {
            "transaction_id": txn_id,
            "confirmation_number": confirmation,
            "gross_amount": wh.gross_amount,
            "federal_withholding": wh.federal_withholding,
            "state_withholding": wh.state_withholding,
            "early_withdrawal_penalty": wh.early_withdrawal_penalty,
            "net_disbursement": wh.net_disbursement,
            "delivery_method": "CHECK",
            "estimated_arrival_days": 7,
            "status": "SUBMITTED",
            "submitted_at": now.isoformat(),
        }

    # -- Submit RMD Distribution ------------------------------------------------

    def submit_rmd_distribution(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        rmd_amount: float,
        owner_age: float,
        auth_token: str,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Submit an RMD distribution - convenience wrapper for submit_ach.

        RMDs have NO early withdrawal penalty (owner is past 59.5 by definition)
        and use the standard 10% non-periodic withholding unless opted out.

        Used by: RMDCalculatorTool

        Returns:
            Same as submit_ach() with disbursement_type="RMD" and additional
            "rmd_amount" and "tax_year" fields.
        """
        result = self.submit_ach(
            account_number=account_number,
            bank_routing_number=bank_routing_number,
            bank_account_number=bank_account_number,
            amount=rmd_amount,
            auth_token=auth_token,
            disbursement_type="RMD",
            owner_age=owner_age,
            custom_withholding_rate=custom_withholding_rate,
            idempotency_key=idempotency_key,
        )
        result["rmd_amount"] = rmd_amount
        result["tax_year"] = date.today().year
        return result

    # -- Transaction Lookup ----------------------------------------------------

    def get_transaction(self, transaction_id: str) -> dict[str, Any] | None:
        """Look up a disbursement transaction by ID."""
        with self._lock:
            record = self._transactions.get(transaction_id)
            if record is None:
                return None
            return {
                "transaction_id": record.transaction_id,
                "disbursement_type": record.disbursement_type,
                "delivery_method": record.delivery_method,
                "gross_amount": record.gross_amount,
                "federal_withholding": record.federal_withholding,
                "net_disbursement": record.net_disbursement,
                "status": record.status,
                "submitted_at": record.submitted_at,
            }

    def update_status(self, transaction_id: str, new_status: str) -> bool:
        """Update the status of a transaction (for test simulation)."""
        with self._lock:
            record = self._transactions.get(transaction_id)
            if record is None:
                return False
            record.status = new_status
            return True

    # -- Cleanup & Observability -----------------------------------------------

    def clear(self) -> None:
        with self._lock:
            self._transactions.clear()
            self._idempotency_keys.clear()
            self._audit_log.clear()

    @property
    def audit_log(self) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._audit_log)

    @property
    def transaction_count(self) -> int:
        with self._lock:
            return len(self._transactions)

    def __len__(self) -> int:
        return self.transaction_count


def create_mock_disbursement_api() -> MockDisbursementAPI:
    """Factory that returns a clean MockDisbursementAPI instance."""
    return MockDisbursementAPI()
