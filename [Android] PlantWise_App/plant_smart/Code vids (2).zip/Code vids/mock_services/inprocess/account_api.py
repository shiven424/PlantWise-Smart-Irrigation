"""
Mock Account API – simulates core-banking / recordkeeper account services.

Used by tools:
  - BalanceInquiryTool    -> get_balance()
  - TransactionHistoryTool -> get_transaction_history()
  - RMDCalculatorTool     -> get_prior_year_end_balance()
  - BeneficiaryManager     -> get_beneficiaries(), update_beneficiaries()
  - WithdrawalTool        -> get_account_details() (for vested balance check)
  - IRARolloverTool       -> get_account_details() (for plan type + balance)

Design:
  - In-memory dict keyed by account_number (plaintext – tools
    dereference vault tokens before calling).
  - Thread-safe via threading.Lock.
  - Deterministic: tests seed accounts via seed_account() / seed_accounts().
  - Raises domain-specific errors (AccountNotFoundError, AccountFrozenError).
"""

from __future__ import annotations

import threading
import uuid
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any


# =============================================================================
# Exceptions
# =============================================================================

class AccountNotFoundError(Exception):
    """Raised when the account number does not exist."""


class AccountFrozenError(Exception):
    """Raised when the account is frozen / inactive."""


class InsufficientBalanceError(Exception):
    """Raised when the requested amount exceeds available balance."""


class AuthorizationError(Exception):
    """Raised when auth_token is missing or invalid."""


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class Beneficiary:
    name: str
    relationship: str
    percentage: float
    beneficiary_type: str = "PRIMARY"          # PRIMARY | CONTINGENT
    date_of_birth: str | None = None
    ssn_last4: str | None = None


@dataclass
class Transaction:
    date: str            # ISO date
    type: str            # CONTRIBUTION | EMPLOYER_MATCH | ...
    description: str
    amount: float        # signed: + inflow / - outflow
    running_balance: float
    reference_id: str


@dataclass
class AccountRecord:
    account_number: str
    account_type: str                          # 401K, TRADITIONAL_IRA, ROTH_IRA, etc.
    owner_name: str
    owner_age_years: float
    owner_dob: str                             # ISO date
    is_active: bool = True
    is_frozen: bool = False

    # — Balances ——————————————————————————————————————————————————————————————
    total_balance: float = 0.0
    vested_balance: float = 0.0
    unvested_balance: float = 0.0
    prior_year_end_balance: float = 0.0        # For RMD calculation

    # — Contributions —————————————————————————————————————————————————————————
    ytd_contributions: float = 0.0
    ytd_employer_match: float = 0.0
    annual_match_max: float = 0.0

    # — Loan ——————————————————————————————————————————————————————————————————
    outstanding_loan_balance: float = 0.0
    highest_loan_balance_12m: float = 0.0      # Highest in past 12 months (IRC 72(p))

    # — Plan details ——————————————————————————————————————————————————————————
    account_age_days: int = 365
    plan_name: str = "Default 401(k) Plan"
    plan_allows_loans: bool = True
    plan_allows_hardship: bool = True
    plan_allows_rollovers_in: bool = True

    # — Beneficiaries —————————————————————————————————————————————————————————
    beneficiaries: list[Beneficiary] = field(default_factory=list)

    transactions: list[Transaction] = field(default_factory=list)

    # — Metadata ——————————————————————————————————————————————————————————————
    last_updated: str = ""

    def __post_init__(self):
        if not self.last_updated:
            self.last_updated = datetime.now(timezone.utc).isoformat()


def _coerce_to_date(val: Any) -> date:
    """Parse boundary date from ISO string, datetime, or date."""
    if isinstance(val, date) and not isinstance(val, datetime):
        return val
    if isinstance(val, datetime):
        return val.astimezone(timezone.utc).date()
    if isinstance(val, str):
        s = val.strip()
        return date.fromisoformat(s[:10])
    raise TypeError(f"Unsupported date boundary type: {type(val)}")


# =============================================================================
# Mock Account API
# =============================================================================

class MockAccountAPI:
    """
    Thread-safe in-memory mock for the account / recordkeeper API.

    Tools call these methods with raw (dereferenced) account numbers
    and an auth_token.  In production these would be REST/gRPC calls to
    the core-banking platform.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._accounts: dict[str, AccountRecord] = {}
        self._audit_log: list[dict[str, Any]] = []

    # — Seeding (test setup) ——————————————————————————————————————————————————

    def seed_account(self, record: AccountRecord) -> None:
        with self._lock:
            self._accounts[record.account_number] = deepcopy(record)

    def seed_accounts(self, records: list[AccountRecord]) -> None:
        for r in records:
            self.seed_account(r)

    def clear(self) -> None:
        with self._lock:
            self._accounts.clear()
            self._audit_log.clear()

    # — Internal helpers ——————————————————————————————————————————————————————

    def _require_auth(self, auth_token: str) -> None:
        if not auth_token:
            raise AuthorizationError("auth_token is required for account access")

    def _get_record(self, account_number: str) -> AccountRecord:
        record = self._accounts.get(account_number)
        if record is None:
            raise AccountNotFoundError(
                f"Account {account_number[-4:] if len(account_number) >= 4 else '****'} not found"
            )
        if record.is_frozen:
            raise AccountFrozenError(
                f"Account ending {account_number[-4:]} is frozen – contact plan administrator"
            )
        if not record.is_active:
            raise AccountFrozenError(
                f"Account ending {account_number[-4:]} is inactive"
            )
        return record

    def _log(self, operation: str, account_number: str, **details: Any) -> None:
        self._audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            "account_last4": account_number[-4:] if len(account_number) >= 4 else "****",
            **details,
        })

    # — Balance Inquiry ———————————————————————————————————————————————————————

    def get_balance(self, account_number: str, auth_token: str) -> dict[str, Any]:
        """
        Return current balance summary for an account.

        Used by: BalanceInquiryTool

        Returns:
            {
                "total_balance": float,
                "vested_balance": float,
                "unvested_balance": float,
                "ytd_contributions": float,
                "ytd_employer_match": float,
                "annual_match_max": float,
                "outstanding_loan_balance": float,
                "account_type": str,
                "plan_name": str,
                "as_of": str,   # ISO timestamp
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            self._log("get_balance", account_number)
            return {
                "total_balance": r.total_balance,
                "vested_balance": r.vested_balance,
                "unvested_balance": r.unvested_balance,
                "ytd_contributions": r.ytd_contributions,
                "ytd_employer_match": r.ytd_employer_match,
                "annual_match_max": r.annual_match_max,
                "outstanding_loan_balance": r.outstanding_loan_balance,
                "account_type": r.account_type,
                "plan_name": r.plan_name,
                "as_of": datetime.now(timezone.utc).isoformat(),
            }

    def get_transaction_history(
        self,
        account_number: str,
        auth_token: str,
        start_date: str | date | datetime | None = None,
        end_date: str | date | datetime | None = None,
        *,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return recent posted-like transactions within an optional window.

        When ``start_date`` / ``end_date`` are omitted, uses the last **90 days**
        ending today (UTC), then caps to ``limit`` rows (most recent first).

        Used by: TransactionHistoryTool
        """
        self._require_auth(auth_token)

        lim = max(1, min(int(limit), 500))

        today_utc = datetime.now(timezone.utc).date()

        try:
            period_end_d = (
                _coerce_to_date(end_date) if end_date is not None else today_utc
            )
        except Exception as exc:
            raise ValueError(f"Invalid end_date: {exc}") from exc

        try:
            period_start_d = (
                _coerce_to_date(start_date)
                if start_date is not None
                else period_end_d - timedelta(days=90)
            )
        except Exception as exc:
            raise ValueError(f"Invalid start_date: {exc}") from exc

        if period_start_d > period_end_d:
            raise ValueError("start_date must be on or before end_date")

        with self._lock:
            r = self._get_record(account_number)
            self._log(
                "get_transaction_history",
                account_number,
                period_start=str(period_start_d),
                period_end=str(period_end_d),
            )

            filtered: list[Transaction] = []
            for t in r.transactions:
                try:
                    tx_d = date.fromisoformat(str(t.date)[:10])
                except ValueError:
                    continue
                if period_start_d <= tx_d <= period_end_d:
                    filtered.append(t)

            filtered.sort(
                key=lambda tr: (
                    date.fromisoformat(str(tr.date)[:10]),
                    tr.reference_id,
                ),
                reverse=True,
            )
            clipped = filtered[:lim]

            return {
                "transactions": [
                    {
                        "date": tr.date,
                        "type": tr.type,
                        "description": tr.description,
                        "amount": tr.amount,
                        "running_balance": tr.running_balance,
                        "reference_id": tr.reference_id,
                    }
                    for tr in clipped
                ],
                "period_start": period_start_d.isoformat(),
                "period_end": period_end_d.isoformat(),
                "account_type": r.account_type,
                "plan_name": r.plan_name,
                "transaction_count": len(clipped),
                "as_of": datetime.now(timezone.utc).isoformat(),
            }

    # — Prior Year-End Balance (RMD) ——————————————————————————————————————————

    def get_prior_year_end_balance(
        self, account_number: str, auth_token: str
    ) -> dict[str, Any]:
        """
        Return the December 31 balance of the prior year for RMD calculation.

        Used by: RMDCalculatorTool

        Returns:
            {
                "prior_year_end_balance": float,
                "tax_year": int,
                "account_type": str,
                "owner_age_years": float,
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            self._log("get_prior_year_end_balance", account_number)
            return {
                "prior_year_end_balance": r.prior_year_end_balance,
                "tax_year": date.today().year - 1,
                "account_type": r.account_type,
                "owner_age_years": r.owner_age_years,
            }

    # — Account Details (general lookup) ——————————————————————————————————————

    def get_account_details(
        self, account_number: str, auth_token: str
    ) -> dict[str, Any]:
        """
        Return full account details.

        Used by: WithdrawalTool, IRARolloverTool, PlanLoanTool

        Returns:
            {
                "account_number_last4": str,
                "account_type": str,
                "owner_name": str,
                "owner_age_years": float,
                "is_active": bool,
                "total_balance": float,
                "vested_balance": float,
                "outstanding_loan_balance": float,
                "highest_loan_balance_12m": float,
                "account_age_days": int,
                "plan_name": str,
                "plan_allows_loans": bool,
                "plan_allows_hardship": bool,
                "plan_allows_rollovers_in": bool,
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            self._log("get_account_details", account_number)
            return {
                "account_number_last4": account_number[-4:],
                "account_type": r.account_type,
                "owner_name": r.owner_name,
                "owner_age_years": r.owner_age_years,
                "is_active": r.is_active,
                "total_balance": r.total_balance,
                "vested_balance": r.vested_balance,
                "outstanding_loan_balance": r.outstanding_loan_balance,
                "highest_loan_balance_12m": r.highest_loan_balance_12m,
                "account_age_days": r.account_age_days,
                "plan_name": r.plan_name,
                "plan_allows_loans": r.plan_allows_loans,
                "plan_allows_hardship": r.plan_allows_hardship,
                "plan_allows_rollovers_in": r.plan_allows_rollovers_in,
            }

    # — Beneficiary Management ————————————————————————————————————————————————

    def get_beneficiaries(
        self, account_number: str, auth_token: str
    ) -> dict[str, Any]:
        """
        Return current beneficiary designations.

        Used by: BeneficiaryManagerTool

        Returns:
            {
                "beneficiaries": [
                    {"name": str, "relationship": str, "percentage": float,
                     "beneficiary_type": str},
                    ...
                ],
                "total_primary_pct": float,
                "total_contingent_pct": float,
                "count": int,
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            self._log("get_beneficiaries", account_number)

            primary = [b for b in r.beneficiaries if b.beneficiary_type == "PRIMARY"]
            contingent = [b for b in r.beneficiaries if b.beneficiary_type == "CONTINGENT"]

            return {
                "beneficiaries": [
                    {
                        "name": b.name,
                        "relationship": b.relationship,
                        "percentage": b.percentage,
                        "beneficiary_type": b.beneficiary_type,
                    }
                    for b in r.beneficiaries
                ],
                "total_primary_pct": sum(b.percentage for b in primary),
                "total_contingent_pct": sum(b.percentage for b in contingent),
                "count": len(r.beneficiaries),
            }

    def update_beneficiaries(
        self,
        account_number: str,
        beneficiaries: list[dict[str, Any]],
        auth_token: str,
    ) -> dict[str, Any]:
        """
        Replace the beneficiary designation for an account.

        Validates:
          - Primary beneficiary percentages must sum to 100%.
          - Contingent beneficiary percentages must sum to 100% if any exist.
          - At least one primary beneficiary is required.

        Used by: BeneficiaryManagerTool

        Returns:
            {
                "confirmation_number": str,
                "beneficiary_count": int,
                "effective_date": str,  # ISO date
                "status": "UPDATED",
            }
        """
        self._require_auth(auth_token)

        # — Validation ————————————————————————————————————————————————————————
        new_beneficiaries = []
        for b in beneficiaries:
            new_beneficiaries.append(
                Beneficiary(
                    name=b["name"],
                    relationship=b.get("relationship", "OTHER"),
                    percentage=b["percentage"],
                    beneficiary_type=b.get("beneficiary_type", "PRIMARY"),
                    date_of_birth=b.get("date_of_birth"),
                    ssn_last4=b.get("ssn_last4"),
                )
            )

        primaries = [b for b in new_beneficiaries if b.beneficiary_type == "PRIMARY"]
        contingents = [b for b in new_beneficiaries if b.beneficiary_type == "CONTINGENT"]

        if not primaries:
            raise ValueError("At least one PRIMARY beneficiary is required")

        primary_total = sum(b.percentage for b in primaries)
        if abs(primary_total - 100.0) > 0.01:
            raise ValueError(
                f"Primary beneficiary percentages must sum to 100%, got {primary_total}%"
            )

        if contingents:
            contingent_total = sum(b.percentage for b in contingents)
            if abs(contingent_total - 100.0) > 0.01:
                raise ValueError(
                    f"Contingent beneficiary percentages must sum to 100%, got {contingent_total}%"
                )

        # — Apply —————————————————————————————————————————————————————————————
        with self._lock:
            r = self._get_record(account_number)
            r.beneficiaries = new_beneficiaries
            r.last_updated = datetime.now(timezone.utc).isoformat()

            confirmation = f"BEN-{uuid.uuid4().hex[:8].upper()}"
            self._log(
                "update_beneficiaries",
                account_number,
                confirmation=confirmation,
                count=len(new_beneficiaries),
            )
            return {
                "confirmation_number": confirmation,
                "beneficiary_count": len(new_beneficiaries),
                "effective_date": date.today().isoformat(),
                "status": "UPDATED",
            }

    # — Balance Mutation (used by disbursement / loan mocks) ——————————————————

    def debit_balance(
        self, account_number: str, amount: float, auth_token: str, reason: str = ""
    ) -> dict[str, Any]:
        """
        Debit (reduce) the account's vested balance.

        Used by: DisbursementAPI, LoanAPI (internal cross-mock calls in tests).

        Returns:
            {"new_vested_balance": float, "debited_amount": float}

        Raises:
            InsufficientBalanceError if amount > vested_balance.
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            if amount > r.vested_balance:
                raise InsufficientBalanceError(
                    f"Requested ${amount:,.2f} exceeds vested balance ${r.vested_balance:,.2f}"
                )
            r.vested_balance -= amount
            r.total_balance -= amount
            r.last_updated = datetime.now(timezone.utc).isoformat()
            self._log("debit_balance", account_number, amount=amount, reason=reason)
            return {
                "new_vested_balance": r.vested_balance,
                "debited_amount": amount,
            }

    def credit_balance(
        self, account_number: str, amount: float, auth_token: str, reason: str = ""
    ) -> dict[str, Any]:
        """
        Credit (increase) the account balance.

        Used by: Rollover receiving side.

        Returns:
            {"new_total_balance": float, "credited_amount": float}
        """
        self._require_auth(auth_token)
        with self._lock:
            r = self._get_record(account_number)
            r.total_balance += amount
            r.vested_balance += amount
            r.last_updated = datetime.now(timezone.utc).isoformat()
            self._log("credit_balance", account_number, amount=amount, reason=reason)
            return {
                "new_total_balance": r.total_balance,
                "credited_amount": amount,
            }

    # — Rollover Initiation ———————————————————————————————————————————————————

    def initiate_rollover(
        self,
        source_account: str,
        destination_account: str,
        amount: float,
        rollover_type: str,
        auth_token: str,
    ) -> dict[str, Any]:
        """
        Initiate a rollover transfer between two accounts.

        Used by: IRARolloverTool

        Validates:
          - Source account exists and has sufficient vested balance.
          - Destination account exists and accepts incoming rollovers.

        Returns:
            {
                "confirmation_number": str,
                "source_account_last4": str,
                "destination_account_last4": str,
                "amount": float,
                "rollover_type": str,
                "estimated_completion_days": int,
                "status": "INITIATED",
                "initiated_at": str,
            }
        """
        self._require_auth(auth_token)

        # C1: Prevent rollover-to-self – same object reference causes
        #     debit/credit to cancel, producing a silent no-op.
        if source_account == destination_account:
            raise ValueError(
                "Cannot rollover to the same account. "
                "Source and destination must be different."
            )

        with self._lock:
            src = self._get_record(source_account)
            dst = self._get_record(destination_account)

            if amount > src.vested_balance:
                raise InsufficientBalanceError(
                    f"Rollover amount ${amount:,.2f} exceeds source vested "
                    f"balance ${src.vested_balance:,.2f}"
                )
            if not dst.plan_allows_rollovers_in:
                raise ValueError(
                    f"Destination plan does not accept incoming rollovers"
                )

            # Debit source, credit destination
            src.vested_balance -= amount
            src.total_balance -= amount
            dst.vested_balance += amount
            dst.total_balance += amount

            now = datetime.now(timezone.utc)
            src.last_updated = now.isoformat()
            dst.last_updated = now.isoformat()

            confirmation = f"ROL-{uuid.uuid4().hex[:8].upper()}"
            self._log(
                "initiate_rollover",
                source_account,
                destination_last4=destination_account[-4:],
                amount=amount,
                rollover_type=rollover_type,
                confirmation=confirmation,
            )
            return {
                "confirmation_number": confirmation,
                "source_account_last4": source_account[-4:],
                "destination_account_last4": destination_account[-4:],
                "amount": amount,
                "rollover_type": rollover_type,
                "estimated_completion_days": 3 if rollover_type == "DIRECT" else 5,
                "status": "INITIATED",
                "initiated_at": now.isoformat(),
            }

    # — Observability —————————————————————————————————————————————————————————

    @property
    def audit_log(self) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._audit_log)

    def __len__(self) -> int:
        with self._lock:
            return len(self._accounts)


# =============================================================================
# Standard Test Accounts
# =============================================================================

STANDARD_401K = AccountRecord(
    account_number="1234567890",
    account_type="401K",
    owner_name="Jane Doe",
    owner_age_years=45.0,
    owner_dob="1981-03-15",
    total_balance=150_000.00,
    vested_balance=135_000.00,
    unvested_balance=15_000.00,
    prior_year_end_balance=142_000.00,
    ytd_contributions=12_500.00,
    ytd_employer_match=6_250.00,
    annual_match_max=11_750.00,
    outstanding_loan_balance=0.00,
    highest_loan_balance_12m=0.00,
    account_age_days=3650,
    plan_allows_loans=True,
    plan_allows_hardship=True,
    plan_allows_rollovers_in=True,
    beneficiaries=[
        Beneficiary(name="John Doe", relationship="SPOUSE", percentage=100.0),
    ],
    transactions=[
        Transaction(
            date="2026-04-28",
            type="CONTRIBUTION",
            description="Payroll deferral",
            amount=500.00,
            running_balance=150_000.00,
            reference_id="T-STD401K-0428",
        ),
        Transaction(
            date="2024-01-10",
            type="CONTRIBUTION",
            description="Stale window row",
            amount=100.00,
            running_balance=149_400.00,
            reference_id="T-STD401K-OLD",
        ),
    ],
)

STANDARD_IRA = AccountRecord(
    account_number="9876543210",
    account_type="TRADITIONAL_IRA",
    owner_name="Jane Doe",
    owner_age_years=45.0,
    owner_dob="1981-03-15",
    total_balance=85_000.00,
    vested_balance=85_000.00,
    prior_year_end_balance=80_000.00,
    account_age_days=2920,
    plan_allows_loans=False,
    plan_allows_rollovers_in=True,
    beneficiaries=[
        Beneficiary(name="John Doe", relationship="SPOUSE", percentage=100.0),
    ],
    transactions=[
        Transaction(
            date="2026-03-05",
            type="DIVIDEND",
            description="Bond fund payout",
            amount=42.55,
            running_balance=85_000.00,
            reference_id="T-STDIRA-0305",
        ),
        Transaction(
            date="2026-02-02",
            type="CONTRIBUTION",
            description="Annual contribution",
            amount=7000.00,
            running_balance=84_957.45,
            reference_id="T-STDIRA-0202",
        ),
    ],
)

ROTH_IRA = AccountRecord(
    account_number="5555555555",
    account_type="ROTH_IRA",
    owner_name="Jane Doe",
    owner_age_years=45.0,
    owner_dob="1981-03-15",
    total_balance=60_000.00,
    vested_balance=60_000.00,
    prior_year_end_balance=55_000.00,
    account_age_days=1825,
    plan_allows_loans=False,
    plan_allows_rollovers_in=True,
    transactions=[
        Transaction(
            date="2026-04-03",
            type="CONTRIBUTION",
            description="Monthly Roth IRA savings",
            amount=500.00,
            running_balance=60_000.00,
            reference_id="T-ROTH-0403",
        ),
    ],
)

RMD_ELIGIBLE_ACCOUNT = AccountRecord(
    account_number="7777777777",
    account_type="401K",
    owner_name="Robert Smith",
    owner_age_years=75.0,
    owner_dob="1951-06-20",
    total_balance=500_000.00,
    vested_balance=500_000.00,
    prior_year_end_balance=480_000.00,
    account_age_days=10_950,
    plan_allows_loans=False,
    beneficiaries=[
        Beneficiary(name="Mary Smith", relationship="SPOUSE", percentage=100.0),
    ],
    transactions=[
        Transaction(
            date="2026-04-20",
            type="WITHDRAWAL",
            description="RMD distribution estimate",
            amount=-8000.00,
            running_balance=500_000.00,
            reference_id="T-RMD-0420",
        ),
    ],
)

HIGH_BALANCE_401K = AccountRecord(
    account_number="8888888888",
    account_type="401K",
    owner_name="Alice Johnson",
    owner_age_years=55.0,
    owner_dob="1971-01-10",
    total_balance=750_000.00,
    vested_balance=720_000.00,
    unvested_balance=30_000.00,
    prior_year_end_balance=700_000.00,
    ytd_contributions=23_500.00,
    ytd_employer_match=11_750.00,
    annual_match_max=11_750.00,
    outstanding_loan_balance=15_000.00,
    highest_loan_balance_12m=20_000.00,
    account_age_days=7300,
    plan_allows_loans=True,
    beneficiaries=[
        Beneficiary(name="Bob Johnson", relationship="SPOUSE", percentage=60.0),
        Beneficiary(name="Carol Johnson", relationship="CHILD", percentage=40.0),
    ],
    transactions=[
        Transaction(
            date="2026-04-10",
            type="LOAN_PAYMENT",
            description="Loan #2 payment",
            amount=450.50,
            running_balance=750_000.00,
            reference_id="T-HI401-0410",
        ),
        Transaction(
            date="2026-03-12",
            type="FEE",
            description="Quarterly advisory fee",
            amount=-225.75,
            running_balance=749_549.50,
            reference_id="T-HI401-0312",
        ),
    ],
)

FROZEN_ACCOUNT = AccountRecord(
    account_number="0000000000",
    account_type="401K",
    owner_name="Frozen User",
    owner_age_years=50.0,
    owner_dob="1976-01-01",
    is_frozen=True,
    total_balance=50_000.00,
    vested_balance=50_000.00,
)

INACTIVE_ACCOUNT = AccountRecord(
    account_number="1111111111",
    account_type="TRADITIONAL_IRA",
    owner_name="Inactive User",
    owner_age_years=60.0,
    owner_dob="1966-05-05",
    is_active=False,
    total_balance=30_000.00,
    vested_balance=30_000.00,
)


def create_mock_account_api(preload: bool = True) -> MockAccountAPI:
    """
    Factory that returns a MockAccountAPI pre-loaded with standard test accounts.

    Args:
        preload: If True, seed with all standard accounts. If False, return empty.
    """
    api = MockAccountAPI()
    if preload:
        api.seed_accounts([
            STANDARD_401K,
            STANDARD_IRA,
            ROTH_IRA,
            RMD_ELIGIBLE_ACCOUNT,
            HIGH_BALANCE_401K,
            FROZEN_ACCOUNT,
            INACTIVE_ACCOUNT,
        ])
    return api
