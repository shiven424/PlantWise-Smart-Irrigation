"""
Mock Loan API – simulates 401(k) plan loan origination and servicing.

Used by tools:
  - PlanLoanTool -> initiate_loan(), get_loan_status(), get_loan_eligibility()

Regulatory references:
  - IRC 72(p)(2)(A): Maximum loan = lesser of 50% vested balance or $50,000
  - IRC 72(p)(2)(B): $50,000 ceiling reduced by highest outstanding loan
                     balance in the trailing 12 months
  - IRC 72(p)(2)(B): General-purpose loans: max 60-month term
                     Primary residence loans: max 360-month (30-year) term
  - IRC 72(p)(2)(C): Substantially level amortization required
  - SECURE 2.0 §314: Disaster distribution / loan extensions (not modeled here)

Design:
  - In-memory loan store keyed by loan_id.
  - Thread-safe via threading.Lock.
  - Deterministic loan IDs and payment schedules.
  - Validates IRC 72(p) dual-limit and term constraints.
  - Computes amortization schedule per IRC 72(p)(2)(C).
"""

from __future__ import annotations

import math
import threading
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any


# =============================================================================
# Exceptions
# =============================================================================

class LoanRejectedError(Exception):
    """Raised when the loan request fails regulatory or plan-level checks."""


class LoanNotFoundError(Exception):
    """Raised when a loan_id does not exist."""


class DuplicateLoanError(Exception):
    """Raised when an idempotency key has already been used."""


class AuthorizationError(Exception):
    """Raised when auth_token is missing or invalid."""


class PlanDoesNotAllowLoansError(Exception):
    """Raised when the plan document prohibits participant loans."""


# =============================================================================
# IRC 72(p) Constants
# =============================================================================

IRC_72P_ABSOLUTE_MAX = 50_000           # IRC 72(p)(2)(A)(i) – dollar ceiling
IRC_72P_VESTED_PCT = 0.50              # IRC 72(p)(2)(A)(ii) – 50% of vested
IRC_72P_FLOOR = 10_000                 # IRC 72(p)(2)(A)(ii) – $10,000 statutory floor
GENERAL_PURPOSE_MAX_TERM_MONTHS = 60   # 5 years
PRIMARY_RESIDENCE_MAX_TERM_MONTHS = 360  # 30 years
DEFAULT_INTEREST_RATE = 0.055          # Prime + 1% (typical plan rate)
MINIMUM_LOAN_AMOUNT = 1_000            # Typical plan minimum


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class AmortizationEntry:
    payment_number: int
    payment_date: str                  # ISO date
    principal: float
    interest: float
    total_payment: float
    remaining_balance: float


@dataclass
class LoanEligibility:
    eligible: bool
    max_loan_amount: float
    vested_balance: float
    irc_72p_limit: float               # Lesser of 50% vested or $50K
    net_limit: float                   # After subtracting highest 12m balance
    highest_loan_balance_12m: float
    outstanding_loan_balance: float
    plan_allows_loans: bool
    rejection_reason: str | None = None


@dataclass
class LoanRecord:
    loan_id: str
    account_number_last4: str
    loan_type: str                     # GENERAL_PURPOSE | PRIMARY_RESIDENCE
    principal_amount: float
    interest_rate: float
    term_months: int
    monthly_payment: float
    first_payment_date: str            # ISO date
    maturity_date: str                 # ISO date
    outstanding_balance: float
    payments_made: int = 0
    status: str = "ACTIVE"            # ACTIVE | PAID_OFF | DEFAULTED | DEEMED_DISTRIBUTION
    originated_at: str = ""
    idempotency_key: str | None = None

    def __post_init__(self):
        if not self.originated_at:
            self.originated_at = datetime.now(timezone.utc).isoformat()


# =============================================================================
# Amortization Calculator
# =============================================================================

def calculate_monthly_payment(
    principal: float,
    annual_rate: float,
    term_months: int,
) -> float:
    """
    Calculate the fixed monthly payment using standard amortization formula.

    IRC 72(p)(2)(C) requires "substantially level amortization" – this ensures
    each payment is identical (standard fixed-rate amortization).

    Formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
    Where: P = principal, r = monthly rate, n = number of payments
    """
    if annual_rate <= 0 or term_months <= 0:
        return round(principal / max(term_months, 1), 2)

    r = annual_rate / 12.0
    n = term_months
    numerator = r * (1 + r) ** n
    denominator = (1 + r) ** n - 1

    if denominator == 0:
        return round(principal / n, 2)

    return round(principal * (numerator / denominator), 2)


def generate_amortization_schedule(
    principal: float,
    annual_rate: float,
    term_months: int,
    start_date: date,
) -> list[AmortizationEntry]:
    """
    Generate a full amortization schedule for the loan.

    Returns a list of AmortizationEntry objects, one per payment period.
    """
    monthly_payment = calculate_monthly_payment(principal, annual_rate, term_months)
    r = annual_rate / 12.0
    balance = principal
    schedule: list[AmortizationEntry] = []

    for i in range(1, term_months + 1):
        interest = round(balance * r, 2)
        principal_portion = round(monthly_payment - interest, 2)

        # Last payment adjustment to avoid rounding drift
        if i == term_months:
            principal_portion = round(balance, 2)
            total = round(principal_portion + interest, 2)
        else:
            total = monthly_payment

        balance = max(round(balance - principal_portion, 2), 0.0)
        payment_date = start_date + timedelta(days=30 * i)

        schedule.append(AmortizationEntry(
            payment_number=i,
            payment_date=payment_date.isoformat(),
            principal=principal_portion,
            interest=interest,
            total_payment=total,
            remaining_balance=balance,
        ))

    return schedule


# =============================================================================
# Mock Loan API
# =============================================================================

class MockLoanAPI:
    """
    Thread-safe in-memory mock for the 401(k) plan loan origination service.

    Validates IRC 72(p) constraints, computes amortization, and tracks loan
    lifecycle.  Tools call these methods with raw (dereferenced) data.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._loans: dict[str, LoanRecord] = {}
        self._idempotency_keys: set[str] = set()
        self._audit_log: list[dict[str, Any]] = []

    # — Helpers ———————————————————————————————————————————————————————————————

    def _require_auth(self, auth_token: str) -> None:
        if not auth_token:
            raise AuthorizationError("auth_token is required for loan operations")

    def _check_idempotency(self, idempotency_key: str | None) -> None:
        if idempotency_key and idempotency_key in self._idempotency_keys:
            raise DuplicateLoanError(
                f"Loan with idempotency key {idempotency_key!r} already submitted"
            )

    def _log(self, operation: str, **details: Any) -> None:
        self._audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            **details,
        })

    # — Loan Eligibility Check ————————————————————————————————————————————————

    @staticmethod
    def check_eligibility(
        vested_balance: float,
        outstanding_loan_balance: float,
        highest_loan_balance_12m: float,
        plan_allows_loans: bool,
    ) -> LoanEligibility:
        """
        Determine loan eligibility per IRC 72(p) dual-limit rules.

        Step 1: irc_72p_limit = min(50% of vested_balance, $50,000)
        Step 2: net_limit = irc_72p_limit - highest_loan_balance_12m
        Step 3: max_loan_amount = max(net_limit, 0)

        The highest_loan_balance_12m lookback (not current balance) prevents
        participants from repeatedly paying down and re-borrowing to circumvent
        the $50,000 cap.

        Args:
            vested_balance: Current vested account balance.
            outstanding_loan_balance: Current outstanding loan balance.
            highest_loan_balance_12m: Highest balance in trailing 12 months.
            plan_allows_loans: Whether the plan document permits loans.

        Returns:
            LoanEligibility with computed limits and eligibility decision.
        """
        if not plan_allows_loans:
            return LoanEligibility(
                eligible=False,
                max_loan_amount=0.0,
                vested_balance=vested_balance,
                irc_72p_limit=0.0,
                net_limit=0.0,
                highest_loan_balance_12m=highest_loan_balance_12m,
                outstanding_loan_balance=outstanding_loan_balance,
                plan_allows_loans=False,
                rejection_reason="Plan document does not permit participant loans",
            )

        # IRC 72(p)(2)(A): greater of (50% vested, $10,000) capped at $50,000,
        # then capped at vested balance so the loan cannot exceed what is available.
        irc_limit = min(
            max(vested_balance * IRC_72P_VESTED_PCT, IRC_72P_FLOOR),
            IRC_72P_ABSOLUTE_MAX,
        )
        irc_limit = min(irc_limit, vested_balance)

        # IRC 72(p)(2)(B): reduce by highest outstanding balance in trailing 12 months
        net_limit = max(irc_limit - highest_loan_balance_12m, 0.0)
        max_amount = round(net_limit, 2)

        if max_amount < MINIMUM_LOAN_AMOUNT:
            reason = (
                f"Maximum eligible loan amount ${max_amount:,.2f} is below the "
                f"plan minimum of ${MINIMUM_LOAN_AMOUNT:,.2f}"
            )
            return LoanEligibility(
                eligible=False,
                max_loan_amount=max_amount,
                vested_balance=vested_balance,
                irc_72p_limit=round(irc_limit, 2),
                net_limit=round(net_limit, 2),
                highest_loan_balance_12m=highest_loan_balance_12m,
                outstanding_loan_balance=outstanding_loan_balance,
                plan_allows_loans=True,
                rejection_reason=reason,
            )

        return LoanEligibility(
            eligible=True,
            max_loan_amount=max_amount,
            vested_balance=vested_balance,
            irc_72p_limit=round(irc_limit, 2),
            net_limit=round(net_limit, 2),
            highest_loan_balance_12m=highest_loan_balance_12m,
            outstanding_loan_balance=outstanding_loan_balance,
            plan_allows_loans=True,
        )

    # — Get Loan Eligibility ——————————————————————————————————————————————————

    def get_loan_eligibility(
        self,
        account_number: str,
        vested_balance: float,
        outstanding_loan_balance: float,
        highest_loan_balance_12m: float,
        plan_allows_loans: bool,
        auth_token: str,
    ) -> dict[str, Any]:
        """
        Check loan eligibility and return the result as a dict.

        Used by: PlanLoanTool (pre-check before initiate_loan)

        Returns:
            {
                "eligible": bool,
                "max_loan_amount": float,
                "vested_balance": float,
                "irc_72p_limit": float,
                "net_limit": float,
                "plan_allows_loans": bool,
                "rejection_reason": str | None,
            }
        """
        self._require_auth(auth_token)
        elig = self.check_eligibility(
            vested_balance=vested_balance,
            outstanding_loan_balance=outstanding_loan_balance,
            highest_loan_balance_12m=highest_loan_balance_12m,
            plan_allows_loans=plan_allows_loans,
        )
        self._log(
            "get_loan_eligibility",
            account_last4=account_number[-4:] if len(account_number) >= 4 else "****",
            eligible=elig.eligible,
            max_loan_amount=elig.max_loan_amount,
        )
        return {
            "eligible": elig.eligible,
            "max_loan_amount": elig.max_loan_amount,
            "vested_balance": elig.vested_balance,
            "irc_72p_limit": elig.irc_72p_limit,
            "net_limit": elig.net_limit,
            "highest_loan_balance_12m": elig.highest_loan_balance_12m,
            "outstanding_loan_balance": elig.outstanding_loan_balance,
            "plan_allows_loans": elig.plan_allows_loans,
            "rejection_reason": elig.rejection_reason,
        }

    # — Initiate Loan —————————————————————————————————————————————————————————

    def initiate_loan(
        self,
        account_number: str,
        amount: float,
        term_months: int,
        auth_token: str,
        loan_type: str = "GENERAL_PURPOSE",
        interest_rate: float | None = None,
        vested_balance: float = 0.0,
        outstanding_loan_balance: float = 0.0,
        highest_loan_balance_12m: float = 0.0,
        plan_allows_loans: bool = True,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Originate a new plan loan.

        Validates:
          1. Plan allows loans.
          2. Amount does not exceed IRC 72(p) limit.
          3. Amount >= plan minimum ($1,000).
          4. Term does not exceed IRC 72(p)(2)(B) limits:
             - General purpose: 60 months (5 years)
             - Primary residence: 360 months (30 years)

        Used by: PlanLoanTool

        Returns:
            {
                "loan_id": str,
                "confirmation_number": str,
                "principal_amount": float,
                "interest_rate": float,
                "term_months": int,
                "monthly_payment": float,
                "first_payment_date": str,
                "maturity_date": str,
                "total_interest": float,
                "total_repayment": float,
                "status": "ACTIVE",
                "originated_at": str,
            }
        """
        self._require_auth(auth_token)
        self._check_idempotency(idempotency_key)

        # — Validate plan eligibility —————————————————————————————————————————
        if not plan_allows_loans:
            raise PlanDoesNotAllowLoansError(
                "The plan document does not permit participant loans"
            )

        # — Validate IRC 72(p) amount limits ——————————————————————————————————
        elig = self.check_eligibility(
            vested_balance=vested_balance,
            outstanding_loan_balance=outstanding_loan_balance,
            highest_loan_balance_12m=highest_loan_balance_12m,
            plan_allows_loans=plan_allows_loans,
        )

        if not elig.eligible:
            raise LoanRejectedError(
                elig.rejection_reason or "Loan eligibility check failed"
            )

        if amount > elig.max_loan_amount:
            raise LoanRejectedError(
                f"Requested ${amount:,.2f} exceeds IRC 72(p) maximum "
                f"of ${elig.max_loan_amount:,.2f}"
            )

        if amount < MINIMUM_LOAN_AMOUNT:
            raise LoanRejectedError(
                f"Requested ${amount:,.2f} is below the plan minimum "
                f"of ${MINIMUM_LOAN_AMOUNT:,.2f}"
            )

        # — Validate term limits ——————————————————————————————————————————————
        max_term = (
            PRIMARY_RESIDENCE_MAX_TERM_MONTHS
            if loan_type == "PRIMARY_RESIDENCE"
            else GENERAL_PURPOSE_MAX_TERM_MONTHS
        )
        if term_months > max_term:
            raise LoanRejectedError(
                f"{loan_type} loan term {term_months} months exceeds "
                f"IRC 72(p) maximum of {max_term} months"
            )
        if term_months < 1:
            raise LoanRejectedError("Loan term must be at least 1 month")

        # — Compute amortization ——————————————————————————————————————————————
        rate = interest_rate if interest_rate is not None else DEFAULT_INTEREST_RATE
        monthly = calculate_monthly_payment(amount, rate, term_months)
        total_repayment = round(monthly * term_months, 2)
        total_interest = round(total_repayment - amount, 2)

        today = date.today()
        first_payment = today + timedelta(days=30)
        maturity = today + timedelta(days=30 * term_months)

        # — Create loan record ————————————————————————————————————————————————
        loan_id = f"LOAN-{uuid.uuid4().hex[:8].upper()}"
        confirmation = f"LN-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now(timezone.utc)

        record = LoanRecord(
            loan_id=loan_id,
            account_number_last4=account_number[-4:] if len(account_number) >= 4 else "****",
            loan_type=loan_type,
            principal_amount=amount,
            interest_rate=rate,
            term_months=term_months,
            monthly_payment=monthly,
            first_payment_date=first_payment.isoformat(),
            maturity_date=maturity.isoformat(),
            outstanding_balance=amount,
            status="ACTIVE",
            originated_at=now.isoformat(),
            idempotency_key=idempotency_key,
        )

        with self._lock:
            self._loans[loan_id] = record
            if idempotency_key:
                self._idempotency_keys.add(idempotency_key)

            self._log(
                "initiate_loan",
                loan_id=loan_id,
                account_last4=record.account_number_last4,
                amount=amount,
                term_months=term_months,
                loan_type=loan_type,
                monthly_payment=monthly,
            )

        return {
            "loan_id": loan_id,
            "confirmation_number": confirmation,
            "principal_amount": amount,
            "interest_rate": rate,
            "term_months": term_months,
            "monthly_payment": monthly,
            "first_payment_date": first_payment.isoformat(),
            "maturity_date": maturity.isoformat(),
            "total_interest": total_interest,
            "total_repayment": total_repayment,
            "status": "ACTIVE",
            "originated_at": now.isoformat(),
        }

    # — Loan Status ———————————————————————————————————————————————————————————

    def get_loan_status(
        self, loan_id: str, auth_token: str
    ) -> dict[str, Any]:
        """
        Look up current loan status and payment details.

        Used by: PlanLoanTool (post-origination confirmation)

        Returns:
            {
                "loan_id": str,
                "loan_type": str,
                "principal_amount": float,
                "outstanding_balance": float,
                "monthly_payment": float,
                "interest_rate": float,
                "term_months": int,
                "payments_made": int,
                "payments_remaining": int,
                "first_payment_date": str,
                "maturity_date": str,
                "status": str,
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            record = self._loans.get(loan_id)
            if record is None:
                raise LoanNotFoundError(f"Loan {loan_id} not found")

            self._log("get_loan_status", loan_id=loan_id)
            return {
                "loan_id": record.loan_id,
                "loan_type": record.loan_type,
                "principal_amount": record.principal_amount,
                "outstanding_balance": record.outstanding_balance,
                "monthly_payment": record.monthly_payment,
                "interest_rate": record.interest_rate,
                "term_months": record.term_months,
                "payments_made": record.payments_made,
                "payments_remaining": record.term_months - record.payments_made,
                "first_payment_date": record.first_payment_date,
                "maturity_date": record.maturity_date,
                "status": record.status,
            }

    # — Make Payment (test simulation) ————————————————————————————————————————

    def make_payment(
        self, loan_id: str, payment_amount: float, auth_token: str
    ) -> dict[str, Any]:
        """
        Record a loan repayment.

        Used by: test simulation of payroll-deducted repayments.

        Returns:
            {
                "loan_id": str,
                "payment_applied": float,
                "interest_portion": float,
                "principal_portion": float,
                "new_outstanding_balance": float,
                "payments_made": int,
                "status": str,
            }
        """
        self._require_auth(auth_token)
        with self._lock:
            record = self._loans.get(loan_id)
            if record is None:
                raise LoanNotFoundError(f"Loan {loan_id} not found")

            if record.status != "ACTIVE":
                raise LoanRejectedError(
                    f"Cannot make payment on loan {loan_id} with status {record.status}"
                )

            # Calculate interest and principal portions
            monthly_rate = record.interest_rate / 12.0
            interest = round(record.outstanding_balance * monthly_rate, 2)
            principal = round(payment_amount - interest, 2)
            principal = min(principal, record.outstanding_balance)

            record.outstanding_balance = max(
                round(record.outstanding_balance - principal, 2), 0.0
            )
            record.payments_made += 1

            # Auto-close if paid off
            if record.outstanding_balance <= 0.01:
                record.outstanding_balance = 0.0
                record.status = "PAID_OFF"

            self._log(
                "make_payment",
                loan_id=loan_id,
                payment=payment_amount,
                interest=interest,
                principal=principal,
                remaining=record.outstanding_balance,
            )

            return {
                "loan_id": record.loan_id,
                "payment_applied": payment_amount,
                "interest_portion": interest,
                "principal_portion": principal,
                "new_outstanding_balance": record.outstanding_balance,
                "payments_made": record.payments_made,
                "status": record.status,
            }

    # — Get Amortization Schedule —————————————————————————————————————————————

    def get_amortization_schedule(
        self, loan_id: str, auth_token: str
    ) -> list[dict[str, Any]]:
        """
        Return the full amortization schedule for an active loan.

        Returns:
            List of payment entries: [
                {"payment_number": int, "payment_date": str,
                 "principal": float, "interest": float,
                 "total_payment": float, "remaining_balance": float},
                ...
            ]
        """
        self._require_auth(auth_token)
        with self._lock:
            record = self._loans.get(loan_id)
            if record is None:
                raise LoanNotFoundError(f"Loan {loan_id} not found")

            start = date.fromisoformat(record.first_payment_date)
            schedule = generate_amortization_schedule(
                principal=record.principal_amount,
                annual_rate=record.interest_rate,
                term_months=record.term_months,
                start_date=start - timedelta(days=30),
            )
            return [
                {
                    "payment_number": e.payment_number,
                    "payment_date": e.payment_date,
                    "principal": e.principal,
                    "interest": e.interest,
                    "total_payment": e.total_payment,
                    "remaining_balance": e.remaining_balance,
                }
                for e in schedule
            ]

    # — List Loans by Account ————————————————————————————————————————————————

    def list_loans_by_account(
        self,
        account_number: str,
        auth_token: str,
        *,
        status_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Return all loans associated with an account number (last-4 match).

        Used by: PlanLoanTool STATUS branch when no specific loan_id is provided.

        Args:
            account_number: Raw account number; only the last 4 digits are
                compared against stored records (PII-safe comparison).
            auth_token: Must be non-empty.
            status_filter: Optional – restrict to "ACTIVE", "PAID_OFF", etc.

        Returns:
            List of loan summaries, most-recently-originated first:
            [
                {
                    "loan_id": str,
                    "loan_type": str,
                    "principal_amount": float,
                    "outstanding_balance": float,
                    "monthly_payment": float,
                    "interest_rate": float,
                    "term_months": int,
                    "payments_made": int,
                    "payments_remaining": int,
                    "first_payment_date": str,
                    "maturity_date": str,
                    "status": str,
                    "originated_at": str,
                },
                ...
            ]
        """
        self._require_auth(auth_token)
        last4 = account_number[-4:] if len(account_number) >= 4 else account_number
        with self._lock:
            results = [
                {
                    "loan_id": r.loan_id,
                    "loan_type": r.loan_type,
                    "principal_amount": r.principal_amount,
                    "outstanding_balance": r.outstanding_balance,
                    "monthly_payment": r.monthly_payment,
                    "interest_rate": r.interest_rate,
                    "term_months": r.term_months,
                    "payments_made": r.payments_made,
                    "payments_remaining": r.term_months - r.payments_made,
                    "first_payment_date": r.first_payment_date,
                    "maturity_date": r.maturity_date,
                    "status": r.status,
                    "originated_at": r.originated_at,
                }
                for r in self._loans.values()
                if r.account_number_last4 == last4
                and (status_filter is None or r.status == status_filter)
            ]
            results.sort(key=lambda x: x["originated_at"], reverse=True)
            self._log(
                "list_loans_by_account",
                account_last4=last4,
                count=len(results),
                status_filter=status_filter,
            )
            return results

    # — Default a Loan (test simulation) ——————————————————————————————————————

    def default_loan(self, loan_id: str) -> bool:
        """
        Mark a loan as defaulted (deemed distribution per IRC 72(p)).

        When a participant fails to make payments, the outstanding balance
        is treated as a taxable distribution (deemed distribution).

        Returns True if the loan was successfully defaulted.
        """
        with self._lock:
            record = self._loans.get(loan_id)
            if record is None:
                return False
            if record.status != "ACTIVE":
                return False
            record.status = "DEEMED_DISTRIBUTION"
            self._log("default_loan", loan_id=loan_id, balance=record.outstanding_balance)
            return True

    # — Cleanup & Observability ———————————————————————————————————————————————

    def clear(self) -> None:
        with self._lock:
            self._loans.clear()
            self._idempotency_keys.clear()
            self._audit_log.clear()

    @property
    def audit_log(self) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._audit_log)

    @property
    def loan_count(self) -> int:
        with self._lock:
            return len(self._loans)

    def __len__(self) -> int:
        return self.loan_count


def create_mock_loan_api() -> MockLoanAPI:
    """Factory that returns a clean MockLoanAPI instance."""
    return MockLoanAPI()
