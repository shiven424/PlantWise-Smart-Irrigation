"""FastAPI app for the mock account / loan / disbursement service.

Single ASGI app exposing all 14 endpoints under ``/v1/...`` with the
shared bearer-token auth dependency and standard error envelope.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from .errors import install_exception_handlers
from .routes import accounts, disbursements, loans
from .store import _bootstrap

_log = logging.getLogger("mock_services.account_service")


@asynccontextmanager
async def _lifespan(app: FastAPI):  # noqa: ARG001
    _bootstrap()
    _log.info("mock_account_service.started")
    yield
    _log.info("mock_account_service.stopped")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Mock Account Service",
        version="1.0.0",
        description=(
            "Mock recordkeeper / custodian API. Mirrors the in-process "
            "MockAccountAPI / MockLoanAPI / MockDisbursementAPI surface "
            "over HTTP so tools can talk to a real service in demos."
        ),
        lifespan=_lifespan,
    )
    app.include_router(accounts.router)
    app.include_router(loans.router)
    app.include_router(disbursements.router)
    install_exception_handlers(app)

    @app.get("/health", tags=["meta"])
    def _health() -> dict:
        return {"status": "ok"}

    return app


app = create_app()
