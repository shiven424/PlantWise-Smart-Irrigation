"""Account-related routes (balance, details, beneficiaries, rollover)."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from .. import schemas
from ..auth import assert_user_owns_account, authenticated_user
from ..store import account_api

router = APIRouter(prefix="/v1/accounts", tags=["accounts"])


@router.get("/{account_number}/balance", response_model=schemas.BalanceResponse)
def get_balance(
    account_number: str,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().get_balance(account_number, token)


@router.get(
    "/{account_number}/prior-year-balance",
    response_model=schemas.PriorYearEndBalanceResponse,
)
def get_prior_year_end_balance(
    account_number: str,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().get_prior_year_end_balance(account_number, token)


@router.get("/{account_number}", response_model=schemas.AccountDetailsResponse)
def get_account_details(
    account_number: str,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().get_account_details(account_number, token)


@router.get(
    "/{account_number}/beneficiaries",
    response_model=schemas.GetBeneficiariesResponse,
)
def get_beneficiaries(
    account_number: str,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().get_beneficiaries(account_number, token)


@router.put(
    "/{account_number}/beneficiaries",
    response_model=schemas.UpdateBeneficiariesResponse,
)
def update_beneficiaries(
    account_number: str,
    body: schemas.UpdateBeneficiariesRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().update_beneficiaries(
        account_number,
        [b.model_dump(exclude_none=True) for b in body.beneficiaries],
        token,
    )


@router.post(
    "/{account_number}/rollover",
    response_model=schemas.RolloverResponse,
)
def initiate_rollover(
    account_number: str,
    body: schemas.RolloverRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, user_id = auth
    assert_user_owns_account(user_id, account_number)
    return account_api().initiate_rollover(
        source_account=account_number,
        destination_account=body.destination_account,
        amount=body.amount,
        rollover_type=body.rollover_type,
        auth_token=token,
    )
