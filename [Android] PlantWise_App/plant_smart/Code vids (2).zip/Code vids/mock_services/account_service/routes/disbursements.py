"""Disbursement routes (ACH, wire, check, RMD)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Header

from .. import schemas
from ..auth import authenticated_user
from ..store import disbursement_api

router = APIRouter(prefix="/v1/disbursements", tags=["disbursements"])


@router.post("/ach", response_model=schemas.DisbursementResponse)
def submit_ach(
    body: schemas.AchDisbursementRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict:
    token, _ = auth
    return disbursement_api().submit_ach(
        account_number=body.account_number,
        bank_routing_number=body.bank_routing_number,
        bank_account_number=body.bank_account_number,
        amount=body.amount,
        auth_token=token,
        disbursement_type=body.disbursement_type,
        owner_age=body.owner_age,
        custom_withholding_rate=body.custom_withholding_rate,
        state_withholding_rate=body.state_withholding_rate,
        idempotency_key=idempotency_key,
    )


@router.post("/wire", response_model=schemas.DisbursementResponse)
def submit_wire(
    body: schemas.WireDisbursementRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict:
    token, _ = auth
    return disbursement_api().submit_wire(
        account_number=body.account_number,
        bank_routing_number=body.bank_routing_number,
        bank_account_number=body.bank_account_number,
        amount=body.amount,
        auth_token=token,
        disbursement_type=body.disbursement_type,
        owner_age=body.owner_age,
        custom_withholding_rate=body.custom_withholding_rate,
        idempotency_key=idempotency_key,
    )


@router.post("/check", response_model=schemas.DisbursementResponse)
def submit_check(
    body: schemas.CheckDisbursementRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict:
    token, _ = auth
    return disbursement_api().submit_check(
        account_number=body.account_number,
        mailing_address=body.mailing_address,
        amount=body.amount,
        auth_token=token,
        disbursement_type=body.disbursement_type,
        owner_age=body.owner_age,
        custom_withholding_rate=body.custom_withholding_rate,
        idempotency_key=idempotency_key,
    )


@router.post("/rmd", response_model=schemas.DisbursementResponse)
def submit_rmd_distribution(
    body: schemas.RmdDisbursementRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict:
    token, _ = auth
    return disbursement_api().submit_rmd_distribution(
        account_number=body.account_number,
        bank_routing_number=body.bank_routing_number,
        bank_account_number=body.bank_account_number,
        rmd_amount=body.rmd_amount,
        owner_age=body.owner_age,
        auth_token=token,
        custom_withholding_rate=body.custom_withholding_rate,
        idempotency_key=idempotency_key,
    )
