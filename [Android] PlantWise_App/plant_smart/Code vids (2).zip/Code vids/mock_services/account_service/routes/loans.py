"""Loan routes (eligibility, initiate, status, payments)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Header

from .. import schemas
from ..auth import authenticated_user
from ..store import loan_api

router = APIRouter(prefix="/v1/loans", tags=["loans"])


@router.post("/eligibility", response_model=schemas.LoanEligibilityResponse)
def get_loan_eligibility(
    body: schemas.LoanEligibilityRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, _ = auth
    return loan_api().get_loan_eligibility(
        account_number=body.account_number,
        vested_balance=body.vested_balance,
        outstanding_loan_balance=body.outstanding_loan_balance,
        highest_loan_balance_12m=body.highest_loan_balance_12m,
        plan_allows_loans=body.plan_allows_loans,
        auth_token=token,
    )


@router.post("", response_model=schemas.LoanInitiateResponse)
def initiate_loan(
    body: schemas.LoanInitiateRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict:
    token, _ = auth
    return loan_api().initiate_loan(
        account_number=body.account_number,
        amount=body.amount,
        term_months=body.term_months,
        auth_token=token,
        loan_type=body.loan_type,
        interest_rate=body.interest_rate,
        vested_balance=body.vested_balance,
        outstanding_loan_balance=body.outstanding_loan_balance,
        highest_loan_balance_12m=body.highest_loan_balance_12m,
        plan_allows_loans=body.plan_allows_loans,
        idempotency_key=idempotency_key,
    )


@router.get("/{loan_id}", response_model=schemas.LoanStatusResponse)
def get_loan_status(
    loan_id: str,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, _ = auth
    return loan_api().get_loan_status(loan_id, token)


@router.post("/{loan_id}/payments", response_model=schemas.LoanPaymentResponse)
def make_payment(
    loan_id: str,
    body: schemas.LoanPaymentRequest,
    auth: tuple[str, str] = Depends(authenticated_user),
) -> dict:
    token, _ = auth
    return loan_api().make_payment(loan_id, body.payment_amount, token)
