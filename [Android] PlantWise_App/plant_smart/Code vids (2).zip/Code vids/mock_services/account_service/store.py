"""Singleton store for the three in-process mock APIs.

The FastAPI routes call these functions instead of constructing the
mocks themselves; this guarantees a single shared state across the
running service. Seeded once on startup from
``demo_data/accounts.json`` (whatever ``settings.auth_demo_accounts_path``
points at) and from the standard preloaded test accounts.
"""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Any

from config import settings
from mock_services.inprocess.account_api import (
    AccountRecord,
    Beneficiary,
    MockAccountAPI,
    create_mock_account_api,
)
from mock_services.inprocess.disbursement_api import MockDisbursementAPI
from mock_services.inprocess.loan_api import MockLoanAPI

_log = logging.getLogger("mock_services.account_service")

_LOCK = threading.Lock()
_account_api: MockAccountAPI | None = None
_loan_api: MockLoanAPI | None = None
_disbursement_api: MockDisbursementAPI | None = None


def account_api() -> MockAccountAPI:
    global _account_api
    if _account_api is None:
        _bootstrap()
    assert _account_api is not None
    return _account_api


def loan_api() -> MockLoanAPI:
    global _loan_api
    if _loan_api is None:
        _bootstrap()
    assert _loan_api is not None
    return _loan_api


def disbursement_api() -> MockDisbursementAPI:
    global _disbursement_api
    if _disbursement_api is None:
        _bootstrap()
    assert _disbursement_api is not None
    return _disbursement_api


def reset() -> None:
    """Clear all state. Used by tests."""
    global _account_api, _loan_api, _disbursement_api
    with _LOCK:
        _account_api = None
        _loan_api = None
        _disbursement_api = None


def _bootstrap() -> None:
    """Initialise singletons. Idempotent."""
    global _account_api, _loan_api, _disbursement_api
    with _LOCK:
        if _account_api is not None:
            return
        _account_api = create_mock_account_api(preload=True)
        _loan_api = MockLoanAPI()
        _disbursement_api = MockDisbursementAPI()
        try:
            seeded = seed_from_demo_data(_account_api)
            _log.info("mock_account_service.seeded users=%d", seeded)
        except Exception:  # pragma: no cover - demo seeding must never crash boot
            _log.exception("mock_account_service.seed_failed")


def seed_from_demo_data(api: MockAccountAPI) -> int:
    """Seed the account API from ``settings.auth_demo_accounts_path``.

    Generalised version of the helper found in
    ``tests/e2e/test_balance_inquiry_e2e.py``; reads every account in
    every demo user's ``account_context.accounts`` map and pushes a
    matching ``AccountRecord`` into the in-memory mock so that the demo
    JSON becomes the source of truth for the running service.

    Returns the number of users for which at least one account was seeded.
    """
    path = Path(settings.auth_demo_accounts_path)
    if not path.is_file():
        _log.warning("mock_account_service.seed_skipped path=%s missing", path)
        return 0

    raw = json.loads(path.read_text(encoding="utf-8"))
    seeded_users = 0

    for user_id, user in raw.items():
        ctx = (user or {}).get("account_context") or {}
        accounts = ctx.get("accounts") or {}
        if not accounts:
            continue

        owner_age = float(ctx.get("owner_age_years", 40))
        owner_dob = str(ctx.get("owner_dob") or "1985-01-01")
        owner_name = str(user.get("display_name") or user_id)

        for atype, acct in accounts.items():
            number = (acct or {}).get("account_number")
            if not number:
                continue

            vested = float(acct.get("vested_balance", 0.0))
            total = float(acct.get("total_balance", vested))
            unvested = float(acct.get("unvested_balance", max(total - vested, 0.0)))

            api.seed_account(AccountRecord(
                account_number=number,
                account_type=str(acct.get("account_type") or atype),
                owner_name=owner_name,
                owner_age_years=owner_age,
                owner_dob=owner_dob,
                total_balance=total,
                vested_balance=vested,
                unvested_balance=unvested,
                prior_year_end_balance=float(
                    acct.get("prior_year_end_balance", total)
                ),
                ytd_contributions=float(acct.get("ytd_contributions", 0.0)),
                ytd_employer_match=float(acct.get("ytd_employer_match", 0.0)),
                annual_match_max=float(acct.get("annual_match_max", 0.0)),
                outstanding_loan_balance=float(
                    acct.get("outstanding_loan_balance", 0.0)
                ),
                highest_loan_balance_12m=float(
                    acct.get("highest_loan_balance_12m", 0.0)
                ),
                plan_name=str(acct.get("plan_name") or "Demo Plan"),
                plan_allows_loans=bool(acct.get("plan_allows_loans", True)),
                beneficiaries=_parse_beneficiaries(acct.get("beneficiaries")),
            ))
        seeded_users += 1

    return seeded_users


def _parse_beneficiaries(raw: Any) -> list[Beneficiary]:
    if not isinstance(raw, list):
        return []
    out: list[Beneficiary] = []
    for b in raw:
        if not isinstance(b, dict):
            continue
        try:
            out.append(Beneficiary(
                name=str(b["name"]),
                relationship=str(b.get("relationship", "OTHER")),
                percentage=float(b["percentage"]),
                beneficiary_type=str(b.get("beneficiary_type", "PRIMARY")),
                date_of_birth=b.get("date_of_birth"),
                ssn_last4=b.get("ssn_last4"),
            ))
        except (KeyError, TypeError, ValueError):
            continue
    return out
