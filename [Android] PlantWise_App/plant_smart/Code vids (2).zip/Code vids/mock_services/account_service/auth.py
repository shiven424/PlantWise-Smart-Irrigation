"""Bearer-token authentication for the mock service.

Reuses the same JWT signing key/algorithm as the agent app so a token
issued by ``/auth/login`` works against this service unchanged.
"""

from __future__ import annotations

from fastapi import Header, HTTPException, status

from auth.jwt_utils import InvalidTokenError, decode_token


_BEARER = "Bearer "


def bearer_token(authorization: str | None = Header(default=None)) -> str:
    """Extract the raw JWT from the ``Authorization`` header.

    The raw token (not the user_id) is returned because the in-process
    mock APIs require ``auth_token`` as a non-empty string and we want
    to forward the original credential unchanged.
    """
    if not authorization or not authorization.startswith(_BEARER):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error_code": "MISSING_TOKEN", "message": "Bearer token required"},
            headers={"WWW-Authenticate": "Bearer"},
        )
    return authorization[len(_BEARER):].strip()


def current_user(token: str) -> str:
    """Decode the bearer token and return the ``user_id`` (subject).

    Used as a FastAPI dependency::

        def route(user_id: str = Depends(authenticated_user)):
            ...
    """
    try:
        return decode_token(token)
    except InvalidTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error_code": "INVALID_TOKEN", "message": str(exc)},
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


def authenticated_user(token: str = Header(default=None, alias="Authorization")) -> tuple[str, str]:
    """Combined dependency returning ``(token, user_id)`` for routes.

    Most routes need both the raw token (to forward into the in-process
    mock) and the resolved user_id (for ownership checks/logging).
    """
    raw = bearer_token(token)
    return raw, current_user(raw)


# Future: assert_user_owns_account(user_id, account_number) — the
# in-process mocks do not enforce per-user ownership today, so we
# stub a no-op here. Switch to a real check when adding multi-tenant
# isolation to the demo.
def assert_user_owns_account(user_id: str, account_number: str) -> None:  # noqa: ARG001
    return None
