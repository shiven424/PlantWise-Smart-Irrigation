"""Mock account / loan / disbursement HTTP service.

A thin FastAPI app that exposes the exact method surface of the
in-process mocks at ``mock_services.inprocess.*`` over HTTP, so the
agent code can be wired against an out-of-process backend without
changing any tool logic.

Run locally::

    python -m mock_services.account_service

Then point the agent at it with::

    TOOL_API_PROVIDER=http \\
    ACCOUNT_API_BASE_URL=http://localhost:8081 \\
    python main.py
"""
