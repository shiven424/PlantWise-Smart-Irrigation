"""Map in-process mock exceptions to HTTP responses.

The HTTP client in ``tools.clients.http`` re-raises the original
exception class based on the ``error_code`` field, so tool code
keeps catching the same exceptions whether the backend is in-process
or HTTP.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from mock_services.inprocess.account_api import (
    AccountFrozenError,
    AccountNotFoundError,
    AuthorizationError as AccountAuthError,
    InsufficientBalanceError,
)
from mock_services.inprocess.disbursement_api import (
    AuthorizationError as DisbAuthError,
    DisbursementRejectedError,
    DuplicateRequestError,
    InvalidRoutingNumberError,
)
from mock_services.inprocess.loan_api import (
    AuthorizationError as LoanAuthError,
    DuplicateLoanError,
    LoanNotFoundError,
    LoanRejectedError,
    PlanDoesNotAllowLoansError,
)


_log = logging.getLogger("mock_services.account_service.errors")


# (status_code, error_code) per exception class.
_MAP: dict[type[Exception], tuple[int, str]] = {
    AccountAuthError: (status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED"),
    DisbAuthError: (status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED"),
    LoanAuthError: (status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED"),
    AccountNotFoundError: (status.HTTP_404_NOT_FOUND, "ACCOUNT_NOT_FOUND"),
    LoanNotFoundError: (status.HTTP_404_NOT_FOUND, "LOAN_NOT_FOUND"),
    AccountFrozenError: (423, "ACCOUNT_FROZEN"),
    InsufficientBalanceError: (
        status.HTTP_422_UNPROCESSABLE_ENTITY, "INSUFFICIENT_BALANCE",
    ),
    InvalidRoutingNumberError: (
        status.HTTP_400_BAD_REQUEST, "INVALID_ROUTING_NUMBER",
    ),
    DuplicateRequestError: (status.HTTP_409_CONFLICT, "DUPLICATE_REQUEST"),
    DuplicateLoanError: (status.HTTP_409_CONFLICT, "DUPLICATE_LOAN"),
    PlanDoesNotAllowLoansError: (
        status.HTTP_422_UNPROCESSABLE_ENTITY, "PLAN_DISALLOWS_LOANS",
    ),
    LoanRejectedError: (status.HTTP_422_UNPROCESSABLE_ENTITY, "LOAN_REJECTED"),
    DisbursementRejectedError: (
        status.HTTP_422_UNPROCESSABLE_ENTITY, "DISBURSEMENT_REJECTED",
    ),
    ValueError: (status.HTTP_400_BAD_REQUEST, "VALIDATION_ERROR"),
}


def _envelope(error_code: str, message: str, trace_id: str) -> dict[str, Any]:
    return {"error_code": error_code, "message": message, "trace_id": trace_id}


def _trace_id(request: Request) -> str:
    return request.headers.get("x-trace-id") or uuid.uuid4().hex


def _make_handler(http_status: int, code: str):
    async def _h(request: Request, exc: Exception) -> JSONResponse:
        trace = _trace_id(request)
        if http_status >= 500:
            _log.exception(
                "mock_account_service.error code=%s trace=%s", code, trace,
            )
        else:
            _log.info(
                "mock_account_service.error code=%s trace=%s msg=%s",
                code, trace, exc,
            )
        return JSONResponse(
            status_code=http_status,
            content=_envelope(code, str(exc), trace),
            headers={"X-Trace-Id": trace},
        )
    return _h


def install_exception_handlers(app: FastAPI) -> None:
    """Register a per-exception-class handler for every mapped error.

    Registering specific subclasses rather than ``Exception`` ensures
    Starlette's exception middleware treats them as handled (so they
    don't propagate into the test client / ASGI transport).
    """
    for cls, (http_status, code) in _MAP.items():
        app.add_exception_handler(cls, _make_handler(http_status, code))
