"""Pydantic request/response schemas for the mock account service.

Field names mirror the dict keys returned by the in-process mocks
verbatim, so HTTP responses are drop-in compatible — the HTTP client
in ``tools.clients.http`` simply calls ``response.json()`` and
returns it to the tool unchanged.

Currency uses ``float`` (matching the in-process mocks). Pydantic
validators reject NaN/Inf at the boundary because tools rely
on numeric comparisons that silently misbehave on those values.
"""

from __future__ import annotations

import math
from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ---------------------------------------------------------------------------
# Common
# ---------------------------------------------------------------------------

class ErrorEnvelope(BaseModel):
    error_code: str
    message: str
    trace_id: str


def _reject_nonfinite(v: float) -> float:
    if math.isnan(v) or math.isinf(v):
        raise ValueError("must be a finite number")
    return v


Money = Annotated[float, Field(ge=0)]


# ---------------------------------------------------------------------------
# Accounts
# ---------------------------------------------------------------------------

class BalanceResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    total_balance: float
    vested_balance: float
    unvested_balance: float
    ytd_contributions: float
    ytd_employer_match: float
    annual_match_max: float
    outstanding_loan_balance: float
    account_type: str
    plan_name: str
    as_of: str


class PriorYearEndBalanceResponse(BaseModel):
    prior_year_end_balance: float
    tax_year: int
    account_type: str
    owner_age_years: float


class AccountDetailsResponse(BaseModel):
    account_number_last4: str
    account_type: str
    owner_name: str
    owner_age_years: float
    is_active: bool
    total_balance: float
    vested_balance: float
    outstanding_loan_balance: float
    highest_loan_balance_12m: float
    account_age_days: int
    plan_name: str
    plan_allows_loans: bool
    plan_allows_hardship: bool
    plan_allows_rollovers_in: bool


class BeneficiaryDTO(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    relationship: str = Field(default="OTHER", max_length=50)
    percentage: float = Field(ge=0, le=100)
    beneficiary_type: str = Field(default="PRIMARY", pattern="^(PRIMARY|CONTINGENT)$")
    date_of_birth: str | None = None
    ssn_last4: str | None = None

    @field_validator("percentage")
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class GetBeneficiariesResponse(BaseModel):
    beneficiaries: list[dict[str, Any]]
    total_primary_pct: float
    total_contingent_pct: float
    count: int


class UpdateBeneficiariesRequest(BaseModel):
    beneficiaries: list[BeneficiaryDTO] = Field(min_length=1, max_length=20)


class UpdateBeneficiariesResponse(BaseModel):
    confirmation_number: str
    beneficiary_count: int
    effective_date: str
    status: str


# ---------------------------------------------------------------------------
# Rollover
# ---------------------------------------------------------------------------

class RolloverRequest(BaseModel):
    destination_account: str = Field(min_length=1, max_length=64)
    amount: float = Field(gt=0)
    rollover_type: str = Field(pattern="^(DIRECT|INDIRECT)$")

    @field_validator("amount")
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class RolloverResponse(BaseModel):
    confirmation_number: str
    source_account_last4: str
    destination_account_last4: str
    amount: float
    rollover_type: str
    estimated_completion_days: int
    status: str
    initiated_at: str


# ---------------------------------------------------------------------------
# Loans
# ---------------------------------------------------------------------------

class LoanEligibilityRequest(BaseModel):
    account_number: str = Field(min_length=1, max_length=64)
    vested_balance: float = Field(ge=0)
    outstanding_loan_balance: float = Field(ge=0)
    highest_loan_balance_12m: float = Field(ge=0)
    plan_allows_loans: bool

    @field_validator(
        "vested_balance",
        "outstanding_loan_balance",
        "highest_loan_balance_12m",
    )
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class LoanEligibilityResponse(BaseModel):
    eligible: bool
    max_loan_amount: float
    vested_balance: float
    irc_72p_limit: float
    net_limit: float
    highest_loan_balance_12m: float
    outstanding_loan_balance: float
    plan_allows_loans: bool
    rejection_reason: str | None = None


class LoanInitiateRequest(BaseModel):
    account_number: str = Field(min_length=1, max_length=64)
    amount: float = Field(gt=0)
    term_months: int = Field(ge=1, le=360)
    loan_type: str = Field(
        default="GENERAL_PURPOSE",
        pattern="^(GENERAL_PURPOSE|PRIMARY_RESIDENCE)$",
    )
    interest_rate: float | None = Field(default=None, ge=0, le=0.20)
    vested_balance: float = Field(default=0.0, ge=0)
    outstanding_loan_balance: float = Field(default=0.0, ge=0)
    highest_loan_balance_12m: float = Field(default=0.0, ge=0)
    plan_allows_loans: bool = True

    @field_validator("amount", "vested_balance",
                     "outstanding_loan_balance", "highest_loan_balance_12m")
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class LoanInitiateResponse(BaseModel):
    loan_id: str
    confirmation_number: str
    principal_amount: float
    interest_rate: float
    term_months: int
    monthly_payment: float
    first_payment_date: str
    maturity_date: str
    total_interest: float
    total_repayment: float
    status: str
    originated_at: str


class LoanStatusResponse(BaseModel):
    loan_id: str
    loan_type: str
    principal_amount: float
    outstanding_balance: float
    monthly_payment: float
    interest_rate: float
    term_months: int
    payments_made: int
    payments_remaining: int
    first_payment_date: str
    maturity_date: str
    status: str


class LoanPaymentRequest(BaseModel):
    payment_amount: float = Field(gt=0)


class LoanPaymentResponse(BaseModel):
    loan_id: str
    payment_applied: float
    interest_portion: float
    principal_portion: float
    new_outstanding_balance: float
    payments_made: int
    status: str


# ---------------------------------------------------------------------------
# Disbursements
# ---------------------------------------------------------------------------

class _DisbursementCommon(BaseModel):
    account_number: str = Field(min_length=1, max_length=64)
    amount: float = Field(gt=0)
    disbursement_type: str = Field(
        default="WITHDRAWAL",
        pattern="^(WITHDRAWAL|RMD|ROLLOVER_DISTRIBUTION|HARDSHIP)$",
    )
    owner_age: float = Field(default=60.0, ge=0, le=130)
    custom_withholding_rate: float | None = Field(default=None, ge=0, le=1)

    @field_validator("amount", "owner_age")
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class AchDisbursementRequest(_DisbursementCommon):
    bank_routing_number: str = Field(min_length=9, max_length=9)
    bank_account_number: str = Field(min_length=1, max_length=34)
    state_withholding_rate: float = Field(default=0.0, ge=0, le=1)


class WireDisbursementRequest(_DisbursementCommon):
    bank_routing_number: str = Field(min_length=9, max_length=9)
    bank_account_number: str = Field(min_length=1, max_length=34)


class CheckDisbursementRequest(_DisbursementCommon):
    mailing_address: str = Field(min_length=5, max_length=500)


class RmdDisbursementRequest(BaseModel):
    account_number: str = Field(min_length=1, max_length=64)
    bank_routing_number: str = Field(min_length=9, max_length=9)
    bank_account_number: str = Field(min_length=1, max_length=34)
    rmd_amount: float = Field(gt=0)
    owner_age: float = Field(ge=0, le=130)
    custom_withholding_rate: float | None = Field(default=None, ge=0, le=1)

    @field_validator("rmd_amount", "owner_age")
    @classmethod
    def _finite(cls, v: float) -> float:
        return _reject_nonfinite(v)


class DisbursementResponse(BaseModel):
    model_config = ConfigDict(extra="allow")  # RMD adds rmd_amount + tax_year
    transaction_id: str
    confirmation_number: str
    gross_amount: float
    federal_withholding: float
    state_withholding: float
    early_withdrawal_penalty: float
    net_disbursement: float
    delivery_method: str
    estimated_arrival_days: int
    status: str
    submitted_at: str
