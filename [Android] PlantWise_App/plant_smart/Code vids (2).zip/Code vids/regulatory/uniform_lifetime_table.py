"""Uniform Lifetime Table for Required Minimum Distributions (RMDs).
Source: https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-required-minimum-distributions#lifetable
Used to calculate RMD amounts based on the account owner's age.
Note: RMDs are required starting at age 73 per SECURE Act 2.0 (rising to 75 in 2033). The table includes ages 72-120 for convenience, but RMDs are not required before 73.
"""

UNIFORM_LIFETIME_TABLE: dict[int, float] = {
    72: 27.4,
    73: 26.5,
    74: 25.5,
    75: 24.6,
    76: 23.7,
    77: 22.9,
    78: 22.0,
    79: 21.1,
    80: 20.2,
    81: 19.4,
    82: 18.5,
    83: 17.7,
    84: 16.8,
    85: 16.0,
    86: 15.2,
    87: 14.4,
    88: 13.7,
    89: 12.9,
    90: 12.2,
    91: 11.5,
    92: 10.8,
    93: 10.1,
    94: 9.5,
    95: 8.9,
    96: 8.4,
    97: 7.8,
    98: 7.3,
    99: 6.8,
    100: 6.4,
    101: 6.0,
    102: 5.6,
    103: 5.2,
    104: 4.9,
    105: 4.5,
    106: 4.2,
    107: 3.9,
    108: 3.7,
    109: 3.4,
    110: 3.1,
    111: 2.9,
    112: 2.6,
    113: 2.4,
    114: 2.1,
    115: 1.9,
    116: 1.7,
    117: 1.5,
    118: 1.3,
    119: 1.1,
    120: 0.9,
}

_RMD_START_AGE = 73  # per SECURE Act 2.0 - rises to 75 in 2033

def get_distribution_period(owner_age: int | float) -> float:
    """Return the distribution period from the Uniform Lifetime Table for a given age."""
    age = int(owner_age)

    if owner_age < _RMD_START_AGE:
        raise ValueError(f"RMDs not required before age {_RMD_START_AGE}.")
    
    age = min(age, 120)  # cap at max age in table
    return UNIFORM_LIFETIME_TABLE[age]