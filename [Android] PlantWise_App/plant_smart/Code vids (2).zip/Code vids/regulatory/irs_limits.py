"""
IRS regulatory limits - update annually in January.

Sources:
    IRS Rev. Proc. 2023-34   (2024 contribution/benefit limits)
    IRS Notice 2023-75       (2024 retirement plan limits)
    SECURE Act 2.0 (2022)    (RMD age change, penalty reduction)

All dollar amounts are in whole dollars unless the key ends in _CENTS.
All rates are decimal fractions (0.10 = 10%).
"""

# Tax Year 2025 - update this block each January
# Note: 2025 limits per IRS Notice 2024-80
IRS_LIMITS: dict = {
    # -- 401(k) / 403(b) / 457(b) ------------------------------------------
    "401K_CONTRIBUTION_LIMIT": 23_500,   # IRC 402(g) - employee elective deferral
    "401K_CATCHUP_LIMIT": 7_500,        # IRC 414(v) - age 50-59 and 64+ catch-up
    "401K_CATCHUP_LIMIT_60_63": 11_250, # IRC 414(v)(2)(B) - SECURE 2.0 super catch-up age 60-63
    "401K_TOTAL_LIMIT": 70_000,         # IRC 415(c) - employee + employer total additions
    "401K_LOAN_MAX": 50_000,            # IRC 72(p)(2)(A) - absolute ceiling
    "401K_LOAN_MAX_CENTS": 5_000_000,   # same in cents (used by tools)
    "401K_LOAN_MIN": 1_000,             # typical plan minimum

    # -- IRA ----------------------------------------------------------------
    "IRA_CONTRIBUTION_LIMIT": 7_000,    # IRC 219 - traditional & Roth combined
    "IRA_CATCHUP_LIMIT": 1_000,         # IRC 219(b)(5) - age 50+ catch-up (not COLA-indexed)

    # -- Compensation / HCE thresholds
    "COMPENSATION_LIMIT": 350_000,      # IRC 401(a)(17) - annual comp limit for plan purposes
    "HIGHLY_COMPENSATED_THRESHOLD": 160_000,  # IRC 414(q) - HCE definition threshold

    # -- RMD
    "RMD_START_AGE": 73,                # SECURE Act 2.0 §107 (was 72 before 2023; rises to 75 in 2033)
    "RMD_PENALTY_RATE": 0.25,           # IRC 4974 - excise tax on RMD shortfall (SECURE 2.0 reduced from 50%)
    "RMD_CORRECTION_PENALTY_RATE": 0.10,# IRC 4974(d) - corrected within 2-year correction window

    # -- Early withdrawal
    "EARLY_WITHDRAWAL_AGE": 59.5,       # IRC 72(t) - penalty-free threshold
    "EARLY_WITHDRAWAL_PENALTY": 0.10,   # IRC 72(t)(1) - 10% additional income tax

    # -- Federal withholding
    "ELIGIBLE_ROLLOVER_WITHHOLDING": 0.20,  # IRC 3405(c) - mandatory on eligible rollover distributions
    "NON_PERIODIC_WITHHOLDING": 0.10,       # IRC 3405(b) - default opt-out rate on non-periodic distributions

    # -- Social Security / FICA
    "SS_WAGE_BASE": 176_100,            # OASDI taxable wage base
    "SS_EMPLOYEE_RATE": 0.062,          # 6.2%
    "MEDICARE_ADDITIONAL_RATE": 0.009,  # 0.9% additional Medicare on wages > $200k single
}


def get_limit(key: str) -> int | float:
    """
    Retrieve a limit value by key. Raises KeyError with a helpful message
    if the key is not found (avoids silent use of 0 or None).
    """
    if key not in IRS_LIMITS:
        raise KeyError(
            f"IRS_LIMITS has no key {key!r}."
            f"Available keys: {sorted(IRS_LIMITS.keys())}"
        )
    return IRS_LIMITS[key]
