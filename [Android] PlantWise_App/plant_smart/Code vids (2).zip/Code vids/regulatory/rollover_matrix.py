"""
IRA / Retirement Plan Rollover Compatibility Matrix.

Source: IRS Publication 590-A (2024), Table 1 — "IRA Rollover Chart"
        IRS Publication 575 (2024) — Pension and Annuity Income
        IRS Rev. Rul. 2014-9 — direct rollover rules

Structure:
    ROLLOVER_MATRIX[(source_type, dest_type)] = {
        "allowed":     bool  — whether the rollover is permitted at all
        "direct_only": bool  — True means ONLY trustee-to-trustee (no 60-day indirect)
        "tax_event":   bool  — True = taxable (e.g. Roth conversion)
        "notes":       str   — optional regulatory clarification
    }

All type strings are UPPER_SNAKE_CASE and must match account_context["account_type"].
Unlisted combinations are NOT permitted — use check_rollover() which returns
{"allowed": False} for any unknown pair.
"""

from typing import TypedDict


class RolloverRule(TypedDict, total=False):
    allowed:     bool
    direct_only: bool
    tax_event:   bool
    notes:       str


ROLLOVER_MATRIX: dict[tuple[str, str], RolloverRule] = {
    # — Traditional IRA as source ——————————————————————————————————————————————
    ("TRADITIONAL_IRA", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("TRADITIONAL_IRA", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion — entire pre-tax amount is included in gross income",
    },
    ("TRADITIONAL_IRA", "401K"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Only pre-tax amounts; after-tax IRA basis cannot roll to 401k",
    },
    ("TRADITIONAL_IRA", "403B"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Only pre-tax amounts",
    },
    ("TRADITIONAL_IRA", "457B"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Governmental 457(b) only — tax-exempt 457(b) not eligible",
    },
    ("TRADITIONAL_IRA", "SIMPLE_IRA"): {
        "allowed": False,
        "notes": "Cannot roll traditional IRA into SIMPLE IRA",
    },

    # — Roth IRA as source ——————————————————————————————————————————————————————
    ("ROTH_IRA", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("ROTH_IRA", "ROTH_401K"): {
        "allowed": False,
        "notes": "IRS Pub 590-A Table 1: Roth IRA cannot roll into employer Roth accounts (401k/403b). Only Roth 401k → Roth IRA is permitted.",
    },
    ("ROTH_IRA", "ROTH_403B"): {
        "allowed": False,
        "notes": "IRS Pub 590-A Table 1: Roth IRA cannot roll into employer Roth accounts (401k/403b). Only Roth 403b → Roth IRA is permitted.",
    },
    ("ROTH_IRA", "TRADITIONAL_IRA"): {
        "allowed": False,
        "notes": "Cannot convert Roth back to traditional IRA",
    },
    ("ROTH_IRA", "401K"): {
        "allowed": False,
        "notes": "Roth IRA cannot roll into a traditional (pre-tax) 401k",
    },

    # — 401(k) as source ————————————————————————————————————————————————————————
    ("401K", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("401K", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion — entire pre-tax amount is taxable in year of rollover",
    },
    ("401K", "401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "New plan must accept incoming rollovers — verify plan document",
    },
    ("401K", "403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("401K", "457B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Governmental 457(b) only",
    },
    ("401K", "ROTH_401K"): {
        "allowed": True, "direct_only": True, "tax_event": True,
        "notes": "In-plan Roth conversion — taxable event",
    },
    ("401K", "SIMPLE_IRA"): {
        "allowed": False,
        "notes": "401k cannot roll into SIMPLE IRA",
    },

    # — Roth 401(k) as source ———————————————————————————————————————————————————
    ("ROTH_401K", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Basis carries over; holding period for 5-year Roth rule may restart",
    },
    ("ROTH_401K", "ROTH_401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("ROTH_401K", "ROTH_403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("ROTH_401K", "TRADITIONAL_IRA"): {
        "allowed": False,
        "notes": "Roth amounts cannot roll into a traditional (pre-tax) IRA",
    },

    # — 403(b) as source ————————————————————————————————————————————————————————
    ("403B", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("403B", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
    },
    ("403B", "401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("403B", "403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("403B", "457B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Governmental 457(b) only",
    },
    ("403B", "ROTH_403B"): {
        "allowed": True, "direct_only": True, "tax_event": True,
        "notes": "In-plan Roth conversion",
    },

    # — Roth 403(b) as source ———————————————————————————————————————————————————
    ("ROTH_403B", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("ROTH_403B", "ROTH_401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },

    # — 457(b) as source ————————————————————————————————————————————————————————
    ("457B", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Governmental 457(b) — tax-exempt 457(b) cannot roll over",
    },
    ("457B", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion",
    },
    ("457B", "401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("457B", "403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },

    # — SIMPLE IRA as source ————————————————————————————————————————————————————
    ("SIMPLE_IRA", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Only permitted after 2 years of SIMPLE IRA participation (IRC 408(d)(3)(G))",
    },
    ("SIMPLE_IRA", "SIMPLE_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("SIMPLE_IRA", "401K"): {
        "allowed": True, "direct_only": False, "tax_event": False,
        "notes": "Only after 2-year participation requirement is met",
    },
    ("SIMPLE_IRA", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion; 2-year participation requirement still applies",
    },

    # — SEP IRA as source ———————————————————————————————————————————————————————
    ("SEP_IRA", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("SEP_IRA", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion",
    },
    ("SEP_IRA", "401K"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("SEP_IRA", "403B"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("SEP_IRA", "SEP_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },

    # — Pension as source ———————————————————————————————————————————————————————
    ("PENSION", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("PENSION", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion — entire pre-tax amount is taxable",
    },
    ("PENSION", "401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Receiving plan must accept incoming rollovers",
    },
    ("PENSION", "403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },
    ("PENSION", "457B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Governmental 457(b) only",
    },

    # — Profit Sharing as source ————————————————————————————————————————————————
    ("PROFIT_SHARING", "TRADITIONAL_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": False,
    },
    ("PROFIT_SHARING", "ROTH_IRA"): {
        "allowed": True, "direct_only": False, "tax_event": True,
        "notes": "Roth conversion",
    },
    ("PROFIT_SHARING", "401K"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Receiving plan must accept incoming rollovers",
    },
    ("PROFIT_SHARING", "403B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
    },

    # — Self-referencing transfers ———————————————————————————————————————————————
    ("457B", "457B"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Governmental 457(b) intra-plan transfer",
    },
    ("PENSION", "PENSION"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Direct trustee-to-trustee transfer between pension plans",
    },
    ("PROFIT_SHARING", "PROFIT_SHARING"): {
        "allowed": True, "direct_only": True, "tax_event": False,
        "notes": "Direct trustee-to-trustee transfer between profit-sharing plans",
    },
}


def check_rollover(source_type: str, dest_type: str) -> RolloverRule:
    """
    Look up rollover rules for a source → destination pair.

    Args:
        source_type: Account type of the distributing plan (e.g. "401K").
        dest_type:   Account type of the receiving plan (e.g. "TRADITIONAL_IRA").

    Returns:
        RolloverRule dict.  Always contains "allowed" key.
        Returns {"allowed": False, "notes": "..."} for unlisted combinations.
    """
    key = (source_type.upper(), dest_type.upper())
    rule = ROLLOVER_MATRIX.get(
        key,
        {"allowed": False, "notes": "Not a recognised rollover combination per IRS Publication 590-A"},
    )

    # Fix M19: Tax-exempt 457(b) plans have more restrictive rollover
    # rules than governmental 457(b).  The matrix entries marked
    # "Governmental 457(b) only" must be blocked for tax-exempt plans.
    # Callers should pass "TAX_EXEMPT_457B" to distinguish; but if
    # they pass "457B" with no subtype, the notes are informational
    # only — the matrix assumes governmental by default.
    if source_type.upper() == "TAX_EXEMPT_457B" or dest_type.upper() == "TAX_EXEMPT_457B":
        return {
            "allowed": False,
            "notes": (
                "Tax-exempt 457(b) plans have restricted rollover options. "
                "Only trustee-to-trustee transfers to another tax-exempt "
                "457(b) are permitted. Contact a plan specialist."
            ),
        }

    return rule
