from __future__ import annotations

"""
Tool 1 — Account Balance Inquiry.

Reads validated_entities for the account_number (when present) or
falls back to ``account_context`` from the authenticated user's profile,
dereferences the vault token, calls the account API, and returns
a balance summary as transaction_result.

Taxonomy intent: ACCOUNT_BALANCE_INQUIRY
Required slots: (none — operates on the user's single account_context)
Auth level: STRONG
Router mapping: balance_inquiry

Write-ownership:
    transaction_result  — balance summary dict
    tool_exec           — execution lifecycle state
"""

from datetime import datetime, timezone
from typing import ClassVar

from tools.base import BaseTool
from schemas.enums import AuthLevel, ToolExecutionStatus
from schemas.primitives import EntityRecord, ToolExecutionState
from tools._account_resolution import (
    account_detection_scan_text,
    detect_requested_account_types,
    looks_like_fresh_balance_request,
    resolve_account_type_alias,
)
from vault.dereferencer import dereference_entity
from observability.logger import log


class BalanceInquiryTool(BaseTool):
    name: ClassVar[str] = "balance_inquiry"
    version: ClassVar[str] = "1.0.0"

    description: ClassVar[str] = (
        "Read-only inquiry that returns the balance, vesting, and "
        "YTD-contribution summary for a single retirement / brokerage "
        "account owned by the authenticated user."
    )
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = False
    input_schema: ClassVar[dict] = {
        "account_type": {
            "type": "string",
            "required": False,
            "description": "Canonical account type (401K, ROTH_IRA, ...). "
                           "Optional for single-account users.",
        },
    }

    # Read-only inquiry: a single-account user can have their balance
    # resolved purely from account_context (no entity required).  execute()
    # already implements that fallback path and returns a graceful failure
    # for multi-account users with no account_type slot, so it is safe to
    # bypass the strict empty-validated_entities gate here.
    allow_empty_validated_entities: ClassVar[bool] = True

    def execute(
        self,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        last_user_message: str = "",
        recent_user_queries_text: str = "",
        current_turn: int = 0,
    ) -> dict:
        """
        Fetch balance data from the account API.

        Steps:
            1. Resolve account_number — dereference vault token if PII,
               or fall back to account_context for the raw number.
            2. Call account API get_balance().
            3. Compute derived values (vested %, match remaining).
            4. Scrub raw PII from local scope.
            5. Return transaction_result + tool_exec.

        last_user_message / recent_user_queries_text / current_turn are forwarded
        by ``invoke_tool`` and used to (a) detect stale carried-over account_type
        slots (_current_ utterance only) and (b) detect requests for multiple
        accounts ("all my balances", "401k and IRA balance"), including wording
        from earlier turns when the execute turn is only an auth artifact.
        """
        now = datetime.now(timezone.utc)
        accounts_map: dict = account_context.get("accounts") or {}
        is_multi_account_user = len(accounts_map) > 1

        # — Detect requested account types from recent user lines + current text.
        # Returns:
        #   ["ALL"] when the user asked for all/every account
        #   list of canonical keys when the message names specific types
        #   None    when the message contains no account-type tokens
        scan_for_accounts = account_detection_scan_text(
            recent_user_queries_text,
            last_user_message,
        )
        msg_requested = detect_requested_account_types(
            scan_for_accounts,
            accounts_map,
        )

        # ─── Multi-account branch ────────────────────────────────────────────
        # Triggered only when the user explicitly named >1 type or "all".
        # Single-account users still fall through the normal single path.
        if msg_requested and (msg_requested == ["ALL"] or len(msg_requested) > 1):
            return self._process_multi_balance(
                msg_requested, accounts_map, account_context, auth_token, now,
            )

        # — Step 1: Resolve account number
        # Resolution order:
        #   1. Vault-tokenised account_number entity (multi-account user
        #      explicitly identified the account by number)
        #   2. Explicit account_type token in the *current* message (most
        #      recent user intent — preferred over carried-over slot)
        #   3. account_type entity from validated_entities — but only when
        #      the slot is "fresh".  For multi-account users we treat a
        #      slot as STALE (and force re-collection) when the current
        #      user utterance contains no account-type token at all.  This
        #      prevents the LLM-extractor from silently re-binding a prior
        #      turn's account_type to a bare "what's my balance?" follow-up.
        #   4. account_context.accounts has exactly one entry → auto-pick
        #   5. Legacy flat account_context["account_number"]
        account_entity = validated_entities.get("account_number")
        raw_account_number: str | None = None
        selected_account: dict | None = None

        if account_entity and account_entity.vault_token:
            try:
                raw_account_number = dereference_entity(account_entity, auth_token)
            except (KeyError, PermissionError) as exc:
                log.error("balance_inquiry_vault_dereference_failed", error=str(exc))
                return self._failure("Unable to verify account identity", now)
        else:
            requested_type: str | None = None

            # Resolution priority:
            #   1. LLM-extracted account_type slot (handles negation
            #      and natural-language disambiguation correctly).
            #   2. Single explicit token in the *current* user message
            #      (only when the LLM slot is missing).
            acct_type_entity = validated_entities.get("account_type")
            slot_value = (
                getattr(acct_type_entity, "display_value", None)
                if acct_type_entity else None
            )
            if slot_value:
                # Stale-slot guard for multi-account users.  Fires only
                # when the *current* message looks like a fresh balance
                # request AND contains no account-type token at all.
                # Auth-credential turns ("4321"), bare slot answers
                # ("brokerage"), and explicit-type asks all skip this.
                if (
                    is_multi_account_user
                    and last_user_message
                    and msg_requested is None
                    and looks_like_fresh_balance_request(last_user_message)
                ):
                    available = ", ".join(sorted(accounts_map.keys())) or "none"
                    log.info(
                        "balance_inquiry_stale_account_type_slot",
                        slot_value=slot_value,
                        current_turn=current_turn,
                        last_user_message=last_user_message[:80],
                    )
                    return self._failure(
                        "Please specify which account you'd like to check. "
                        f"You have {available} on file.",
                        now,
                    )
                requested_type = str(slot_value)
            elif (
                msg_requested
                and msg_requested != ["ALL"]
                and len(msg_requested) == 1
            ):
                requested_type = msg_requested[0]

            if requested_type and accounts_map:
                acct = accounts_map.get(
                    resolve_account_type_alias(requested_type, accounts_map)
                )
                if acct is None:
                    available = ", ".join(sorted(accounts_map.keys())) or "none"
                    log.warning(
                        "balance_inquiry_unknown_account_type",
                        requested=requested_type,
                        available=available,
                    )
                    return self._failure(
                        f"You don't have a {requested_type} account on file. "
                        f"Available accounts: {available}.",
                        now,
                    )
                selected_account = acct
                raw_account_number = acct.get("account_number")
            elif len(accounts_map) == 1:
                # Single-account user — auto-select.
                selected_account = next(iter(accounts_map.values()))
                raw_account_number = selected_account.get("account_number")
            elif account_context.get("account_number"):
                # Legacy flat shape (no nested accounts map).
                raw_account_number = account_context["account_number"]

        if not raw_account_number:
            log.error(
                "balance_inquiry_no_account",
                message="No account could be resolved from entities or account_context",
                accounts_count=len(accounts_map),
            )
            return self._failure("Missing account_number", now)

        # Fix C2: Wrap all PII usage in try/finally to guarantee scrubbing
        # even when an unexpected exception occurs mid-processing.
        try:
            return self._process_balance(
                raw_account_number, validated_entities, account_context,
                auth_token, now,
            )
        finally:
            # Ensure raw PII is always scrubbed from the local frame
            try:
                del raw_account_number
            except NameError:
                pass

    def _process_multi_balance(
        self,
        requested: list[str],
        accounts_map: dict,
        account_context: dict,
        auth_token: str,
        now: datetime,
    ) -> dict:
        """Resolve and fetch balances for multiple accounts in one turn.

        ``requested`` is either ["ALL"] (use every account on file) or a
        list of canonical account_type keys.  Per-account API failures are
        captured into the result rather than aborting the whole turn.
        """
        # Resolve target keys
        if requested == ["ALL"]:
            target_keys = sorted(accounts_map.keys())
        else:
            seen: set[str] = set()
            target_keys: list[str] = []
            for tok in requested:
                resolved = resolve_account_type_alias(tok, accounts_map)
                if resolved in accounts_map and resolved not in seen:
                    seen.add(resolved)
                    target_keys.append(resolved)

        if not target_keys:
            available = ", ".join(sorted(accounts_map.keys())) or "none"
            return self._failure(
                f"None of the accounts you mentioned are on file. "
                f"Available accounts: {available}.",
                now,
            )

        # Edge case: user asked for "all" but only has one account — degrade
        # gracefully to a single-balance result so the existing single-card
        # rendering is used (no UX change for single-account users).
        if requested == ["ALL"] and len(target_keys) == 1:
            only = accounts_map[target_keys[0]]
            raw = only.get("account_number")
            if not raw:
                return self._failure("Missing account_number", now)
            try:
                return self._process_balance(
                    raw, {}, account_context, auth_token, now,
                )
            finally:
                try:
                    del raw
                except NameError:
                    pass

        api = _get_account_api()
        per_account: list[dict] = []
        errors: list[str] = []
        combined_total = 0.0

        for key in target_keys:
            acct = accounts_map[key]
            raw = acct.get("account_number")
            if not raw:
                errors.append(f"{key}: missing account number")
                continue
            try:
                bd = api.get_balance(account_number=raw, auth_token=auth_token)
            except Exception as exc:
                log.error(
                    "balance_inquiry_multi_api_error",
                    account_type=key,
                    error=str(exc),
                )
                errors.append(f"{key}: {exc}")
                continue
            finally:
                # Scrub raw on every iteration
                try:
                    del raw
                except NameError:
                    pass

            total = bd.get("total_balance", 0.0)
            vested = bd.get("vested_balance", 0.0)
            if vested > total and total > 0:
                vested = total
            vested_pct = round((vested / total) * 100, 1) if total > 0 else 0.0
            account_no = acct.get("account_number", "")
            display_account = f"****{account_no[-4:]}" if account_no else ""
            per_account.append({
                "account_type": bd.get("account_type") or key,
                "account_display": display_account,
                "plan_name": bd.get("plan_name", ""),
                "total_balance": total,
                "vested_balance": vested,
                "vested_percentage": vested_pct,
                "as_of": bd.get("as_of", now.isoformat()),
            })
            combined_total += float(total or 0.0)

        if not per_account:
            return self._failure(
                "Unable to retrieve any balances at this time. "
                + (errors[0] if errors else ""),
                now,
                escalate=True,
            )

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "BALANCE_INQUIRY_MULTI",
            "accounts": per_account,
            "account_count": len(per_account),
            "combined_total_balance": round(combined_total, 2),
            "as_of": now.isoformat(),
        }
        if errors:
            result["partial_errors"] = errors

        log.info(
            "balance_inquiry_multi_complete",
            account_count=len(per_account),
            combined_total=combined_total,
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    def _process_balance(
        self,
        raw_account_number: str,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        now: datetime,
    ) -> dict:
        """Inner logic after account number is resolved. PII scrubbing
        is handled by the caller's ``finally`` block."""
        # — Step 2: Call account API
        try:
            api = _get_account_api()
            balance_data = api.get_balance(
                account_number=raw_account_number,
                auth_token=auth_token,
            )
        except Exception as exc:
            log.error(
                "balance_inquiry_api_error",
                error=str(exc),
            )
            return self._failure(str(exc), now, escalate=True)

        # — Step 3: Compute derived values
        total = balance_data.get("total_balance", 0.0)
        vested = balance_data.get("vested_balance", 0.0)

        # M2: Clamp vested to total if API returns inconsistent data
        if vested > total and total > 0:
            log.warning(
                "balance_inquiry_vested_exceeds_total",
                vested=vested,
                total=total,
            )
            vested = total

        vested_pct = round((vested / total) * 100, 1) if total > 0 else 0.0
        match_max = balance_data.get("annual_match_max", 0.0)
        match_ytd = balance_data.get("ytd_employer_match", 0.0)
        match_remaining = round(max(match_max - match_ytd, 0.0), 2)

        display_account = f"****{raw_account_number[-4:]}"

        # — Step 5: Return result
        # Determine account_type from entity or API response
        account_type = balance_data.get("account_type", "")
        acct_type_entity = validated_entities.get("account_type")
        if acct_type_entity and acct_type_entity.display_value:
            account_type = acct_type_entity.display_value

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "BALANCE_INQUIRY",
            "account_display": display_account,
            "account_type": account_type,
            "plan_name": balance_data.get("plan_name", ""),
            "total_balance": total,
            "vested_balance": vested,
            "unvested_balance": balance_data.get("unvested_balance", 0.0),
            "vested_percentage": vested_pct,
            "ytd_contributions": balance_data.get("ytd_contributions", 0.0),
            "ytd_employer_match": match_ytd,
            "employer_match_remaining": match_remaining,
            "outstanding_loan_balance": balance_data.get(
                "outstanding_loan_balance", 0.0
            ),
            "as_of": balance_data.get("as_of", now.isoformat()),
        }

        log.info(
            "balance_inquiry_complete",
            account_display=display_account,
            total_balance=total,
            vested_balance=vested,
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    def _failure(self, message: str, now: datetime, *, escalate: bool = False) -> dict:
        """Build a standardized failure response.

        Args:
            escalate: True for system/API errors that need human intervention.
            False for user-input validation failures that can be
            re-collected through the normal slot-filling flow.
        """
        log.warning("balance_inquiry_failed", reason=message, escalate=escalate)
        return {
            "transaction_result": {
                "success": False,
                "status": "FAILED",
                "operation": "BALANCE_INQUIRY",
                "errors": [message],
            },
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.FAILED,
                error_message=message,
                last_updated_at=now,
            ),
            "escalation_requested": escalate,
        }

    def health_check(self) -> bool:
        return True


# — Module-level lazy singleton for the account API ——————————
# In production this would be a real REST/gRPC client.
# For now we use the mock; swap by changing _get_account_api().

import threading as _threading

_account_api_instance = None
_account_api_lock = _threading.Lock()

def _get_account_api():
    global _account_api_instance
    if _account_api_instance is not None:
        return _account_api_instance
    with _account_api_lock:
        if _account_api_instance is None:
            from tools.api_factory import create_account_api
            _account_api_instance = create_account_api()
    return _account_api_instance


def set_account_api(api) -> None:
    """Test helper: inject a pre-seeded MockAccountAPI."""
    global _account_api_instance
    _account_api_instance = api
