from __future__ import annotations

from abc import abstractmethod
from typing import Any, ClassVar

from agents.base import BaseAgent
from observability.tracer import trace_agent
from schemas.enums import AuthLevel
from schemas.primitives import EntityRecord
from tools.invoker import invoke_tool


class BaseTool(BaseAgent):
    """
    Every transactional tool MUST inherit from this class.

    Security contract:
    - run() is CONCRETE - it delegates to ``tools.invoker.invoke_tool`` which
      enforces the validated_entities gate and the auth-level gate before
      calling execute(). Tools MUST NOT override run().
    - execute() is ABSTRACT - tools implement this with their actual
      tool/API logic.

    Critical invariants enforced by the invoker:
    - Reads ONLY from validated_entities, never from entity_memory directly.
    - Raises RuntimeError (not silently fails) if validated_entities is empty,
      UNLESS the subclass opts in via ``allow_empty_validated_entities = True``
      (used by read-only inquiries that can resolve everything from
      account_context, e.g. a single-account user's balance lookup).
    - Raises RuntimeError if ``state["auth_state"].current_level`` is below the
      tool's declared ``required_auth_level``.  This is defense-in-depth -
      the supervisor's H3 hard rule should normally block under-authenticated
      tool invocations long before reaching the invoker.
    - Passes account_context and auth_token as explicit parameters so tools
      cannot accidentally touch other state fields.
    - Generates a stable idempotency_key from (conversation_id, turn, intent_id,
      agent_name) and stores it in state for tools to use.

    Descriptor fields (declared per-tool, advertised via the registry):
        description           - one-line human-readable purpose
        required_auth_level   - minimum AuthLevel for invocation
        requires_hitl         - True if this tool performs a state-changing
                                operation that must be confirmed via HITL
        input_schema          - optional JSON-schema-like dict describing
                                the validated_entities the tool consumes
    """

    # Opt-in: when True, the invoker will NOT raise on empty validated_entities.
    # The tool's execute() is then responsible for resolving its inputs
    # entirely from account_context (and returning a graceful failure if it
    # cannot).  Default False keeps the strict gate for write/transactional
    # tools.
    allow_empty_validated_entities: ClassVar[bool] = False

    # ---- Descriptor fields (concrete tools MUST override description /
    # required_auth_level; requires_hitl + input_schema have safe defaults) ----
    description: ClassVar[str] = ""
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = False
    input_schema: ClassVar[dict[str, Any] | None] = None

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        # Skip descriptor checks for abstract intermediates.
        if getattr(cls, "__abstractmethods__", None):
            return
        if not getattr(cls, "description", "").strip():
            raise TypeError(
                f"Concrete tool '{cls.__name__}' must declare a non-empty "
                f"`description` ClassVar."
            )
        if not isinstance(getattr(cls, "required_auth_level", None), AuthLevel):
            raise TypeError(
                f"Concrete tool '{cls.__name__}' must declare "
                f"`required_auth_level: ClassVar[AuthLevel]`."
            )
        if not isinstance(getattr(cls, "requires_hitl", None), bool):
            raise TypeError(
                f"Concrete tool '{cls.__name__}' must declare "
                f"`requires_hitl: ClassVar[bool]`."
            )

    @abstractmethod
    def execute(
        self,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
    ) -> dict:
        """
        Execute the transactional operation.

        Parameters:
            validated_entities: ONLY source of entity data - never use entity_memory.
            account_context: Static account data for the session (from CRM/core).
            auth_token: Vault dereference token for the authenticated session.

        Returns:
            Partial state dict (e.g. {"transaction_result": {...}, "tool_exec": {...}})
        """

    @trace_agent("tool")
    def run(self, state: dict) -> dict:
        """Thin shim around :func:`tools.invoker.invoke_tool`.

        Tools MUST NOT override this method -- override execute() instead.
        All cross-cutting concerns (gate enforcement, idempotency, intent
        bookkeeping) live in the invoker.
        """
        return invoke_tool(self.name, state)
