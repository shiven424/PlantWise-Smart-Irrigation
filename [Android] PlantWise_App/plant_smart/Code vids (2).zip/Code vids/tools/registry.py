"""
Tool registry.

Same pattern as agents/registry.py but for transactional tools.
The graph builder reads exclusively from TOOL_REGISTRY.
"""

from __future__ import annotations

import importlib

from config import settings

_TOOL_CLASS_MAP: dict[str, str] = {
    "balance_inquiry": "BalanceInquiryTool",
    "transaction_history": "TransactionHistoryTool",
    "rmd_calculator": "RMDCalculatorTool",
    "plan_loan": "PlanLoanTool",
}


def _versioned_path(agent_name: str) -> str:
    version = settings.tool_versions.get(agent_name, "v1")
    return f"tools.{agent_name}.{version}.agent"


def _load_tool(agent_name: str, module_path: str):
    class_name = _TOOL_CLASS_MAP.get(agent_name)
    if not class_name:
        raise RuntimeError(
            f"No class name mapping for tool '{agent_name}' in _TOOL_CLASS_MAP."
        )
    try:
        module = importlib.import_module(module_path)
    except (ModuleNotFoundError, ImportError) as e:
        raise RuntimeError(
            f"Cannot import tool '{agent_name}' from '{module_path}'.\n"
            f" Error: {e}"
        ) from e
    try:
        cls = getattr(module, class_name)
    except AttributeError:
        raise RuntimeError(
            f"Module '{module_path}' has no class '{class_name}'.\n"
            f" Expected: class {class_name}(BaseTool)"
        )
    try:
        return cls()
    except Exception as e:
        raise RuntimeError(
            f"Cannot instantiate '{class_name}' from '{module_path}'.\n"
            f" Error: {e}"
        ) from e


def _build_registry() -> dict:
    """Lazy registry builder.

    Skips tools whose modules are empty or not yet implemented,
    allowing incremental development. Every skip is logged at WARNING
    level so that real bugs (e.g. syntax errors, bad imports) are visible
    in the build log and not silently hidden.
    """
    from observability.logger import log

    registry: dict = {}
    for agent_name in _TOOL_CLASS_MAP:
        module_path = _versioned_path(agent_name)
        try:
            registry[agent_name] = _load_tool(agent_name, module_path)
        except RuntimeError as exc:
            log.warning(
                "tool_registry_skip",
                agent=agent_name,
                module=module_path,
                reason=str(exc).split("\n")[0],  # first line only
            )
    return registry


TOOL_REGISTRY: dict = _build_registry()
