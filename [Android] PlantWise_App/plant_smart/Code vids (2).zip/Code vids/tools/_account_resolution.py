"""
Shared helpers for tools that resolve which account(s) to operate on.

Used by BalanceInquiryTool and TransactionHistoryTool so multi-account
disambiguation, "ALL" intents, stale-slot guards, and alias maps stay aligned.
"""

from __future__ import annotations

import re


# Aliases the LLM / user commonly produces for account_type that don't
# exactly match the canonical keys stored in account_context["accounts"].
ACCOUNT_TYPE_ALIASES: dict[str, tuple[str, ...]] = {
    "IRA": ("TRADITIONAL_IRA", "ROTH_IRA"),
    "TRADITIONAL": ("TRADITIONAL_IRA",),
    "ROTH": ("ROTH_IRA", "ROTH_401K"),
    "401_K": ("401K",),
    "403_B": ("403B",),
    "BROKERAGE_ACCOUNT": ("BROKERAGE",),
    "TAXABLE": ("BROKERAGE",),
}

_ACCOUNT_TYPE_TOKENS: tuple[tuple[str, str], ...] = (
    (r"401\s*\(\s*k\s*\)", "401K"),
    (r"\b401\s*[-_]?\s*k\b", "401K"),
    (r"403\s*\(\s*b\s*\)", "403B"),
    (r"\b403\s*[-_]?\s*b\b", "403B"),
    (r"\btraditional\s+ira\b", "TRADITIONAL_IRA"),
    (r"\broth\s+ira\b", "ROTH_IRA"),
    (r"\broth\s*401\s*[-_]?\s*k\b", "ROTH_401K"),
    (r"\bira\b", "IRA"),
    (r"\broth\b", "ROTH"),
    (r"\bbrokerage\b", "BROKERAGE"),
    (r"\btaxable\b", "TAXABLE"),
    (r"\bsep\b", "SEP_IRA"),
)

_ALL_ACCOUNTS_KEYWORDS = ("all", "every", "each")
_ALL_ACCOUNTS_NOUNS = ("balance", "balances", "account", "accounts", "my")

# Extra nouns for "every account" style asks in transaction-history flows only.
_HISTORY_ALL_NOUNS = (
    "transaction",
    "transactions",
    "history",
    "activity",
)

_STANDALONE_ALL_PATTERNS: tuple[str, ...] = (
    r"\ball\s+of\s+(them|the\s+(\w+\s+)?accounts|my\s+accounts)\b",
    r"\ball\s+(two|three|four|five|\d+)\b",
    r"\bevery(thing|\s+one|\s+account)\b",
    r"\beach\s+(one|account)\b",
    r"\bshow\s+them\s+all\b",
    r"\b(give\s+me|show\s+me)\s+all\b",
    r"^\s*all\s*\.?\s*$",
    r"^\s*everything\s*\.?\s*$",
)

_NEGATION_TOKENS = (
    " not ",
    "n't",
    " no ",
    " nor ",
    "instead of",
    "except",
    "skip ",
    "exclude",
    "rather than",
)

_CONJUNCTION_TOKENS = (" and ", " & ", ", ", " plus ")

_FRESH_BALANCE_REQUEST_KEYWORDS = (
    "balance",
    "account",
    "show",
    "how much",
    "what's",
    "what is",
    "tell me",
    "give me",
    "view",
    "see ",
    "check ",
    "look up",
    "look at",
)

_FRESH_TRANSACTION_REQUEST_KEYWORDS = (
    "transaction",
    "transactions",
    "history",
    "activity",
    "statement",
    "ledger",
    "movements",
    "deposits",
    "withdrawals",
    "posting",
    "posted",
    "recent",
)


def resolve_account_type_alias(requested: str, accounts_map: dict) -> str:
    token = re.sub(r"[^A-Z0-9]+", "_", requested.upper()).strip("_")
    if token in accounts_map:
        return token
    candidates = ACCOUNT_TYPE_ALIASES.get(token, ())
    matches = [c for c in candidates if c in accounts_map]
    if len(matches) == 1:
        return matches[0]
    return token


def _has_negation(text_lower: str) -> bool:
    return any(tok in text_lower for tok in _NEGATION_TOKENS)


def _has_conjunction(text_lower: str) -> bool:
    return any(tok in text_lower for tok in _CONJUNCTION_TOKENS)


def scan_explicit_account_types(text_lower: str) -> list[str]:
    spans: list[tuple[int, int, str]] = []
    for pattern, alias in _ACCOUNT_TYPE_TOKENS:
        for m in re.finditer(pattern, text_lower):
            spans.append((m.start(), m.end(), alias))
    if not spans:
        return []
    spans.sort(key=lambda s: (s[0], -(s[1] - s[0])))
    kept: list[tuple[int, int, str]] = []
    for s, e, a in spans:
        if any(ks <= s and ke >= e and (ks, ke) != (s, e) for ks, ke, _ in kept):
            continue
        kept.append((s, e, a))
    kept.sort(key=lambda s: s[0])
    out: list[str] = []
    seen: set[str] = set()
    for _, _, a in kept:
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out


def tail_line_signals_all_accounts(scan: str, *, include_history_nouns: bool) -> bool:
    """True when the *latest non-empty user line* asks for every account.

    When recent lines are newline-joined, older turns may still mention
    ``401k``/``IRA`` tokens.  Those must not block a fresh ``all my accounts``
    balance / activity ask scoped to this line alone.
    """
    lines = [ln.strip() for ln in scan.replace("\r\n", "\n").split("\n") if ln.strip()]
    if not lines:
        return False
    tail_lc = lines[-1].lower()
    extra = _HISTORY_ALL_NOUNS if include_history_nouns else ()
    noun_set = tuple(_ALL_ACCOUNTS_NOUNS) + tuple(extra)
    has_all_kw = any(re.search(rf"\b{kw}\b", tail_lc) for kw in _ALL_ACCOUNTS_KEYWORDS)
    has_noun = any(re.search(rf"\b{n}\b", tail_lc) for n in noun_set)
    if not (has_all_kw and has_noun):
        return False
    return not scan_explicit_account_types(tail_lc)


def recent_user_lines_concat(state: dict, *, limit: int = 35) -> str:
    """Concatenate recent user-only chat rows (used for multi-turn NLP).

    Mirrors the tool-invoker forwarding for ``recent_user_queries_text``.
    Keeps parity with TransactionHistory/Balance inquiries and planner
    soft-fill helpers that must not hinge on credential-only utterances.
    """
    mh = state.get("message_history") or []
    parts: list[str] = []
    for m in mh:
        if not isinstance(m, dict):
            continue
        if str(m.get("role", "")).lower() != "user":
            continue
        c = (m.get("content") or "").strip()
        if c:
            parts.append(c)
    return "\n".join(parts[-limit:])


def account_detection_scan_text(
    recent_user_queries_text: str | None,
    last_user_message: str | None,
) -> str:
    """Merge recent-user lines with the current utterance for account-type NLP.

    On post-auth executes, ``last_user_message`` is often credential-only while
    the original IRA/401(k) wording remains in earlier ``message_history`` rows.
    Stale-slot guards still use ``last_user_message`` alone.
    """
    parts = [
        (recent_user_queries_text or "").strip(),
        (last_user_message or "").strip(),
    ]
    return "\n".join(p for p in parts if p)


def detect_requested_account_types(
    message: str,
    accounts_map: dict,
    *,
    include_history_nouns: bool = False,
) -> list[str] | None:
    """Mirror balance_inquiry ``_detect_requested_account_types``.

    When ``include_history_nouns=True``, phrases like /all.*transactions/
    qualify for ALL without requiring generic account/balance noun.
    """
    if not message:
        return None
    text = message.lower()

    if tail_line_signals_all_accounts(message, include_history_nouns=include_history_nouns):
        return ["ALL"]

    extra_nouns = _HISTORY_ALL_NOUNS if include_history_nouns else ()
    noun_set = tuple(_ALL_ACCOUNTS_NOUNS) + tuple(extra_nouns)

    lines_lc = [
        ln.strip().lower()
        for ln in message.replace("\r\n", "\n").split("\n")
        if ln.strip()
    ]
    tail_lc = lines_lc[-1] if lines_lc else ""

    # Older turns often mention brokerage/IRA/etc.; merged scan text then lists
    # more account types than the user named on the fresh follow-up (“401k and
    # IRA balances” must not resurrect “brokerage” from two turns ago).
    tail_explicit_types = scan_explicit_account_types(tail_lc) if tail_lc else []
    narrow_to_tail_explicit = (
        bool(tail_explicit_types)
        and bool(tail_lc)
        and (
            looks_like_fresh_balance_request(tail_lc)
            or looks_like_fresh_transaction_history_request(tail_lc)
        )
    )
    scope_lc = tail_lc if narrow_to_tail_explicit else text

    explicit = scan_explicit_account_types(scope_lc)

    if not explicit and any(re.search(p, text) for p in _STANDALONE_ALL_PATTERNS):
        return ["ALL"]

    has_all_kw = any(re.search(rf"\b{kw}\b", text) for kw in _ALL_ACCOUNTS_KEYWORDS)
    has_noun = any(re.search(rf"\b{n}\b", text) for n in noun_set)
    if has_all_kw and has_noun and not explicit:
        return ["ALL"]

    if not explicit:
        return None

    if len(explicit) > 1 and (
        _has_negation(scope_lc) or not _has_conjunction(scope_lc)
    ):
        explicit = [explicit[0]]

    resolved: list[str] = []
    seen: set[str] = set()
    for tok in explicit:
        canonical = resolve_account_type_alias(tok, accounts_map)
        if canonical in accounts_map and canonical not in seen:
            seen.add(canonical)
            resolved.append(canonical)
            continue
        token_norm = re.sub(r"[^A-Z0-9]+", "_", str(tok).upper()).strip("_")
        umbrella = ACCOUNT_TYPE_ALIASES.get(token_norm, ())
        matched = False
        for cand in umbrella:
            if cand in accounts_map and cand not in seen:
                seen.add(cand)
                resolved.append(cand)
                matched = True
        if matched:
            continue
    if not resolved:
        return explicit
    return resolved


def looks_like_fresh_balance_request(message: str) -> bool:
    if not message:
        return False
    m = message.strip().lower()
    if len(m) < 6:
        return False
    return any(k in m for k in _FRESH_BALANCE_REQUEST_KEYWORDS)


def looks_like_fresh_transaction_history_request(message: str) -> bool:
    if not message:
        return False
    m = message.strip().lower()
    if len(m) < 6:
        return False
    return (
        any(k in m for k in _FRESH_TRANSACTION_REQUEST_KEYWORDS)
        or any(k in m for k in _FRESH_BALANCE_REQUEST_KEYWORDS)
    )
