"""Tool invoker.

Centralizes the cross-cutting concerns that surround any tool's
``execute()`` call:

* validated_entities gate enforcement (with per-tool opt-out)
* extra-kwarg signature inspection (last_user_message /
  recent_user_queries_text / current_turn)
* stable idempotency-key injection into ``tool_exec``
* ``completed_intent_ids`` bookkeeping for successfully completed intents
* ``[tool_invoke]`` tracing label

``BaseTool.run(state)`` is a thin shim that simply calls
``invoke_tool(self.name, state)``.  Graph nodes can call
``invoke_tool(name, state)`` directly without instantiating a tool.
"""

from __future__ import annotations

import hashlib
import inspect
from typing import Any

from observability.tracer import trace_agent
from tools._account_resolution import recent_user_lines_concat


def _stable_idempotency_key(
    conversation_id: str | None,
    turn: int,
    intent_id: str | None,
    tool_name: str,
) -> str:
    """Generate a deterministic idempotency key for retried invocations.

    Derived from (conversation_id, turn, intent_id, tool_name) so that
    retried graph invocations for the same turn produce the same key,
    preventing duplicate transactions.
    """
    parts = [
        conversation_id or "__none__",
        str(turn),
        intent_id or "__none__",
        tool_name,
    ]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()


def _get_tool(tool_name: str):
    # Lazy import to avoid the import cycle:
    #   tools.registry -> tools.<name>.v1.agent -> tools.base -> tools.invoker
    from tools.registry import TOOL_REGISTRY

    tool = TOOL_REGISTRY.get(tool_name)
    if tool is None:
        raise RuntimeError(
            f"invoke_tool: unknown tool '{tool_name}'. "
            f"Known tools: {sorted(TOOL_REGISTRY)}"
        )
    return tool


@trace_agent("tool_invoke")
def invoke_tool(tool_name: str, state: dict) -> dict:
    """Run the named tool against ``state`` and return a partial state dict.

    This is the single entry point through which transactional tools are
    invoked - both from ``BaseTool.run()`` (legacy) and from graph nodes
    (preferred).  All gate enforcement, idempotency wiring, and intent
    bookkeeping happens here so that individual tool ``execute()`` methods
    only have to implement their domain logic.
    """
    tool = _get_tool(tool_name)

    validated = state.get("validated_entities", {})
    allow_empty = getattr(tool, "allow_empty_validated_entities", False)
    if not validated and not allow_empty:
        raise RuntimeError(
            f"Tool '{tool_name}' called with empty validated_entities. "
            "This should never happen -- the Supervisor must gate tool "
            "execution after HITL approval. Check H3 rule and HITL flow."
        )

    # Auth-level gate (defense-in-depth -- the supervisor's H3 hard rule
    # should already have escalated under-authenticated invocations).
    required_level = getattr(tool, "required_auth_level", None)
    if required_level is not None:
        auth_state = state.get("auth_state")
        current_level = getattr(auth_state, "current_level", None)
        if current_level is not None and current_level < required_level:
            raise RuntimeError(
                f"Tool '{tool_name}' requires auth level "
                f"{getattr(required_level, 'name', required_level)} but "
                f"current session is "
                f"{getattr(current_level, 'name', current_level)}. "
                "Supervisor H3 should have routed to auth_agent before "
                "reaching this tool."
            )

    account_context = state.get("account_context", {})
    auth_token = state.get("auth_token", "")

    # Optional context kwargs -- only forwarded to execute() if the
    # subclass declares them in its signature.
    extra_kwargs: dict[str, Any] = {}
    try:
        sig_params = inspect.signature(tool.execute).parameters
    except (TypeError, ValueError):
        sig_params = {}
    if "last_user_message" in sig_params:
        extra_kwargs["last_user_message"] = state.get("last_user_message") or ""
    if "recent_user_queries_text" in sig_params:
        extra_kwargs["recent_user_queries_text"] = recent_user_lines_concat(state)
    if "current_turn" in sig_params:
        extra_kwargs["current_turn"] = state.get("current_turn", 0)

    # sub_intent — lets multi-operation tools branch without inspecting state
    # (avoids coupling individual tools to the full GraphState schema).
    if "sub_intent" in sig_params:
        intent_stack = state.get("intent_stack", [])
        active = intent_stack[0] if intent_stack else None
        extra_kwargs["sub_intent"] = getattr(active, "sub_intent", None)

    # hitl_confirmed — True only when the user explicitly approved the HITL
    # confirmation card on the *current* turn.  Irreversible operations
    # (loan origination, withdrawal) must gate their commit path on this flag.
    if "hitl_confirmed" in sig_params:
        hitl = state.get("hitl")
        extra_kwargs["hitl_confirmed"] = bool(
            hitl is not None and getattr(hitl, "last_confirmed", None) is True
        )

    # idempotency_key — stable key derived from session/turn/intent so that
    # retried graph invocations produce the same key.  Generated here (before
    # the tool call) so the tool can forward it to external APIs, preventing
    # duplicate transactions on network retries.
    if "idempotency_key" in sig_params:
        _intent_stack = state.get("intent_stack", [])
        _intent_id = (
            getattr(_intent_stack[0], "intent_id", None)
            if _intent_stack else None
        )
        extra_kwargs["idempotency_key"] = _stable_idempotency_key(
            state.get("conversation_id"),
            state.get("current_turn", 0),
            _intent_id,
            tool_name,
        )

    result = tool.execute(validated, account_context, auth_token, **extra_kwargs)

    # Inject a stable idempotency key into tool_exec so retried graph
    # invocations for the same turn produce the same key.
    tool_exec = result.get("tool_exec")
    if tool_exec is not None:
        conversation_id = state.get("conversation_id")
        turn = state.get("current_turn", 0)
        intent_stack = state.get("intent_stack", [])
        intent_id = (
            getattr(intent_stack[0], "intent_id", None)
            if intent_stack else None
        )
        stable_key = _stable_idempotency_key(
            conversation_id, turn, intent_id, tool_name,
        )
        result["tool_exec"] = tool_exec.model_copy(
            update={"idempotency_key": stable_key},
        )

    # Mark the intent fulfilled so the supervisor will not auto-re-run
    # the same read-only inquiry on follow-up turns. Only mark successful
    # completions; failures must remain re-runnable.
    txn = result.get("transaction_result") or {}
    if isinstance(txn, dict) and txn.get("status") == "COMPLETED":
        intent_stack = state.get("intent_stack", [])
        intent_id = (
            getattr(intent_stack[0], "intent_id", None)
            if intent_stack else None
        )
        if intent_id:
            already = list(state.get("completed_intent_ids", []) or [])
            if intent_id not in already:
                already.append(intent_id)
            result["completed_intent_ids"] = already

    return result
