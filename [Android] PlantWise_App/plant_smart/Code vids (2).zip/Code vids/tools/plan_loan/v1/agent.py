from __future__ import annotations

"""
Tool 4 — Plan Loan Initiator / Eligibility Checker / Status Viewer.

Three operations, each backed by a separate sub-intent:

  PLAN_LOAN_ELIGIBILITY  (read-only) — IRC 72(p) max-borrowable computation
  PLAN_LOAN_REQUEST      (write)     — loan origination with HITL preview / commit
  PLAN_LOAN_STATUS       (read-only) — look up active / historical loan(s)

Design per plan-loan-tool-design spec:
  § 2  Branch on sub_intent (not amount presence).
  § 4  Read per-account fields from accounts_map, NOT flat fallbacks.
  § 5  IRA / brokerage gate before any IRC 72(p) math.
  § 7  HITL preview on first invocation; commit only after confirmation.
  § 8  ERISA §417 spousal consent before origination.
  § 3  idempotency_key forwarded to loan API.
  §12  PII scrubbed via try/finally.

Taxonomy intents routed here:
  PLAN_LOAN_REQUEST     (retirement) — transactional
  PLAN_LOAN_ELIGIBILITY (retirement) — informational (is_transactional=True to reach tool)
  PLAN_LOAN_STATUS      (retirement) — informational (is_transactional=True to reach tool)

Required slots:
  PLAN_LOAN_REQUEST:     plan_type, loan_amount, repayment_term
  PLAN_LOAN_ELIGIBILITY: plan_type
  PLAN_LOAN_STATUS:      plan_type

Write-ownership:
  transaction_result  — loan result dict
  tool_exec           — execution lifecycle state
"""

import math
import re as _re
import threading as _threading
from datetime import date, datetime, timedelta, timezone
from typing import ClassVar

from tools.base import BaseTool
from schemas.enums import AuthLevel, ToolExecutionStatus
from schemas.primitives import EntityRecord, ToolExecutionState
from vault.dereferencer import dereference_entity
from observability.logger import log
from regulatory.irs_limits import IRS_LIMITS


# — IRA and non-qualified account types that cannot hold participant loans ———
# IRC 408(e)(4) / 408A — IRA vehicles are ineligible for plan loans.
# Brokerage (taxable) accounts are similarly excluded.
_NON_LOAN_ELIGIBLE_TYPES: frozenset[str] = frozenset({
    "TRADITIONAL_IRA",
    "ROTH_IRA",
    "SEP_IRA",
    "SIMPLE_IRA",
    "BROKERAGE",
})

# ERISA §417: spousal consent required for qualified-plan loans above this amount
_ERISA_SPOUSAL_CONSENT_THRESHOLD = 5_000.00

# Account-type aliases mirror the set in balance_inquiry so the same
# user phrasing ("IRA", "401-k", "traditional") resolves consistently.
_ACCOUNT_TYPE_ALIASES: dict[str, tuple[str, ...]] = {
    "IRA":               ("TRADITIONAL_IRA", "ROTH_IRA"),
    "TRADITIONAL":       ("TRADITIONAL_IRA",),
    "ROTH":              ("ROTH_IRA", "ROTH_401K"),
    "401_K":             ("401K",),
    "403_B":             ("403B",),
    "BROKERAGE_ACCOUNT": ("BROKERAGE",),
    "TAXABLE":           ("BROKERAGE",),
}


class PlanLoanTool(BaseTool):
    name: ClassVar[str] = "plan_loan"
    version: ClassVar[str] = "2.0.0"

    description: ClassVar[str] = (
        "Handles 401(k) plan loan eligibility checks, originations, and "
        "status queries.  Enforces IRC 72(p) limits (§2(A)(i)/(ii)/(B)/(C)) "
        "and ERISA §417 spousal consent.  Routes by sub_intent: "
        "ELIGIBILITY, REQUEST (INITIATE), or STATUS."
    )
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = True

    # ELIGIBILITY and STATUS carry only plan_type; a single-account user
    # may have an auto-selected account even with empty validated_entities,
    # so skip the strict empty-entity gate.
    allow_empty_validated_entities: ClassVar[bool] = True

    input_schema: ClassVar[dict] = {
        "plan_type":      {"type": "string",  "required": True},
        "loan_amount":    {"type": "number",  "required": False,
                           "description": "Required for PLAN_LOAN_REQUEST."},
        "repayment_term": {"type": "integer", "required": False,
                           "description": "Term in months. Required for PLAN_LOAN_REQUEST."},
        "loan_id":        {"type": "string",  "required": False,
                           "description": "Specific loan ID for STATUS lookup."},
    }

    def execute(
        self,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        sub_intent: str | None = None,
        hitl_confirmed: bool = False,
        idempotency_key: str | None = None,
    ) -> dict:
        """
        Route to ELIGIBILITY, INITIATE, or STATUS based on sub_intent.

        sub_intent is injected by the invoker from active_intent.sub_intent
        so the tool never inspects GraphState directly.

        hitl_confirmed is True only after the user has approved the HITL
        card — prevents irreversible loan origination on the first call.

        idempotency_key is pre-computed by the invoker from
        (conversation_id, turn, intent_id, tool_name) so retried
        invocations always produce the same key, preventing duplicate loans.
        """
        now = datetime.now(timezone.utc)
        op = _op_from_intent(sub_intent)

        # — § 4: Resolve account from accounts_map ————————————————————————————
        accounts_map: dict = account_context.get("accounts") or {}
        plan_type_entity = (
            validated_entities.get("plan_type")
            or validated_entities.get("account_type")
        )
        plan_type_raw: str | None = (
            plan_type_entity.display_value if plan_type_entity else None
        )

        resolved_plan_type, account_data, resolve_err = _resolve_account(
            plan_type_raw, accounts_map, account_context,
        )
        if resolve_err:
            return self._failure(resolve_err, now, operation=op)

        # — § 5: Plan-level gate — IRA / brokerage / plan_allows_loans ————————
        if resolved_plan_type in _NON_LOAN_ELIGIBLE_TYPES:
            friendly = resolved_plan_type.replace("_", " ").title()
            return self._failure(
                f"IRC 408(e)(4) — {friendly} accounts cannot offer participant "
                f"loans.  Only qualified plans such as 401(k) and 403(b) permit "
                f"loans under IRC 72(p).",
                now,
                operation=op,
            )
        plan_allows_loans = bool(account_data.get("plan_allows_loans", True))
        if not plan_allows_loans:
            return self._failure(
                "Your plan document does not permit participant loans.  "
                "Contact your plan administrator for details.",
                now,
                operation=op,
            )

        # — § 12: Dereference account number from vault ————————————————————————
        raw_account_number: str | None = None
        try:
            acct_entity = validated_entities.get("account_number")
            if acct_entity and getattr(acct_entity, "vault_token", None):
                try:
                    raw_account_number = dereference_entity(acct_entity, auth_token)
                except (KeyError, PermissionError) as exc:
                    log.error("plan_loan_vault_deref_failed", error=str(exc))
                    return self._failure(
                        "Unable to verify account identity.  Please try again.",
                        now,
                        operation=op,
                    )
            if not raw_account_number:
                raw_account_number = (
                    account_data.get("account_number")
                    or account_context.get("account_number")
                )
            if not raw_account_number:
                return self._failure(
                    "Account number could not be resolved.", now, operation=op,
                )

            # — § 4: Read per-account IRC 72(p) balance fields ————————————————
            try:
                vested_balance = float(account_data.get("vested_balance", 0.0))
                outstanding_loan_balance = float(
                    account_data.get("outstanding_loan_balance", 0.0)
                )
                highest_loan_balance_12m = float(
                    account_data.get("highest_loan_balance_12m", 0.0)
                )
            except (ValueError, TypeError) as exc:
                return self._failure(
                    f"Invalid numeric value in account data: {exc}",
                    now,
                    operation=op,
                )
            for label, val in (
                ("vested_balance", vested_balance),
                ("outstanding_loan_balance", outstanding_loan_balance),
                ("highest_loan_balance_12m", highest_loan_balance_12m),
            ):
                if math.isnan(val) or math.isinf(val):
                    return self._failure(
                        f"Invalid numeric value in account data: {label} is NaN/Inf.",
                        now,
                        operation=op,
                    )

            # — § 2: Branch on sub_intent ——————————————————————————————————————
            if op == "ELIGIBILITY":
                return self._check_eligibility(
                    raw_account_number,
                    vested_balance,
                    outstanding_loan_balance,
                    highest_loan_balance_12m,
                    auth_token,
                    now,
                )
            if op == "STATUS":
                return self._get_status(
                    raw_account_number,
                    validated_entities,
                    auth_token,
                    resolved_plan_type,
                    now,
                )
            # Default: INITIATE (PLAN_LOAN_REQUEST)
            return self._initiate_loan(
                raw_account_number,
                validated_entities,
                account_context,
                resolved_plan_type,
                vested_balance,
                outstanding_loan_balance,
                highest_loan_balance_12m,
                auth_token,
                hitl_confirmed,
                idempotency_key,
                now,
            )

        except Exception as exc:
            log.error("plan_loan_unhandled_error", sub_intent=sub_intent, error=str(exc))
            return self._failure(str(exc), now, operation=op, escalate=True)
        finally:
            # § 12: Guarantee PII scrubbing even on unexpected exceptions.
            try:
                del raw_account_number
            except NameError:
                pass

    # =========================================================================
    # § 6 — ELIGIBILITY CHECK
    # =========================================================================

    def _check_eligibility(
        self,
        raw_account_number: str,
        vested_balance: float,
        outstanding_loan_balance: float,
        highest_loan_balance_12m: float,
        auth_token: str,
        now: datetime,
    ) -> dict:
        """
        Call get_loan_eligibility and surface the result.

        Never originates a loan.  Plan-level gate (§5) already ran so
        plan_allows_loans=True is safe to assert here.
        """
        loan_api = _get_loan_api()
        elig = loan_api.get_loan_eligibility(
            account_number=raw_account_number,
            vested_balance=vested_balance,
            outstanding_loan_balance=outstanding_loan_balance,
            highest_loan_balance_12m=highest_loan_balance_12m,
            plan_allows_loans=True,
            auth_token=auth_token,
        )
        account_display = f"****{raw_account_number[-4:]}"
        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "ELIGIBILITY",
            "account_display": account_display,
            "eligible": elig.get("eligible", False),
            "max_loan_amount": elig.get("max_loan_amount", 0.0),
            "vested_balance": elig.get("vested_balance", 0.0),
            "irc_72p_limit": elig.get("irc_72p_limit", 0.0),
            "outstanding_loan_balance": elig.get("outstanding_loan_balance", 0.0),
            "highest_loan_balance_12m": elig.get("highest_loan_balance_12m", 0.0),
            "plan_allows_loans": True,
            "rejection_reason": elig.get("rejection_reason"),
        }
        log.info(
            "plan_loan_eligibility_complete",
            account_display=account_display,
            eligible=elig.get("eligible", False),
            max_loan_amount=elig.get("max_loan_amount", 0.0),
        )
        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    # =========================================================================
    # § 10 — STATUS LOOKUP
    # =========================================================================

    def _get_status(
        self,
        raw_account_number: str,
        validated_entities: dict[str, EntityRecord],
        auth_token: str,
        resolved_plan_type: str,
        now: datetime,
    ) -> dict:
        """
        Look up a specific loan (if loan_id provided) or list all loans
        for the resolved account.
        """
        from mock_services.inprocess.loan_api import LoanNotFoundError

        loan_api = _get_loan_api()
        account_display = f"****{raw_account_number[-4:]}"

        loan_id_entity = validated_entities.get("loan_id")
        loan_id: str | None = (
            loan_id_entity.display_value
            if loan_id_entity and loan_id_entity.display_value
            else None
        )

        if loan_id:
            try:
                loans = [loan_api.get_loan_status(loan_id, auth_token)]
            except LoanNotFoundError:
                return self._failure(
                    f"Loan {loan_id!r} was not found on your account.",
                    now,
                    operation="STATUS",
                )
        else:
            loans = loan_api.list_loans_by_account(raw_account_number, auth_token)

        result: dict = {
            "success": True,
            "status": "COMPLETED",
            "operation": "STATUS",
            "account_display": account_display,
            "plan_type": resolved_plan_type,
            "loans": loans,
            "loan_count": len(loans),
        }
        if not loans:
            friendly = resolved_plan_type.replace("_", " ").title()
            result["message"] = f"No loans found for your {friendly} account."

        log.info(
            "plan_loan_status_complete",
            account_display=account_display,
            loan_count=len(loans),
            specific_loan_id=loan_id,
        )
        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    # =========================================================================
    # § 7 — LOAN INITIATION  (PLAN_LOAN_REQUEST)
    # =========================================================================

    def _initiate_loan(
        self,
        raw_account_number: str,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        resolved_plan_type: str,
        vested_balance: float,
        outstanding_loan_balance: float,
        highest_loan_balance_12m: float,
        auth_token: str,
        hitl_confirmed: bool,
        idempotency_key: str | None,
        now: datetime,
    ) -> dict:
        """
        Preview-then-commit HITL contract (§7).

        First call (hitl_confirmed=False): validate all regulatory gates,
        compute amortization preview, and return status="PREVIEW".  No loan
        is originated; the synthesizer shows the preview in the HITL card.

        Second call (hitl_confirmed=True, after user approval): re-validate
        gates (same inputs → same outcome) and call loan_api.initiate_loan()
        with the stable idempotency_key to prevent duplicate origination.
        """
        account_display = f"****{raw_account_number[-4:]}"

        # — Parse loan amount ——————————————————————————————————————————————————
        amount = _parse_amount(validated_entities)
        if amount is None or amount <= 0:
            return self._failure(
                "A positive loan amount is required.", now, operation="INITIATE"
            )

        # — Plan minimum (IRS_LIMITS["401K_LOAN_MIN"]) ————————————————————————
        if "401K_LOAN_MIN" not in IRS_LIMITS:
            log.error("missing_irs_limit_config", key="401K_LOAN_MIN")
            return self._failure(
                "System configuration error: loan minimum threshold not set. "
                "Please contact support.",
                now,
                operation="INITIATE",
                escalate=True,
            )
        loan_min = IRS_LIMITS["401K_LOAN_MIN"]
        if amount < loan_min:
            return self._failure(
                f"Loan amount ${amount:,.2f} is below the plan minimum of "
                f"${loan_min:,.2f}.",
                now,
                operation="INITIATE",
            )

        # — IRC 72(p)(2)(A)(i): $50K ceiling reduced by 12-month lookback ———
        # excess = highest_12m − outstanding (floor at 0)
        excess = max(0.0, highest_loan_balance_12m - outstanding_loan_balance)
        limit_50k = IRS_LIMITS["401K_LOAN_MAX"] - excess

        # — IRC 72(p)(2)(A)(ii): 50% of vested balance with $10K floor ————
        half_vested = vested_balance * 0.5
        irc_72p_floor = 10_000.0
        limit_half = max(half_vested, irc_72p_floor)

        # Net limit = lesser of the two caps, minus current outstanding loans,
        # further capped at available (un-borrowed) vested balance.
        gross_limit = min(limit_50k, limit_half)
        net_limit = max(0.0, gross_limit - outstanding_loan_balance)
        net_limit = min(net_limit, max(0.0, vested_balance - outstanding_loan_balance))

        if amount > net_limit:
            return self._failure(
                f"Requested amount ${amount:,.2f} exceeds the IRC 72(p) "
                f"maximum of ${net_limit:,.2f} "
                f"(vested balance ${vested_balance:,.2f}, "
                f"outstanding loans ${outstanding_loan_balance:,.2f}).",
                now,
                operation="INITIATE",
            )

        # — Parse repayment term ———————————————————————————————————————————————
        term_months = _parse_term(validated_entities)
        if term_months is None or term_months < 1:
            return self._failure(
                "A valid repayment term (in months) is required.",
                now,
                operation="INITIATE",
            )

        # — § 7: Loan-purpose source of truth (controls 60/360 ceiling) ———————
        loan_type = _determine_loan_type(validated_entities, account_context)

        # — IRC 72(p)(2)(B): term ceiling ——————————————————————————————————————
        max_term = 360 if loan_type == "PRIMARY_RESIDENCE" else 60
        if term_months > max_term:
            label = (
                "primary residence" if loan_type == "PRIMARY_RESIDENCE"
                else "general-purpose"
            )
            return self._failure(
                f"Repayment term {term_months} months exceeds IRC 72(p)(2)(B) "
                f"maximum of {max_term} months for {label} loans.",
                now,
                operation="INITIATE",
            )

        # — § 8: ERISA §417 spousal consent ————————————————————————————————————
        if (
            resolved_plan_type in ("401K", "403B", "ROTH_401K")
            and amount > _ERISA_SPOUSAL_CONSENT_THRESHOLD
        ):
            marital_status = str(account_context.get("marital_status", "")).upper()
            if marital_status == "MARRIED":
                spousal_consent = bool(
                    account_context.get("spousal_consent_obtained", False)
                )
                if not spousal_consent:
                    return self._failure(
                        "Spousal consent is required under ERISA §417 for loans "
                        "of this size from your plan.  Please complete the spousal "
                        "consent form before proceeding.",
                        now,
                        operation="INITIATE",
                    )

        # — § 9: Interest rate determination ——————————————————————————————————
        interest_rate = _parse_interest_rate(account_context)

        # — Amortization preview (computed for both paths) ————————————————————
        from mock_services.inprocess.loan_api import calculate_monthly_payment
        effective_rate = interest_rate if interest_rate is not None else 0.055
        monthly_payment = calculate_monthly_payment(amount, effective_rate, term_months)
        total_repayment = round(monthly_payment * term_months, 2)
        total_interest = round(total_repayment - amount, 2)
        today = date.today()
        first_payment_date = (today + timedelta(days=30)).isoformat()
        maturity_date = (today + timedelta(days=30 * term_months)).isoformat()

        # — PREVIEW path (pre-HITL confirmation) ——————————————————————————————
        if not hitl_confirmed:
            preview = {
                "success": True,
                "status": "PREVIEW",
                "operation": "INITIATE",
                "account_display": account_display,
                "plan_type": resolved_plan_type,
                "loan_type": loan_type,
                "principal_amount": amount,
                "interest_rate": effective_rate,
                "term_months": term_months,
                "monthly_payment": monthly_payment,
                "first_payment_date": first_payment_date,
                "maturity_date": maturity_date,
                "total_interest": total_interest,
                "total_repayment": total_repayment,
            }
            log.info(
                "plan_loan_preview_computed",
                account_display=account_display,
                amount=amount,
                term_months=term_months,
                monthly_payment=monthly_payment,
            )
            return {
                "transaction_result": preview,
                "tool_exec": ToolExecutionState(
                    in_flight=False,
                    tool_agent_name=self.name,
                    status=ToolExecutionStatus.SUCCEEDED,
                    idempotency_key=idempotency_key or "",
                    last_updated_at=now,
                    result_payload=preview,
                ),
            }

        # — COMMIT path (post-HITL confirmation) ——————————————————————————————
        loan_api = _get_loan_api()
        api_result = loan_api.initiate_loan(
            account_number=raw_account_number,
            amount=amount,
            term_months=term_months,
            auth_token=auth_token,
            loan_type=loan_type,
            interest_rate=interest_rate,
            vested_balance=vested_balance,
            outstanding_loan_balance=outstanding_loan_balance,
            highest_loan_balance_12m=highest_loan_balance_12m,
            plan_allows_loans=True,
            idempotency_key=idempotency_key,
        )

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "INITIATE",
            "account_display": account_display,
            "plan_type": resolved_plan_type,
            "loan_type": loan_type,
            "loan_id": api_result.get("loan_id", ""),
            "confirmation_number": api_result.get("confirmation_number", ""),
            "principal_amount": api_result.get("principal_amount", 0.0),
            "interest_rate": api_result.get("interest_rate", 0.0),
            "term_months": api_result.get("term_months", 0),
            "monthly_payment": api_result.get("monthly_payment", 0.0),
            "first_payment_date": api_result.get("first_payment_date", ""),
            "maturity_date": api_result.get("maturity_date", ""),
            "total_interest": api_result.get("total_interest", 0.0),
            "total_repayment": api_result.get("total_repayment", 0.0),
        }
        log.info(
            "plan_loan_initiate_complete",
            account_display=account_display,
            loan_id=api_result.get("loan_id", ""),
            amount=amount,
            term_months=term_months,
            monthly_payment=api_result.get("monthly_payment", 0.0),
        )
        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key=idempotency_key or "",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    # =========================================================================
    # Failure helper (§ 11 output contract)
    # =========================================================================

    def _failure(
        self,
        message: str,
        now: datetime,
        *,
        operation: str = "PLAN_LOAN",
        escalate: bool = False,
    ) -> dict:
        """
        Standardised failure response.

        escalate=True for system / API errors that need human intervention.
        escalate=False for user-input validation failures — slot-filling can
        re-collect after the user receives the rejection message.
        """
        log.warning(
            "plan_loan_failed", reason=message, operation=operation, escalate=escalate
        )
        return {
            "transaction_result": {
                "success": False,
                "status": "FAILED",
                "operation": operation,
                "errors": [message],
            },
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.FAILED,
                error_message=message,
                last_updated_at=now,
            ),
            "escalation_requested": escalate,
        }

    def health_check(self) -> bool:
        return True


# =============================================================================
# Module-level helpers
# =============================================================================

def _op_from_intent(sub_intent: str | None) -> str:
    """Map a sub_intent string to the tool's branch label."""
    if sub_intent == "PLAN_LOAN_ELIGIBILITY":
        return "ELIGIBILITY"
    if sub_intent == "PLAN_LOAN_STATUS":
        return "STATUS"
    return "INITIATE"


def _resolve_account(
    plan_type_raw: str | None,
    accounts_map: dict,
    account_context: dict,
) -> tuple[str, dict, str | None]:
    """
    Resolve a user-supplied plan_type label to (canonical_key, account_data, error).

    Returns (canonical, data, None) on success or ("", {}, error_message) on failure.

    Resolution order (§4):
      1. Match plan_type_raw against accounts_map via alias table.
      2. Auto-select if exactly one loan-eligible account exists.
      3. Fall back to flat account_context for single-account users.
      4. Return error if ambiguous.
    """
    if not accounts_map:
        # Single-account user without structured accounts_map — use flat context.
        acct_type = (
            account_context.get("plan_type")
            or account_context.get("primary_account_type")
            or "UNKNOWN"
        )
        return acct_type, account_context, None

    if plan_type_raw:
        canonical = _resolve_account_type_alias(plan_type_raw, accounts_map)
        if canonical in accounts_map:
            return canonical, accounts_map[canonical], None
        available = ", ".join(sorted(accounts_map.keys()))
        return "", {}, (
            f"You don't have a {plan_type_raw!r} account on file. "
            f"Available: {available}."
        )

    # No plan_type provided — auto-select if exactly one loan-eligible account.
    loan_eligible = {
        k: v
        for k, v in accounts_map.items()
        if k not in _NON_LOAN_ELIGIBLE_TYPES and v.get("plan_allows_loans", True)
    }
    if len(loan_eligible) == 1:
        key = next(iter(loan_eligible))
        return key, loan_eligible[key], None

    if len(accounts_map) == 1:
        key = next(iter(accounts_map))
        return key, accounts_map[key], None

    available = ", ".join(sorted(accounts_map.keys()))
    return "", {}, (
        f"Please specify which account you'd like a loan from. "
        f"Available: {available}."
    )


def _resolve_account_type_alias(requested: str, accounts_map: dict) -> str:
    """
    Map a user-supplied account_type label to a canonical key in accounts_map.

    Uses the same normalization and alias table as balance_inquiry so that
    "IRA", "401-k", "traditional IRA" etc. resolve consistently across tools.
    Returns the canonical key when an unambiguous match exists, otherwise
    returns the normalized token (which will miss the dict and surface an
    "account not found" error via the caller).
    """
    token = _re.sub(r"[^A-Z0-9]+", "_", requested.upper()).strip("_")
    if token in accounts_map:
        return token
    candidates = _ACCOUNT_TYPE_ALIASES.get(token, ())
    matches = [c for c in candidates if c in accounts_map]
    if len(matches) == 1:
        return matches[0]
    return token


def _parse_amount(validated_entities: dict[str, EntityRecord]) -> float | None:
    """Parse dollar amount from loan_amount or dollar_amount entity."""
    for key in ("loan_amount", "dollar_amount"):
        entity = validated_entities.get(key)
        if entity and entity.display_value:
            cleaned = entity.display_value.replace("$", "").replace(",", "").strip()
            try:
                val = float(cleaned)
                if not math.isnan(val) and not math.isinf(val):
                    return val
            except ValueError:
                continue
    return None


def _parse_term(validated_entities: dict[str, EntityRecord]) -> int | None:
    """Parse repayment term in months from repayment_term or term_months entity."""
    for key in ("repayment_term", "term_months"):
        entity = validated_entities.get(key)
        if entity and entity.display_value:
            cleaned = (
                entity.display_value.lower()
                .replace("months", "")
                .replace("month", "")
                .replace("mo", "")
                .strip()
            )
            try:
                return int(float(cleaned))
            except ValueError:
                continue
    return None


def _determine_loan_type(
    validated_entities: dict[str, EntityRecord],
    account_context: dict,
) -> str:
    """
    Determine API loan_type string from entities or account context (§7).

    Precedence:
      1. validated_entities["loan_purpose"]  — user-declared (preferred)
      2. validated_entities["loan_type"]     — legacy slot name (kept for compat)
      3. account_context["loan_purpose"]     — CRM hint
      4. Default → GENERAL_PURPOSE
    """
    for key in ("loan_purpose", "loan_type"):
        entity = validated_entities.get(key)
        if entity and entity.display_value:
            val = entity.display_value.upper().replace(" ", "_")
            if val in ("PRIMARY_RESIDENCE", "HOME_PURCHASE"):
                return "PRIMARY_RESIDENCE"
            return "GENERAL_PURPOSE"
    ctx_val = str(account_context.get("loan_purpose", "")).upper()
    if ctx_val in ("PRIMARY_RESIDENCE", "HOME_PURCHASE"):
        return "PRIMARY_RESIDENCE"
    return "GENERAL_PURPOSE"


def _parse_interest_rate(account_context: dict) -> float | None:
    """
    Parse plan-document interest rate from account_context (§9).

    Strips trailing '%', validates 0–20% range.  Returns None to let the
    loan API fall back to its DEFAULT_INTEREST_RATE (prime + 1%).
    """
    rate_str = account_context.get("interest_rate")
    if not rate_str:
        return None
    try:
        rate = float(str(rate_str).replace("%", "").strip())
        if 0.0 <= rate <= 20.0:
            return rate
        log.warning("plan_loan_invalid_rate", rate=rate)
    except (ValueError, TypeError):
        log.warning("plan_loan_unparseable_rate", raw=str(rate_str))
    return None


# — Module-level lazy singleton for the loan API ——————————————————————————————

_loan_api_instance = None
_loan_api_lock = _threading.Lock()


def _get_loan_api():
    global _loan_api_instance
    if _loan_api_instance is not None:
        return _loan_api_instance
    with _loan_api_lock:
        if _loan_api_instance is None:
            from tools.api_factory import create_loan_api
            _loan_api_instance = create_loan_api()
    return _loan_api_instance


def set_loan_api(api) -> None:
    """Test helper — inject a pre-seeded MockLoanAPI."""
    global _loan_api_instance
    _loan_api_instance = api
