from __future__ import annotations

"""
Tool — Transaction History Inquiry.

Read-only recent posted-like transactions via MockAccountAPI.get_transaction_history().

Taxonomy intent: TRANSACTION_HISTORY_INQUIRY
Required slots: account_type (soft-filled for single-account users in graph/state.py)
Router mapping: transaction_history
"""

import calendar
import re
from datetime import date, datetime, timedelta, timezone
from typing import ClassVar


def _month_num(tok: str) -> int | None:
    raw = (tok or "").lower().strip()
    stems = (
        ("january", "jan"),
        ("february", "feb"),
        ("march", "mar"),
        ("april", "apr"),
        ("may", "may"),
        ("june", "jun"),
        ("july", "jul"),
        ("august", "aug"),
        ("september", "sep"),
        ("october", "oct"),
        ("november", "nov"),
        ("december", "dec"),
    )
    mn_by_stem = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4,
        "may": 5, "jun": 6, "jul": 7, "aug": 8,
        "sep": 9, "oct": 10, "nov": 11, "dec": 12,
    }
    if raw.startswith("sept"):  # "sept" / "sep" share stem
        return 9
    for long, stem in stems:
        if raw == long:
            return mn_by_stem[stem[:3]]
    return mn_by_stem.get(raw[:3])


_ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")

# Allow 2–4 digit years; short years are inferred against ``now``.
_RE_DD_MON_Y = re.compile(
    r"\b((?:0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?)\s+(?:of\s+)?"
    r"(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|"
    r"sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
    r"\s*,?\s*(\d{2,4})\b",
    re.I,
)

_RE_MON_DD_Y = re.compile(
    r"\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|"
    r"aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
    r"\s+((?:0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?)"
    r"\s*,?\s*(\d{2,4})\b",
    re.I,
)

_FROM_SINCE_AFTER = re.compile(
    r"\b(from|since|after|starting(?:\s+from|\s+on)?)\b",
)


from tools.base import BaseTool
from schemas.enums import AuthLevel, ToolExecutionStatus
from schemas.primitives import EntityRecord, ToolExecutionState
from tools._account_resolution import (
    account_detection_scan_text,
    detect_requested_account_types,
    looks_like_fresh_transaction_history_request,
    resolve_account_type_alias,
)
from tools.balance_inquiry.v1.agent import _get_account_api
from vault.dereferencer import dereference_entity
from observability.logger import log


def _entity_text(er: EntityRecord | None) -> str:
    if er is None:
        return ""
    for attr in ("display_value", "canonical_value"):
        v = getattr(er, attr, None)
        if v is not None and str(v).strip():
            return str(v).strip()
    return ""


def _combined_date_candidate_text(
    validated_entities: dict[str, EntityRecord],
    user_scan: str | None,
) -> str:
    blobs: list[str] = []
    for slot in ("date_range", "statement_period"):
        blobs.append(_entity_text(validated_entities.get(slot)))
    slot_blob = " ".join(b for b in blobs if b).strip()
    parts: list[str] = []
    if slot_blob:
        parts.append(slot_blob)
    us = (user_scan or "").strip()
    if us:
        parts.append(us)
    return "\n".join(parts)


def _day_int(day_tok: str) -> int:
    return int("".join(c for c in day_tok if c.isdigit()))


def _subtract_months_clamped(base: date, months_back: int) -> date:
    if months_back <= 0:
        return base
    y, m, day = base.year, base.month, base.day
    m -= months_back
    while m <= 0:
        m += 12
        y -= 1
    last_dm = calendar.monthrange(y, m)[1]
    return date(y, m, min(day, last_dm))


def _subtract_years_clamped(base: date, years_back: int) -> date:
    if years_back <= 0:
        return base
    y = base.year - years_back
    m, day = base.month, base.day
    last_dm = calendar.monthrange(y, m)[1]
    return date(y, m, min(day, last_dm))


def _normalize_calendar_year_digits(
    raw_y: str,
    *,
    hint_year: int,
    ceiling_year: int | None = None,
) -> int | None:
    """Resolve 2–4 digit spoken years.

    ``ceiling_year`` narrows ambiguous 3-digit prefixes (``202``) when a later
    explicit 4-digit year appears in the same phrase (``… to 1st april, 2026``).
    """
    ys = raw_y.strip()
    if not ys.isdigit():
        return None
    if len(ys) == 4:
        cand = int(ys)
        if 1800 <= cand <= 2200:
            return cand
        return None
    if len(ys) == 2:
        yd = int(ys)
        century = hint_year // 100 * 100
        cand = century + yd
        picks = sorted({cand - 100, cand, cand + 100}, key=lambda yy: abs(yy - hint_year))
        for cand_y in picks:
            if 1940 <= cand_y <= hint_year + 1:
                return cand_y
        return cand if 1800 <= cand <= 2200 else None
    if len(ys) == 3:
        cands = [
            yr for yr in range(hint_year - 96, hint_year + 24)
            if str(yr).startswith(ys)
        ]
        if ceiling_year is not None:
            narrow = [y for y in cands if y <= ceiling_year]
            if narrow:
                cands = narrow
            if not cands:
                return None
            tgt = ceiling_year - 2
            return min(cands, key=lambda y: abs(y - tgt))
        if not cands:
            return None
        return min(cands, key=lambda yr: abs(yr - hint_year))
    return None


_MONTH_WORD_TO_N: dict[str, int] = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
}


def _structured_relative_calendar_bounds(
    lc: str,
    now: datetime,
) -> tuple[str | None, str | None]:
    """Ranges such as ``last month``, rolling ``past N months``, prior calendar ``year``."""
    if not lc.strip():
        return None, None
    today_u = now.astimezone(timezone.utc).date()
    ym = lc.strip().lower()

    if re.search(r"\blast\s+month\b", ym):
        end_d = date(today_u.year, today_u.month, 1) - timedelta(days=1)
        start_d = date(end_d.year, end_d.month, 1)
        return start_d.isoformat(), end_d.isoformat()

    m_or = re.search(
        r"\b(?:past|last|over\s+the\s+past)\s+(\d{1,2})\s*"
        r"(?:or|/|,|\s+and\s+|to\s+)\s*(\d{1,2})\s+months?\b",
        ym,
    )
    if m_or:
        mm = max(int(m_or.group(1)), int(m_or.group(2)))
        mm = min(max(mm, 1), 120)
        start_d = _subtract_months_clamped(today_u, mm)
        return start_d.isoformat(), today_u.isoformat()

    m_mult = re.search(
        r"\b(?:past|last|over\s+the\s+past|during\s+the\s+past|in\s+the\s+past)\s+"
        r"(?:the\s+last\s+)?(?:(one|two|three|four|five|six|seven|eight|nine|ten)"
        r"|(\d{1,3}))\s+months?\b",
        ym,
    )
    if m_mult:
        w, d = m_mult.group(1), m_mult.group(2)
        if w:
            mm = _MONTH_WORD_TO_N.get(w, 2)
        else:
            mm = int(d) if d else 1
        mm = min(max(mm, 1), 120)
        start_d = _subtract_months_clamped(today_u, mm)
        return start_d.isoformat(), today_u.isoformat()

    if re.search(r"\blast\s+few\s+months\b", ym):
        start_d = _subtract_months_clamped(today_u, 3)
        return start_d.isoformat(), today_u.isoformat()

    if re.search(r"\b(?:last|past|previous)\s+(?:calendar\s+)?year\b", ym):
        y0 = today_u.year - 1
        return date(y0, 1, 1).isoformat(), date(y0, 12, 31).isoformat()

    m_ty = re.search(
        r"\b(?:past|last|over\s+the\s+past)\s+(?:the\s+last\s+)?"
        r"(?:(one|two|three|four|five|six|seven|eight|nine|ten)|(\d{1,3}))"
        r"\s+years?\b",
        ym,
    )
    if m_ty:
        w, d = m_ty.group(1), m_ty.group(2)
        if w:
            ny = min(_MONTH_WORD_TO_N.get(w, 1), 50)
        else:
            ny = min(int(d) if d else 1, 50)
        start_d = _subtract_years_clamped(today_u, ny)
        return start_d.isoformat(), today_u.isoformat()

    return None, None


def _nl_date_anchor_spans(lc: str, now: datetime) -> list[tuple[date, int]]:
    """Calendar dates anchored at match position (for ``from/since ...`` probing)."""
    hint_year = now.astimezone(timezone.utc).date().year
    pending: list[tuple[int, tuple[str, ...]]] = []

    def _enqueue(start: int, parts: tuple[str, ...]) -> None:
        pending.append((start, parts))

    for m in _RE_DD_MON_Y.finditer(lc):
        _enqueue(m.start(), ("dmy", m.group(1), m.group(2), m.group(3)))
    for m in _RE_MON_DD_Y.finditer(lc):
        _enqueue(m.start(), ("mdy", m.group(1), m.group(2), m.group(3)))

    pending.sort(key=lambda t: (t[0], t[1][0]))
    keyed: dict[tuple[date, int], None] = {}

    for i, (start, tup) in enumerate(pending):
        try:
            ceiling_y: int | None = None
            ys_raw_early = tup[3]
            if len(str(ys_raw_early)) == 3:
                for _s2, tup2 in pending[i + 1 :]:
                    tl = tup2[3]
                    if len(str(tl)) == 4 and str(tl).isdigit():
                        yi = int(tl)
                        if 1900 <= yi <= 2200:
                            ceiling_y = yi
                            break

            yr: int | None
            if tup[0] == "dmy":
                dd_raw, mon_nm, ys_raw = tup[1], tup[2], tup[3]
                mi = _month_num(mon_nm)
                if mi is None:
                    continue
                yr = _normalize_calendar_year_digits(
                    ys_raw,
                    hint_year=hint_year,
                    ceiling_year=ceiling_y if len(str(ys_raw)) == 3 else None,
                )
                if yr is None:
                    continue
                d_conv = date(yr, mi, _day_int(dd_raw))
            else:
                mon_nm, dd_raw, ys_raw = tup[1], tup[2], tup[3]
                mi = _month_num(mon_nm)
                if mi is None:
                    continue
                yr = _normalize_calendar_year_digits(
                    ys_raw,
                    hint_year=hint_year,
                    ceiling_year=ceiling_y if len(str(ys_raw)) == 3 else None,
                )
                if yr is None:
                    continue
                d_conv = date(yr, mi, _day_int(dd_raw))
        except ValueError:
            continue
        hint_year = yr
        keyed.setdefault((d_conv, start), None)

    return sorted(((d, i) for d, i in keyed), key=lambda t: (t[1], t[0]))


def _structured_date_bounds(lc: str, now: datetime) -> tuple[str | None, str | None]:
    if not lc.strip():
        return None, None
    rel_start, rel_end = _structured_relative_calendar_bounds(lc, now)
    if rel_start is not None and rel_end is not None:
        return rel_start, rel_end
    lm = re.search(r"\blast\s+(\d{1,3})\s+days?\b", lc)
    if lm:
        n = min(max(int(lm.group(1)), 1), 365)
        end_d = now.astimezone(timezone.utc).date()
        start_d = end_d - timedelta(days=n)
        return start_d.isoformat(), end_d.isoformat()
    iso_hits = list(_ISO_DATE.finditer(lc))
    if len(iso_hits) >= 2:
        return iso_hits[0].group(), iso_hits[-1].group()
    if len(iso_hits) == 1:
        d0 = iso_hits[0].group()
        hi = iso_hits[0].start()
        if hi > 0 and _FROM_SINCE_AFTER.search(lc[:hi]):
            tail = now.astimezone(timezone.utc).date().isoformat()
            return d0, tail
        return d0, d0
    return None, None


def _natural_language_date_bounds(
    lc: str,
    now: datetime,
) -> tuple[str | None, str | None]:
    anchors = _nl_date_anchor_spans(lc, now)
    if len(anchors) >= 2:
        ordered = sorted({d for d, _ in anchors})
        return ordered[0].isoformat(), ordered[-1].isoformat()
    if len(anchors) == 1:
        solo, pos = anchors[0]
        if pos > 0 and _FROM_SINCE_AFTER.search(lc[:pos]):
            end_u = now.astimezone(timezone.utc).date().isoformat()
            return solo.isoformat(), end_u
        return solo.isoformat(), solo.isoformat()
    return None, None


def extract_transaction_history_date_bounds(
    validated_entities: dict[str, EntityRecord],
    user_scan: str | None,
    now: datetime,
) -> tuple[str | None, str | None]:
    """Resolve optional yyyy-mm-dd bounds from slots + conversational scan text."""
    raw = _combined_date_candidate_text(validated_entities, user_scan)
    lc = raw.strip().lower()
    st_s, ed_s = _structured_date_bounds(lc, now)
    if st_s is not None and ed_s is not None:
        return st_s, ed_s
    st_n, ed_n = _natural_language_date_bounds(lc, now)
    if st_n is not None and ed_n is not None:
        return st_n, ed_n
    return None, None


def _masked_display(acct_no: str) -> str:
    return f"****{acct_no[-4:]}" if len(acct_no) >= 4 else "****"


def _combine_flow_totals(rows: list[dict]) -> tuple[float, float]:
    inf = sum(float(r["amount"]) for r in rows if float(r["amount"]) > 0)
    out = sum(-float(r["amount"]) for r in rows if float(r["amount"]) < 0)
    return round(inf, 2), round(out, 2)


class TransactionHistoryTool(BaseTool):
    name: ClassVar[str] = "transaction_history"
    version: ClassVar[str] = "1.0.0"

    description: ClassVar[str] = (
        "Read-only retrieval of recent posted transactions (contributions, "
        "dividends, trades, withdrawals, fees) for a participant account."
    )
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = False

    input_schema: ClassVar[dict] = {
        "account_type": {
            "type": "string",
            "required": False,
            "description": "Canonical account type — optional when only one "
                           "account is on file.",
        },
        "date_range": {
            "type": "string",
            "required": False,
            "description": "Optional ISO date span or wording like \"last 30 days\".",
        },
    }

    allow_empty_validated_entities: ClassVar[bool] = True

    def execute(
        self,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        last_user_message: str = "",
        recent_user_queries_text: str = "",
        current_turn: int = 0,
    ) -> dict:
        now = datetime.now(timezone.utc)
        accounts_map: dict = account_context.get("accounts") or {}
        is_multi_account_user = len(accounts_map) > 1

        scan_for_accounts = account_detection_scan_text(
            recent_user_queries_text,
            last_user_message,
        )

        msg_requested = detect_requested_account_types(
            scan_for_accounts,
            accounts_map,
            include_history_nouns=True,
        )

        if msg_requested and (msg_requested == ["ALL"] or len(msg_requested) > 1):
            return self._process_multi_transactions(
                msg_requested,
                accounts_map,
                account_context,
                auth_token,
                validated_entities,
                now,
                scan_for_accounts,
            )

        account_entity = validated_entities.get("account_number")
        raw_account_number: str | None = None
        selected_account: dict | None = None

        if account_entity and account_entity.vault_token:
            try:
                raw_account_number = dereference_entity(account_entity, auth_token)
            except (KeyError, PermissionError) as exc:
                log.error("transaction_history_vault_fail", error=str(exc))
                return self._failure("Unable to verify account identity", now)
        else:
            requested_type: str | None = None
            acct_type_entity = validated_entities.get("account_type")
            slot_value = (
                getattr(acct_type_entity, "display_value", None)
                if acct_type_entity
                else None
            )
            if slot_value:
                if (
                    is_multi_account_user
                    and last_user_message
                    and msg_requested is None
                    and looks_like_fresh_transaction_history_request(
                        last_user_message,
                    )
                ):
                    available = ", ".join(sorted(accounts_map.keys())) or "none"
                    log.info(
                        "transaction_history_stale_account_type_slot",
                        slot_value=slot_value,
                        current_turn=current_turn,
                        last_user_message=last_user_message[:80],
                    )
                    return self._failure(
                        "Please specify which account you'd like to see transactions for. "
                        f"You have {available} on file.",
                        now,
                    )
                requested_type = str(slot_value)
            elif (
                msg_requested
                and msg_requested != ["ALL"]
                and len(msg_requested) == 1
            ):
                requested_type = msg_requested[0]

            if requested_type and accounts_map:
                acct = accounts_map.get(
                    resolve_account_type_alias(requested_type, accounts_map)
                )
                if acct is None:
                    available = ", ".join(sorted(accounts_map.keys())) or "none"
                    log.warning(
                        "transaction_history_unknown_account_type",
                        requested=requested_type,
                        available=available,
                    )
                    return self._failure(
                        f"You don't have a {requested_type} account on file. "
                        f"Available accounts: {available}.",
                        now,
                    )
                selected_account = acct
                raw_account_number = acct.get("account_number")
            elif len(accounts_map) == 1:
                selected_account = next(iter(accounts_map.values()))
                raw_account_number = selected_account.get("account_number")
            elif account_context.get("account_number"):
                raw_account_number = account_context["account_number"]

        if not raw_account_number:
            log.error(
                "transaction_history_no_account",
                accounts_count=len(accounts_map),
            )
            return self._failure("Missing account_number", now)

        try:
            return self._process_transactions(
                raw_account_number,
                validated_entities,
                account_context,
                auth_token,
                now,
                scan_for_accounts,
            )
        finally:
            try:
                del raw_account_number
            except NameError:
                pass

    def _process_transactions(
        self,
        raw_account_number: str,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        now: datetime,
        user_scan_for_dates: str = "",
    ) -> dict:
        api = _get_account_api()
        start_d, end_d = extract_transaction_history_date_bounds(
            validated_entities,
            user_scan_for_dates or None,
            now,
        )
        try:
            tx_api = api.get_transaction_history(
                account_number=raw_account_number,
                auth_token=auth_token,
                start_date=start_d,
                end_date=end_d,
                limit=50,
            )
        except ValueError as exc:
            log.warning("transaction_history_range_error", error=str(exc))
            return self._failure(str(exc), now)
        except Exception as exc:
            log.error("transaction_history_api_error", error=str(exc))
            return self._failure(str(exc), now, escalate=True)

        display_account = _masked_display(raw_account_number)
        account_type_val = tx_api.get("account_type") or ""

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "TRANSACTION_HISTORY",
            "account_display": display_account,
            "account_type": account_type_val,
            "plan_name": tx_api.get("plan_name", ""),
            "period_start": tx_api.get("period_start"),
            "period_end": tx_api.get("period_end"),
            "transaction_count": tx_api.get(
                "transaction_count",
                len(tx_api.get("transactions") or []),
            ),
            "transactions": tx_api.get("transactions") or [],
            "as_of": tx_api.get("as_of", now.isoformat()),
        }
        acct_type_entity = validated_entities.get("account_type")
        if acct_type_entity and acct_type_entity.display_value:
            result["account_type"] = acct_type_entity.display_value

        log.info(
            "transaction_history_complete",
            account_display=display_account,
            txn_count=len(result["transactions"]),
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    def _process_multi_transactions(
        self,
        requested: list[str],
        accounts_map: dict,
        account_context: dict,
        auth_token: str,
        validated_entities: dict[str, EntityRecord],
        now: datetime,
        scan_for_dates: str,
    ) -> dict:
        if requested == ["ALL"]:
            target_keys = sorted(accounts_map.keys())
        else:
            seen: set[str] = set()
            target_keys = []
            for tok in requested:
                resolved = resolve_account_type_alias(tok, accounts_map)
                if resolved in accounts_map and resolved not in seen:
                    seen.add(resolved)
                    target_keys.append(resolved)

        if not target_keys:
            available = ", ".join(sorted(accounts_map.keys())) or "none"
            return self._failure(
                f"None of the accounts you mentioned are on file. "
                f"Available accounts: {available}.",
                now,
            )

        if requested == ["ALL"] and len(target_keys) == 1:
            only = accounts_map[target_keys[0]]
            raw = only.get("account_number")
            if not raw:
                return self._failure("Missing account_number", now)
            try:
                return self._process_transactions(
                    raw,
                    validated_entities,
                    account_context,
                    auth_token,
                    now,
                    scan_for_dates,
                )
            finally:
                try:
                    del raw
                except NameError:
                    pass

        api = _get_account_api()
        start_d, end_d = extract_transaction_history_date_bounds(
            validated_entities,
            scan_for_dates or None,
            now,
        )
        per_account: list[dict] = []
        errors: list[str] = []
        total_inflow = 0.0
        total_outflow = 0.0

        for key in target_keys:
            acct = accounts_map[key]
            raw = acct.get("account_number")
            if not raw:
                errors.append(f"{key}: missing account number")
                continue
            try:
                tx_api = api.get_transaction_history(
                    account_number=raw,
                    auth_token=auth_token,
                    start_date=start_d,
                    end_date=end_d,
                    limit=50,
                )
            except Exception as exc:
                log.error(
                    "transaction_history_multi_api_error",
                    account_type=key,
                    error=str(exc),
                )
                errors.append(f"{key}: {exc}")
                continue
            finally:
                try:
                    del raw
                except NameError:
                    pass

            rows = tx_api.get("transactions") or []
            inf, ouf = _combine_flow_totals(rows if isinstance(rows, list) else [])
            total_inflow += inf
            total_outflow += ouf

            account_no = acct.get("account_number", "")
            per_account.append({
                "account_type": tx_api.get("account_type") or key,
                "account_display": _masked_display(str(account_no)),
                "plan_name": tx_api.get("plan_name", ""),
                "period_start": tx_api.get("period_start"),
                "period_end": tx_api.get("period_end"),
                "transaction_count": len(rows),
                "transactions": rows,
                "combined_inflow": inf,
                "combined_outflow": ouf,
                "as_of": tx_api.get("as_of", now.isoformat()),
            })

        if not per_account:
            return self._failure(
                "Unable to retrieve any transactions at this time. "
                + (errors[0] if errors else ""),
                now,
                escalate=True,
            )

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "TRANSACTION_HISTORY_MULTI",
            "accounts": per_account,
            "account_count": len(per_account),
            "combined_total_inflow": round(total_inflow, 2),
            "combined_total_outflow": round(total_outflow, 2),
            "as_of": now.isoformat(),
        }
        if errors:
            result["partial_errors"] = errors

        log.info(
            "transaction_history_multi_complete",
            account_count=len(per_account),
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    def _failure(self, message: str, now: datetime, *, escalate: bool = False) -> dict:
        log.warning("transaction_history_failed", reason=message, escalate=escalate)
        return {
            "transaction_result": {
                "success": False,
                "status": "FAILED",
                "operation": "TRANSACTION_HISTORY",
                "errors": [message],
            },
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.FAILED,
                error_message=message,
                last_updated_at=now,
            ),
            "escalation_requested": escalate,
        }

    def health_check(self) -> bool:
        return True
