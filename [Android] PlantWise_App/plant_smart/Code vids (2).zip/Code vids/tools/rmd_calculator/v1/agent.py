from __future__ import annotations

"""
Tool 5 - RMD Calculator.

Computes Required Minimum Distributions per IRS rules.

Regulatory gates (deterministic - no LLM):
    - SECURE Act 2.0 §107: RMDs begin at age 73 (previously 72).
    - IRS Publication 590-B Table III (Uniform Lifetime Table):
      RMD = prior_year_end_balance / distribution_period_factor.
    - IRC 4974: 25% excise tax on RMD shortfall; reduced to 10%
      if corrected within the 2-year correction window (SECURE 2.0).
    - Roth IRAs are exempt from lifetime RMDs (IRC 408A(c)(5)).

Taxonomy intents routed here:
    - RMD_CALCULATION  (retirement) - transactional
    - RMD_INQUIRY      (retirement) - informational

Required slots (RMD_CALCULATION):
    plan_type, date_of_birth

Write-ownership:
    transaction_result  - RMD calculation dict
    tool_exec           - execution lifecycle state
"""

from datetime import datetime, timezone, date
import math
from uuid import uuid4
from typing import ClassVar

from tools.base import BaseTool
from schemas.enums import AuthLevel, ToolExecutionStatus
from schemas.primitives import EntityRecord, ToolExecutionState
from vault.dereferencer import dereference_entity
from observability.logger import log
from regulatory.irs_limits import IRS_LIMITS
from regulatory.uniform_lifetime_table import (
    UNIFORM_LIFETIME_TABLE,
    get_distribution_period,
)


# Roth accounts exempt from lifetime RMDs.
# ROTH_IRA: always exempt (IRC 408A(c)(5)).
# ROTH_401K / ROTH_403B: exempt starting 2024 per SECURE Act 2.0 §325.
_ROTH_EXEMPT_TYPES: frozenset[str] = frozenset({
    "ROTH_IRA",
    "ROTH_401K",
    "ROTH_403B",
})

# Account types eligible for an RMD calculation. Non-retirement vehicles
# (BROKERAGE, JOINT, TRUST, CUSTODIAL, ...) carry no distribution
# requirement and are filtered out before the multi-account loop fires.
_RMD_ELIGIBLE_ACCOUNT_TYPES: frozenset[str] = frozenset({
    "401K", "ROTH_401K", "TRADITIONAL_IRA", "ROTH_IRA",
    "403B", "ROTH_403B", "457B", "SEP_IRA", "SIMPLE_IRA",
    "PENSION", "PROFIT_SHARING",
})


class RMDCalculatorTool(BaseTool):
    name: ClassVar[str] = "rmd_calculator"
    version: ClassVar[str] = "1.0.0"

    description: ClassVar[str] = (
        "Calculates the IRS Required Minimum Distribution (RMD) for a "
        "retirement account using IRS Publication 590-B Table III "
        "(Uniform Lifetime Table) and SECURE 2.0 \u00a7107 starting ages."
    )
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = False
    # Both required slots (date_of_birth, plan_type) are auto-filled
    # from account_context for authenticated single-account users; the
    # tool's _get_owner_age / _get_account_type resolvers handle that.
    # Permit empty validated_entities so the supervisor can route here
    # without a phantom slot value the entity_extraction allowed-values
    # guard would otherwise have to invent.
    allow_empty_validated_entities: ClassVar[bool] = True
    input_schema: ClassVar[dict] = {
        "plan_type":     {"type": "string", "required": True},
        "date_of_birth": {"type": "string", "required": True,
                           "format": "date"},
    }

    def execute(
        self,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        last_user_message: str = "",
    ) -> dict:
        """
        Calculate Required Minimum Distribution.

        Steps:
            1. Resolve account number.
            2. Determine owner age.
            3. Check Roth exemption.
            4. Check whether RMDs are required (age >= 73).
            5. Fetch prior year-end balance from account API.
            6. Look up distribution period factor from Uniform Lifetime Table.
            7. Compute RMD = prior_balance / factor.
            8. Compute remaining RMD after YTD distributions.
            9. Compute potential penalty if deadline passed.
            10. Scrub PII and return.

        When the user explicitly names two or more retirement plans in
        their utterance (e.g. "RMD on my 401k and IRA") OR asks for "all
        my retirement accounts", the per-account compute loop runs and
        an aggregated multi-account result is returned.
        """
        now = datetime.now(timezone.utc)
        accounts_map: dict = account_context.get("accounts") or {}

        # — Multi-account detection ——————————————————————————————————————————
        # Reuse balance_inquiry's well-tested message scanner, then keep
        # only the canonical retirement-eligible accounts (BROKERAGE etc.
        # have no RMD). Single-account user / single-type ask falls
        # through to the legacy single path.
        retirement_only_map = {
            k: v for k, v in accounts_map.items()
            if str(k).upper() in _RMD_ELIGIBLE_ACCOUNT_TYPES
        }
        msg_requested: list[str] | None = None
        if retirement_only_map and last_user_message:
            try:
                from tools.balance_inquiry.v1.agent import (
                    _detect_requested_account_types,
                )
                msg_requested = _detect_requested_account_types(
                    last_user_message, retirement_only_map,
                )
            except Exception:
                msg_requested = None

        if msg_requested and (
            msg_requested == ["ALL"] or len(msg_requested) > 1
        ):
            return self._process_multi_rmd(
                msg_requested, retirement_only_map,
                validated_entities, account_context, auth_token, now,
            )

        # — 1. Resolve account number —————————————————————————————————————————
        raw_account_number = self._resolve_account_number(
            validated_entities, account_context, auth_token,
        )
        if not raw_account_number:
            return self._failure("Missing account number", now)

        # Fix C2: Guarantee PII scrubbing even on unexpected exceptions.
        try:
            return self._process_rmd(
                raw_account_number, validated_entities,
                account_context, auth_token, now,
            )
        finally:
            try:
                del raw_account_number
            except NameError:
                pass

    def _process_rmd(
        self,
        raw_account_number: str,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        now: datetime,
    ) -> dict:
        """Inner RMD logic. PII scrubbing handled by caller's finally."""
        # — 2. Determine owner age ————————————————————————————————————————————
        owner_age = self._get_owner_age(validated_entities, account_context)
        if owner_age is None:
            return self._failure(
                "Owner age or date of birth is required for RMD calculation",
                now,
            )

        # — 3. Check Roth exemption ———————————————————————————————————————————
        account_type = self._get_account_type(validated_entities, account_context)
        if account_type.upper() in _ROTH_EXEMPT_TYPES:
            display_account = f"****{raw_account_number[-4:]}"
            result = {
                "success": True,
                "status": "COMPLETED",
                "operation": "RMD_CALCULATION",
                "account_display": display_account,
                "rmd_required": False,
                "reason": "Roth IRAs are exempt from lifetime RMDs (IRC 408A(c)(5))",
                "rmd_amount": 0.0,
                "remaining_rmd": 0.0,
                "penalty_if_missed": 0.0,
            }
            return {
                "transaction_result": result,
                "tool_exec": ToolExecutionState(
                    in_flight=False,
                    tool_agent_name=self.name,
                    status=ToolExecutionStatus.SUCCEEDED,
                    idempotency_key="",
                    last_updated_at=now,
                    result_payload=result,
                ),
            }

        # — 4. Check RMD start age ————————————————————————————————————————————
        if "RMD_START_AGE" not in IRS_LIMITS:
            log.error("missing_irs_limit_config", key="RMD_START_AGE")
            return self._failure(
                "System configuration error: RMD start age threshold not set. "
                "Please contact support.",
                now,
                escalate=True,
            )
        rmd_start_age = IRS_LIMITS["RMD_START_AGE"]
        owner_age_int = int(owner_age)

        if owner_age_int < rmd_start_age:
            display_account = f"****{raw_account_number[-4:]}"

            birth_year = self._get_birth_year(validated_entities, account_context)
            first_rmd_year = (birth_year + rmd_start_age) if birth_year else None

            result = {
                "success": True,
                "status": "COMPLETED",
                "operation": "RMD_CALCULATION",
                "account_display": display_account,
                "rmd_required": False,
                "owner_age": owner_age_int,
                "rmd_start_age": rmd_start_age,
                "first_rmd_year": first_rmd_year,
                "reason": (
                    f"RMDs are not required until age {rmd_start_age} "
                    f"(SECURE Act 2.0 §107). Current age: {owner_age_int}."
                ),
                "rmd_amount": 0.0,
                "remaining_rmd": 0.0,
                "penalty_if_missed": 0.0,
            }

            log.info(
                "rmd_not_required",
                owner_age=owner_age_int,
                rmd_start_age=rmd_start_age,
            )

            return {
                "transaction_result": result,
                "tool_exec": ToolExecutionState(
                    in_flight=False,
                    tool_agent_name=self.name,
                    status=ToolExecutionStatus.SUCCEEDED,
                    idempotency_key="",
                    last_updated_at=now,
                    result_payload=result,
                ),
            }

        # — 5. Fetch prior year-end balance ———————————————————————————————————
        try:
            api = _get_account_api()
            balance_data = api.get_prior_year_end_balance(
                account_number=raw_account_number,
                auth_token=auth_token,
            )
        except Exception as exc:
            log.error("rmd_calculator_api_error", error=str(exc))
            return self._failure(str(exc), now, escalate=True)

        prior_balance = balance_data.get("prior_year_end_balance", 0.0)
        if isinstance(prior_balance, str):
            try:
                prior_balance = float(prior_balance)
            except (ValueError, TypeError):
                return self._failure("Invalid prior-year balance from API", now, escalate=True)
        if math.isnan(prior_balance) or math.isinf(prior_balance):
            return self._failure("Invalid prior-year balance from API (NaN/Inf)", now, escalate=True)
        if prior_balance < 0:
            return self._failure("Prior-year balance cannot be negative", now, escalate=True)
        tax_year = balance_data.get("tax_year", datetime.now(timezone.utc).date().year - 1)

        # — 6. Distribution period factor —————————————————————————————————————
        try:
            distribution_period = get_distribution_period(owner_age_int)
        except ValueError as exc:
            return self._failure(str(exc), now, escalate=True)

        # C2: Guard against zero / negative distribution period
        if distribution_period <= 0:
            return self._failure(
                f"Invalid distribution period ({distribution_period}) for age {owner_age_int}. "
                "Cannot compute RMD.",
                now,
            )

        # — 7. Compute RMD ————————————————————————————————————————————————————
        rmd_amount = round(prior_balance / distribution_period, 2)

        # — 8. YTD distributions and remaining ————————————————————————————————
        # Fix H11: Guard against non-numeric ytd_distributions values
        # (e.g. "N/A", "pending") from external CRM data.
        raw_ytd = account_context.get("ytd_distributions", 0.0)
        try:
            ytd_distributions = float(raw_ytd)
        except (ValueError, TypeError):
            log.warning(
                "rmd_ytd_distributions_unparseable",
                raw_value=str(raw_ytd)[:50],
            )
            ytd_distributions = 0.0
        remaining_rmd = round(max(0.0, rmd_amount - ytd_distributions), 2)

        # — 9. Penalty calculation (IRC 4974) —————————————————————————————————
        if "RMD_PENALTY_RATE" not in IRS_LIMITS:
            log.error("missing_irs_limit_config", key="RMD_PENALTY_RATE")
            return self._failure(
                "System configuration error: RMD penalty rate not set. "
                "Please contact support.",
                now,
                escalate=True,
            )
        penalty_rate = IRS_LIMITS["RMD_PENALTY_RATE"]
        rmd_deadline_passed = account_context.get("rmd_deadline_passed", False)

        penalty_if_missed = 0.0
        if remaining_rmd > 0 and rmd_deadline_passed:
            # Check for correction window
            correction_window = account_context.get(
                "rmd_correction_window", False,
            )
            if correction_window and "RMD_CORRECTION_PENALTY_RATE" not in IRS_LIMITS:
                log.error("missing_irs_limit_config", key="RMD_CORRECTION_PENALTY_RATE")
                return self._failure(
                    "System configuration error: RMD correction penalty rate not set. "
                    "Please contact support.",
                    now,
                    escalate=True,
                )
            effective_rate = (
                IRS_LIMITS["RMD_CORRECTION_PENALTY_RATE"]
                if correction_window
                else penalty_rate
            )
            penalty_if_missed = round(remaining_rmd * effective_rate, 2)

        # — 10. Build display and result ——————————————————————————————————————
        display_account = f"****{raw_account_number[-4:]}"

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "RMD_CALCULATION",
            "account_display": display_account,
            "rmd_required": True,
            "owner_age": owner_age_int,
            "tax_year": tax_year,
            "prior_year_end_balance": prior_balance,
            "distribution_period": distribution_period,
            "rmd_amount": rmd_amount,
            "ytd_distributions": ytd_distributions,
            "remaining_rmd": remaining_rmd,
            "rmd_deadline_passed": rmd_deadline_passed,
            "penalty_if_missed": penalty_if_missed,
            "penalty_rate": penalty_rate if rmd_deadline_passed else 0.0,
        }

        log.info(
            "rmd_calculation_complete",
            account_display=display_account,
            owner_age=owner_age_int,
            rmd_amount=rmd_amount,
            remaining_rmd=remaining_rmd,
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    def _process_multi_rmd(
        self,
        requested: list[str],
        retirement_map: dict,
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
        now: datetime,
    ) -> dict:
        """Compute RMDs for multiple retirement accounts in one turn.

        ``requested`` is either ``["ALL"]`` (use every retirement account
        on file) or a list of canonical retirement-eligible keys.  Per
        account failures are captured into the aggregated result rather
        than aborting the whole turn.
        """
        # — Resolve target keys ——————————————————————————————————————————
        if requested == ["ALL"]:
            target_keys = sorted(retirement_map.keys())
        else:
            try:
                from tools.balance_inquiry.v1.agent import (
                    _resolve_account_type_alias,
                )
            except Exception:  # pragma: no cover — defensive
                _resolve_account_type_alias = lambda t, m: t  # type: ignore
            seen: set[str] = set()
            target_keys: list[str] = []
            for tok in requested:
                resolved = _resolve_account_type_alias(tok, retirement_map)
                if resolved in retirement_map and resolved not in seen:
                    seen.add(resolved)
                    target_keys.append(resolved)

        if not target_keys:
            available = ", ".join(sorted(retirement_map.keys())) or "none"
            return self._failure(
                f"None of the retirement plans you mentioned are on file. "
                f"Available retirement plans: {available}.",
                now,
            )

        # Single-target — fall back to the legacy single-account path so
        # the existing single-card render is used unchanged.
        if len(target_keys) == 1:
            sole = retirement_map[target_keys[0]]
            raw = sole.get("account_number")
            if not raw:
                return self._failure("Missing account_number", now)
            try:
                return self._process_rmd(
                    raw, validated_entities, account_context, auth_token, now,
                )
            finally:
                try:
                    del raw
                except NameError:
                    pass

        # — Per-account loop ———————————————————————————————————————————
        per_account: list[dict] = []
        errors: list[str] = []
        combined_rmd = 0.0
        combined_remaining = 0.0
        any_required = False

        for key in target_keys:
            acct = retirement_map[key]
            raw = acct.get("account_number")
            if not raw:
                errors.append(f"{key}: missing account number")
                continue

            # Per-account context override so the inner pipeline sees
            # only this account when resolving plan_type / balances.
            per_ctx = dict(account_context)
            per_ctx["accounts"] = {key: acct}
            # Drop any prior single-account explicit account_number that
            # would otherwise short-circuit ``_resolve_account_number``.
            per_ctx.pop("account_number", None)
            per_entities = dict(validated_entities)
            per_entities.pop("plan_type", None)
            per_entities.pop("account_type", None)

            try:
                inner = self._process_rmd(
                    raw, per_entities, per_ctx, auth_token, now,
                )
            except Exception as exc:  # pragma: no cover — defensive
                log.error(
                    "rmd_multi_per_account_error",
                    account_type=key,
                    error=str(exc),
                )
                errors.append(f"{key}: {exc}")
                continue
            finally:
                try:
                    del raw
                except NameError:
                    pass

            inner_result = inner.get("transaction_result") or {}
            if not inner_result.get("success"):
                errors.append(
                    f"{key}: {inner_result.get('reason', 'calculation failed')}"
                )
                continue

            entry = {
                "account_type": key,
                "account_display": inner_result.get("account_display", ""),
                "rmd_required": bool(inner_result.get("rmd_required")),
                "rmd_amount": float(inner_result.get("rmd_amount") or 0.0),
                "remaining_rmd": float(inner_result.get("remaining_rmd") or 0.0),
                "penalty_if_missed": float(inner_result.get("penalty_if_missed") or 0.0),
                "prior_year_end_balance": inner_result.get("prior_year_end_balance"),
                "tax_year": inner_result.get("tax_year"),
                "owner_age": inner_result.get("owner_age"),
                "rmd_start_age": inner_result.get("rmd_start_age"),
                "first_rmd_year": inner_result.get("first_rmd_year"),
                "reason": inner_result.get("reason"),
            }
            per_account.append(entry)
            if entry["rmd_required"]:
                any_required = True
                combined_rmd += entry["rmd_amount"]
                combined_remaining += entry["remaining_rmd"]

        if not per_account:
            return self._failure(
                "Unable to calculate RMD for any of the requested accounts. "
                + "; ".join(errors),
                now,
            )

        result = {
            "success": True,
            "status": "COMPLETED",
            "operation": "RMD_CALCULATION",
            "multi_account": True,
            "rmd_required": any_required,
            "per_account": per_account,
            "combined_rmd_amount": round(combined_rmd, 2),
            "combined_remaining_rmd": round(combined_remaining, 2),
            "account_count": len(per_account),
            "errors": errors,
        }

        log.info(
            "rmd_calculation_multi_complete",
            account_count=len(per_account),
            combined_rmd=combined_rmd,
            errors=len(errors),
        )

        return {
            "transaction_result": result,
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.SUCCEEDED,
                idempotency_key="",
                last_updated_at=now,
                result_payload=result,
            ),
        }

    #
    # Helpers
    # =========================================================================

    @staticmethod
    def _resolve_account_number(
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
        auth_token: str,
    ) -> str | None:
        """Resolve the account number to query against the recordkeeper.

        Resolution order:
            1. Vault-tokenised ``account_number`` entity (multi-account
               disambiguation by raw account digits).
            2. ``plan_type`` / ``account_type`` slot used to pick the
               matching entry from ``account_context.accounts``.
            3. Single-account auto-pick.
            4. Legacy flat ``account_context.account_number``.
        """
        acct_entity = validated_entities.get("account_number")
        if acct_entity and acct_entity.vault_token:
            try:
                return dereference_entity(acct_entity, auth_token)
            except (KeyError, PermissionError) as exc:
                log.error("rmd_calculator_vault_dereference_failed", error=str(exc))
                return None

        accounts_map = account_context.get("accounts") or {}
        plan_entity = validated_entities.get("plan_type") or validated_entities.get(
            "account_type",
        )
        requested_type = (
            getattr(plan_entity, "display_value", None) if plan_entity else None
        )
        if requested_type and accounts_map:
            # Case-insensitive lookup with light alias matching.
            wanted = str(requested_type).upper().replace(" ", "_").replace("(", "").replace(")", "").replace("-", "_")
            for key, acct in accounts_map.items():
                if str(key).upper() == wanted and acct.get("account_number"):
                    return str(acct["account_number"])
            # Fuzzy: try contains match (e.g. "401K" in "ROTH_401K").
            for key, acct in accounts_map.items():
                ku = str(key).upper()
                if (wanted in ku or ku in wanted) and acct.get("account_number"):
                    return str(acct["account_number"])

        if len(accounts_map) == 1:
            sole = next(iter(accounts_map.values()))
            if sole.get("account_number"):
                return str(sole["account_number"])

        return account_context.get("account_number")

    @staticmethod
    def _get_owner_age(
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
    ) -> float | None:
        """Extract owner age from entities or context.

        Fix 140: IRS Pub 590-B uses the age attained during the
        calendar year, i.e. age as-of December 31 of the distribution
        year - NOT the current date.
        """
        # Fix 140: IRS Pub 590-B uses the age attained during the
        # calendar year, i.e. age as-of December 31 of the distribution
        # year - NOT the current date.
        #
        # Fix H6: Accept tax_year from validated_entities so users can ask
        # "What's my RMD for 2024?" and get the correct calculation even
        # when the current year is different.
        tax_year_entity = validated_entities.get("tax_year")
        if tax_year_entity and tax_year_entity.display_value:
            try:
                requested_year = int(tax_year_entity.display_value)
                # Sanity-check: reject years more than 1 year in the future
                # or before 1960 (no one needs RMD history that far back)
                current_year = datetime.now(timezone.utc).year
                if 1960 <= requested_year <= current_year + 1:
                    ref_date = date(requested_year, 12, 31)
                else:
                    ref_date = date(current_year, 12, 31)
            except (ValueError, TypeError):
                ref_date = date(datetime.now(timezone.utc).year, 12, 31)
        else:
            ref_date = date(datetime.now(timezone.utc).year, 12, 31)

        # Try date_of_birth entity -> compute age
        dob_entity = validated_entities.get("date_of_birth")
        if dob_entity and dob_entity.display_value:
            try:
                dob = date.fromisoformat(dob_entity.display_value)
                age = ref_date.year - dob.year
                if (ref_date.month, ref_date.day) < (dob.month, dob.day):
                    age -= 1
                # M3: Bounds check - skip impossible ages
                if 0 <= age <= 150:
                    return float(age)
            except (ValueError, TypeError):
                pass

        # Try explicit age entity
        age_entity = validated_entities.get("owner_age")
        if age_entity and age_entity.display_value:
            try:
                val = float(age_entity.display_value)
                # M3: Bounds check
                if 0 <= val <= 150:
                    return val
            except (ValueError, TypeError):
                pass

        # Fall back to context
        ctx_age = account_context.get("owner_age_years")
        if ctx_age is not None:
            try:
                val = float(ctx_age)
                if 0 <= val <= 150:
                    return val
            except (ValueError, TypeError):
                pass

        ctx_age2 = account_context.get("owner_age")
        if ctx_age2 is not None:
            try:
                val = float(ctx_age2)
                if 0 <= val <= 150:
                    return val
            except (ValueError, TypeError):
                pass

        # Try computing from DOB in context
        ctx_dob = account_context.get("owner_dob")
        if ctx_dob:
            try:
                dob = date.fromisoformat(str(ctx_dob))
                age = ref_date.year - dob.year
                if (ref_date.month, ref_date.day) < (dob.month, dob.day):
                    age -= 1
                if 0 <= age <= 150:
                    return float(age)
            except (ValueError, TypeError):
                pass

        return None

    @staticmethod
    def _get_birth_year(
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
    ) -> int | None:
        """Extract birth year for first_rmd_year calculation."""
        dob_entity = validated_entities.get("date_of_birth")
        if dob_entity and dob_entity.display_value:
            try:
                return date.fromisoformat(dob_entity.display_value).year
            except (ValueError, TypeError):
                pass

        ctx_dob = account_context.get("owner_dob")
        if ctx_dob:
            try:
                return date.fromisoformat(str(ctx_dob)).year
            except (ValueError, TypeError):
                pass

        return account_context.get("birth_year")

    @staticmethod
    def _get_account_type(
        validated_entities: dict[str, EntityRecord],
        account_context: dict,
    ) -> str:
        """Resolve the plan/account type for the calculation.

        Resolution order (highest priority first):
            1. Validated ``plan_type`` / ``account_type`` entity from the
               current turn (covers user-supplied disambiguation).
            2. ``account_context.account_type`` legacy flat field.
            3. ``account_context.plan_type`` (legacy flat) — most demo
               profiles use this key, not ``account_type``.
            4. Single-account auto-pick: when ``account_context.accounts``
               has exactly one entry, its key is unambiguous.
            5. ``account_context.primary_account_type`` declared default.
        """
        entity = validated_entities.get("plan_type") or validated_entities.get(
            "account_type",
        )
        if entity and entity.display_value:
            return entity.display_value
        for key in ("account_type", "plan_type"):
            val = account_context.get(key)
            if val:
                return str(val)
        accounts_map = account_context.get("accounts") or {}
        if len(accounts_map) == 1:
            sole = next(iter(accounts_map.values()))
            sole_type = sole.get("account_type") or sole.get("plan_type")
            if sole_type:
                return str(sole_type)
            # Fallback to the dict key if the inner record omits the type.
            return str(next(iter(accounts_map.keys())))
        primary = account_context.get("primary_account_type")
        if primary:
            return str(primary)
        return ""

    def _failure(self, message: str, now: datetime, *, escalate: bool = False) -> dict:
        """Build a standardized failure response.

        Args:
            escalate: True for system/API errors that need human intervention.
                      False for user-input validation failures that can be
                      re-collected through the normal slot-filling flow.
        """
        log.warning("rmd_calculator_failed", reason=message, escalate=escalate)
        return {
            "transaction_result": {
                "success": False,
                "status": "FAILED",
                "operation": "RMD_CALCULATION",
                "errors": [message],
            },
            "tool_exec": ToolExecutionState(
                in_flight=False,
                tool_agent_name=self.name,
                status=ToolExecutionStatus.FAILED,
                error_message=message,
                last_updated_at=now,
            ),
            "escalation_requested": escalate,
        }

    def health_check(self) -> bool:
        return True


# — Module-level lazy singleton for the account API ———————————————————————————
import threading as _threading

_account_api_instance = None
_account_api_lock = _threading.Lock()


def _get_account_api():
    global _account_api_instance
    if _account_api_instance is not None:
        return _account_api_instance
    with _account_api_lock:
        if _account_api_instance is None:
            from tools.api_factory import create_account_api
            _account_api_instance = create_account_api()
    return _account_api_instance


def set_account_api(api) -> None:
    """Test helper - inject a pre-seeded MockAccountAPI."""
    global _account_api_instance
    _account_api_instance = api
