"""Centralised API client factories for tools.

Decouples production tool code from any concrete backend.
Switch via ``settings.tool_api_provider``:

  - ``mock`` -> in-process ``mock_services.inprocess.*`` stubs (default).
  - ``http`` -> HTTP clients in ``tools.clients.http.*`` that talk
                to ``mock_services.account_service`` (run with
                ``python -m mock_services.account_service``).
  - ``real`` -> production recordkeeper / custodian clients (TBD).

Each tool calls the appropriate factory here instead of importing
implementations directly.
"""

from __future__ import annotations

from config import settings


def create_account_api():
    """Create an AccountAPI instance based on configuration."""
    provider = settings.tool_api_provider
    if provider == "mock":
        from mock_services.inprocess.account_api import MockAccountAPI

        return MockAccountAPI()
    if provider == "http":
        from tools.clients.http.account_api import HttpAccountAPI

        return HttpAccountAPI()
    raise NotImplementedError(
        f"Account API provider '{provider}' is not implemented. "
        "Set tool_api_provider='mock' or 'http'."
    )


def create_disbursement_api():
    """Create a DisbursementAPI instance based on configuration."""
    provider = settings.tool_api_provider
    if provider == "mock":
        from mock_services.inprocess.disbursement_api import MockDisbursementAPI

        return MockDisbursementAPI()
    if provider == "http":
        from tools.clients.http.disbursement_api import HttpDisbursementAPI

        return HttpDisbursementAPI()
    raise NotImplementedError(
        f"Disbursement API provider '{provider}' is not implemented."
    )


def create_loan_api():
    """Create a LoanAPI instance based on configuration."""
    provider = settings.tool_api_provider
    if provider == "mock":
        from mock_services.inprocess.loan_api import MockLoanAPI

        return MockLoanAPI()
    if provider == "http":
        from tools.clients.http.loan_api import HttpLoanAPI

        return HttpLoanAPI()
    raise NotImplementedError(
        f"Loan API provider '{provider}' is not implemented."
    )
