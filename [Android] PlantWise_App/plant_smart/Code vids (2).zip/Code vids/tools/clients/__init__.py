"""HTTP-backed implementations of the AccountAPI / LoanAPI / DisbursementAPI surfaces.

Each class exposes the same public methods as the in-process mocks at
``mock_services.inprocess.*`` and returns the same response dicts. On
HTTP error, the ``error_code`` in the response envelope is mapped back
to the original exception class so tool ``try/except`` blocks
keep working unchanged.
"""
