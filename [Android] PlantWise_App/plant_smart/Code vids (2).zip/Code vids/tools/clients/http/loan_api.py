"""HTTP-backed LoanAPI client. Drop-in replacement for ``MockLoanAPI``."""

from __future__ import annotations

from typing import Any

from ._transport import auth_headers, get_client, parse_response


class HttpLoanAPI:
    _API = "loan"

    def get_loan_eligibility(
        self,
        account_number: str,
        vested_balance: float,
        outstanding_loan_balance: float,
        highest_loan_balance_12m: float,
        plan_allows_loans: bool,
        auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.post(
                "/v1/loans/eligibility",
                headers=auth_headers(auth_token),
                json={
                    "account_number": account_number,
                    "vested_balance": vested_balance,
                    "outstanding_loan_balance": outstanding_loan_balance,
                    "highest_loan_balance_12m": highest_loan_balance_12m,
                    "plan_allows_loans": plan_allows_loans,
                },
            )
        return parse_response(r, api=self._API)

    def initiate_loan(
        self,
        account_number: str,
        amount: float,
        term_months: int,
        auth_token: str,
        loan_type: str = "GENERAL_PURPOSE",
        interest_rate: float | None = None,
        vested_balance: float = 0.0,
        outstanding_loan_balance: float = 0.0,
        highest_loan_balance_12m: float = 0.0,
        plan_allows_loans: bool = True,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "account_number": account_number,
            "amount": amount,
            "term_months": term_months,
            "loan_type": loan_type,
            "vested_balance": vested_balance,
            "outstanding_loan_balance": outstanding_loan_balance,
            "highest_loan_balance_12m": highest_loan_balance_12m,
            "plan_allows_loans": plan_allows_loans,
        }
        if interest_rate is not None:
            body["interest_rate"] = interest_rate

        with get_client() as c:
            r = c.post(
                "/v1/loans",
                headers=auth_headers(auth_token, idempotency_key=idempotency_key),
                json=body,
            )
        return parse_response(r, api=self._API)

    def get_loan_status(self, loan_id: str, auth_token: str) -> dict[str, Any]:
        with get_client() as c:
            r = c.get(
                f"/v1/loans/{loan_id}",
                headers=auth_headers(auth_token),
            )
        return parse_response(r, api=self._API)

    def make_payment(
        self, loan_id: str, payment_amount: float, auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.post(
                f"/v1/loans/{loan_id}/payments",
                headers=auth_headers(auth_token),
                json={"payment_amount": payment_amount},
            )
        return parse_response(r, api=self._API)
