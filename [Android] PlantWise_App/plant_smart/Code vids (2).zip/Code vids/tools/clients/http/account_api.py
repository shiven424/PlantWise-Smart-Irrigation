"""HTTP-backed AccountAPI client.

Implements the same method surface as ``MockAccountAPI`` so it is a
drop-in replacement behind ``tools.api_factory``.
"""

from __future__ import annotations

from typing import Any

from ._transport import auth_headers, get_client, parse_response


class HttpAccountAPI:
    _API = "account"

    def get_balance(self, account_number: str, auth_token: str) -> dict[str, Any]:
        with get_client() as c:
            r = c.get(
                f"/v1/accounts/{account_number}/balance",
                headers=auth_headers(auth_token),
            )
        return parse_response(r, api=self._API)

    def get_prior_year_end_balance(
        self, account_number: str, auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.get(
                f"/v1/accounts/{account_number}/prior-year-balance",
                headers=auth_headers(auth_token),
            )
        return parse_response(r, api=self._API)

    def get_account_details(
        self, account_number: str, auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.get(
                f"/v1/accounts/{account_number}",
                headers=auth_headers(auth_token),
            )
        return parse_response(r, api=self._API)

    def get_beneficiaries(
        self, account_number: str, auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.get(
                f"/v1/accounts/{account_number}/beneficiaries",
                headers=auth_headers(auth_token),
            )
        return parse_response(r, api=self._API)

    def update_beneficiaries(
        self,
        account_number: str,
        beneficiaries: list[dict[str, Any]],
        auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.put(
                f"/v1/accounts/{account_number}/beneficiaries",
                headers=auth_headers(auth_token),
                json={"beneficiaries": beneficiaries},
            )
        return parse_response(r, api=self._API)

    def initiate_rollover(
        self,
        source_account: str,
        destination_account: str,
        amount: float,
        rollover_type: str,
        auth_token: str,
    ) -> dict[str, Any]:
        with get_client() as c:
            r = c.post(
                f"/v1/accounts/{source_account}/rollover",
                headers=auth_headers(auth_token),
                json={
                    "destination_account": destination_account,
                    "amount": amount,
                    "rollover_type": rollover_type,
                },
            )
        return parse_response(r, api=self._API)
