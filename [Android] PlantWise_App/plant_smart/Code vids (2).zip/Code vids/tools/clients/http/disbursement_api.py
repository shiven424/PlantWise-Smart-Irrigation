"""HTTP-backed DisbursementAPI client. Drop-in replacement for ``MockDisbursementAPI``."""

from __future__ import annotations

from typing import Any

from ._transport import auth_headers, get_client, parse_response


class HttpDisbursementAPI:
    _API = "disbursement"

    def submit_ach(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        state_withholding_rate: float = 0.0,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "account_number": account_number,
            "bank_routing_number": bank_routing_number,
            "bank_account_number": bank_account_number,
            "amount": amount,
            "disbursement_type": disbursement_type,
            "owner_age": owner_age,
            "state_withholding_rate": state_withholding_rate,
        }
        if custom_withholding_rate is not None:
            body["custom_withholding_rate"] = custom_withholding_rate
        with get_client() as c:
            r = c.post(
                "/v1/disbursements/ach",
                headers=auth_headers(auth_token, idempotency_key=idempotency_key),
                json=body,
            )
        return parse_response(r, api=self._API)

    def submit_wire(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "account_number": account_number,
            "bank_routing_number": bank_routing_number,
            "bank_account_number": bank_account_number,
            "amount": amount,
            "disbursement_type": disbursement_type,
            "owner_age": owner_age,
        }
        if custom_withholding_rate is not None:
            body["custom_withholding_rate"] = custom_withholding_rate
        with get_client() as c:
            r = c.post(
                "/v1/disbursements/wire",
                headers=auth_headers(auth_token, idempotency_key=idempotency_key),
                json=body,
            )
        return parse_response(r, api=self._API)

    def submit_check(
        self,
        account_number: str,
        mailing_address: str,
        amount: float,
        auth_token: str,
        disbursement_type: str = "WITHDRAWAL",
        owner_age: float = 60.0,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "account_number": account_number,
            "mailing_address": mailing_address,
            "amount": amount,
            "disbursement_type": disbursement_type,
            "owner_age": owner_age,
        }
        if custom_withholding_rate is not None:
            body["custom_withholding_rate"] = custom_withholding_rate
        with get_client() as c:
            r = c.post(
                "/v1/disbursements/check",
                headers=auth_headers(auth_token, idempotency_key=idempotency_key),
                json=body,
            )
        return parse_response(r, api=self._API)

    def submit_rmd_distribution(
        self,
        account_number: str,
        bank_routing_number: str,
        bank_account_number: str,
        rmd_amount: float,
        owner_age: float,
        auth_token: str,
        custom_withholding_rate: float | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "account_number": account_number,
            "bank_routing_number": bank_routing_number,
            "bank_account_number": bank_account_number,
            "rmd_amount": rmd_amount,
            "owner_age": owner_age,
        }
        if custom_withholding_rate is not None:
            body["custom_withholding_rate"] = custom_withholding_rate
        with get_client() as c:
            r = c.post(
                "/v1/disbursements/rmd",
                headers=auth_headers(auth_token, idempotency_key=idempotency_key),
                json=body,
            )
        return parse_response(r, api=self._API)
