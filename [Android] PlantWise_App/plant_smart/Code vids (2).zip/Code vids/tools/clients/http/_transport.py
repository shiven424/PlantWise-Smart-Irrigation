"""Shared HTTP transport helpers for the http-backed API clients.

Centralises:
  - httpx.Client construction (pooling, timeout)
  - Bearer auth header injection
  - Error envelope -> exception mapping (re-raises the same class the
    in-process mock would raise, preserving tool behaviour)
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from config import settings
from mock_services.inprocess.account_api import (
    AccountFrozenError,
    AccountNotFoundError,
    AuthorizationError as AccountAuthError,
    InsufficientBalanceError,
)
from mock_services.inprocess.disbursement_api import (
    AuthorizationError as DisbAuthError,
    DisbursementRejectedError,
    DuplicateRequestError,
    InvalidRoutingNumberError,
)
from mock_services.inprocess.loan_api import (
    AuthorizationError as LoanAuthError,
    DuplicateLoanError,
    LoanNotFoundError,
    LoanRejectedError,
    PlanDoesNotAllowLoansError,
)


_log = logging.getLogger("tools.clients.http")


# error_code (from service envelope) -> exception class.
# Auth errors map to the AccountAPI variant by default; all three classes
# are defined identically so ``except AuthorizationError`` keeps working
# regardless of which API raised it.
_ERROR_CODE_MAP: dict[str, type[Exception]] = {
    "UNAUTHORIZED": AccountAuthError,
    "MISSING_TOKEN": AccountAuthError,
    "INVALID_TOKEN": AccountAuthError,
    "ACCOUNT_NOT_FOUND": AccountNotFoundError,
    "LOAN_NOT_FOUND": LoanNotFoundError,
    "ACCOUNT_FROZEN": AccountFrozenError,
    "INSUFFICIENT_BALANCE": InsufficientBalanceError,
    "INVALID_ROUTING_NUMBER": InvalidRoutingNumberError,
    "DUPLICATE_REQUEST": DuplicateRequestError,
    "DUPLICATE_LOAN": DuplicateLoanError,
    "PLAN_DISALLOWS_LOANS": PlanDoesNotAllowLoansError,
    "LOAN_REJECTED": LoanRejectedError,
    "DISBURSEMENT_REJECTED": DisbursementRejectedError,
    "VALIDATION_ERROR": ValueError,
}


# Per-API auth-error overrides so that an auth failure raised by a loan
# call still raises ``loan_api.AuthorizationError`` (some tests catch the
# specific subclass).
def auth_error_for(api: str) -> type[Exception]:
    return {
        "loan": LoanAuthError,
        "disbursement": DisbAuthError,
    }.get(api, AccountAuthError)


def get_client() -> httpx.Client:
    """Create a fresh ``httpx.Client`` configured from settings.

    A fresh client per call keeps wiring trivial; tools already
    construct API instances per-turn so additional pooling is unnecessary
    for the demo. Switch to a module-level singleton if perf demands it.
    """
    return httpx.Client(
        base_url=settings.account_api_base_url,
        timeout=settings.account_api_timeout_s,
        headers={"User-Agent": "agent-app/1.0"},
    )


def auth_headers(token: str, *, idempotency_key: str | None = None) -> dict[str, str]:
    if not token:
        # Match the in-process mock contract: empty token -> AuthorizationError
        # *before* any HTTP request is made.
        raise AccountAuthError("auth_token is required")
    h = {"Authorization": f"Bearer {token}"}
    if idempotency_key:
        h["Idempotency-Key"] = idempotency_key
    return h


def parse_response(
    response: httpx.Response, *, api: str = "account",
) -> dict[str, Any]:
    """Return the JSON body or raise the mapped exception class."""
    if 200 <= response.status_code < 300:
        return response.json()

    try:
        envelope = response.json()
    except Exception:  # noqa: BLE001
        envelope = {}

    code = str(envelope.get("error_code") or "")
    message = str(envelope.get("message") or response.text)

    # 401 always maps to the api-specific AuthorizationError subclass.
    if response.status_code == 401 or code in {"UNAUTHORIZED", "MISSING_TOKEN", "INVALID_TOKEN"}:
        raise auth_error_for(api)(message or "unauthorized")

    exc_cls = _ERROR_CODE_MAP.get(code)
    if exc_cls is not None:
        raise exc_cls(message)

    # Pydantic 422 from the service (request validation) — surface as ValueError
    # so tools see a consistent failure shape.
    if response.status_code == 422:
        raise ValueError(message or "request validation failed")

    _log.error(
        "http_client.unmapped_error status=%d code=%s msg=%s",
        response.status_code, code, message,
    )
    raise RuntimeError(
        f"unexpected status {response.status_code} from account service: {message}"
    )
