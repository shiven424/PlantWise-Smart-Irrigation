from __future__ import annotations

"""
ChromaDB-backed vector store implementing the KnowledgeBase interface.

Stores document chunks with dense embeddings and metadata.  Supports
metadata-filtered search (e.g. by ``service_domain`` or ``doc_type``).
"""

import logging
from pathlib import Path

import chromadb
from chromadb.config import Settings as ChromaSettings

from config import settings
from knowledge_base.base import ChunkResult, KnowledgeBase

logger = logging.getLogger(__name__)

# ChromaDB caps a single add/query at internally limited batch sizes.
# We split large ingestion payloads into batches of this size.
_CHROMA_BATCH_SIZE = 5_000


class ChromaVectorStore(KnowledgeBase):
    """
    Persistent ChromaDB collection for the contact-center knowledge base.

    Parameters
    ----------
    collection_name : str
        Name of the ChromaDB collection (default ``"kb_chunks"``).
    persist_directory : str | None
        Path for on-disk persistence.  Falls back to
        ``settings.chromadb_path`` (default ``"./data/chromadb"``).
    """

    def __init__(
        self,
        collection_name: str = "kb_chunks",
        persist_directory: str | None = None,
    ) -> None:
        self._persist_dir = persist_directory or settings.chromadb_path
        Path(self._persist_dir).mkdir(parents=True, exist_ok=True)

        self._client = chromadb.PersistentClient(
            path=self._persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        actual_space = (self._collection.metadata or {}).get("hnsw:space")
        if actual_space and actual_space != "cosine":
            raise RuntimeError(
                f"ChromaDB collection '{collection_name}' exists with "
                f"hnsw:space='{actual_space}' but expected 'cosine'. "
                f"Delete and re-index, or use a different collection name."
            )
        logger.info(
            "ChromaVectorStore ready - collection=%s, chunks=%d",
            collection_name,
            self._collection.count(),
        )

    # -----------------------------------------------------------------------
    # KnowledgeBase interface
    # -----------------------------------------------------------------------

    def add_documents(
        self,
        chunks: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict],
        ids: list[str],
    ) -> None:
        """Upsert chunks in batches to stay within ChromaDB limits."""
        if not chunks:
            raise ValueError("Cannot add empty batch - must provide at least 1 chunk.")
        lengths = (len(chunks), len(embeddings), len(metadatas), len(ids))
        if len(set(lengths)) != 1:
            raise ValueError(
                f"Misaligned input lists: chunks={lengths[0]}, "
                f"embeddings={lengths[1]}, metadatas={lengths[2]}, ids={lengths[3]}"
            )
        total = len(chunks)
        for start in range(0, total, _CHROMA_BATCH_SIZE):
            end = min(start + _CHROMA_BATCH_SIZE, total)
            self._collection.upsert(
                ids=ids[start:end],
                documents=chunks[start:end],
                embeddings=embeddings[start:end],
                metadatas=metadatas[start:end],
            )
        logger.info("Upserted %d chunks into collection.", total)

    def search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        metadata_filter: dict | None = None,
    ) -> list[ChunkResult]:
        """Dense cosine-similarity search with optional metadata filter."""
        query_kwargs: dict = {
            "query_embeddings": [query_embedding],
            "n_results": top_k,
            "include": ["documents", "metadatas", "distances"],
        }
        if metadata_filter:
            query_kwargs["where"] = metadata_filter

        results = self._collection.query(**query_kwargs)

        # ChromaDB returns lists-of-lists (one list per query).
        chunk_results: list[ChunkResult] = []
        for idx in range(len(results["ids"][0])):
            # ChromaDB returns cosine *distance*; convert to similarity.
            # Clamp to [0, 1] as a safety net: cosine distance is normally
            # in [0, 2] for normalised vectors (making similarity [-1, 1]),
            # but clamping protects against non-normalised embeddings or
            # future model changes.
            distance = results["distances"][0][idx]
            similarity = max(0.0, min(1.0, 1.0 - distance))

            chunk_results.append(
                ChunkResult(
                    chunk_id=results["ids"][0][idx],
                    text=results["documents"][0][idx],
                    score=round(similarity, 4),
                    metadata=results["metadatas"][0][idx],
                )
            )
        return chunk_results

    def delete(self, ids: list[str]) -> None:
        """Delete chunks by their IDs."""
        if ids:
            self._collection.delete(ids=ids)
            logger.info("Deleted %d chunks.", len(ids))

    def count(self) -> int:
        """Return total number of stored chunks."""
        return self._collection.count()

    def reset_collection(self) -> None:
        """Drop and recreate the collection.  Destructive - use in tests only."""
        name = self._collection.name
        self._client.delete_collection(name)
        self._collection = self._client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"},
        )
        logger.warning("Collection '%s' reset (all chunks deleted).", name)
