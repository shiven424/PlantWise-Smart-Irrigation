from __future__ import annotations

"""
Abstract Knowledge Base interface.

Every knowledge base backend (ChromaDB, Pinecone, etc.) implements this
contract so the RAG agent can swap providers via config without touching
retrieval logic.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

# Shared constant for domain metadata key format.
# Used by indexer (write) and retriever (read) to stay in sync.
DOMAIN_KEY_FORMAT = "domain__{}"


@dataclass
class ChunkResult:
    """Single retrieval result returned by a knowledge base search."""

    chunk_id: str
    text: str
    score: float
    metadata: dict = field(default_factory=dict)


class KnowledgeBase(ABC):
    """
    Abstract interface that every vector-store backend must implement.

    Methods
    -------
    add_documents(chunks, embeddings, metadatas, ids)
        Upsert document chunks with their embeddings and metadata.
    search(query_embedding, top_k, metadata_filter)
        Dense similarity search - returns the top-k most relevant chunks.
    delete(ids)
        Remove chunks by their IDs.
    count()
        Return the total number of stored chunks.
    """

    @abstractmethod
    def add_documents(
        self,
        chunks: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict],
        ids: list[str],
    ) -> None:
        """Upsert chunks with pre-computed embeddings and metadata."""

    @abstractmethod
    def search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        metadata_filter: dict | None = None,
    ) -> list[ChunkResult]:
        """Return the top-k chunks most similar to *query_embedding*."""

    @abstractmethod
    def delete(self, ids: list[str]) -> None:
        """Delete chunks by their IDs."""

    @abstractmethod
    def count(self) -> int:
        """Return the total number of stored chunks."""
