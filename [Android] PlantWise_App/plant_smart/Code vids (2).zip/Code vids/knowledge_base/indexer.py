from __future__ import annotations

"""
Document indexer - reads files, chunks them, and upserts into the vector store.

Supports two chunking strategies (set per-document in ``document_metadata.json``):

* **sliding_window** - overlapping fixed-size windows for prose-heavy documents
  (statutes, regulations, revenue rulings).
* **structured** - section/Q&A-aware splitting for tabular or structured documents
  (SPD, fee schedules, FAQ, forms, rate tables).

Usage
-----
    from knowledge_base.indexer import Indexer
    indexer = Indexer()
    stats = indexer.index_all()       # ingest entire knowledge base
    stats = indexer.index_file(...)   # ingest a single document
"""

import hashlib
import json
import logging
import re
from pathlib import Path

from knowledge_base.base import DOMAIN_KEY_FORMAT
from knowledge_base.embedder import Embedder
from knowledge_base.vector_store import ChromaVectorStore

logger = logging.getLogger(__name__)

# -- Chunking defaults -------------------------------------------------------
_SLIDING_WINDOW_SIZE = 512        # characters per chunk
_SLIDING_WINDOW_OVERLAP = 128     # overlap between consecutive chunks
_STRUCTURED_MAX_SECTION = 1024    # max characters for a structured section chunk
_MIN_CHUNK_LENGTH = 50            # discard chunks shorter than this

# Path to the documents folder and metadata manifest.
_DOCS_DIR = Path(__file__).resolve().parent / "documents"
_METADATA_PATH = _DOCS_DIR / "document_metadata.json"


# -- File loaders ------------------------------------------------------------

def _load_text(path: Path) -> str:
    """Read a UTF-8 text file."""
    return path.read_text(encoding="utf-8")


def _load_pdf(path: Path) -> str:
    """Extract text from all pages of a PDF using pypdf."""
    from pypdf import PdfReader  # deferred import - heavy dependency

    reader = PdfReader(str(path))
    pages: list[str] = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            pages.append(text)
    return "\n\n".join(pages)


# -- Chunking strategies -----------------------------------------------------

def _chunk_sliding_window(
    text: str,
    window: int = _SLIDING_WINDOW_SIZE,
    overlap: int = _SLIDING_WINDOW_OVERLAP,
) -> list[str]:
    """Split *text* into overlapping fixed-size windows."""
    # Fix M17: Guard against overlap >= window which would cause
    # step size <= 0 and an infinite loop.
    if overlap >= window:
        overlap = max(0, window - 1)
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = start + window
        chunk = text[start:end].strip()
        if len(chunk) >= _MIN_CHUNK_LENGTH:
            chunks.append(chunk)
        start += window - overlap
    return chunks


def _chunk_structured(
    text: str,
    max_section: int = _STRUCTURED_MAX_SECTION,
) -> list[str]:
    """Split on section headers (lines of ``===``, ``---``, or numbered headings).

    Each section becomes one chunk.  Sections exceeding *max_section*
    characters are sub-split with a sliding window.
    """
    # Split on prominent delimiters:  ====, ----, numbered headings, Q: prefixes
    pattern = r"(?:^|\n)(?:={3,}|-{3,}|\d+\.\s+[A-Z]|[Qq]\d*[\.:]|\s|Section\s+\d)"
    raw_sections = re.split(pattern, text)

    chunks: list[str] = []
    for section in raw_sections:
        section = section.strip()
        if len(section) < _MIN_CHUNK_LENGTH:
            continue
        if len(section) <= max_section:
            chunks.append(section)
        else:
            # Sub-split large sections with sliding window
            chunks.extend(
                _chunk_sliding_window(section, max_section, max_section // 4)
            )
    return chunks


# -- Stable chunk ID generation ----------------------------------------------

def _make_chunk_id(document_name: str, chunk_index: int) -> str:
    """Deterministic chunk ID so re-indexing upserts rather than duplicates."""
    raw = f"{document_name}::chunk_{chunk_index}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# -- Public Indexer class ----------------------------------------------------

class Indexer:
    """
    Reads documents, chunks them, embeds, and upserts into ChromaDB.

    Parameters
    ----------
    embedder : Embedder | None
        Reuse an existing embedder; creates one if not provided.
    vector_store : ChromaVectorStore | None
        Reuse an existing store; creates one if not provided.
    """

    def __init__(
        self,
        embedder: Embedder | None = None,
        vector_store: ChromaVectorStore | None = None,
    ) -> None:
        self.embedder = embedder or Embedder()
        self.store = vector_store or ChromaVectorStore()
        self._metadata_entries = self._load_metadata()

    # -- Metadata loading ----------------------------------------------------

    @staticmethod
    def _load_metadata() -> dict[str, dict]:
        """Load ``document_metadata.json`` into a dict keyed by document_name."""
        if not _METADATA_PATH.exists():
            logger.warning("document_metadata.json not found at %s", _METADATA_PATH)
            return {}
        with open(_METADATA_PATH, encoding="utf-8") as fh:
            data = json.load(fh)
        return {entry["document_name"]: entry for entry in data.get("documents", [])}

    # -- Single-file indexing ------------------------------------------------

    def index_file(self, document_name: str) -> int:
        """Index a single document by its ``document_name`` from metadata.

        Returns the number of chunks upserted.
        """
        meta = self._metadata_entries.get(document_name)
        if meta is None:
            raise ValueError(
                f"Document '{document_name}' not found in document_metadata.json"
            )

        # M4: Validate required metadata keys before access
        if "path" not in meta:
            raise ValueError(
                f"Document '{document_name}' metadata is missing the required 'path' key. "
                f"Available keys: {list(meta.keys())}"
            )

        file_path = _DOCS_DIR / meta["path"]
        if not file_path.exists():
            raise FileNotFoundError(f"Document file not found: {file_path}")

        # Load
        fmt = meta.get("format", "txt")
        if fmt == "pdf":
            raw_text = _load_pdf(file_path)
        else:
            raw_text = _load_text(file_path)

        if not raw_text.strip():
            logger.warning("Empty content for %s - skipping.", document_name)
            return 0

        # Chunk
        strategy = meta.get("chunking_strategy", "sliding_window")
        if strategy == "structured":
            chunks = _chunk_structured(raw_text)
        else:
            chunks = _chunk_sliding_window(raw_text)

        if not chunks:
            logger.warning("No chunks produced for %s - skipping.", document_name)
            return 0

        # Build IDs and per-chunk metadata
        ids: list[str] = []
        chunk_metadatas: list[dict] = []
        for i, _chunk_text in enumerate(chunks):
            ids.append(_make_chunk_id(document_name, i))
            chunk_meta: dict = {
                "document_name": document_name,
                "doc_type": meta.get("doc_type", "unknown"),
                "source_authority": meta.get("source_authority", "unknown"),
                "freshness_date": meta.get("freshness_date", ""),
                "chunking_strategy": strategy,
                "chunk_index": i,
            }
            # Store each service domain as a separate flag key so
            # ChromaDB can filter with $eq on "domain__<NAME>".
            for domain in meta.get("service_domains", []):
                chunk_meta[DOMAIN_KEY_FORMAT.format(domain)] = "1"
            chunk_metadatas.append(chunk_meta)

        # Embed
        embeddings = self.embedder.embed(chunks)

        # Upsert
        self.store.add_documents(
            chunks=chunks,
            embeddings=embeddings,
            metadatas=chunk_metadatas,
            ids=ids,
        )

        logger.info(
            "Indexed %s -> %d chunks (strategy=%s)", document_name, len(chunks), strategy
        )
        return len(chunks)

    # -- Bulk indexing -------------------------------------------------------

    def index_all(self) -> dict[str, int]:
        """Index every document listed in ``document_metadata.json``.

        Returns a dict mapping each ``document_name`` to its chunk count.
        Skips documents whose files are missing (logs a warning).
        """
        stats: dict[str, int] = {}
        for doc_name, meta in self._metadata_entries.items():
            if "path" not in meta:
                logger.warning("Metadata for '%s' is missing 'path' - skipping.", doc_name)
                stats[doc_name] = 0
                continue
            file_path = _DOCS_DIR / meta["path"]
            if not file_path.exists():
                logger.warning("File missing for '%s': %s - skipping.", doc_name, file_path)
                stats[doc_name] = 0
                continue
            try:
                count = self.index_file(doc_name)
            except Exception as exc:
                logger.error(
                    "Failed to index '%s': %s - skipping.",
                    doc_name, exc,
                    exc_info=True,
                )
                count = 0
            stats[doc_name] = count

        total = sum(stats.values())
        logger.info(
            "Bulk indexing complete - %d documents, %d total chunks.",
            len(stats),
            total,
        )
        return stats
