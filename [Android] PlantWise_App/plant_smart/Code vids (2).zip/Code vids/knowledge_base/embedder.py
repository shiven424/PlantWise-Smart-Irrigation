from __future__ import annotations

"""
Embedding wrapper — supports OpenAI Embeddings API and local SentenceTransformer.

Provider is selected via ``config.settings.embedding_provider``:
  - ``"openai"``  — calls OpenAI Embeddings API (default)
  - ``"local"``   — loads a SentenceTransformer model locally

For OpenAI, uses the model specified in ``settings.embedding_model``
(default: ``text-embedding-3-small``, 1536-dimensional vectors).

For local, uses the same model name with SentenceTransformer.

The class is intentionally thin: it initialises the backend once on
construction and exposes ``embed`` (batch) and ``embed_single`` (one text).
"""

import logging

from config import settings

logger = logging.getLogger(__name__)


class Embedder:
    """Provider-agnostic embedder for document and query embedding."""

    def __init__(self, model_name: str | None = None) -> None:
        self._provider = settings.embedding_provider
        self._model_name = model_name or settings.embedding_model

        if self._provider == "openai":
            self._init_openai()
        else:
            self._init_local()

        logger.info(
            "Embedder ready — provider=%s, model=%s, dim=%d",
            self._provider,
            self._model_name,
            self.dimension,
        )

    # -- OpenAI backend -------------------------------------------------------

    def _init_openai(self) -> None:
        from openai import OpenAI

        self._client = OpenAI(
            api_key=settings.openai_api_key,
            timeout=float(settings.llm_timeout_seconds),
        )
        self.dimension: int = settings.embedding_dimensions

    def _embed_openai(self, texts: list[str]) -> list[list[float]]:
        """Call OpenAI Embeddings API for a batch of texts."""
        response = self._client.embeddings.create(
            input=texts,
            model=self._model_name,
        )
        # Sort by index to guarantee order matches input
        sorted_data = sorted(response.data, key=lambda x: x.index)
        return [item.embedding for item in sorted_data]

    # -- Local SentenceTransformer backend ------------------------------------

    def _init_local(self) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "sentence-transformers is required for local embedding. "
                "Install it with: pip install sentence-transformers"
            ) from exc

        try:
            self._local_model = SentenceTransformer(self._model_name)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to load local embedding model '{self._model_name}': {exc}."
            ) from exc
        self.dimension: int = self._local_model.get_sentence_embedding_dimension()

    def _embed_local(self, texts: list[str]) -> list[list[float]]:
        return self._local_model.encode(texts).tolist()

    # -- Public API -----------------------------------------------------------

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts. Returns a list of float vectors."""
        if self._provider == "openai":
            return self._embed_openai(texts)
        return self._embed_local(texts)

    def embed_single(self, text: str) -> list[float]:
        """Embed a single text string. Returns one float vector."""
        if self._provider == "openai":
            result = self._embed_openai([text])
            return result[0]
        return self._local_model.encode(text).tolist()
