from __future__ import annotations

from typing import Literal

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM
    llm_provider: Literal["anthropic", "openai", "github", "bedrock"] = "openai"
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    github_token: str = ""
    llm_model: str = ""
    llm_max_tokens: int = 1000
    llm_timeout_seconds: int = 30

    # Vault
    vault_provider: Literal["hashicorp", "aws_secrets", "mock"] = "mock"
    hashicorp_vault_url: str = "http://localhost:8200"
    hashicorp_vault_token: str = ""
    aws_region: str = "us-east-1"
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_secret_prefix: str = "contact-center/pii/"

    # User profile store
    profile_store_provider: Literal["memory", "redis"] = "memory"
    profile_store_url: str = "redis://localhost:6379/0"
    profile_ttl_days: int = 90

    # Vector store
    vector_store_provider: Literal["chromadb", "pinecone"] = "chromadb"
    pinecone_api_key: str = ""
    pinecone_index_name: str = "contact-center-kb"
    chromadb_path: str = "./data/chromadb"

    # Embeddings
    embedding_provider: Literal["local", "openai"] = "openai"
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536  # text-embedding-3-small default

    # Reranker
    reranker_provider: Literal["local", "openai"] = "openai"

    # Agent versions — change ONE line here to swap any agent
    agent_versions: dict = {
        "message_classifier": "v1",
        "intent_agent": "v1",
        "entity_extraction": "v1",
        "rag_agent": "v1",
        "auth_agent": "v1",
        "entity_validator": "v1",
        "supervisor": "v1",
        "response_synthesizer": "v1",
    }

    tool_versions: dict = {
        "balance_inquiry": "v1",
        "transaction_history": "v1",
        "rmd_calculator": "v1",
        "plan_loan": "v1",
    }

    # Operational limits
    max_clarification_retries: int = 3
    max_auth_retries: int = 3
    max_hitl_corrections: int = 3
    min_rag_confidence: float = 0.70
    hitl_timeout_seconds: int = 300
    idle_session_ttl_seconds: int = 1800  # 30 min inactivity → purge

    # Classifier confidence thresholds
    classifier_transactional_threshold: float = 0.50
    classifier_default_threshold: float = 0.70

    # CORS — allowed origins (tighten for production)
    allowed_origins: list[str] = ["http://localhost:3000"]

    # Graph invocation timeout (seconds) — prevents stalled LLM from hanging requests
    graph_invoke_timeout: int = 55

    # Supervisor agent
    supervisor_max_iterations: int = 6
    supervisor_model: str | None = None  # override llm_model for supervisor
    supervisor_temperature: float = 0.0

    # ----- Conversation persistence ------------------------------------------
    # conversation_store_backend: "memory" = in-process dict (dev/test, no restart survival)
    #                             "postgres" = durable PostgreSQL table
    conversation_store_backend: Literal["memory", "postgres"] = "postgres"
    conversation_store_postgres_url: str = "postgresql://cc:cc@localhost:5432/contact_center"   # e.g. postgresql://user:pass@host:5432/db

    # ----- Graph checkpoint backend ------------------------------------------
    # checkpoint_backend: "memory"   = MemorySaver (no restart survival, default)
    #                     "postgres" = PostgresSaver via langgraph-checkpoint-postgres
    checkpoint_backend: Literal["memory", "postgres"] = "postgres"
    checkpoint_postgres_url: str = "postgresql://cc:cc@localhost:5432/contact_center"   # e.g. postgresql://user:pass@host:5432/db

    # Tool API backend:
    #   "mock" (in-process)  - default for tests/dev, no network
    #   "http" (mock service) - talk to mock_services.account_service over HTTP
    #   "real"               - production recordkeeper / custodian client (TBD)
    tool_api_provider: Literal["mock", "http", "real"] = "mock"
    account_api_base_url: str = "http://localhost:8081"
    account_api_timeout_s: float = 5.0
    account_api_retries: int = 2

    # ----- Auth subsystem (login + KBA + OTP) --------------------------------
    auth_secrets_provider: Literal["memory"] = "memory"
    auth_demo_accounts_path: str = "./demo_data/accounts.json"
    auth_jwt_secret: str = ""
    auth_jwt_ttl_seconds: int = 900            # 15 min
    auth_otp_ttl_seconds: int = 300            # 5 min
    auth_reverify_ttl_seconds: int = 1800      # 30 min - re-prompt KBA past this
    auth_fraud_block_threshold: float = 0.7    # >= disables expedited path
    auth_login_attempt_limit: int = 5          # per IP per 60s

    model_config = {"env_file": ".env", "extra": "ignore"}


settings = Settings()
