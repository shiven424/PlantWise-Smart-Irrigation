"""
Contact Center AI - FastAPI Application Entry Point.

This module is the single orchestration surface that:
  1. Boots FastAPI + middleware (CORS, request-ID, logging).
  2. Provides REST endpoints for multi-turn conversations.
  3. Manages LangGraph thread lifecycle (create -> turn -> HITL resume -> end).
  4. Handles the HITL interrupt/resume flow for transactional operations.
  5. Exposes health / readiness probes.

Endpoints:
  POST /conversations                    -> start a new conversation
  POST /conversations/{id}/turns         -> send a user message (single turn)
  POST /conversations/{id}/hitl          -> resume after HITL approval/correction
  POST /conversations/{id}/end           -> gracefully end conversation
  GET  /conversations/{id}               -> get conversation state snapshot
  GET  /health                           -> liveness probe
  GET  /ready                            -> readiness probe (agents + vault)
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from config import settings
from graph.builder import compile_graph
from graph.state import initial_state
from observability.logger import log
from observability.metrics import metrics
from observability.tracer import init_tracer, set_trace_id, clear_trace_id
from schemas.enums import ActionType, ToolExecutionStatus
from schemas.primitives import HITLState, SessionContext, ToolExecutionState

# -- Logging bootstrap --------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s %(message)s",
)


# =============================================================================
# Request / Response Models
# =============================================================================

class StartConversationRequest(BaseModel):
    user_id: str | None = Field(default=None, description="DEPRECATED: ignored. user_id is derived from the bearer JWT.")
    channel: str = Field(default="web", description="Channel originating the call (web, ivr, mobile)")
    client_tier: str = Field(default="STANDARD", description="Customer tier")
    locale: str = Field(default="en-US", description="Locale / language")
    account_context: dict[str, Any] = Field(
        default_factory=dict,
        description="Static CRM/account data (balances, plan type, owner_age, etc.). No raw PII.",
    )
    auth_token: str = Field(default="", description="Vault dereference token for the session")
    fraud_risk_score: float = Field(default=0.0, ge=0.0, le=1.0)
    device_fingerprint: str | None = Field(default=None)


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=200)
    password: str = Field(min_length=1, max_length=200)


class LoginResponse(BaseModel):
    user_id: str
    username: str
    access_token: str
    expires_in: int
    token_type: str = "Bearer"


class StartConversationResponse(BaseModel):
    conversation_id: str
    session_token: str = Field(description="Bearer token for subsequent requests on this conversation")
    message: str


class TurnRequest(BaseModel):
    message: str = Field(min_length=1, max_length=5000, description="User message text")


class HITLRequest(BaseModel):
    approved: bool = Field(description="True = user confirmed; False = user wants corrections")
    corrections: dict[str, Any] = Field(
        default_factory=dict,
        description="Slot corrections when approved=False, e.g. {'withdrawal_amount': '5000'}",
    )


class TurnResponse(BaseModel):
    conversation_id: str
    turn: int
    action_type: str | None = None
    response: dict[str, Any] | None = None
    hitl_pending: bool = False
    escalation: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ConversationSnapshot(BaseModel):
    conversation_id: str
    turn: int
    intent: str | None = None
    auth_status: str | None = None
    hitl_pending: bool = False
    last_response: dict[str, Any] | None = None


class HealthResponse(BaseModel):
    status: str
    timestamp: str


class ConversationListItem(BaseModel):
    conversation_id: str
    status: str
    title: str | None = None
    last_user_message_preview: str | None = None
    current_turn: int = 0
    channel: str = "web"
    created_at: str
    last_active_at: str
    ended_at: str | None = None
    deleted_at: str | None = None


class ConversationListResponse(BaseModel):
    conversations: list[ConversationListItem]
    total: int
    next_cursor: str | None = None


class ResumeConversationResponse(BaseModel):
    conversation_id: str
    session_token: str = Field(description="New bearer token for subsequent requests on this conversation")
    status: str
    current_turn: int
    last_active_at: str
    message_history: list[dict[str, str]] = Field(
        default_factory=list,
        description=(
            "Prior transcript for UI hydration (role/content; assistant rows may "
            "include action_type, response_json, metadata_json for structured replay)."
        ),
    )


class RestoreConversationResponse(BaseModel):
    conversation_id: str
    status: str


# =============================================================================
# Application Lifespan - compile graph once at startup
# =============================================================================

_graph = None
_conversations: dict[str, dict[str, Any]] = {}
_conversation_locks: dict[str, asyncio.Lock] = {}
_cleanup_task: asyncio.Task | None = None

# Fix 135: Track in-flight graph invocations so we can block new turns
# while an orphaned thread from a timeout is still running.
_inflight_futures: dict[str, asyncio.Future] = {}

# TTL for idle conversations (seconds) - separate from HITL timeout.
# Conversations untouched for longer than this are purged.
_CONVERSATION_TTL_SECONDS: int = settings.idle_session_ttl_seconds


async def _purge_once() -> None:
    """Run a single purge sweep - extracted for testability (Fix 138)."""
    now = datetime.now(timezone.utc)
    stale_ids: list[str] = []
    for cid, meta in list(_conversations.items()):
        last_active = meta.get("last_active_at", meta.get("created_at", ""))
        if not last_active:
            continue
        try:
            last_dt = datetime.fromisoformat(last_active)
            if (now - last_dt).total_seconds() > _CONVERSATION_TTL_SECONDS:
                stale_ids.append(cid)
        except (ValueError, TypeError):
            continue

    for cid in stale_ids:
        # C1-6th: Acquire lock before purging to prevent race with
        # concurrent process_turn / hitl_resume requests.
        lock = _conversation_locks.get(cid)
        if lock is None:
            # Lock already removed (e.g. end_conversation ran).
            # Fix 53: Clean up vault tokens before discarding state.
            stale_meta = _conversations.get(cid)
            if stale_meta:
                _cleanup_vault_tokens(stale_meta.get("state", {}))
            _conversations.pop(cid, None)
            continue
        if lock.locked():
            # Active request in progress - skip this cycle; it'll be
            # caught on the next purge sweep.
            log.info("conversation_purge_skipped", conversation_id=cid, reason="lock_held")
            continue
        # Fix 108: Acquire the lock to prevent race between the
        # lock.locked() check above and the actual deletion below.
        # Use try_lock pattern: if we can't acquire immediately, skip.
        if not lock.locked():
            try:
                async with lock:
                    # Fix 136: Re-check freshness INSIDE the lock.
                    # A concurrent process_turn may have updated
                    # last_active_at between the outer scan and lock
                    # acquisition, making this conversation no longer
                    # stale.
                    meta = _conversations.get(cid)
                    if not meta:
                        # Already removed by end_conversation
                        _conversation_locks.pop(cid, None)
                        continue
                    inner_last = meta.get(
                        "last_active_at", meta.get("created_at", "")
                    )
                    try:
                        inner_dt = datetime.fromisoformat(inner_last)
                        still_stale = (
                            datetime.now(timezone.utc) - inner_dt
                        ).total_seconds() > _CONVERSATION_TTL_SECONDS
                    except (ValueError, TypeError):
                        still_stale = False
                    if not still_stale:
                        log.info(
                            "conversation_purge_skipped",
                            conversation_id=cid,
                            reason="refreshed_under_lock",
                        )
                        continue
                    # H3: Clean up vault tokens before purging conversation data
                    _cleanup_vault_tokens(meta.get("state", {}))
                    _conversations.pop(cid, None)
                    _conversation_locks.pop(cid, None)
                    _inflight_futures.pop(cid, None)
                    log.info("conversation_purged", conversation_id=cid, reason="ttl_expired")
            except Exception:
                log.warning("conversation_purge_lock_error", conversation_id=cid)
                continue


async def _purge_stale_conversations() -> None:
    """Background task that removes conversations idle longer than TTL."""
    while True:
        await asyncio.sleep(60)
        try:
            await _purge_once()
        except Exception as exc:
            # Fix 136: Top-level guard keeps the background task alive
            log.error("purge_sweep_error", error=str(exc))


def _get_lock(conversation_id: str) -> asyncio.Lock:
    """Get the async lock for an existing conversation.

    Raises 404 if the conversation_id has no lock (i.e. was never created
    via start_conversation).  This prevents an attacker from exhausting
    memory by sending requests with arbitrary conversation_ids - each
    would previously create an orphaned asyncio.Lock that was never
    cleaned up.
    """
    lock = _conversation_locks.get(conversation_id)
    if lock is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation {conversation_id} not found.",
        )
    return lock


def _seed_demo_accounts() -> None:
    """Seed the MockAccountAPI with all demo accounts.

    Each demo user's ``account_context.accounts`` map declares one or more
    accounts (401K, IRA, BROKERAGE, etc.).  We seed the mock recordkeeper
    once per (user, account_type) pair so the BalanceInquiryTool can
    return real values for whichever account the user selects.

    Production swaps the mock for a real recordkeeper client and removes
    this seeding entirely.
    """
    # Only the in-process mock backend needs in-app seeding. When the
    # ``http`` provider is selected, ``mock_services.account_service``
    # seeds itself from the same demo data on its own startup, so any
    # attempt to call ``seed_account`` on the HTTP client would fail
    # (and is unnecessary).
    from config import settings
    if settings.tool_api_provider != "mock":
        log.info(
            "demo_account_seed_skipped",
            reason="non_mock_provider",
            provider=settings.tool_api_provider,
        )
        return
    try:
        # Each tool owns an INDEPENDENT module-level singleton of the
        # MockAccountAPI; we seed every one so any tool the supervisor
        # routes to can find the demo account.
        from tools.balance_inquiry.v1.agent import (
            _get_account_api as _get_balance_api,
        )
        from tools.rmd_calculator.v1.agent import (
            _get_account_api as _get_rmd_api,
        )
        from tests.mocks.account_api import AccountRecord
        from mock_services.inprocess.account_api import Transaction as DemoTransaction

        apis = [
            _get_balance_api(),
            _get_rmd_api(),
        ]
        from auth.client import secrets_provider
        provider = secrets_provider()
        seeded_numbers: list[str] = []
        for user_id in (
            "demo-user-001", "demo-user-002", "demo-user-003",
            "demo-user-004", "demo-user-005", "demo-user-006",
        ):
            ctx = provider.get_account_context(user_id) or {}
            accounts_map: dict = ctx.get("accounts") or {}

            # Fall back to legacy flat shape if no nested accounts map.
            if not accounts_map and ctx.get("account_number"):
                accounts_map = {ctx.get("plan_type", "401K"): {
                    "account_number": ctx["account_number"],
                    "account_type": ctx.get("plan_type", "401K"),
                    "vested_balance": ctx.get("vested_balance", 0.0),
                    "outstanding_loan_balance": ctx.get("outstanding_loan_balance", 0.0),
                    "highest_loan_balance_12m": ctx.get("highest_loan_balance_12m", 0.0),
                    "plan_allows_loans": ctx.get("plan_allows_loans", True),
                    "plan_name": "Demo Plan",
                }}

            for acct_type, acct in accounts_map.items():
                acct_num = acct.get("account_number")
                if not acct_num:
                    continue
                vested = float(acct.get("vested_balance", 0.0))
                total = float(acct.get("total_balance", vested))
                txs_raw = acct.get("transactions") or []
                tx_objs = []
                if isinstance(txs_raw, list):
                    for row in txs_raw:
                        if isinstance(row, dict):
                            tx_objs.append(DemoTransaction(**row))
                record = AccountRecord(
                    account_number=acct_num,
                    account_type=acct.get("account_type", acct_type),
                    owner_name=ctx.get("owner_name", "Demo User"),
                    owner_age_years=float(ctx.get("owner_age_years", 40)),
                    owner_dob=ctx.get("owner_dob", "1985-01-01"),
                    total_balance=total,
                    vested_balance=vested,
                    unvested_balance=float(acct.get("unvested_balance", max(total - vested, 0.0))),
                    prior_year_end_balance=float(acct.get("prior_year_end_balance", max(vested - 5_000.00, 0.0))),
                    ytd_contributions=float(acct.get("ytd_contributions", 0.0)),
                    ytd_employer_match=float(acct.get("ytd_employer_match", 0.0)),
                    annual_match_max=float(acct.get("annual_match_max", 0.0)),
                    outstanding_loan_balance=float(acct.get("outstanding_loan_balance", 0.0)),
                    highest_loan_balance_12m=float(acct.get("highest_loan_balance_12m", 0.0)),
                    plan_allows_loans=bool(acct.get("plan_allows_loans", True)),
                    plan_name=acct.get("plan_name", "Demo Plan"),
                    transactions=tx_objs,
                )
                # Seed under the canonical account_number AND under the
                # last-4 alias.  Tools may receive either:
                #   - the literal vault token from session bootstrap
                #     (e.g. "tok_acc_8810"), or
                #   - a dereferenced raw value if entity_extraction
                #     re-tokenised the user-spoken digits (e.g. "8810").
                # Seeding both forms guarantees lookup succeeds.
                aliases = {acct_num}
                if len(acct_num) >= 4:
                    aliases.add(acct_num[-4:])
                from dataclasses import replace as _dc_replace
                for api in apis:
                    for key in aliases:
                        alias_record = record if key == acct_num else _dc_replace(record, account_number=key)
                        api.seed_account(alias_record)
                seeded_numbers.append(acct_num[-4:] if len(acct_num) >= 4 else "****")
        log.info("demo_account_seeded", account_last4s=seeded_numbers)
    except Exception as exc:
        log.warning("demo_account_seed_failed", error=str(exc))


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _graph, _cleanup_task
    log.info("app_startup", phase="begin")

    # Initialise the conversation persistence store (memory or postgres)
    from conversation_store.client import conversation_store
    await conversation_store.setup()
    log.info("app_startup", phase="conversation_store_ready",
             backend=settings.conversation_store_backend)

    # Compile the LangGraph with the configured checkpointer
    from graph.checkpointer import get_checkpointer
    _checkpointer = get_checkpointer()
    _graph = compile_graph(checkpointer=_checkpointer)
    log.info("app_startup", phase="graph_compiled",
             checkpoint_backend=settings.checkpoint_backend)

    # Initialise external tracing (LangSmith) if configured
    init_tracer()

    # Run boot-time registry health checks
    from agents.registry import AGENT_REGISTRY
    from tools.registry import TOOL_REGISTRY
    from agents.validator import validate_registry
    validate_registry(AGENT_REGISTRY, "Agent")
    validate_registry(TOOL_REGISTRY, "Tool")
    log.info(
        "app_startup",
        phase="registries_validated",
        agents=list(AGENT_REGISTRY.keys()),
        tools=list(TOOL_REGISTRY.keys()),
    )

    # Seed a demo account so the balance_inquiry / withdrawal / loan
    # tools can return real data when called with the demo
    # account_number that the frontend injects via account_context.
    _seed_demo_accounts()

    # Start background conversation cleanup
    _cleanup_task = asyncio.create_task(_purge_stale_conversations())

    log.info("app_startup", phase="complete")
    yield

    # Shutdown: cancel cleanup task and close store connection pool
    if _cleanup_task:
        _cleanup_task.cancel()
    try:
        from conversation_store.client import conversation_store
        await conversation_store.close()
    except Exception:
        pass
    try:
        from graph.checkpointer import close_checkpointer
        close_checkpointer()
    except Exception:
        pass
    log.info("app_shutdown", phase="complete")


# =============================================================================
# FastAPI Application
# =============================================================================

app = FastAPI(
    title="Contact Center AI",
    version="1.0.0",
    description="Multi-agent conversational AI for financial services.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=settings.allowed_origins != ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# -- Request-ID middleware -----------------------------------------------------

@app.middleware("http")
async def add_request_id(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", uuid.uuid4().hex[:12])
    # M10: Set trace_id so all log lines within this request are correlated
    set_trace_id(request_id)
    try:
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
    finally:
        clear_trace_id()


# -- Global exception handler -------------------------------------------------

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    log.error("unhandled_exception", error=str(exc), path=request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error. Please try again later."},
    )


# =============================================================================
# Helper Utilities
# =============================================================================

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash_token(token: str) -> str:
    """Return hex SHA-256 of a token for safe storage (never store plaintext)."""
    import hashlib
    return hashlib.sha256(token.encode()).hexdigest()


def _preview_text(text: str, max_len: int = 120) -> str:
    """Return a safe, truncated preview string for UI display."""
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[:max_len] + "…"


def _synth_as_dict(synth: Any) -> dict[str, Any]:
    if synth is None:
        return {}
    if isinstance(synth, dict):
        return synth
    dump = getattr(synth, "model_dump", None)
    if callable(dump):
        return dump()
    return {}


def _build_assistant_transcript_entry(
    result_state: dict[str, Any],
    synth: dict[str, Any],
) -> dict[str, str] | None:
    """One message_history row with string values only (GraphState compatibility)."""
    full_msg = (synth.get("full_message") or "").strip()
    if not full_msg:
        return None
    plan = result_state.get("current_action_plan")
    action_type: str | None = None
    if plan is not None:
        at_plan = getattr(plan, "action_type", None)
        if at_plan is not None:
            action_type = (
                at_plan.value if hasattr(at_plan, "value") else str(at_plan)
            )
    if not action_type:
        sat = synth.get("action_type")
        if sat is not None:
            action_type = sat.value if hasattr(sat, "value") else str(sat)
    auth_raw = result_state.get("auth_status")
    auth_status = (
        auth_raw
        if isinstance(auth_raw, str)
        else (getattr(auth_raw, "value", None) or "PENDING")
    )
    slot_gap = result_state.get("slot_gap") or []
    if not isinstance(slot_gap, list):
        slot_gap = []
    slot_gap_strs = [str(s) for s in slot_gap]
    resp_payload: dict[str, Any] = {
        "opening_frame": synth.get("opening_frame") or "",
        "core_content": synth.get("core_content") or "",
        "compliance_tail": synth.get("compliance_tail") or "",
        "full_message": synth.get("full_message") or "",
        "disclosures_appended": list(synth.get("disclosures_appended") or []),
    }
    sat2 = synth.get("action_type")
    if sat2 is not None:
        resp_payload["action_type"] = (
            sat2.value if hasattr(sat2, "value") else str(sat2)
        )
    meta_ui: dict[str, Any] = {
        "auth_status": auth_status,
        "slot_gap": slot_gap_strs,
    }
    tout = _transaction_ui_outcome(result_state)
    if tout is not None:
        meta_ui["transaction_ui_outcome"] = tout
    row: dict[str, str] = {
        "role": "assistant",
        "content": full_msg,
        "response_json": json.dumps(resp_payload, default=str),
        "metadata_json": json.dumps(meta_ui, default=str),
    }
    if action_type:
        row["action_type"] = action_type
    return row


def _sanitize_message_history_for_ui(history: list[Any] | None) -> list[dict[str, str]]:
    """Return transcript rows safe for frontend hydration (role/content + UI replay)."""
    out: list[dict[str, str]] = []
    for item in history or []:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role not in {"user", "assistant"} or not isinstance(content, str):
            continue
        row: dict[str, str] = {"role": role, "content": content}
        if role == "assistant":
            at = item.get("action_type")
            if isinstance(at, str) and at.strip():
                row["action_type"] = at
            rj = item.get("response_json")
            if isinstance(rj, str) and rj.strip():
                row["response_json"] = rj
            mj = item.get("metadata_json")
            if isinstance(mj, str) and mj.strip():
                row["metadata_json"] = mj
        out.append(row)
    return out


def _get_conversation(conversation_id: str) -> dict[str, Any]:
    meta = _conversations.get(conversation_id)
    if meta is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation {conversation_id} not found.",
        )
    return meta


def _validate_session_token(request: Request, meta: dict[str, Any]) -> None:
    """M6: Validate the bearer token matches the conversation's session_token.

    Prevents unauthorized access to conversations by ID enumeration.
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header. Use: Bearer <session_token>",
        )
    token = auth_header[7:]  # strip "Bearer "
    if not hmac.compare_digest(token, meta.get("session_token", "")):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid session token for this conversation.",
        )


# ----- Login JWT (separate from per-conversation session_token) ---------------
# `/auth/login` issues a short-lived JWT identifying the user.
# `/conversations` (start) requires that JWT and trusts only its `sub` claim
# for `session.user_id`.  Per-turn endpoints continue to use the per-
# conversation `session_token` for authorization.

_LOGIN_ATTEMPT_WINDOW_SECONDS = 60
_login_attempts: dict[str, list[float]] = {}
_login_attempts_lock = asyncio.Lock()


async def _check_login_rate_limit(client_ip: str) -> None:
    now_ts = time.time()
    cutoff = now_ts - _LOGIN_ATTEMPT_WINDOW_SECONDS
    async with _login_attempts_lock:
        attempts = [t for t in _login_attempts.get(client_ip, []) if t > cutoff]
        if len(attempts) >= settings.auth_login_attempt_limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many login attempts. Try again in a minute.",
            )
        attempts.append(now_ts)
        _login_attempts[client_ip] = attempts


async def require_user(
    authorization: str | None = Header(default=None),
) -> str:
    """FastAPI dependency: decode the bearer JWT and return the user_id."""
    from auth.jwt_utils import InvalidTokenError, decode_token

    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header. Use: Bearer <jwt>",
            headers={"WWW-Authenticate": "Bearer"},
        )
    token = authorization[7:]
    try:
        return decode_token(token)
    except InvalidTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {exc}",
            headers={"WWW-Authenticate": "Bearer"},
        )


_TRANSACTION_UI_FAILURE_STATUSES: frozenset[str] = frozenset(
    {"FAILED", "ERROR", "REJECTED", "CANCELLED", "CANCELED"},
)


def _transaction_ui_outcome(state: dict[str, Any]) -> str | None:
    """Classify transactional tool outcomes for TransactionResult UX (non-PII).

    Mirrors the failure / success distinctions in synthesizer._core_transaction_complete
    so the client banner matches the substantive message regardless of headings.
    """
    plan = state.get("current_action_plan")
    if plan is None:
        return None
    at = getattr(plan, "action_type", None)
    if at not in (ActionType.EXECUTE_TRANSACTION, ActionType.HITL_APPROVED):
        return None
    tx = state.get("transaction_result")
    if not isinstance(tx, dict):
        return None
    status_raw = str(tx.get("status", "") or "").upper()
    sf = tx.get("success")
    if sf is False or status_raw in _TRANSACTION_UI_FAILURE_STATUSES:
        return "failure"
    if sf is True and status_raw == "PREVIEW":
        return "informational"
    if sf is True or status_raw in {"SUCCESS", "COMPLETED"}:
        return "success"
    return "informational"


def _build_turn_response(conversation_id: str, state: dict) -> TurnResponse:
    plan = state.get("current_action_plan")
    action_type = plan.action_type.value if plan else None
    response_data = state.get("last_synthesized_response")
    hitl = state.get("hitl")
    hitl_pending = getattr(hitl, "pending", False) if hitl else False

    escalation = None
    esc_ctx = state.get("escalation_context")
    if esc_ctx:
        escalation = {
            "reason": esc_ctx.reason.value,
            "triggered_by": esc_ctx.triggered_by,
            "carry_context": esc_ctx.carry_context,
        }

    # Metadata for the client (non-PII operational data)
    active_intent = None
    stack = state.get("intent_stack", [])
    if stack:
        active = stack[0]
        # M4: Defensive access - guard against incomplete IntentRecord
        try:
            active_intent = {
                "intent_id": active.intent_id,
                "sub_intent": active.sub_intent,
                "service_domain": active.service_domain.value,
                "confidence": active.confidence,
            }
        except AttributeError:
            log.warning("build_response_incomplete_intent", active=str(active))
            active_intent = None

    # Fix 91: Sanitize rag_error - only expose a boolean flag to clients,
    # never raw exception strings that may leak internal architecture.
    raw_rag_error = state.get("rag_error")
    metadata = {
        "rag_confidence": state.get("rag_confidence"),
        "rag_error": bool(raw_rag_error),
        "auth_status": state.get("auth_status", "PENDING")
            if isinstance(state.get("auth_status"), str)
            else getattr(state.get("auth_status"), "value", "PENDING"),
        "slot_gap": state.get("slot_gap", []),
        "active_intent": active_intent,
        "policy_path": state.get("policy_path"),
    }
    ui_outcome = _transaction_ui_outcome(state)
    if ui_outcome is not None:
        metadata["transaction_ui_outcome"] = ui_outcome

    # When an HITL screen is being shown, expose the editable slots
    # (validated entities scoped to the active intent) so the frontend
    # "Edit & Correct" form has fields to render.  The slot_gap list is
    # empty by definition once validation has passed, so without this the
    # UI shows no inputs at all.
    if hitl_pending:
        try:
            from graph.state import get_active_intent as _get_active_intent
            _active = _get_active_intent(state)
            _required = list(getattr(_active, "required_slots", []) or []) if _active else []
            _validated = state.get("validated_entities") or {}
            editable: dict[str, str] = {}
            for slot in _required:
                ent = _validated.get(slot)
                if ent is None:
                    continue
                if isinstance(ent, dict):
                    val = ent.get("display_value")
                else:
                    val = getattr(ent, "display_value", None)
                if val is not None:
                    editable[slot] = str(val)
            if editable:
                metadata["editable_slots"] = editable
        except Exception:
            pass

    return TurnResponse(
        conversation_id=conversation_id,
        turn=state.get("current_turn", 0),
        action_type=action_type,
        response=response_data,
        hitl_pending=hitl_pending,
        escalation=escalation,
        metadata=metadata,
    )


async def _invoke_graph(conversation_id: str, state_input: dict | None = None) -> dict:
    """Run the LangGraph with the given input and thread config.

    Uses asyncio.to_thread() to avoid blocking the event loop during
    synchronous LLM calls within the graph.

    Fix 135: Tracks the underlying future so that if a timeout occurs,
    subsequent turns wait for the orphaned thread to complete before
    starting a new invocation - preventing checkpoint data races.

    Args:
        conversation_id: Thread ID for the checkpointer.
        state_input: Full state dict for a fresh run, or None to resume
                     from a pending interrupt_before checkpoint.
    """
    # Fix 135: If a previous invocation for this conversation is still
    # running (orphaned after timeout), wait for it to finish first.
    prev_future = _inflight_futures.get(conversation_id)
    if prev_future is not None and not prev_future.done():
        log.warning(
            "graph_invoke_wait_orphan",
            conversation_id=conversation_id,
            message="Waiting for orphaned graph invocation to complete",
        )
        try:
            await asyncio.wait_for(asyncio.shield(prev_future), timeout=10.0)
        except (asyncio.TimeoutError, Exception):
            log.error(
                "graph_invoke_orphan_stuck",
                conversation_id=conversation_id,
                message="Orphaned invocation did not finish; proceeding with new invocation",
            )

    thread_config = {"configurable": {"thread_id": conversation_id}}

    # Fix 147: Set conversation_id in thread-local so _merge_dict reducer
    # can tag orphaned vault tokens to the correct conversation.
    def _run_graph():
        from schemas.graph_state import set_reducer_conversation_id
        set_reducer_conversation_id(conversation_id)
        return _graph.invoke(state_input, thread_config)

    future = asyncio.ensure_future(
        asyncio.to_thread(_run_graph)
    )
    _inflight_futures[conversation_id] = future
    try:
        result = await asyncio.wait_for(
            asyncio.shield(future),
            timeout=settings.graph_invoke_timeout,
        )
    except asyncio.TimeoutError:
        # Fix 135: The future continues running in the background.
        # We do NOT cancel it - the thread cannot be stopped.  The next
        # invocation will wait for it to finish (above).
        log.error(
            "graph_invoke_timeout",
            conversation_id=conversation_id,
            timeout_seconds=settings.graph_invoke_timeout,
        )
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Request timed out. Please try again.",
        )
    finally:
        # Clean up tracking only if the future is done
        if future.done():
            _inflight_futures.pop(conversation_id, None)
    return result


async def _auto_resume_if_interrupted(
    conversation_id: str,
    result_state: dict,
) -> dict:
    """Resume the graph if it was interrupted at tool_router.

    The graph is compiled with ``interrupt_before=["tool_router"]``.
    When a turn or HITL resume routes to tool_router, invoke()
    returns partial state at the interrupt point.  This helper detects
    that condition and calls invoke(None) to continue execution through
    the tool and back to response_synthesizer.
    """
    plan = result_state.get("current_action_plan")
    if plan is None:
        return result_state

    action = getattr(plan, "action_type", None)
    needs_tool = action in (ActionType.HITL_APPROVED, ActionType.EXECUTE_TRANSACTION)
    has_result = result_state.get("transaction_result") is not None

    if needs_tool and not has_result:
        log.info(
            "auto_resume_interrupt",
            conversation_id=conversation_id,
            action_type=str(action),
        )
        result_state = await _invoke_graph(conversation_id, None)

    return result_state


def _cleanup_vault_tokens(state: dict) -> None:
    """
    Delete all vault tokens accumulated during the session (M7).

    Iterates entity_memory AND validated_entities for vault_token
    references and calls vault.delete() for each to prevent PII
    accumulation.  Also cleans up orphaned tokens that were displaced
    when _merge_dict overwrote entity_memory entries.
    """
    try:
        from vault.client import vault_client
        from schemas.graph_state import get_orphaned_tokens, clear_orphaned_tokens

        seen: set[str] = set()
        for source in ("entity_memory", "validated_entities"):
            container = state.get(source, {})
            if not container:
                continue
            for _key, entity in container.items():
                # Fix 55: Dual-access pattern - entities may be Pydantic
                # models (getattr) or plain dicts (dict.get) after
                # serialization/deserialization from LangGraph checkpoints.
                token = getattr(entity, "vault_token", None) or (
                    entity.get("vault_token") if isinstance(entity, dict) else None
                )
                if token and token not in seen:
                    seen.add(token)
                    try:
                        vault_client.delete(token)
                    except Exception as exc:
                        log.warning("vault_cleanup_failed", token=token[:8], error=str(exc))

        # Clean orphaned tokens displaced by _merge_dict overwrites
        conv_id = state.get("conversation_id") or "__global__"
        for token in get_orphaned_tokens(conv_id):
            if token not in seen:
                seen.add(token)
                try:
                    vault_client.delete(token)
                except Exception as exc:
                    log.warning("vault_orphan_cleanup_failed", token=token[:8], error=str(exc))
        clear_orphaned_tokens(conv_id)
        # Also clear the __global__ bucket
        for token in get_orphaned_tokens("__global__"):
            if token not in seen:
                seen.add(token)
                try:
                    vault_client.delete(token)
                except Exception as exc:
                    log.warning("vault_orphan_cleanup_failed", token=token[:8], error=str(exc))
        clear_orphaned_tokens("__global__")
    except Exception as exc:
        log.warning("vault_cleanup_error", error=str(exc))


def _persist_profile_updates(meta: dict[str, Any]) -> None:
    """Extract learnable data from the finished conversation and update
    the user's persistent profile.

    Only runs when the session has a ``user_id``.  Failures are logged
    and swallowed - profile persistence must never block session cleanup.
    """
    state: dict = meta["state"]
    session = state.get("session")
    user_id: str | None = getattr(session, "user_id", None) if session else None
    if not user_id:
        return

    try:
        from user_profile.client import profile_store
        from user_profile.base import UserProfile

        profile = profile_store.load(user_id) or UserProfile(user_id=user_id)

        # 1. Update display name from entity_memory (display_value only, no PII)
        entity_mem = state.get("entity_memory", {})
        name_entity = entity_mem.get("FULL_NAME")
        if name_entity:
            display = (
                getattr(name_entity, "display_value", None)
                or (name_entity.get("display_value") if isinstance(name_entity, dict) else None)
            )
            if display:
                profile.display_name = display

        # 2. Record intents used this session (most recent first, cap at 10)
        intent_stack = state.get("intent_stack", [])
        for intent in intent_stack:
            sub = getattr(intent, "sub_intent", None) or (
                intent.get("sub_intent") if isinstance(intent, dict) else None
            )
            if sub and sub not in profile.recent_intents:
                profile.recent_intents.insert(0, sub)
        profile.recent_intents = profile.recent_intents[:10]

        # 3. Record auth level if user verified this session
        auth_state = state.get("auth_state")
        if auth_state:
            level = getattr(auth_state, "current_level", None)
            if level and level.value > 1:  # anything above SESSION
                profile.last_verified_at = _now_iso()
                profile.last_verified_level = level.name

        # 4. Increment transaction count if a tool executed
        if state.get("transaction_result"):
            profile.past_transaction_count += 1

        # 5. Capture default entities (non-PII, non-financial slots only)
        # Fix M6: Only store entity types that are safe to persist across
        # sessions.  Financial values (amounts, balances) and account-
        # specific data are excluded even though they aren't PII-flagged,
        # because they are sensitive in aggregate and could leak cross-
        # session financial details into LLM prompts.
        _SAFE_PROFILE_SLOTS = frozenset({
            "account_type", "plan_type", "distribution_type",
            "delivery_method", "rollover_type", "withholding_type",
            "risk_tolerance", "investment_horizon",
            "rebalance_frequency", "distribution_frequency",
            "reinvest_option", "state", "country",
        })
        validated = state.get("validated_entities", {})
        for slot_name, entity in validated.items():
            if slot_name not in _SAFE_PROFILE_SLOTS:
                continue
            is_pii = getattr(entity, "is_pii", True) if not isinstance(entity, dict) else entity.get("is_pii", True)
            if is_pii:
                continue
            display = (
                getattr(entity, "display_value", None)
                or (entity.get("display_value") if isinstance(entity, dict) else None)
            )
            if display:
                profile.default_entities[slot_name] = display

        # 6. Timestamp
        profile.updated_at = _now_iso()

        profile_store.save(profile)
        log.info(
            "user_profile_saved",
            user_id=user_id,
            display_name=profile.display_name,
            intent_count=len(profile.recent_intents),
            transaction_count=profile.past_transaction_count,
        )
    except Exception:
        log.warning(
            "user_profile_save_failed  user_id=%s",
            user_id,
            exc_info=True,
        )


# =============================================================================
# Endpoints
# =============================================================================

# -- POST /auth/login - Issue a short-lived JWT for the user -----------------

@app.post(
    "/auth/login",
    response_model=LoginResponse,
)
async def login(req: LoginRequest, request: Request):
    client_ip = (request.client.host if request.client else "unknown") or "unknown"
    await _check_login_rate_limit(client_ip)

    from auth.client import secrets_provider
    from auth.jwt_utils import issue_token

    user_id = secrets_provider().verify_password(req.username, req.password)
    if user_id is None:
        log.info("auth_login_failed", username=req.username, ip=client_ip)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
        )
    login_handle = (req.username or "").strip()
    token, ttl = issue_token(user_id, preferred_username=login_handle or None)
    log.info("auth_login_ok", user_id=user_id, ip=client_ip)
    return LoginResponse(
        user_id=user_id,
        username=login_handle,
        access_token=token,
        expires_in=ttl,
    )


# -- GET /demo/last_otp/{user_id} - Demo-only OTP fetch ----------------------

@app.get("/demo/last_otp/{user_id}")
async def demo_last_otp(user_id: str, current_user: str = Depends(require_user)):
    if settings.auth_secrets_provider != "memory":
        raise HTTPException(status_code=404, detail="Not found")
    if current_user != user_id:
        raise HTTPException(status_code=403, detail="Cannot read another user's OTP.")
    from auth.client import otp_channel

    last = otp_channel().get_last_otp_for_demo(user_id)
    if last is None:
        raise HTTPException(status_code=404, detail="No OTP issued yet.")
    code, expires_at = last
    return {"code": code, "expires_at": expires_at.isoformat()}


# -- POST /conversations - Start a new conversation ---------------------------

@app.post(
    "/conversations",
    response_model=StartConversationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def start_conversation(
    req: StartConversationRequest,
    current_user: str = Depends(require_user),
):
    conversation_id = uuid.uuid4().hex
    # M6: Generate a session token that callers must present as a bearer
    # token on subsequent requests to prevent unauthorized access.
    session_token = uuid.uuid4().hex

    # Trust ONLY the JWT for user identity. Body `user_id`, if any, is
    # discarded so a client cannot impersonate another account.
    user_id = current_user

    session = SessionContext(
        session_id=uuid.uuid4(),
        user_id=user_id,
        channel=req.channel,
        client_tier=req.client_tier,
        locale=req.locale,
        started_at=datetime.now(timezone.utc),
    )

    state = initial_state(session)
    state["conversation_id"] = conversation_id
    # Store the opening greeting so it is available when the conversation
    # is resumed from checkpoint (transcript hydration in resume_conversation).
    _welcome = "Hi! How can I help you today?"
    state["message_history"] = [{"role": "assistant", "content": _welcome}]

    # Defensive: strip any `auth_*` keys the client may have tried to
    # inject into account_context. Auth secrets must come from the
    # server-side AuthSecretsProvider, never from the request body.
    sanitised_ctx = {
        k: v for k, v in (req.account_context or {}).items()
        if not k.lower().startswith("auth_")
    }

    # Merge in seeded CRM context for the user (demo wiring).
    try:
        from auth.client import secrets_provider
        seeded = secrets_provider().get_account_context(user_id) or {}
    except Exception:
        seeded = {}
    state["account_context"] = {**seeded, **sanitised_ctx}

    # Mint an internal JWT used by tools when calling backend
    # services (mock account service over HTTP, real recordkeeper, etc.).
    # Any client-supplied ``req.auth_token`` is intentionally ignored —
    # backend identity is derived solely from the verified login JWT.
    try:
        from auth.jwt_utils import issue_token as _issue_service_token
        service_token, _ = _issue_service_token(user_id)
    except Exception:
        log.exception("service_token_issue_failed", user_id=user_id)
        service_token = ""
    state["auth_token"] = service_token
    state["fraud_risk_score"] = req.fraud_risk_score
    state["device_fingerprint"] = req.device_fingerprint

    # Load cross-session user profile.
    try:
        from user_profile.client import profile_store
        profile = profile_store.load(user_id)
        if profile:
            state["user_profile"] = profile.model_dump()
            log.info(
                "user_profile_loaded",
                user_id=user_id,
                display_name=profile.display_name,
            )
    except Exception:
        log.exception(
            "user_profile_load_failed",
            user_id=user_id,
        )

    # H2: Create lock BEFORE storing conversation so _get_lock() never
    # creates orphaned locks for non-existent conversations.
    _conversation_locks[conversation_id] = asyncio.Lock()

    _now = _now_iso()
    _conversations[conversation_id] = {
        "session": session,
        "session_token": session_token,
        "state": state,
        "turn": 0,
        "created_at": _now,
        "last_active_at": _now,
    }

    # Persist to durable store (memory or postgres depending on config)
    try:
        from conversation_store.client import conversation_store
        from conversation_store.models import ConversationRecord, ConversationStatus
        await conversation_store.create(
            ConversationRecord(
                conversation_id=conversation_id,
                user_id=user_id,
                status=ConversationStatus.ACTIVE,
                channel=req.channel,
                session_token_hash=_hash_token(session_token),
            )
        )
    except Exception:
        log.exception("conversation_store_create_failed", conversation_id=conversation_id)

    log.info(
        "conversation_started",
        conversation_id=conversation_id,
        channel=req.channel,
        client_tier=req.client_tier,
    )
    metrics.record_conversation_start(req.channel)

    return StartConversationResponse(
        conversation_id=conversation_id,
        session_token=session_token,
        message="Hi! How can I help you today?",
    )


# -- POST /conversations/{id}/turns - Process a user turn ---------------------

@app.post(
    "/conversations/{conversation_id}/turns",
    response_model=TurnResponse,
)
async def process_turn(conversation_id: str, req: TurnRequest, request: Request):
    meta = _get_conversation(conversation_id)
    _validate_session_token(request, meta)

    async with _get_lock(conversation_id):
        # Fix 144: Re-validate that the conversation still exists.
        # A concurrent end_conversation may have deleted it between
        # _get_conversation and lock acquisition.
        if conversation_id not in _conversations:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation {conversation_id} not found.",
            )

        meta["turn"] += 1
        meta["last_active_at"] = _now_iso()
        turn = meta["turn"]

        session: SessionContext = meta["session"]
        prior_state: dict = meta["state"]

        # Build the input for this turn
        turn_input = dict(prior_state)
        turn_input["current_turn"] = turn
        turn_input["last_user_message"] = req.message
        turn_input["updated_at"] = _now_iso()

        # Refresh the internal service token so long-running conversations
        # don't hit JWT expiry mid-flow when tools call backend APIs.
        try:
            from auth.jwt_utils import issue_token as _issue_service_token
            _svc_token, _ = _issue_service_token(session.user_id)
            turn_input["auth_token"] = _svc_token
        except Exception:
            log.exception("service_token_refresh_failed", user_id=session.user_id)

        # Append user message to history
        turn_input["message_history"] = prior_state.get("message_history", []) + [
            {"role": "user", "content": req.message}
        ]

        # If an auth challenge is pending, route this turn's text to the typed
        # verification_input slot so the auth agent treats it as a challenge
        # answer (and not as a fresh NLU utterance).
        _prior_scratch_for_vinput = prior_state.get("scratch") or {}
        _pending_for_vinput = _prior_scratch_for_vinput.get("pending_auth_challenge")
        if _pending_for_vinput and isinstance(_pending_for_vinput, dict):
            turn_input["verification_input"] = req.message
        else:
            turn_input["verification_input"] = None

        # Reset per-turn fields so stale data from previous turn doesn't leak
        turn_input["current_action_plan"] = None
        turn_input["policy_path"] = None
        turn_input["planner_reasoning"] = None
        turn_input["last_synthesized_response"] = None
        turn_input["transaction_result"] = None
        turn_input["rag_answer"] = None
        turn_input["rag_citations"] = []
        turn_input["rag_confidence"] = None
        turn_input["rag_caveats"] = []
        turn_input["rag_verification_passed"] = False
        turn_input["rag_freshness_warning"] = False
        turn_input["rag_error"] = None
        turn_input["validation_status"] = None
        turn_input["violations"] = []
        turn_input["escalation_requested"] = False
        turn_input["escalation_context"] = None
        turn_input["tool_exec"] = ToolExecutionState()
        # Fix C5: Reset contradictions so they don't accumulate across
        # turns via the operator.add reducer.
        turn_input["contradictions"] = []
        # H3: Reset HITL state so stale last_confirmed / last_corrections
        # from a prior turn don't leak into the new turn's policy routing.
        turn_input["hitl"] = HITLState()
        # C1: Reset per-turn scratch fields so stale supervisor_completed /
        # supervisor_iteration / supervisor_route from the previous turn
        # don't carry over.  IMPORTANT: simply assigning `{}` does NOT work
        # because the scratch field uses _merge_dict as its reducer — an
        # empty new dict merges into the old, leaving stale values intact.
        # We must explicitly write the reset values so they overwrite.
        # We also explicitly clear pending_auth_challenge (with `{}`, since
        # _merge_dict skips None) unless auth is still in progress.
        from schemas.enums import AuthLevel as _AuthLevel
        _prior_scratch = prior_state.get("scratch") or {}
        _pending_challenge = _prior_scratch.get("pending_auth_challenge")
        _prior_auth = prior_state.get("auth_state")
        _cur_lvl = (
            getattr(_prior_auth, "current_level", _AuthLevel.SESSION)
            if _prior_auth else _AuthLevel.SESSION
        )
        _req_lvl = prior_state.get("required_auth_level", _AuthLevel.SESSION)
        _auth_still_pending = (
            _pending_challenge
            and isinstance(_pending_challenge, dict)
            and _cur_lvl < _req_lvl
        )

        turn_input["scratch"] = {
            "supervisor_completed": [],
            "supervisor_iteration": 0,
            "supervisor_route": "",
            # HITL correction keeps this True across supervisor loops; new user
            # turns must reset so normal extraction still runs.
            "suppress_ambient_entity_llm_when_slot_gap_empty": False,
            # Preserve the challenge across turns only while auth is still
            # below the required level; otherwise overwrite with `{}` so the
            # reducer doesn't keep a stale challenge alive after success.
            "pending_auth_challenge": (
                _pending_challenge if _auth_still_pending else {}
            ),
        }

        log.info(
            "turn_start",
            conversation_id=conversation_id,
            turn=turn,
            message_len=len(req.message),
        )
        _turn_start_time = time.perf_counter()

        try:
            result_state = await _invoke_graph(conversation_id, turn_input)
            # Fix 143: Persist state after the first invocation
            # BEFORE auto-resume.  If _auto_resume throws, we keep the
            # first invocation's state in sync with the checkpointer
            # instead of falling back to the pre-turn state.
            meta["state"] = result_state
            # C2: Auto-resume past interrupt_before=["tool_router"]
            # so the tool executes within this same request.
            result_state = await _auto_resume_if_interrupted(
                conversation_id, result_state,
            )
        except HTTPException:
            raise  # Fix 111: Don't swallow FastAPI HTTPExceptions as 500
        except Exception as exc:
            log.error(
                "turn_graph_error",
                conversation_id=conversation_id,
                turn=turn,
                error=str(exc),
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An error occurred processing your request. Please try again.",
            )

        # Append assistant response to message history
        synth_raw = result_state.get("last_synthesized_response")
        synth = _synth_as_dict(synth_raw)
        if synth:
            entry = _build_assistant_transcript_entry(result_state, synth)
            if entry:
                result_state.setdefault("message_history", [])
                result_state["message_history"] = (
                    result_state.get("message_history", []) + [entry]
                )
                # Patch the checkpoint so this assistant message survives restarts.
                # LangGraph writes the checkpoint at the END of graph.invoke(), before
                # we append the assistant response here — so we must update the
                # checkpoint explicitly to keep it in sync with in-memory state.
                try:
                    _thread_cfg = {"configurable": {"thread_id": conversation_id}}
                    await asyncio.to_thread(
                        _graph.update_state,
                        _thread_cfg,
                        {"message_history": result_state["message_history"]},
                    )
                except Exception:
                    log.exception(
                        "checkpoint_message_history_patch_failed",
                        conversation_id=conversation_id,
                    )

        # Persist updated state
        meta["state"] = result_state

        # Persist turn metadata to durable store
        try:
            from conversation_store.client import conversation_store
            from conversation_store.models import ConversationStatus
            await conversation_store.update_activity(
                conversation_id,
                turn=turn,
                preview=_preview_text(req.message),
                status=ConversationStatus.ACTIVE,
            )
        except Exception:
            log.exception("conversation_store_update_failed", conversation_id=conversation_id)

        log.info(
            "turn_complete",
            conversation_id=conversation_id,
            turn=turn,
            action_type=getattr(
                result_state.get("current_action_plan"), "action_type", None
            ),
        )
        metrics.record_turn_latency(
            (time.perf_counter() - _turn_start_time) * 1000
        )
        metrics.record_active_conversations(len(_conversations))

        return _build_turn_response(conversation_id, result_state)


# -- POST /conversations/{id}/hitl - HITL approval / correction ---------------

@app.post(
    "/conversations/{conversation_id}/hitl",
    response_model=TurnResponse,
)
async def hitl_resume(conversation_id: str, req: HITLRequest, request: Request):
    """
    Resume the graph after a human-in-the-loop interrupt.

    Flow:
      1. Supervisor emitted EXECUTE_TRANSACTION or HITL_APPROVED.
      2. Response Synthesizer rendered a confirmation message.
      3. route_after_synthesizer() routed to tool_router.
      4. Graph paused at interrupt_before=["tool_router"].
      5. Client calls this endpoint with approval/corrections.
      6. We update HITL state and resume the graph.
      7. tool_router dispatches to the correct tool.
      8. Tool executes the transaction.
      9. Response Synthesizer renders the result.
    """
    meta = _get_conversation(conversation_id)
    _validate_session_token(request, meta)

    async with _get_lock(conversation_id):
        # Fix 144: Re-validate that the conversation still exists.
        if conversation_id not in _conversations:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation {conversation_id} not found.",
            )

        # Fix 92: Increment turn counter so HITL-resume logging,
        # metrics, and turn-dependent logic use the correct value.
        meta["turn"] += 1
        meta["last_active_at"] = _now_iso()
        prior_state: dict = meta["state"]

        hitl = prior_state.get("hitl")
        plan = prior_state.get("current_action_plan")

        if not hitl or not getattr(hitl, "pending", False):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="No HITL confirmation is pending for this conversation.",
            )

        # M6: HITL timeout enforcement - reject stale approvals
        # Use the dedicated pending_since timestamp set by supervisor
        # when HITL was presented, rather than updated_at which can drift.
        hitl_requested_at = (
            getattr(hitl, "pending_since", None)
            or prior_state.get("updated_at")
            or meta.get("last_active_at", "")
        )
        if hitl_requested_at:
            try:
                if isinstance(hitl_requested_at, datetime):
                    requested_dt = hitl_requested_at
                else:
                    requested_dt = datetime.fromisoformat(hitl_requested_at)
                elapsed = (datetime.now(timezone.utc) - requested_dt).total_seconds()
                if elapsed > settings.hitl_timeout_seconds:
                    log.warning(
                        "hitl_timeout",
                        conversation_id=conversation_id,
                        elapsed_seconds=elapsed,
                        timeout=settings.hitl_timeout_seconds,
                    )
                    raise HTTPException(
                        status_code=status.HTTP_408_REQUEST_TIMEOUT,
                        detail=(
                            f"HITL confirmation timed out after {int(elapsed)}s "
                            f"(limit: {settings.hitl_timeout_seconds}s). "
                            "Please restart the transaction."
                        ),
                    )
            except (ValueError, TypeError):
                # H3: Unparseable timestamp - log warning and enforce conservative timeout
                log.warning(
                    "hitl_timestamp_unparseable",
                    conversation_id=conversation_id,
                    raw_timestamp=hitl_requested_at,
                )
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Unable to verify HITL timestamp. Please restart the transaction.",
                )

        log.info(
            "hitl_resume",
            conversation_id=conversation_id,
            approved=req.approved,
            has_corrections=bool(req.corrections),
        )
        metrics.record_hitl_decision(approved=req.approved)

        if req.approved:
            # User confirmed - update HITL state and resume graph
            resume_input = dict(prior_state)
            resume_input["hitl"] = hitl.model_copy(update={
                "pending": False,
                "last_confirmed": True,
                "last_corrections": {},
            })
            resume_input["current_action_plan"] = plan.model_copy(update={
                "action_type": ActionType.HITL_APPROVED,
            }) if plan else None

        else:
            # User wants corrections - route back through validation
            resume_input = dict(prior_state)
            resume_input["hitl"] = hitl.model_copy(update={
                "pending": False,
                "last_confirmed": False,
                "last_corrections": req.corrections,
                "attempt_count": hitl.attempt_count + 1,
            })
            resume_input["current_action_plan"] = plan.model_copy(update={
                "action_type": ActionType.HITL_CORRECTION,
            }) if plan else None
            resume_input["correction_count"] = prior_state.get("correction_count", 0) + 1
            # H4: Clear old validated entities so stale data doesn't leak into correction
            resume_input["validated_entities"] = {}

            # Fix 23+28: Apply user corrections to entity_memory so the
            # corrected values are visible to downstream agents, and reset
            # validation state so entity_validator re-runs.
            if req.corrections:
                entity_memory = dict(resume_input.get("entity_memory", {}))
                for slot_name, new_value in req.corrections.items():
                    if slot_name in entity_memory:
                        old_entity = entity_memory[slot_name]
                        # Fix 105: After LangGraph checkpoint deserialization,
                        # entities may be plain dicts instead of Pydantic models.
                        if isinstance(old_entity, dict):
                            updated = dict(old_entity)
                            updated["display_value"] = str(new_value)
                            updated["is_confirmed"] = False
                            updated["turn_confirmed"] = None
                            entity_memory[slot_name] = updated
                        else:
                            entity_memory[slot_name] = old_entity.model_copy(update={
                                "display_value": str(new_value),
                                "is_confirmed": False,
                                "turn_confirmed": None,
                            })
                    else:
                        log.warning(
                            "hitl_correction_unknown_slot",
                            conversation_id=conversation_id,
                            slot=slot_name,
                        )
                resume_input["entity_memory"] = entity_memory

            # Fix 28: Reset validation state to force re-validation of
            # corrected entities instead of reusing stale PASSED status.
            resume_input["validation_status"] = None
            resume_input["violations"] = []

            # Fix: also reset per-turn supervisor scratch fields so a
            # stale ``supervisor_completed=[entity_validator]`` from the
            # turn that produced the HITL screen doesn't suppress the
            # validator-dispatch guard on this correction turn.  Without
            # this, the supervisor decides VALIDATE_ENTITIES, finds the
            # validator already "completed", and falls through to the
            # synthesizer which renders a useless "I'm verifying the
            # details you provided." placeholder.
            _prior_scratch = resume_input.get("scratch") or {}
            resume_input["scratch"] = {
                **_prior_scratch,
                "supervisor_completed": [],
                "supervisor_iteration": 0,
                "supervisor_route": "",
                # One-shot hint: entity_extractor must not hallucinate PLAN_TYPE /
                # account labels from disclosure-heavy HITL text when corrections
                # already filled entity_memory outside chat (see extractor docstring).
                "suppress_ambient_entity_llm_when_slot_gap_empty": True,
            }

        # Fix 92: Propagate incremented turn counter into graph input
        resume_input["current_turn"] = meta["turn"]
        resume_input["updated_at"] = _now_iso()

        try:
            result_state = await _invoke_graph(conversation_id, resume_input)
            # C1: Auto-resume past interrupt_before=["tool_router"]
            # so the tool executes within this same HITL request.
            result_state = await _auto_resume_if_interrupted(
                conversation_id, result_state,
            )
        except HTTPException:
            raise  # Fix 111: Don't swallow FastAPI HTTPExceptions as 500
        except Exception as exc:
            log.error(
                "hitl_graph_error",
                conversation_id=conversation_id,
                error=str(exc),
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="An error occurred resuming the transaction. Please try again.",
            )

        # Append assistant response to history
        synth_raw = result_state.get("last_synthesized_response")
        synth = _synth_as_dict(synth_raw)
        if synth:
            entry = _build_assistant_transcript_entry(result_state, synth)
            if entry:
                result_state["message_history"] = (
                    result_state.get("message_history", []) + [entry]
                )
                try:
                    _thread_cfg = {"configurable": {"thread_id": conversation_id}}
                    await asyncio.to_thread(
                        _graph.update_state,
                        _thread_cfg,
                        {"message_history": result_state["message_history"]},
                    )
                except Exception:
                    log.exception(
                        "checkpoint_message_history_patch_failed",
                        conversation_id=conversation_id,
                    )

        meta["state"] = result_state

        return _build_turn_response(conversation_id, result_state)


# -- POST /conversations/{id}/end - End conversation --------------------------

@app.post(
    "/conversations/{conversation_id}/end",
    response_model=TurnResponse,
)
async def end_conversation(conversation_id: str, request: Request):
    meta = _get_conversation(conversation_id)
    _validate_session_token(request, meta)

    # M3: Acquire conversation lock to prevent race with concurrent turns
    async with _get_lock(conversation_id):
        return await _end_conversation_locked(conversation_id, meta)


async def _end_conversation_locked(
    conversation_id: str, meta: dict[str, Any],
) -> TurnResponse:
    """Inner implementation of end_conversation, called under lock.

    Fix 24: Invoke ONLY the response_synthesizer directly instead of
    the full graph, preventing the pre-set END_SESSION plan from
    being overwritten by supervisor.
    """
    prior_state: dict = meta["state"]

    from schemas.primitives import ActionPlan, ResponseDirective
    from agents.registry import AGENT_REGISTRY

    end_plan = ActionPlan(
        action_type=ActionType.END_SESSION,
        response_directive=ResponseDirective(tone="PROFESSIONAL"),
    )

    # Build input state for synthesizer only
    synth_input = dict(prior_state)
    synth_input["current_action_plan"] = end_plan
    synth_input["updated_at"] = _now_iso()
    synth_input["escalation_requested"] = False
    synth_input["escalation_context"] = None
    synth_input["hitl"] = HITLState()
    synth_input["transaction_result"] = None

    try:
        synth_agent = AGENT_REGISTRY["response_synthesizer"]
        synth_result = await asyncio.to_thread(synth_agent.run, synth_input)
        synth_input.update(synth_result)
    except Exception as exc:
        log.warning("end_conversation_synth_error", error=str(exc))

    meta["state"] = synth_input

    # Layer 5: Persist user profile updates before cleanup
    _persist_profile_updates(meta)

    # M7: Vault PII cleanup - delete all vault tokens created during session
    _cleanup_vault_tokens(meta["state"])

    # Mark conversation as ENDED in durable store
    try:
        from conversation_store.client import conversation_store
        await conversation_store.mark_ended(conversation_id)
    except Exception:
        log.exception("conversation_store_end_failed", conversation_id=conversation_id)

    log.info("conversation_ended", conversation_id=conversation_id)
    metrics.record_conversation_end(
        meta["session"].channel if hasattr(meta.get("session"), "channel") else "unknown"
    )

    response = _build_turn_response(conversation_id, meta["state"])

    # Clean up in-memory conversation data
    _conversations.pop(conversation_id, None)
    _conversation_locks.pop(conversation_id, None)
    # Fix C2: Clean up inflight future tracking to prevent unbounded growth
    _inflight_futures.pop(conversation_id, None)

    return response


# -- GET /conversations/{id} - Conversation snapshot --------------------------

@app.get(
    "/conversations/{conversation_id}",
    response_model=ConversationSnapshot,
)
async def get_conversation(conversation_id: str, request: Request):
    meta = _get_conversation(conversation_id)
    _validate_session_token(request, meta)

    # H3-6th: Acquire lock to avoid reading partially-updated state
    # during a concurrent process_turn or hitl_resume.
    async with _get_lock(conversation_id):
        state = meta["state"]

        intent_label = None
        stack = state.get("intent_stack", [])
        if stack:
            intent_label = stack[0].sub_intent

        auth_status_val = state.get("auth_status")
        if hasattr(auth_status_val, "value"):
            auth_status_val = auth_status_val.value

        hitl = state.get("hitl")
        hitl_pending = getattr(hitl, "pending", False) if hitl else False

        return ConversationSnapshot(
            conversation_id=conversation_id,
            turn=meta["turn"],
            intent=intent_label,
            auth_status=auth_status_val,
            hitl_pending=hitl_pending,
            last_response=state.get("last_synthesized_response"),
        )


# -- GET /conversations - List user's conversations --------------------------

@app.get(
    "/conversations",
    response_model=ConversationListResponse,
)
async def list_conversations(
    include_deleted: bool = False,
    limit: int = 50,
    cursor: str | None = None,
    current_user: str = Depends(require_user),
):
    """Return all conversations owned by the authenticated user.

    Results are most-recently-active first.  Use ``cursor`` (an ISO
    timestamp returned as ``next_cursor``) for pagination.
    Set ``include_deleted=true`` to also retrieve soft-deleted chats.
    """
    from conversation_store.client import conversation_store

    records = await conversation_store.list_by_user(
        current_user,
        include_deleted=include_deleted,
        limit=limit + 1,   # fetch one extra to detect next page
        cursor=cursor,
    )

    next_cursor = None
    if len(records) > limit:
        records = records[:limit]
        next_cursor = records[-1].last_active_at.isoformat()

    items = [
        ConversationListItem(
            conversation_id=r.conversation_id,
            status=r.status.value,
            title=r.title,
            last_user_message_preview=r.last_user_message_preview,
            current_turn=r.current_turn,
            channel=r.channel,
            created_at=r.created_at.isoformat(),
            last_active_at=r.last_active_at.isoformat(),
            ended_at=r.ended_at.isoformat() if r.ended_at else None,
            deleted_at=r.deleted_at.isoformat() if r.deleted_at else None,
        )
        for r in records
    ]
    return ConversationListResponse(
        conversations=items,
        total=len(items),
        next_cursor=next_cursor,
    )


# -- POST /conversations/{id}/resume - Resume a past conversation ------------

@app.post(
    "/conversations/{conversation_id}/resume",
    response_model=ResumeConversationResponse,
)
async def resume_conversation(
    conversation_id: str,
    current_user: str = Depends(require_user),
):
    """Re-open a past conversation after logout/login.

    Issues a new ``session_token`` for the conversation so the client
    can call ``/turns``, ``/hitl``, and ``/end`` again.  Requires the
    login JWT; ownership is enforced against ``user_id`` from the token.

    The graph checkpoint is preserved in the Postgres checkpointer under
    the original ``thread_id=conversation_id``.
    """
    from conversation_store.client import conversation_store
    from conversation_store.models import ConversationStatus
    from graph.state import initial_state

    record = await conversation_store.get(conversation_id, user_id=current_user)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation {conversation_id} not found.",
        )
    if record.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="This conversation has been deleted and cannot be resumed.",
        )

    # If already live in memory, just rotate the session token
    if conversation_id in _conversations:
        meta = _conversations[conversation_id]
        new_token = uuid.uuid4().hex
        meta["session_token"] = new_token
        await conversation_store.update_activity(
            conversation_id,
            turn=meta["turn"],
            preview=None,
            status=ConversationStatus(record.status.value),
            session_token_hash=_hash_token(new_token),
        )
        return ResumeConversationResponse(
            conversation_id=conversation_id,
            session_token=new_token,
            status=record.status.value,
            current_turn=meta["turn"],
            last_active_at=meta["last_active_at"],
            message_history=_sanitize_message_history_for_ui(meta["state"].get("message_history")),
        )

    # Rebuild the in-memory entry from the durable store
    new_token = uuid.uuid4().hex
    try:
        from auth.client import secrets_provider
        from auth.jwt_utils import issue_token as _issue_service_token
        from schemas.enums import AuthLevel as _AuthLevel, AuthStatus as _AuthStatus
        from schemas.primitives import AuthState as _AuthState

        seeded = secrets_provider().get_account_context(current_user) or {}
        service_token, _ = _issue_service_token(current_user)
    except Exception:
        log.exception("resume_setup_failed", conversation_id=conversation_id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to restore conversation context.",
        )

    session = SessionContext(
        session_id=uuid.uuid4(),
        user_id=current_user,
        channel=record.channel,
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )
    state = initial_state(session)
    # Hydrate from LangGraph checkpoint when available so transcript/intent
    # context survives process restarts.
    restored_values: dict[str, Any] = {}
    if _graph is not None:
        try:
            thread_config = {"configurable": {"thread_id": conversation_id}}
            snapshot = await asyncio.to_thread(_graph.get_state, thread_config)
            values = getattr(snapshot, "values", None)
            if isinstance(values, dict):
                restored_values = dict(values)
        except Exception:
            log.exception("resume_checkpoint_restore_failed", conversation_id=conversation_id)

    if restored_values:
        state.update(restored_values)

    # Always refresh runtime-sensitive fields for the current process.
    state["conversation_id"] = conversation_id
    state["account_context"] = seeded
    state["auth_token"] = service_token
    state["current_turn"] = record.current_turn

    # Load cross-session user profile
    try:
        from user_profile.client import profile_store
        profile = profile_store.load(current_user)
        if profile:
            state["user_profile"] = profile.model_dump()
    except Exception:
        pass

    _conversation_locks[conversation_id] = asyncio.Lock()
    _conversations[conversation_id] = {
        "session": session,
        "session_token": new_token,
        "state": state,
        "turn": record.current_turn,
        "created_at": record.created_at.isoformat(),
        "last_active_at": record.last_active_at.isoformat(),
    }

    # Update token hash in store
    await conversation_store.update_activity(
        conversation_id,
        turn=record.current_turn,
        preview=None,
        status=ConversationStatus(record.status.value),
        session_token_hash=_hash_token(new_token),
    )

    log.info(
        "conversation_resumed",
        conversation_id=conversation_id,
        user_id=current_user,
        turn=record.current_turn,
    )
    return ResumeConversationResponse(
        conversation_id=conversation_id,
        session_token=new_token,
        status=record.status.value,
        current_turn=record.current_turn,
        last_active_at=record.last_active_at.isoformat(),
        message_history=_sanitize_message_history_for_ui(state.get("message_history")),
    )


# -- DELETE /conversations/{id} - Soft delete --------------------------------

@app.delete(
    "/conversations/{conversation_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def soft_delete_conversation(
    conversation_id: str,
    current_user: str = Depends(require_user),
):
    """Soft-delete a conversation (hide from default list).

    Metadata and checkpoint remain until hard-deleted or restored via
    ``POST …/restore``.
    """
    from conversation_store.client import conversation_store

    deleted = await conversation_store.soft_delete(conversation_id, current_user)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found or already deleted.",
        )
    # Evict from in-memory cache so subsequent requests see the deletion
    _conversations.pop(conversation_id, None)
    _conversation_locks.pop(conversation_id, None)
    _inflight_futures.pop(conversation_id, None)
    log.info("conversation_soft_deleted", conversation_id=conversation_id, user_id=current_user)


# -- POST /conversations/{id}/restore - Unhide soft-deleted ------------------

@app.post(
    "/conversations/{conversation_id}/restore",
    response_model=RestoreConversationResponse,
)
async def restore_conversation(
    conversation_id: str,
    current_user: str = Depends(require_user),
):
    """Clear soft-delete so the conversation appears in the default list again."""
    from conversation_store.client import conversation_store

    restored = await conversation_store.restore_soft_delete(
        conversation_id, current_user
    )
    if not restored:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found or not hidden.",
        )
    record = await conversation_store.get(conversation_id, user_id=current_user)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation {conversation_id} not found.",
        )
    log.info("conversation_restored", conversation_id=conversation_id, user_id=current_user)
    return RestoreConversationResponse(
        conversation_id=conversation_id,
        status=record.status.value,
    )


# -- DELETE /conversations/{id}/hard - Permanent delete ----------------------

@app.delete(
    "/conversations/{conversation_id}/hard",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def hard_delete_conversation(
    conversation_id: str,
    current_user: str = Depends(require_user),
):
    """Permanently delete a conversation and its graph checkpoint.

    This action is irreversible.  All graph checkpoint state is removed
    from the checkpointer and the metadata row is deleted from the
    database.  Vault tokens are cleaned up if the conversation is still
    in memory.
    """
    from conversation_store.client import conversation_store

    # Clean up vault tokens if conversation is still live in memory
    meta = _conversations.get(conversation_id)
    if meta:
        session: SessionContext = meta.get("session")
        if session and session.user_id != current_user:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not own this conversation.",
            )
        _cleanup_vault_tokens(meta.get("state", {}))
        _conversations.pop(conversation_id, None)
        _conversation_locks.pop(conversation_id, None)
        _inflight_futures.pop(conversation_id, None)

    deleted = await conversation_store.hard_delete(conversation_id, current_user)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found.",
        )

    # Remove graph checkpoint from the checkpointer if it supports deletion
    try:
        if _graph is not None:
            checkpointer = getattr(_graph, "checkpointer", None)
            if checkpointer and hasattr(checkpointer, "delete"):
                thread_config = {"configurable": {"thread_id": conversation_id}}
                checkpointer.delete(thread_config)
            elif checkpointer and hasattr(checkpointer, "adelete"):
                thread_config = {"configurable": {"thread_id": conversation_id}}
                await asyncio.to_thread(checkpointer.adelete, thread_config)
    except Exception:
        log.warning("checkpoint_delete_failed", conversation_id=conversation_id)

    log.info("conversation_hard_deleted", conversation_id=conversation_id, user_id=current_user)


# -- GET /health - Liveness probe ---------------------------------------------

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok", timestamp=_now_iso())


# -- GET /ready - Readiness probe ---------------------------------------------

@app.get("/ready", response_model=HealthResponse)
async def readiness():
    if _graph is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Graph not compiled yet.",
        )

    from agents.registry import AGENT_REGISTRY
    required = [
        "message_classifier", "intent_agent", "entity_extraction",
        "rag_agent", "auth_agent", "entity_validator",
        "supervisor", "response_synthesizer",
    ]
    missing = [a for a in required if a not in AGENT_REGISTRY]
    if missing:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"{len(missing)} required agent(s) not loaded",
        )

    return HealthResponse(status="ready", timestamp=_now_iso())


# =============================================================================
# CLI Entry Point
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
