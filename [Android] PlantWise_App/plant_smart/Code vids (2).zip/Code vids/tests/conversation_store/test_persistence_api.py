"""Integration-style tests for the conversation persistence API layer.

Uses the FastAPI ``TestClient`` with a monkeypatched in-memory conversation
store and MemorySaver checkpointer so no real database is needed.

Tests cover:
  - POST  /conversations           creates a row in the store
  - POST  /conversations/{id}/resume  issues a new session token
  - GET   /conversations           lists user chats (owned, not deleted)
  - DELETE /conversations/{id}        soft delete
  - DELETE /conversations/{id}/hard   hard delete
  - Ownership enforcement (cross-user access rejected)
  - Re-login continuity: create → list → resume → turn
"""

from __future__ import annotations

import asyncio
import uuid
from unittest.mock import patch, AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from conversation_store.memory import MemoryConversationStore
from conversation_store.models import ConversationRecord, ConversationStatus


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def memory_store(monkeypatch):
    """Replace the global conversation store with a fresh in-memory instance."""
    store = MemoryConversationStore()

    # Run setup synchronously (MemoryConversationStore.setup is a no-op)
    asyncio.get_event_loop().run_until_complete(store.setup())

    import conversation_store.client as _cs_client
    monkeypatch.setattr(_cs_client, "_store", store)
    return store


@pytest.fixture
def client(monkeypatch):
    """TestClient for the FastAPI app with patched graph and auth."""
    # Patch JWT decode so every request is treated as coming from "demo-user-001"
    from auth import jwt_utils
    monkeypatch.setattr(jwt_utils, "decode_token", lambda t: "demo-user-001")

    # Patch graph compilation to avoid actually loading all agents
    from graph import builder
    mock_graph = MagicMock()
    mock_graph.invoke.return_value = {
        "last_synthesized_response": {"full_message": "Hello!"},
        "current_action_plan": None,
        "message_history": [],
    }
    monkeypatch.setattr(builder, "compile_graph", lambda checkpointer=None: mock_graph)

    import main as _main
    monkeypatch.setattr(_main, "_graph", mock_graph)

    # Patch conversation_store.setup in lifespan to avoid DB calls
    from conversation_store.client import conversation_store as _cs
    monkeypatch.setattr(_cs, "setup", AsyncMock())

    from fastapi.testclient import TestClient as _TC
    with _TC(_main.app) as c:
        yield c


AUTH_HEADER = {"Authorization": "Bearer test-token"}


# ---------------------------------------------------------------------------
# POST /conversations
# ---------------------------------------------------------------------------


def test_start_conversation_creates_store_record(client, memory_store):
    resp = client.post("/conversations", json={}, headers=AUTH_HEADER)
    assert resp.status_code == 201
    data = resp.json()
    cid = data["conversation_id"]

    loop = asyncio.get_event_loop()
    record = loop.run_until_complete(memory_store.get(cid, user_id="demo-user-001"))
    assert record is not None
    assert record.status == ConversationStatus.ACTIVE
    assert record.user_id == "demo-user-001"


# ---------------------------------------------------------------------------
# GET /conversations
# ---------------------------------------------------------------------------


def test_list_conversations_returns_own_chats(client, memory_store):
    # Pre-seed two conversations for demo-user-001
    from datetime import timezone
    loop = asyncio.get_event_loop()
    for i in range(2):
        loop.run_until_complete(memory_store.create(ConversationRecord(
            conversation_id=f"seed-{i}",
            user_id="demo-user-001",
        )))

    resp = client.get("/conversations", headers=AUTH_HEADER)
    assert resp.status_code == 200
    data = resp.json()
    ids = {c["conversation_id"] for c in data["conversations"]}
    assert {"seed-0", "seed-1"}.issubset(ids)


def test_list_excludes_soft_deleted_by_default(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="visible", user_id="demo-user-001",
    )))
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="hidden", user_id="demo-user-001",
    )))
    loop.run_until_complete(memory_store.soft_delete("hidden", "demo-user-001"))

    resp = client.get("/conversations", headers=AUTH_HEADER)
    ids = {c["conversation_id"] for c in resp.json()["conversations"]}
    assert "visible" in ids
    assert "hidden" not in ids


def test_list_includes_deleted_when_flag_set(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="deleted-one", user_id="demo-user-001",
    )))
    loop.run_until_complete(memory_store.soft_delete("deleted-one", "demo-user-001"))

    resp = client.get("/conversations?include_deleted=true", headers=AUTH_HEADER)
    ids = {c["conversation_id"] for c in resp.json()["conversations"]}
    assert "deleted-one" in ids


# ---------------------------------------------------------------------------
# DELETE /conversations/{id}  (soft)
# ---------------------------------------------------------------------------


def test_soft_delete_returns_204(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="to-soft", user_id="demo-user-001",
    )))

    resp = client.delete("/conversations/to-soft", headers=AUTH_HEADER)
    assert resp.status_code == 204

    record = loop.run_until_complete(memory_store.get("to-soft"))
    assert record.status == ConversationStatus.SOFT_DELETED


def test_soft_delete_wrong_owner_returns_404(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="other-conv", user_id="other-user",
    )))

    resp = client.delete("/conversations/other-conv", headers=AUTH_HEADER)
    # Store enforces user_id ownership; record not found for demo-user-001
    assert resp.status_code == 404


def test_soft_delete_missing_returns_404(client):
    resp = client.delete("/conversations/does-not-exist", headers=AUTH_HEADER)
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# POST /conversations/{id}/restore
# ---------------------------------------------------------------------------


def test_restore_soft_deleted_returns_active(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="to-restore",
        user_id="demo-user-001",
    )))
    client.delete("/conversations/to-restore", headers=AUTH_HEADER)

    resp = client.post("/conversations/to-restore/restore", headers=AUTH_HEADER)
    assert resp.status_code == 200
    body = resp.json()
    assert body["conversation_id"] == "to-restore"
    assert body["status"] == "ACTIVE"

    vis = client.get("/conversations", headers=AUTH_HEADER).json()["conversations"]
    assert any(c["conversation_id"] == "to-restore" for c in vis)


def test_restore_not_hidden_returns_404(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="never-hidden",
        user_id="demo-user-001",
    )))
    resp = client.post("/conversations/never-hidden/restore", headers=AUTH_HEADER)
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# DELETE /conversations/{id}/hard
# ---------------------------------------------------------------------------


def test_hard_delete_returns_204(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="to-hard", user_id="demo-user-001",
    )))

    resp = client.delete("/conversations/to-hard/hard", headers=AUTH_HEADER)
    assert resp.status_code == 204

    record = loop.run_until_complete(memory_store.get("to-hard"))
    assert record is None


def test_hard_delete_wrong_owner_returns_404(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="other-hard", user_id="other-user",
    )))
    resp = client.delete("/conversations/other-hard/hard", headers=AUTH_HEADER)
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# POST /conversations/{id}/resume (re-login flow)
# ---------------------------------------------------------------------------


def test_resume_returns_new_session_token(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="old-conv", user_id="demo-user-001",
        current_turn=3,
    )))

    resp = client.post("/conversations/old-conv/resume", headers=AUTH_HEADER)
    assert resp.status_code == 200
    data = resp.json()
    assert "session_token" in data
    assert data["conversation_id"] == "old-conv"
    assert data["current_turn"] == 3


def test_resume_deleted_conversation_returns_410(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="deleted-conv", user_id="demo-user-001",
    )))
    loop.run_until_complete(memory_store.soft_delete("deleted-conv", "demo-user-001"))

    resp = client.post("/conversations/deleted-conv/resume", headers=AUTH_HEADER)
    assert resp.status_code == 410


def test_resume_wrong_owner_returns_404(client, memory_store):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(memory_store.create(ConversationRecord(
        conversation_id="owned-by-other", user_id="other-user",
    )))
    resp = client.post("/conversations/owned-by-other/resume", headers=AUTH_HEADER)
    assert resp.status_code == 404


def test_resume_missing_returns_404(client):
    resp = client.post("/conversations/not-a-real-id/resume", headers=AUTH_HEADER)
    assert resp.status_code == 404
