"""Unit tests for MemoryConversationStore.

Tests cover: create, get, list, update_activity, mark_ended,
soft_delete, hard_delete, and ownership enforcement.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import pytest

from conversation_store.memory import MemoryConversationStore
from conversation_store.models import ConversationRecord, ConversationStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _record(
    cid: str = "conv-001",
    uid: str = "user-001",
    channel: str = "web",
) -> ConversationRecord:
    return ConversationRecord(
        conversation_id=cid,
        user_id=uid,
        status=ConversationStatus.ACTIVE,
        channel=channel,
    )


@pytest.fixture
def store():
    return MemoryConversationStore()


# ---------------------------------------------------------------------------
# create / get
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_and_get(store):
    rec = _record()
    await store.create(rec)
    result = await store.get("conv-001")
    assert result is not None
    assert result.conversation_id == "conv-001"
    assert result.user_id == "user-001"


@pytest.mark.asyncio
async def test_get_missing_returns_none(store):
    assert await store.get("does-not-exist") is None


@pytest.mark.asyncio
async def test_get_with_wrong_owner_returns_none(store):
    await store.create(_record(uid="alice"))
    result = await store.get("conv-001", user_id="bob")
    assert result is None


@pytest.mark.asyncio
async def test_get_with_correct_owner_returns_record(store):
    await store.create(_record(uid="alice"))
    result = await store.get("conv-001", user_id="alice")
    assert result is not None


# ---------------------------------------------------------------------------
# list_by_user
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_by_user_returns_own_conversations(store):
    await store.create(_record("c1", "user-A"))
    await store.create(_record("c2", "user-A"))
    await store.create(_record("c3", "user-B"))
    results = await store.list_by_user("user-A")
    ids = {r.conversation_id for r in results}
    assert ids == {"c1", "c2"}


@pytest.mark.asyncio
async def test_list_excludes_deleted_by_default(store):
    await store.create(_record("c1", "user-A"))
    await store.create(_record("c2", "user-A"))
    await store.soft_delete("c2", "user-A")
    results = await store.list_by_user("user-A")
    assert len(results) == 1
    assert results[0].conversation_id == "c1"


@pytest.mark.asyncio
async def test_list_includes_deleted_when_flag_set(store):
    await store.create(_record("c1", "user-A"))
    await store.create(_record("c2", "user-A"))
    await store.soft_delete("c2", "user-A")
    results = await store.list_by_user("user-A", include_deleted=True)
    assert len(results) == 2


@pytest.mark.asyncio
async def test_list_respects_limit(store):
    for i in range(10):
        await store.create(_record(f"c{i}", "user-A"))
    results = await store.list_by_user("user-A", limit=3)
    assert len(results) == 3


# ---------------------------------------------------------------------------
# update_activity
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_activity_sets_turn_and_preview(store):
    await store.create(_record())
    await store.update_activity(
        "conv-001",
        turn=5,
        preview="What is my balance?",
    )
    result = await store.get("conv-001")
    assert result.current_turn == 5
    assert result.last_user_message_preview == "What is my balance?"


@pytest.mark.asyncio
async def test_update_activity_on_missing_is_noop(store):
    # Should not raise
    await store.update_activity("does-not-exist", turn=1, preview=None)


# ---------------------------------------------------------------------------
# mark_ended
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_mark_ended_sets_status_and_timestamp(store):
    await store.create(_record())
    await store.mark_ended("conv-001")
    result = await store.get("conv-001")
    assert result.status == ConversationStatus.ENDED
    assert result.ended_at is not None


# ---------------------------------------------------------------------------
# soft_delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_soft_delete_sets_status_and_deleted_at(store):
    await store.create(_record())
    ok = await store.soft_delete("conv-001", "user-001")
    assert ok is True
    result = await store.get("conv-001")
    assert result.status == ConversationStatus.SOFT_DELETED
    assert result.deleted_at is not None


@pytest.mark.asyncio
async def test_soft_delete_wrong_owner_returns_false(store):
    await store.create(_record(uid="alice"))
    ok = await store.soft_delete("conv-001", "bob")
    assert ok is False


@pytest.mark.asyncio
async def test_soft_delete_already_deleted_returns_false(store):
    await store.create(_record())
    await store.soft_delete("conv-001", "user-001")
    ok = await store.soft_delete("conv-001", "user-001")
    assert ok is False


@pytest.mark.asyncio
async def test_soft_delete_missing_returns_false(store):
    ok = await store.soft_delete("does-not-exist", "user-001")
    assert ok is False


# ---------------------------------------------------------------------------
# restore_soft_delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_restore_soft_delete_clears_deleted_at(store):
    await store.create(_record())
    await store.soft_delete("conv-001", "user-001")
    ok = await store.restore_soft_delete("conv-001", "user-001")
    assert ok is True
    result = await store.get("conv-001")
    assert result is not None
    assert result.status == ConversationStatus.ACTIVE
    assert result.deleted_at is None


@pytest.mark.asyncio
async def test_restore_soft_delete_not_hidden_returns_false(store):
    await store.create(_record())
    ok = await store.restore_soft_delete("conv-001", "user-001")
    assert ok is False


# ---------------------------------------------------------------------------
# hard_delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_hard_delete_removes_record(store):
    await store.create(_record())
    ok = await store.hard_delete("conv-001", "user-001")
    assert ok is True
    assert await store.get("conv-001") is None


@pytest.mark.asyncio
async def test_hard_delete_wrong_owner_returns_false(store):
    await store.create(_record(uid="alice"))
    ok = await store.hard_delete("conv-001", "bob")
    assert ok is False
    # Record must still exist
    assert await store.get("conv-001") is not None


@pytest.mark.asyncio
async def test_hard_delete_missing_returns_false(store):
    ok = await store.hard_delete("does-not-exist", "user-001")
    assert ok is False


# ---------------------------------------------------------------------------
# pagination cursor
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_pagination_cursor(store):
    import time
    for i in range(5):
        rec = _record(f"c{i}", "user-A")
        rec.last_active_at = datetime(2024, 1, i + 1, tzinfo=timezone.utc)
        await store.create(rec)

    page1 = await store.list_by_user("user-A", limit=3)
    assert len(page1) == 3
    next_cursor = page1[-1].last_active_at.isoformat()

    page2 = await store.list_by_user("user-A", limit=3, cursor=next_cursor)
    all_ids = {r.conversation_id for r in page1 + page2}
    assert len(all_ids) == 5
