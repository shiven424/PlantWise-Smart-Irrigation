"""
**Extended v3** end-to-end LangGraph scenarios for balance_inquiry.

Builds on top of:
  * ``test_balance_inquiry_e2e.py``               (S1-S6,   6 base scenarios)
  * ``test_balance_inquiry_e2e_extended.py``      (S7-S16, 10 scenarios)
  * ``test_balance_inquiry_e2e_extended_v2.py``   (S17-S26, 10 scenarios)

This file adds **S27-S37** (11 more) covering remaining angles:

  EASY (1 turn)
    S27  alex preauth, single account, BARE "what's my balance?" -- no
         account_type token; agent must auto-pick the only account.
    S28  jordan preauth, ALL-CAPS shouting "WHAT IS MY 401K BALANCE?"
         -- case-insensitive intent + slot extraction.
    S29  alex preauth, typo on the keyword "balanace" -- robustness
         against minor misspellings on a single-account user.

  MEDIUM (2 turns)
    S30  jordan unauth, SSN supplied PREEMPTIVELY in the same message
         as the request ("My SSN ends in 7766, show me my IRA balance").
         Eventually returns IRA ****2200 once the auth pipeline runs.
    S31  jordan preauth, sequential DIFFERENT-account follow-up:
         "401k balance" -> ****1100, then "and what about my IRA?" ->
         ****2200.  Distinct from S13 (3 sequential same-style) -- this
         tests the "and what about X?" follow-up phrasing.
    S32  jordan preauth CANCEL mid-flow: "balance?" -> COLLECT_SLOT ->
         "actually nevermind" -- no false-positive transaction, no
         escalation, graceful close.

  COMPLEX (3+ turns)
    S33  taylor unauth, TWO wrong SSNs then the correct one:
         "0000" -> retry, "1111" -> retry, "5544" -> ROTH ****5500.
         Tests that auth_agent retries past more than one wrong answer.
    S34  jordan preauth PIVOT mid-slot-fill: "balance?" -> COLLECT_SLOT
         -> "actually scratch that, IRA please" -> ****2200.  Last-
         expressed account wins.
    S35  jordan preauth INTERLEAVED chitchat + multi-account balances:
         "Hi" -> chitchat ; "401k" -> ****1100 ; "thanks!" -> chitchat ;
         "IRA balance now" -> ****2200.  Stresses tool_exec / intent
         lifecycle resets across mixed turns.
    S36  taylor preauth NEGATION in a single message: "Don't show me
         my Roth, give me my 401(k) balance" -> ****4400.  Different
         from S19 which uses parenthetical disambiguation.
    S37  morgan preauth, BARE keyword reply on slot collection: a
         multi-step tickle where the user is terse ("balance" then
         "401k") -- single-account user should still resolve cleanly
         to ****5511 even if the first turn slot-collects.

Each test asserts every turn:
  * synthesizer action_type
  * transaction_result success / account_display / total_balance
  * auth_status transitions where relevant
  * absence of escalation on happy paths
  * absence of false-positive transactions on slot-fill / cancel /
    chitchat turns

Requires OPENAI_API_KEY (real LLM per turn -> slow).
"""
from __future__ import annotations

import os

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from schemas.enums import ActionType, AuthStatus

from tests.e2e._balance_helpers import (
    assert_balance_response,
    drive_one_turn,
    drive_turn_with_auto_resume,
    new_session,
    preauth_state,
    seed_account_context,
    seed_mock_account_api_from_demo_data,
    thread_config,
)
from graph.state import initial_state


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; balance_inquiry e2e tests need a live LLM.",
)


@pytest.fixture(scope="module")
def graph():
    seed_mock_account_api_from_demo_data()
    return compile_graph(checkpointer=get_checkpointer())


# ===========================================================================
# Local helper -- prime an unauth challenge until expected_hash exists.
# ===========================================================================

def _prime_until_challenge(graph, state: dict, config: dict, max_primes: int = 4) -> dict:
    """Send filler 'ok-style' messages until the auth challenge has an
    expected_hash, mirroring the priming pattern used by S6/S15/S16/S21/S22."""
    for msg in ("sure", "yes please", "go ahead", "ok")[:max_primes]:
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            return state
        state = drive_one_turn(graph, state, msg, config)
    return state


# ===========================================================================
# EASY -- 1-turn variations
# ===========================================================================


# --- S27 alex preauth, chitchat-then-balance on single-account user -------

def test_s27_chitchat_then_balance_single_account(graph):
    """alex (single-account 401K) preauth, two-turn flow:
        Turn 1: 'Hi there!'              -> CHITCHAT_RESPOND.
        Turn 2: 'What's my 401k balance?' -> ****8810 / 148,980.55.

    Distinct from S10 (which exercises the same flow but on jordan,
    a multi-account user).  Validates that chitchat on a single-
    account user does not perturb the subsequent balance turn."""
    session, state = preauth_state("demo-user-001")
    config = thread_config(session)

    # Turn 1 -- chitchat
    state = drive_one_turn(graph, state, "Hi there!", config)
    assert state.get("transaction_result") is None
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.CHITCHAT_RESPOND.value, ActionType.ANSWER.value,
    )

    # Turn 2 -- balance
    result = drive_turn_with_auto_resume(
        graph, state, "What's my 401k balance?", config,
    )
    assert_balance_response(result, expected_last4="8810", expected_total=148980.55)
    assert not result.get("escalation_requested")


# --- S28 jordan preauth, ALL-CAPS request ---------------------------------

def test_s28_all_caps_request(graph):
    """jordan (demo-user-004, multi-account) shouts the request in all
    caps.  Intent classifier and entity extractor must be case-
    insensitive -- result should be 401K ****1100 / 492,100.25."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state, "WHAT IS MY 401K BALANCE?", config,
    )
    assert_balance_response(result, expected_last4="1100", expected_total=492100.25)
    assert not result.get("escalation_requested")


# --- S29 alex preauth, misspelled "balanace" ------------------------------

def test_s29_misspelled_balance_keyword(graph):
    """alex (single-account) asks with a typo on 'balance' ->
    'whats my 401k balanace?'.  The intent classifier should still
    detect ACCOUNT_BALANCE_INQUIRY and return ****8810."""
    session, state = preauth_state("demo-user-001")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state, "whats my 401k balanace?", config,
    )
    assert_balance_response(result, expected_last4="8810", expected_total=148980.55)
    assert not result.get("escalation_requested")


# ===========================================================================
# MEDIUM -- 2-turn flows
# ===========================================================================


# --- S30 jordan unauth, preemptive SSN in opening message -----------------

def test_s30_preemptive_ssn_in_opening_message(graph):
    """jordan unauth says 'My SSN ends in 7766, show me my IRA
    balance.' in a single message.  Whether the auth agent accepts
    the SSN immediately or still requires a challenge round, the
    flow must EVENTUALLY return IRA ****2200 / 78,400 without
    escalating, and must NOT produce a false transaction prior to
    auth."""
    session = new_session("demo-user-004")
    state = initial_state(session)
    seed_account_context(state, "demo-user-004")
    config = thread_config(session)

    # Turn 1 -- combined SSN + balance ask
    state = drive_turn_with_auto_resume(
        graph, state,
        "My SSN ends in 7766, show me my IRA balance please.",
        config,
    )
    tx = state.get("transaction_result") or {}

    if tx.get("success") is True:
        # Best case -- system pulled the SSN out and authenticated.
        assert_balance_response(state, expected_last4="2200", expected_total=78400.00)
        assert state.get("auth_status") == AuthStatus.VERIFIED
        return

    # Otherwise -- transaction must NOT have spuriously succeeded.
    assert state.get("transaction_result") is None or not tx.get("success"), (
        f"Pre-auth turn must not return real balance, got {tx!r}"
    )
    assert not state.get("escalation_requested")

    # Drive the standard auth challenge to completion.
    state = _prime_until_challenge(graph, state, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )
    result = drive_turn_with_auto_resume(graph, state, "7766", config)
    assert result.get("auth_status") == AuthStatus.VERIFIED
    assert_balance_response(result, expected_last4="2200", expected_total=78400.00)


# --- S31 jordan preauth, sequential DIFFERENT-account follow-up -----------

def test_s31_sequential_different_account_followup(graph):
    """jordan preauth:
        Turn 1: 'Show me my 401k balance.'    -> ****1100.
        Turn 2: 'And what about my IRA?'      -> ****2200.

    Verifies the 'and what about X?' follow-up phrasing carries the
    BALANCE_INQUIRY intent forward with a NEW account_type slot."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    state = drive_turn_with_auto_resume(
        graph, state, "Show me my 401k balance.", config,
    )
    assert_balance_response(state, expected_last4="1100", expected_total=492100.25)

    result = drive_turn_with_auto_resume(
        graph, state, "And what about my IRA?", config,
    )
    assert_balance_response(result, expected_last4="2200", expected_total=78400.00)
    assert not result.get("escalation_requested")


# --- S32 jordan preauth, CANCEL mid-flow ----------------------------------

def test_s32_cancel_mid_slot_collection(graph):
    """jordan preauth:
        Turn 1: 'Check my balance please'  -> COLLECT_SLOT (multi-acct).
        Turn 2: 'Actually nevermind.'       -> no transaction, no
                                              escalation, graceful close.

    The cancel turn must not somehow execute a balance with stale
    entity_memory (e.g. a leftover account_type from a prior turn
    that doesn't exist here)."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1 -- ambiguous, expect slot-collect
    state = drive_one_turn(graph, state, "Check my balance please.", config)
    assert state.get("transaction_result") is None
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.COLLECT_SLOT.value, ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value,
    ), f"Unexpected turn-1 action: {synth1.get('action_type')!r}"

    # Turn 2 -- cancel
    result = drive_one_turn(graph, state, "Actually nevermind.", config)
    tx = result.get("transaction_result")
    assert tx is None or tx.get("success") is False, (
        f"Cancel must not produce a successful balance, got {tx!r}"
    )
    assert not result.get("escalation_requested")
    synth2 = result.get("last_synthesized_response") or {}
    assert synth2.get("full_message"), "Cancel turn produced no rendered message"


# ===========================================================================
# COMPLEX -- 3+ turn flows
# ===========================================================================


# --- S33 taylor unauth, TWO wrong SSNs then correct -----------------------

def test_s33_two_wrong_ssns_then_correct_roth(graph):
    """taylor (demo-user-005) unauth Roth journey with TWO failed
    attempts before the correct SSN '5544':
        Turn 1: 'What's my Roth IRA balance?'  -> SSN challenge.
        Turn 2..n: prime until challenge hash.
        Wrong:   '0000'                        -> stays PENDING.
        Wrong:   '1111'                        -> stays PENDING.
        Right:   '5544'                        -> VERIFIED, ****5500.

    Validates that the auth pipeline tolerates more than one wrong
    attempt without silently escalating or returning a balance."""
    session = new_session("demo-user-005")
    state = initial_state(session)
    seed_account_context(state, "demo-user-005")
    config = thread_config(session)

    # Turn 1 -- ask
    state = drive_one_turn(graph, state, "What's my Roth IRA balance?", config)
    assert state.get("auth_status") == AuthStatus.PENDING
    assert state.get("transaction_result") is None

    state = _prime_until_challenge(graph, state, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), "No initial challenge"

    # Wrong attempt #1
    state = drive_one_turn(graph, state, "0000", config)
    assert state.get("auth_status") != AuthStatus.VERIFIED
    assert state.get("transaction_result") is None

    # Re-prime if needed
    state = _prime_until_challenge(graph, state, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    if not pending.get("expected_hash"):
        # Some retry policies re-issue the challenge later -- not a hard fail.
        pytest.skip("Auth flow did not re-challenge after first wrong SSN")

    # Wrong attempt #2
    state = drive_one_turn(graph, state, "1111", config)
    assert state.get("auth_status") != AuthStatus.VERIFIED
    if state.get("auth_state") and getattr(state["auth_state"], "is_locked", False):
        pytest.skip("Account locked after second wrong SSN -- escalate path")
    assert state.get("transaction_result") is None

    # Re-prime if needed
    state = _prime_until_challenge(graph, state, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    if not pending.get("expected_hash"):
        pytest.skip("Auth flow did not re-challenge after second wrong SSN")

    # Correct
    result = drive_turn_with_auto_resume(graph, state, "5544", config)
    assert result.get("auth_status") == AuthStatus.VERIFIED
    assert_balance_response(result, expected_last4="5500", expected_total=28100.00)


# --- S34 jordan preauth, PIVOT mid-slot-fill ------------------------------

def test_s34_pivot_mid_slot_fill(graph):
    """jordan preauth:
        Turn 1: 'Balance please.'               -> COLLECT_SLOT.
        Turn 2: 'Actually scratch that, IRA please.' -> ****2200.

    Validates that a 'scratch that' / pivot phrasing inside the slot-
    fill turn correctly overwrites any prior partial slot and lands
    on TRADITIONAL_IRA."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    state = drive_one_turn(graph, state, "Balance please.", config)
    assert state.get("transaction_result") is None

    result = drive_turn_with_auto_resume(
        graph, state, "Actually scratch that, IRA please.", config,
    )
    assert_balance_response(result, expected_last4="2200", expected_total=78400.00)
    assert not result.get("escalation_requested")


# --- S35 jordan preauth, INTERLEAVED chitchat + multi-account balances ----

def test_s35_interleaved_chitchat_and_multi_balances(graph):
    """jordan preauth, four-turn flow:
        Turn 1: 'Hi there!'                  -> CHITCHAT_RESPOND.
        Turn 2: '401k balance please.'       -> ****1100.
        Turn 3: 'Thanks!'                    -> CHITCHAT_RESPOND.
        Turn 4: 'And my IRA balance?'        -> ****2200.

    Stresses the per-turn lifecycle resets on tool_exec / tool_id
    and the intent_agent's completed_intent_ids housekeeping across
    chitchat -> txn -> chitchat -> txn boundaries."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1 -- chitchat
    state = drive_one_turn(graph, state, "Hi there!", config)
    assert state.get("transaction_result") is None
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.CHITCHAT_RESPOND.value, ActionType.ANSWER.value,
    )

    # Turn 2 -- first balance
    state = drive_turn_with_auto_resume(
        graph, state, "401k balance please.", config,
    )
    assert_balance_response(state, expected_last4="1100", expected_total=492100.25)

    # Turn 3 -- thanks
    state = drive_one_turn(graph, state, "Thanks!", config)
    tx3 = state.get("transaction_result")
    assert tx3 is None or tx3.get("success") is False, (
        f"Thanks should not retrigger balance, got {tx3!r}"
    )

    # Turn 4 -- second, different balance
    result = drive_turn_with_auto_resume(
        graph, state, "And my IRA balance?", config,
    )
    assert_balance_response(result, expected_last4="2200", expected_total=78400.00)
    assert not result.get("escalation_requested")


# --- S36 taylor preauth, NEGATION single-message --------------------------

def test_s36_negation_single_message(graph):
    """taylor (multi: 401K + ROTH_IRA) preauth single-message
    negation: 'Don't show me my Roth, give me my 401(k) balance.'
    Must extract account_type=401K (not ROTH_IRA) -> ****4400.
    Distinct from S19 which uses parenthetical 'not the Roth' as a
    trailing aside; here the negation is the lead clause."""
    session, state = preauth_state("demo-user-005")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state,
        "Don't show me my Roth, give me my 401(k) balance.",
        config,
    )
    assert_balance_response(result, expected_last4="4400", expected_total=95100.40)
    assert not result.get("escalation_requested")


# --- S37 morgan preauth, polite verbose phrasing --------------------------

def test_s37_polite_verbose_balance_request(graph):
    """morgan (single-account 401K) preauth, single-turn polite
    verbose phrasing: 'Could you kindly tell me what my 401k account
    balance is right now?'  Long, polite, but unambiguous account_type
    -- must return ****5511 / 312,450 in one turn.  Validates the
    entity extractor handles wordy polite phrasings without losing
    the account_type token."""
    session, state = preauth_state("demo-user-002")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state,
        "Could you kindly tell me what my 401k account balance is right now?",
        config,
    )
    assert_balance_response(result, expected_last4="5511", expected_total=312450.00)
    assert not result.get("escalation_requested")
