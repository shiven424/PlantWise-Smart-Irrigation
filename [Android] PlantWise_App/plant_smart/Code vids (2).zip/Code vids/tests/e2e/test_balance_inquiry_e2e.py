"""
End-to-end LangGraph integration tests for the **balance inquiry**
tool.

Where ``test_graph_specialized_agents.py`` stops at the
``tool_router`` interrupt, this file drives the full graph
**through** that interrupt and asserts the synthesised balance
response — exercising every node:

    message_classifier
        -> supervisor
            -> intent_agent / entity_extraction / rag_agent (in parallel)
            -> entity_validator
            -> auth_agent
            -> response_synthesizer    (auth challenge / slot prompt)
        ... user replies ...
            -> auth_agent (verify)
            -> supervisor
            -> response_synthesizer    (EXECUTE_TRANSACTION)
        ... interrupt at tool_router ...
            -> tool_balance_inquiry
            -> response_synthesizer    (TRANSACTION_COMPLETE)
        -> END

Scenarios covered:

  S1  Single-account user, pre-authenticated, simple ask.
  S2  Multi-account user, pre-authenticated, picks 401K explicitly.
  S3  Multi-account user, pre-authenticated, picks "IRA" (alias).
  S4  Multi-account user, pre-authenticated, no type -> COLLECT_SLOT
      then user replies -> balance.
  S5  Multi-account user, pre-authenticated, picks an account they
      do not own -> graceful failure synth.
  S6  Unauthenticated -> auth challenge -> SSN reply -> balance
      (full multi-turn auth + balance flow).

Each test asserts **every turn**'s:
  - message_domain
  - synthesizer action_type
  - intent stack head sub_intent
  - auth_status when relevant
  - whether the tool_router interrupt was reached / cleared
  - final transaction_result fields (success, account_display,
    total_balance, vested_balance) when the agent ran

These tests REQUIRE ``OPENAI_API_KEY`` (or settings.openai_api_key)
and are therefore slow and gated.  Run with ``pytest -m e2e`` or
just ``pytest tests/e2e/test_balance_inquiry_e2e.py``.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from uuid import uuid4

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from graph.state import initial_state
from schemas.enums import ActionType, AuthLevel, AuthStatus, MessageDomain
from schemas.primitives import AuthState, SessionContext


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; balance_inquiry e2e tests need a live LLM.",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _new_session(user_id: str) -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id=user_id,
        channel="web",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _thread_config(session: SessionContext) -> dict:
    return {"configurable": {"thread_id": str(session.session_id)}}


def _seed_account_context(state: dict, user_id: str) -> dict:
    from auth.client import secrets_provider
    ctx = secrets_provider().get_account_context(user_id)
    state["account_context"] = dict(ctx or {})
    state["auth_token"] = "e2e-test-auth-token"
    return state


def _seed_mock_account_api_from_demo_data() -> None:
    """Seed the singleton MockAccountAPI used by BalanceInquiryTool
    with every demo user's accounts so the tool can return real
    values for any user the test drives through the graph."""
    from auth.client import secrets_provider
    from tools.balance_inquiry.v1.agent import _get_account_api
    from tests.mocks.account_api import AccountRecord

    api = _get_account_api()
    provider = secrets_provider()
    for uid in ("demo-user-001", "demo-user-002", "demo-user-003",
                "demo-user-004", "demo-user-005"):
        ctx = provider.get_account_context(uid) or {}
        for atype, acct in (ctx.get("accounts") or {}).items():
            num = acct.get("account_number")
            if not num:
                continue
            vested = float(acct.get("vested_balance", 0.0))
            total  = float(acct.get("total_balance", vested))
            api.seed_account(AccountRecord(
                account_number=num,
                account_type=acct.get("account_type", atype),
                owner_name="Demo User",
                owner_age_years=float(ctx.get("owner_age_years", 40)),
                owner_dob="1985-01-01",
                total_balance=total,
                vested_balance=vested,
                unvested_balance=float(acct.get("unvested_balance", max(total - vested, 0.0))),
                ytd_contributions=float(acct.get("ytd_contributions", 0.0)),
                ytd_employer_match=float(acct.get("ytd_employer_match", 0.0)),
                annual_match_max=float(acct.get("annual_match_max", 0.0)),
                outstanding_loan_balance=float(acct.get("outstanding_loan_balance", 0.0)),
                plan_name=acct.get("plan_name", "Demo Plan"),
            ))


def _drive_one_turn(graph, state: dict, message: str, config: dict) -> dict:
    """Drive a single user turn through the graph (mirrors main.process_turn).
    Returns the partial state at whatever point the graph paused
    (synthesizer END or tool_router interrupt)."""
    turn = (state.get("current_turn") or 0) + 1
    next_input = dict(state)
    next_input["current_turn"] = turn
    next_input["last_user_message"] = message
    next_input["message_history"] = (state.get("message_history") or []) + [
        {"role": "user", "content": message},
    ]
    # Per-turn resets
    for k in (
        "current_action_plan", "policy_path", "planner_reasoning",
        "last_synthesized_response", "transaction_result", "rag_answer",
        "rag_confidence", "rag_error", "validation_status",
        "escalation_context", "verification_input",
    ):
        next_input[k] = None
    next_input["rag_citations"] = []
    next_input["rag_caveats"] = []
    next_input["rag_verification_passed"] = False
    next_input["rag_freshness_warning"] = False
    next_input["violations"] = []
    next_input["escalation_requested"] = False
    next_input["contradictions"] = []

    prior_scratch = state.get("scratch") or {}
    pending = prior_scratch.get("pending_auth_challenge")
    auth_state = state.get("auth_state") or AuthState()
    cur_lvl = getattr(auth_state, "current_level", AuthLevel.SESSION)
    req_lvl = state.get("required_auth_level", AuthLevel.SESSION)
    auth_pending = pending and isinstance(pending, dict) and cur_lvl < req_lvl

    next_input["scratch"] = {
        "supervisor_completed": [],
        "supervisor_iteration": 0,
        "supervisor_route": "",
        "pending_auth_challenge": pending if auth_pending else {},
    }
    next_input["verification_input"] = message if auth_pending else None

    return graph.invoke(next_input, config)


def _drive_turn_with_auto_resume(graph, state: dict, message: str, config: dict) -> dict:
    """Drive a turn AND auto-resume past the tool_router interrupt
    (mirrors main._auto_resume_if_interrupted) so the tool actually
    executes and the synthesizer renders the final transaction message."""
    result = _drive_one_turn(graph, state, message, config)
    plan = result.get("current_action_plan")
    action = getattr(plan, "action_type", None) if plan else None
    needs_tool = action in (
        ActionType.HITL_APPROVED, ActionType.EXECUTE_TRANSACTION,
    )
    has_result = result.get("transaction_result") is not None
    if needs_tool and not has_result:
        result = graph.invoke(None, config)
    return result


def _preauth_state(user_id: str) -> tuple[SessionContext, dict]:
    session = _new_session(user_id)
    state = initial_state(session)
    _seed_account_context(state, user_id)
    state["auth_state"] = AuthState(
        current_level=AuthLevel.ENHANCED,
        is_locked=False,
        failed_attempts=0,
        verified_at=datetime.now(timezone.utc),
    )
    state["auth_status"] = AuthStatus.VERIFIED
    state["required_auth_level"] = AuthLevel.SESSION
    return session, state


def _assert_balance_response(result: dict, *, expected_last4: str,
                             expected_total: float | None = None) -> None:
    """Common assertions for a successful balance response turn."""
    tx = result.get("transaction_result") or {}
    assert tx.get("success") is True, (
        f"Expected balance success, got {tx!r}"
    )
    assert tx.get("account_display") == f"****{expected_last4}", (
        f"Wrong account: {tx.get('account_display')!r}, expected ****{expected_last4}"
    )
    if expected_total is not None:
        assert abs(tx.get("total_balance", 0.0) - expected_total) < 0.01

    synth = result.get("last_synthesized_response") or {}
    assert synth.get("full_message"), "No synthesized message after tool"
    # Synthesizer should have rendered a transaction-complete style message.
    msg = synth.get("full_message") or ""
    assert expected_last4 in msg or "balance" in msg.lower(), (
        f"Synthesised message did not reference the balance: {msg!r}"
    )


# ---------------------------------------------------------------------------
# Module-scope fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def graph():
    _seed_mock_account_api_from_demo_data()
    return compile_graph(checkpointer=get_checkpointer())


# ---------------------------------------------------------------------------
# S1 — Single-account user, pre-authenticated
# ---------------------------------------------------------------------------


def test_s1_single_account_preauth_returns_balance(graph):
    """alex (demo-user-001) has a single 401K. With pre-auth the graph
    must complete in **one turn**: classifier -> intent -> entity ->
    validator -> supervisor (EXECUTE_TRANSACTION) -> synthesizer ->
    tool_router (interrupt) -> balance_inquiry -> synthesizer ->
    END.  Final response must show ****8810 with total 148,980.55."""
    session, state = _preauth_state("demo-user-001")
    config = _thread_config(session)

    result = _drive_turn_with_auto_resume(
        graph, state, "What's my 401k balance?", config,
    )

    assert result.get("message_domain") in (
        MessageDomain.TRANSACTIONAL, MessageDomain.INFORMATIONAL,
    )
    _assert_balance_response(
        result, expected_last4="8810", expected_total=148980.55,
    )

    # Graph terminated cleanly
    snap = graph.get_state(config)
    assert not snap.next, f"Graph did not reach END; paused at {snap.next}"


# ---------------------------------------------------------------------------
# S2 — Multi-account user with explicit 401K in opening message
# ---------------------------------------------------------------------------


def test_s2_multi_account_preauth_explicit_401k(graph):
    """jordan (demo-user-004) has 401K + IRA + BROKERAGE.  Asking for
    the 401K balance directly should fill account_type from the message
    and return ****1100 in one turn."""
    session, state = _preauth_state("demo-user-004")
    config = _thread_config(session)

    result = _drive_turn_with_auto_resume(
        graph, state, "Show me my 401k account balance please.", config,
    )
    _assert_balance_response(
        result, expected_last4="1100", expected_total=492100.25,
    )


# ---------------------------------------------------------------------------
# S3 — Multi-account user picks "IRA" (alias resolution end-to-end)
# ---------------------------------------------------------------------------


def test_s3_multi_account_preauth_ira_alias(graph):
    """jordan asks for 'IRA' balance.  entity_extraction normalises to
    display_value='IRA'; balance_inquiry's alias map resolves to
    TRADITIONAL_IRA (the only IRA-flavour account jordan owns) and
    returns ****2200."""
    session, state = _preauth_state("demo-user-004")
    config = _thread_config(session)

    result = _drive_turn_with_auto_resume(
        graph, state, "what is my IRA balance?", config,
    )
    _assert_balance_response(
        result, expected_last4="2200", expected_total=78400.0,
    )


# ---------------------------------------------------------------------------
# S4 — Multi-account user, no type given -> COLLECT_SLOT then balance
# ---------------------------------------------------------------------------


def test_s4_multi_account_preauth_collects_slot_then_returns_balance(graph):
    """jordan asks 'what's my balance?'.  Multi-account user means
    compute_slot_gap returns ['account_type'] so the supervisor routes
    to COLLECT_SLOT.  After jordan replies 'brokerage' the graph
    re-runs entity_extraction, slot fills, and balance ****3300 is
    returned."""
    session, state = _preauth_state("demo-user-004")
    config = _thread_config(session)

    # Turn 1 — ambiguous ask
    state = _drive_one_turn(graph, state, "What's my balance?", config)
    synth = state.get("last_synthesized_response") or {}
    assert synth.get("action_type") in (
        ActionType.COLLECT_SLOT.value,
        ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value,
    ), f"Expected slot prompt, got {synth.get('action_type')!r}"
    assert state.get("transaction_result") is None, (
        "Tool ran on ambiguous turn - should have asked for slot first"
    )

    # Turn 2 — user picks brokerage
    result = _drive_turn_with_auto_resume(graph, state, "brokerage", config)
    _assert_balance_response(
        result, expected_last4="3300", expected_total=156750.80,
    )


# ---------------------------------------------------------------------------
# S5 — Multi-account user picks an account they don't own
# ---------------------------------------------------------------------------


def test_s5_multi_account_preauth_unowned_account_fails_gracefully(graph):
    """jordan does not have a 403(b).  Asking for it must produce a
    failure transaction_result (no escalation) and a synthesizer message
    listing the accounts jordan actually has.

    NOTE: We deliberately use 403(b) — not 'Roth IRA' — because
    entity_extraction occasionally drops the 'Roth' qualifier and emits
    bare 'IRA', which the alias resolver would then map to jordan's
    TRADITIONAL_IRA (a *correct* fallback for that input).  A 403(b)
    request has no overlap with jordan's accounts, so the negative
    path is unambiguous."""
    session, state = _preauth_state("demo-user-004")
    config = _thread_config(session)

    result = _drive_turn_with_auto_resume(
        graph, state, "Pull my 403b balance please.", config,
    )
    tx = result.get("transaction_result") or {}
    # Either:
    #   (a) supervisor recognises jordan doesn't own a 403B and does
    #       NOT execute the tool (no transaction_result), OR
    #   (b) tool runs and returns success=False with helpful errors.
    if tx:
        assert tx.get("success") is False, (
            f"403b for jordan should not succeed; got {tx!r}"
        )
        joined = " ".join(tx.get("errors") or [])
        assert any(t in joined for t in ("401K", "TRADITIONAL_IRA", "BROKERAGE"))
        # User-correctable failure, not a system escalation.
        assert result.get("escalation_requested") is False

    synth = result.get("last_synthesized_response") or {}
    assert synth.get("full_message"), "Synthesizer must render some response"


# ---------------------------------------------------------------------------
# S6 — Full unauthenticated journey: ask -> SSN challenge -> SSN -> balance
# ---------------------------------------------------------------------------


def test_s6_unauth_full_journey_asks_balance_then_verifies_then_returns_balance(graph):
    """The hardest e2e path:

    Turn 1: alex (no auth) asks for 401k balance.
            -> auth_agent issues an SSN challenge.
            -> synthesizer renders an INITIATE_AUTH / AUTH_CHALLENGE message.
            -> auth_status == PENDING.
            -> tool_router NOT reached.

    Turn 2 (and possibly 3): primer 'yes please' until pending_auth_challenge
            has expected_hash (challenge text actually issued).

    Final turn: alex replies with last-4 SSN '4321'.
            -> auth_agent verifies, auth_status -> VERIFIED.
            -> supervisor plans EXECUTE_TRANSACTION.
            -> synthesizer renders processing message.
            -> tool_router interrupt fires.
            -> balance_inquiry runs, returns ****8810 / 148,980.55.
            -> synthesizer renders TRANSACTION_COMPLETE.
            -> END.
    """
    session = _new_session("demo-user-001")
    state = initial_state(session)
    _seed_account_context(state, "demo-user-001")
    config = _thread_config(session)

    # Turn 1 — ask for balance, expect challenge.
    state = _drive_one_turn(graph, state, "Show me my 401k balance please.", config)
    assert state.get("auth_status") == AuthStatus.PENDING, (
        f"Expected PENDING after first ask, got {state.get('auth_status')!r}"
    )
    synth = state.get("last_synthesized_response") or {}
    assert synth.get("action_type") in (
        ActionType.INITIATE_AUTH.value,
        ActionType.AUTH_CHALLENGE.value,
        ActionType.PROCESS_AUTH.value,
    )

    # Turns 2-N — prime the auth challenge until it has expected_hash.
    primers = ["sure", "yes please", "go ahead", "ok"]
    for msg in primers:
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = _drive_one_turn(graph, state, msg, config)

    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )

    # Decisive turn — answer SSN '4321' and auto-resume past tool router.
    result = _drive_turn_with_auto_resume(graph, state, "4321", config)

    assert result.get("auth_status") == AuthStatus.VERIFIED, (
        f"SSN reply should verify; got auth_status={result.get('auth_status')!r}"
    )
    # The classifier MUST NOT escalate the bare digit string.
    assert result.get("classifier_escalation_flag") is not True

    # Tool ran and returned alex's 401K balance.
    _assert_balance_response(
        result, expected_last4="8810", expected_total=148980.55,
    )
