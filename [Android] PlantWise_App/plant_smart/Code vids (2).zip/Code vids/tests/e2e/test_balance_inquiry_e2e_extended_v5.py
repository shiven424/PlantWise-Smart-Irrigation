"""
**Extended v5** end-to-end LangGraph regression scenarios for balance_inquiry.

Adds two groups of scenarios:

GROUP A — Stale-slot guard (Bug D)
    Multi-account users sometimes have an ``account_type`` slot carried
    over from a prior turn by the LLM-driven entity_extraction agent.
    A bare follow-up question like "what's my balance?" must NOT silently
    re-use that stale slot and return the prior account's balance.

    S39  jordan: "401k balance" -> ****1100, then bare "what's my balance?"
         must fail with a re-collection prompt (not silently re-return 401K).

    S40  jordan: "403b balance" -> graceful failure (no 403b on file),
         then bare "what's my balance?" must NOT repeat the 403b failure
         (proving the stale slot was not reused).

    S41  alex (single-account, regression-protect): "401k balance" ->
         ****8810, then bare "what's my balance?" -> still ****8810.
         Single-account users must be unaffected by the stale-slot guard.

GROUP B — Multi-account aggregation
    Multi-account users can ask for several balances in a single turn.

    S42  jordan: "show me all my balances" -> 3 accounts in result.
    S43  jordan: "balance of 401k and IRA"  -> 2 accounts in result.
    S44  taylor: "all balances"             -> 2 accounts in result.
    S45  alex (single-account):  "all balances" -> falls back to a
         single-account success response (no UX regression).

Requires OPENAI_API_KEY (real LLM per turn -> slow).
"""
from __future__ import annotations

import os

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer

from tests.e2e._balance_helpers import (
    assert_balance_response,
    drive_turn_with_auto_resume,
    preauth_state,
    seed_mock_account_api_from_demo_data,
    thread_config,
)


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; balance_inquiry e2e tests need a live LLM.",
)


@pytest.fixture(scope="module")
def graph():
    seed_mock_account_api_from_demo_data()
    return compile_graph(checkpointer=get_checkpointer())


# ─── helpers ────────────────────────────────────────────────────────────────

def _tx(result: dict) -> dict:
    return result.get("transaction_result") or {}


def _is_failed(result: dict) -> bool:
    tx = _tx(result)
    if not tx:
        return False
    return str(tx.get("status", "")).upper() == "FAILED" or tx.get("success") is False


def _account_types_in_multi(result: dict) -> list[str]:
    tx = _tx(result)
    accounts = tx.get("accounts") or []
    return [str(a.get("account_type", "")).upper() for a in accounts if isinstance(a, dict)]


# ───────────────────── GROUP A — Stale-slot guard ───────────────────────────


def test_s39_jordan_bare_followup_after_401k_must_re_collect(graph):
    """Multi-account user (jordan) asks for 401K balance, then in a follow-up
    turn asks the bare question "what's my balance?" without naming any
    account type.  The carried-over ``account_type=401K`` slot from
    turn-1 must NOT be silently reused; the tool must instead
    surface a re-collection prompt."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # T1 — explicit 401k ask resolves to ****1100
    r1 = drive_turn_with_auto_resume(graph, state, "what's my 401k balance?", config)
    assert_balance_response(r1, expected_last4="1100", expected_total=492100.25)

    # T2 — bare follow-up must NOT silently re-return 401K
    r2 = drive_turn_with_auto_resume(graph, r1, "what's my balance?", config)
    tx2 = _tx(r2)
    # Either: failed-with-re-collection-prompt (preferred), OR a slot-collect
    # action that does not produce a balance.  In both cases there must be
    # NO ****1100 silent re-return.
    assert tx2.get("account_display") != "****1100", (
        "Stale account_type slot was silently re-used: "
        f"got account_display={tx2.get('account_display')!r}"
    )
    # Must surface guidance to the user mentioning multiple accounts.
    synth = (r2.get("last_synthesized_response") or {}).get("full_message") or ""
    lo = synth.lower()
    assert any(k in lo for k in ("which account", "specify", "401k", "ira", "brokerage")), (
        f"Re-collection prompt not surfaced; synth={synth!r}"
    )


def test_s40_jordan_bare_followup_after_403b_failure_must_not_repeat(graph):
    """Multi-account user (jordan) asks for a 403B balance (not on file)
    -> graceful failure.  A bare follow-up "what's my balance?" must NOT
    re-emit the 403B failure (which would happen if entity_extraction
    carried account_type=403B forward and the tool reused it)."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # T1 — 403b ask: graceful failure (not on file)
    r1 = drive_turn_with_auto_resume(graph, state, "what's my 403b balance?", config)
    assert _is_failed(r1), f"Expected 403b failure for jordan, got {_tx(r1)!r}"

    # T2 — bare follow-up
    r2 = drive_turn_with_auto_resume(graph, r1, "what's my balance?", config)
    synth = (r2.get("last_synthesized_response") or {}).get("full_message") or ""
    # The 403b reason must not be repeated (i.e. the stale slot was not reused).
    assert "403b" not in synth.lower() and "403(b)" not in synth.lower(), (
        f"Stale 403B slot was re-used in follow-up; synth={synth!r}"
    )


def test_s41_alex_single_account_bare_followup_still_works(graph):
    """Single-account user (alex) must be UNAFFECTED by the stale-slot
    guard.  T1 "401k balance" -> ****8810; T2 bare "what's my balance?" ->
    ****8810 again.  This locks in S38-class behavior."""
    session, state = preauth_state("demo-user-001")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(graph, state, "what's my 401k balance?", config)
    assert_balance_response(r1, expected_last4="8810", expected_total=148980.55)

    r2 = drive_turn_with_auto_resume(graph, r1, "what's my balance?", config)
    # Single-account user: stale-slot guard MUST NOT fire — same balance.
    assert_balance_response(r2, expected_last4="8810", expected_total=148980.55)


# ───────────────────── GROUP B — Multi-account aggregation ──────────────────


def test_s42_jordan_show_all_balances(graph):
    """Multi-account user (jordan) asks for ALL balances -> 3 accounts."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(graph, state, "show me all my balances", config)
    tx = _tx(r)
    assert tx.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx!r}"
    types = _account_types_in_multi(r)
    assert len(types) == 3, f"Expected 3 accounts for jordan, got {types!r}"
    upper = {t.upper() for t in types}
    assert "401K" in upper
    assert any("IRA" in t for t in upper)
    assert "BROKERAGE" in upper

    combined = tx.get("combined_total_balance")
    assert combined and combined > 700_000, (
        f"Combined total looks wrong: {combined!r}"
    )

    synth = (r.get("last_synthesized_response") or {}).get("full_message") or ""
    assert "Balances" in synth or "balances" in synth.lower(), synth


def test_s43_jordan_two_specific_accounts(graph):
    """Multi-account user (jordan) names 401k AND IRA in one message ->
    2 accounts in the result."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(
        graph, state, "show me the balance of my 401k and IRA", config,
    )
    tx = _tx(r)
    assert tx.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx!r}"
    types = _account_types_in_multi(r)
    assert len(types) == 2, f"Expected exactly 2 accounts, got {types!r}"
    upper = {t.upper() for t in types}
    assert "401K" in upper
    assert any("IRA" in t for t in upper)
    # Must NOT include brokerage.
    assert not any("BROKERAGE" in t for t in upper), types


def test_s44_taylor_all_balances(graph):
    """taylor (multi-account: 401K + ROTH_IRA) "all balances" -> 2 accounts."""
    session, state = preauth_state("demo-user-005")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(graph, state, "show me all my balances", config)
    tx = _tx(r)
    assert tx.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx!r}"
    types = _account_types_in_multi(r)
    assert len(types) == 2, f"Expected 2 accounts for taylor, got {types!r}"
    upper = {t.upper() for t in types}
    assert "401K" in upper
    assert any("ROTH" in t for t in upper)


def test_s45_alex_all_balances_degrades_to_single(graph):
    """Single-account user asking "all balances" must degrade gracefully
    to a single-account success response (no regression)."""
    session, state = preauth_state("demo-user-001")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(graph, state, "show me all my balances", config)
    tx = _tx(r)
    assert tx.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx!r}"
    # Either single-account shape (account_display set) OR multi-account
    # shape with exactly one entry is acceptable.
    if "accounts" in tx and tx.get("accounts"):
        assert len(tx["accounts"]) == 1, f"Expected 1 account, got {tx['accounts']!r}"
        assert tx["accounts"][0].get("account_display") == "****8810"
    else:
        assert_balance_response(r, expected_last4="8810", expected_total=148980.55)


# ───────── GROUP C — "All of them" follow-up after stale-slot prompt ────────
#
# Real-world UI flow that exposed Bug F:
#   T1 "what's my IRA balance?"   -> ****2200
#   T2 "what's my balance?"        -> stale-slot guard fires, asks user
#                                     to specify which account.
#   T3 "All of them"               -> MUST return all 3 account balances,
#                                     not silently re-use the IRA slot.


def test_s46_jordan_all_of_them_after_recollection(graph):
    """jordan: IRA -> bare ask (re-collection) -> "All of them" -> 3 accounts."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(graph, state, "what's my IRA balance?", config)
    assert_balance_response(r1, expected_last4="2200", expected_total=78400)

    r2 = drive_turn_with_auto_resume(graph, r1, "what's my balance?", config)
    tx2 = _tx(r2)
    assert tx2.get("account_display") != "****2200", (
        f"Stale IRA slot was re-used on bare follow-up; tx={tx2!r}"
    )

    r3 = drive_turn_with_auto_resume(graph, r2, "All of them", config)
    tx3 = _tx(r3)
    assert tx3.get("status") == "COMPLETED", (
        f"Expected COMPLETED for 'All of them', got {tx3!r}"
    )
    types = _account_types_in_multi(r3)
    assert len(types) == 3, (
        f"'All of them' must aggregate all 3 accounts, got {types!r}"
    )
    upper = {t.upper() for t in types}
    assert "401K" in upper
    assert any("IRA" in t for t in upper)
    assert "BROKERAGE" in upper


def test_s47_jordan_every_one_after_401k(graph):
    """jordan: 401K -> "every one" -> 3 accounts."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(graph, state, "what's my 401k balance?", config)
    assert_balance_response(r1, expected_last4="1100", expected_total=492100.25)

    r2 = drive_turn_with_auto_resume(graph, r1, "every one", config)
    tx2 = _tx(r2)
    assert tx2.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx2!r}"
    types = _account_types_in_multi(r2)
    assert len(types) == 3, f"'every one' must aggregate all 3, got {types!r}"


def test_s48_taylor_all_of_them_after_roth(graph):
    """taylor (2-account user): Roth -> "all of them" -> 2 accounts."""
    session, state = preauth_state("demo-user-005")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(graph, state, "what's my Roth balance?", config)
    tx1 = _tx(r1)
    assert tx1.get("status") == "COMPLETED", f"Expected COMPLETED for Roth, got {tx1!r}"

    r2 = drive_turn_with_auto_resume(graph, r1, "all of them", config)
    tx2 = _tx(r2)
    assert tx2.get("status") == "COMPLETED", f"Expected COMPLETED, got {tx2!r}"
    types = _account_types_in_multi(r2)
    assert len(types) == 2, f"'all of them' must aggregate both, got {types!r}"
    upper = {t.upper() for t in types}
    assert "401K" in upper
    assert any("ROTH" in t for t in upper)

