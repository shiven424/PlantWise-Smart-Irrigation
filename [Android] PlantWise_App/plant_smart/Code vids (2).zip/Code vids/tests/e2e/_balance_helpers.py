"""Shared helpers for balance_inquiry e2e tests.

Underscore-prefixed so pytest does not try to collect this as a test
module.
"""
from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from graph.state import initial_state
from schemas.enums import ActionType, AuthLevel, AuthStatus
from schemas.primitives import AuthState, SessionContext, HITLState, ToolExecutionState


def new_session(user_id: str) -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id=user_id,
        channel="web",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def thread_config(session: SessionContext) -> dict:
    return {"configurable": {"thread_id": str(session.session_id)}}


def seed_account_context(state: dict, user_id: str) -> dict:
    from auth.client import secrets_provider
    ctx = secrets_provider().get_account_context(user_id)
    state["account_context"] = dict(ctx or {})
    state["auth_token"] = "e2e-test-auth-token"
    return state


def seed_mock_account_api_from_demo_data() -> None:
    """Seed the singleton MockAccountAPI used by BalanceInquiryTool
    with every demo user's accounts."""
    from auth.client import secrets_provider
    from tools.balance_inquiry.v1.agent import _get_account_api
    from tests.mocks.account_api import AccountRecord

    api = _get_account_api()
    provider = secrets_provider()
    for uid in ("demo-user-001", "demo-user-002", "demo-user-003",
                "demo-user-004", "demo-user-005"):
        ctx = provider.get_account_context(uid) or {}
        for atype, acct in (ctx.get("accounts") or {}).items():
            num = acct.get("account_number")
            if not num:
                continue
            vested = float(acct.get("vested_balance", 0.0))
            total  = float(acct.get("total_balance", vested))
            api.seed_account(AccountRecord(
                account_number=num,
                account_type=acct.get("account_type", atype),
                owner_name="Demo User",
                owner_age_years=float(ctx.get("owner_age_years", 40)),
                owner_dob="1985-01-01",
                total_balance=total,
                vested_balance=vested,
                unvested_balance=float(acct.get("unvested_balance", max(total - vested, 0.0))),
                ytd_contributions=float(acct.get("ytd_contributions", 0.0)),
                ytd_employer_match=float(acct.get("ytd_employer_match", 0.0)),
                annual_match_max=float(acct.get("annual_match_max", 0.0)),
                outstanding_loan_balance=float(acct.get("outstanding_loan_balance", 0.0)),
                plan_name=acct.get("plan_name", "Demo Plan"),
            ))


def drive_one_turn(graph, state: dict, message: str, config: dict) -> dict:
    """Drive a single user turn through the graph (mirrors main.process_turn)."""
    turn = (state.get("current_turn") or 0) + 1
    next_input = dict(state)
    next_input["current_turn"] = turn
    next_input["last_user_message"] = message
    next_input["message_history"] = (state.get("message_history") or []) + [
        {"role": "user", "content": message},
    ]
    for k in (
        "current_action_plan", "policy_path", "planner_reasoning",
        "last_synthesized_response", "transaction_result", "rag_answer",
        "rag_confidence", "rag_error", "validation_status",
        "escalation_context", "verification_input",
    ):
        next_input[k] = None
    next_input["rag_citations"] = []
    next_input["rag_caveats"] = []
    next_input["rag_verification_passed"] = False
    next_input["rag_freshness_warning"] = False
    next_input["violations"] = []
    next_input["escalation_requested"] = False
    next_input["contradictions"] = []
    # Per-turn lifecycle resets (mirror main.process_turn).  Without these,
    # turn-2 routing sees turn-1's SUCCEEDED tool_exec status and
    # short-circuits before the tool can run again.
    next_input["tool_exec"] = ToolExecutionState()
    next_input["hitl"] = HITLState()

    prior_scratch = state.get("scratch") or {}
    pending = prior_scratch.get("pending_auth_challenge")
    auth_state = state.get("auth_state") or AuthState()
    cur_lvl = getattr(auth_state, "current_level", AuthLevel.SESSION)
    req_lvl = state.get("required_auth_level", AuthLevel.SESSION)
    auth_pending = pending and isinstance(pending, dict) and cur_lvl < req_lvl

    next_input["scratch"] = {
        "supervisor_completed": [],
        "supervisor_iteration": 0,
        "supervisor_route": "",
        "pending_auth_challenge": pending if auth_pending else {},
    }
    next_input["verification_input"] = message if auth_pending else None

    return graph.invoke(next_input, config)


def drive_turn_with_auto_resume(graph, state: dict, message: str, config: dict) -> dict:
    """Drive a turn AND auto-resume past tool_router interrupt."""
    result = drive_one_turn(graph, state, message, config)
    plan = result.get("current_action_plan")
    action = getattr(plan, "action_type", None) if plan else None
    needs_tool = action in (
        ActionType.HITL_APPROVED, ActionType.EXECUTE_TRANSACTION,
    )
    has_result = result.get("transaction_result") is not None
    if needs_tool and not has_result:
        result = graph.invoke(None, config)
    return result


def preauth_state(user_id: str) -> tuple[SessionContext, dict]:
    session = new_session(user_id)
    state = initial_state(session)
    seed_account_context(state, user_id)
    state["auth_state"] = AuthState(
        current_level=AuthLevel.ENHANCED,
        is_locked=False,
        failed_attempts=0,
        verified_at=datetime.now(timezone.utc),
    )
    state["auth_status"] = AuthStatus.VERIFIED
    state["required_auth_level"] = AuthLevel.SESSION
    return session, state


def assert_balance_response(result: dict, *, expected_last4: str,
                            expected_total: float | None = None) -> None:
    """Common assertions for a successful balance response turn."""
    tx = result.get("transaction_result") or {}
    assert tx.get("success") is True, f"Expected balance success, got {tx!r}"
    assert tx.get("account_display") == f"****{expected_last4}", (
        f"Wrong account: {tx.get('account_display')!r}, expected ****{expected_last4}"
    )
    if expected_total is not None:
        assert abs(tx.get("total_balance", 0.0) - expected_total) < 0.01

    synth = result.get("last_synthesized_response") or {}
    assert synth.get("full_message"), "No synthesized message after tool"
    msg = synth.get("full_message") or ""
    assert expected_last4 in msg or "balance" in msg.lower(), (
        f"Synthesised message did not reference the balance: {msg!r}"
    )
