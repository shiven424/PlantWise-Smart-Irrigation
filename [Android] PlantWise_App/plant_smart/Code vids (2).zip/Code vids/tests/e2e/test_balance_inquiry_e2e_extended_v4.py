"""
**Extended v4** end-to-end LangGraph regression scenarios for balance_inquiry.

Adds **S38**, a regression for a real frontend-reported bug:

    Single-account user (alex / demo-user-001) starts UNAUTHENTICATED,
    asks the bare question "what's my balance??" without naming an
    account_type.  After the SSN auth round-trip, the supervisor
    correctly skips re-running entity_extraction (the SSN reply is
    not slot data) and dispatches to balance_inquiry.  Because the
    user never named an account_type, validated_entities is empty.

    Previously this raised:
        RuntimeError: Tool 'balance_inquiry' called with empty
        validated_entities.

    Fix: balance_inquiry opts in to
    ``allow_empty_validated_entities = True`` and falls back to the
    single-entry account_context path inside execute().  This file
    locks in that behavior with a real-LLM e2e test.

Requires OPENAI_API_KEY (real LLM per turn -> slow).
"""
from __future__ import annotations

import os

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from graph.state import initial_state
from schemas.enums import AuthStatus

from tests.e2e._balance_helpers import (
    assert_balance_response,
    drive_one_turn,
    drive_turn_with_auto_resume,
    new_session,
    seed_account_context,
    seed_mock_account_api_from_demo_data,
    thread_config,
)


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; balance_inquiry e2e tests need a live LLM.",
)


@pytest.fixture(scope="module")
def graph():
    seed_mock_account_api_from_demo_data()
    return compile_graph(checkpointer=get_checkpointer())


# --- S38 unauth, single-account user, bare 'balance?' (no account_type) ----

def test_s38_unauth_single_account_no_account_type(graph):
    """alex (demo-user-001) is a single-account user (only a 401K).
    Starting UNAUTHENTICATED, the user asks the bare question
    "what's my balance??" -- no account_type token in the message.

    Expected flow:
        Turn 1: 'whats my balance??'  -> INITIATE_AUTH (PENDING).
        Turn 2..N: prime ('ok')        -> AUTH_CHALLENGE for last-4 SSN.
        Final:  '4321'                 -> auth verified, tool runs
                with empty validated_entities and resolves the only
                account from account_context -> ****8810 / 148,980.55.

    Regression: prior to the
    ``allow_empty_validated_entities = True`` opt-in on
    BalanceInquiryTool, the final turn raised RuntimeError because
    the supervisor's post-auth ``skip_extraction`` path produced an
    empty validated_entities map for the tool."""
    session = new_session("demo-user-001")
    state = initial_state(session)
    seed_account_context(state, "demo-user-001")
    config = thread_config(session)

    # Turn 1 -- bare ask, no account_type
    state = drive_one_turn(graph, state, "whats my balance??", config)
    assert state.get("auth_status") == AuthStatus.PENDING, (
        f"Expected PENDING after bare ask, got {state.get('auth_status')!r}"
    )
    assert state.get("transaction_result") is None, (
        "Bare ask must not execute a balance before auth"
    )

    # Prime until challenge has expected_hash
    for msg in ("ok", "yes please", "go ahead", "sure"):
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = drive_one_turn(graph, state, msg, config)

    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )

    # Decisive turn -- correct SSN, tool runs with empty
    # validated_entities and must auto-resolve from account_context.
    result = drive_turn_with_auto_resume(graph, state, "4321", config)

    assert result.get("auth_status") == AuthStatus.VERIFIED, (
        f"SSN '4321' should verify alex; "
        f"got auth_status={result.get('auth_status')!r}"
    )
    assert_balance_response(
        result, expected_last4="8810", expected_total=148980.55,
    )
    assert not result.get("escalation_requested"), (
        "Single-account empty-entities path must not escalate"
    )
