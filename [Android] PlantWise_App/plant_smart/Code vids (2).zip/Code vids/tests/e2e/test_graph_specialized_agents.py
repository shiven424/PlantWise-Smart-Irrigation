"""End-to-end LangGraph integration tests for the specialized agents.

These tests drive the *real* compiled graph (real LLM calls, real
agents, real router) but **never invoke any tool** — the graph
is compiled with ``interrupt_before=["tool_router"]``, so any
transactional flow that reaches EXECUTE_TRANSACTION cleanly pauses
at the tool boundary.  We assert the pause itself as the
success signal for the "transactional" scenario.

What this exercises end-to-end:
    message_classifier -> supervisor -> intent_agent
                                    \\-> entity_extraction
                                    \\-> rag_agent
                                    -> entity_validator
                                    -> auth_agent
                                    -> response_synthesizer

Tools (balance_inquiry, plan_loan, rmd_calculator) are intentionally
**out of scope** for this file and will be covered separately.

These tests REQUIRE a working ``OPENAI_API_KEY`` in the environment.
They are slow (real LLM calls per turn) — mark with ``-m e2e`` to
opt in / out.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from uuid import uuid4

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from graph.state import initial_state
from schemas.enums import ActionType, AuthLevel, AuthStatus, MessageDomain
from schemas.primitives import AuthState, SessionContext


# Skip the whole module if no API key — these are real LLM tests.
pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; e2e graph tests require a live LLM.",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _new_session(user_id: str = "demo-user-001") -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id=user_id,
        channel="web",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _thread_config(session: SessionContext) -> dict:
    return {"configurable": {"thread_id": str(session.session_id)}}


def _seed_account_context(state: dict, user_id: str) -> dict:
    """Hydrate state.account_context from the auth provider, mirroring
    what main.start_conversation does for real requests."""
    from auth.client import secrets_provider
    ctx = secrets_provider().get_account_context(user_id)
    state["account_context"] = dict(ctx or {})
    return state


def _drive_one_turn(graph, state: dict, message: str, config: dict) -> dict:
    """Run a single turn through the graph and return the resulting
    state.  Mirrors the per-turn reset logic in main.process_turn so the
    agents see the same shape they would in production."""
    turn = (state.get("current_turn") or 0) + 1
    next_input = dict(state)
    next_input["current_turn"] = turn
    next_input["last_user_message"] = message
    next_input["message_history"] = (state.get("message_history") or []) + [
        {"role": "user", "content": message}
    ]

    # Per-turn resets (subset of main.process_turn — enough for tests).
    next_input["current_action_plan"] = None
    next_input["policy_path"] = None
    next_input["planner_reasoning"] = None
    next_input["last_synthesized_response"] = None
    next_input["transaction_result"] = None
    next_input["rag_answer"] = None
    next_input["rag_citations"] = []
    next_input["rag_confidence"] = None
    next_input["rag_caveats"] = []
    next_input["rag_verification_passed"] = False
    next_input["rag_freshness_warning"] = False
    next_input["rag_error"] = None
    next_input["validation_status"] = None
    next_input["violations"] = []
    next_input["escalation_requested"] = False
    next_input["escalation_context"] = None
    next_input["contradictions"] = []

    prior_scratch = state.get("scratch") or {}
    pending = prior_scratch.get("pending_auth_challenge")
    auth_state = state.get("auth_state") or AuthState()
    cur_lvl = getattr(auth_state, "current_level", AuthLevel.SESSION)
    req_lvl = state.get("required_auth_level", AuthLevel.SESSION)
    auth_pending = pending and isinstance(pending, dict) and cur_lvl < req_lvl

    next_input["scratch"] = {
        "supervisor_completed": [],
        "supervisor_iteration": 0,
        "supervisor_route": "",
        "pending_auth_challenge": pending if auth_pending else {},
    }
    next_input["verification_input"] = message if auth_pending else None

    return graph.invoke(next_input, config)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def graph():
    """One compiled graph shared across the module — compilation is
    expensive and stateless once built."""
    return compile_graph(checkpointer=get_checkpointer())


@pytest.fixture
def fresh_state():
    """A brand-new initial state for ``demo-user-001`` (alex, single,
    has loans enabled)."""
    session = _new_session("demo-user-001")
    state = initial_state(session)
    _seed_account_context(state, "demo-user-001")
    return session, state


# ---------------------------------------------------------------------------
# Scenario 1 — Chitchat
# ---------------------------------------------------------------------------

def test_chitchat_routes_through_classifier_supervisor_synthesizer(graph, fresh_state):
    """A simple greeting should:
      - be classified as CHITCHAT,
      - skip intent / entity / rag / auth (no transactional work),
      - reach the synthesizer with action_type=CHITCHAT_RESPOND,
      - terminate at END (no tool interrupt).
    """
    session, state = fresh_state
    config = _thread_config(session)

    result = _drive_one_turn(graph, state, "Hi there, how are you today?", config)

    # Classifier ran
    assert result.get("message_domain") == MessageDomain.CHITCHAT, (
        f"Expected CHITCHAT, got {result.get('message_domain')!r}"
    )

    # Synthesizer produced a response
    synth = result.get("last_synthesized_response")
    assert synth is not None, "Synthesizer did not produce a response"
    assert synth.get("full_message"), "Synthesized full_message is empty"
    assert synth.get("action_type") in (
        ActionType.CHITCHAT_RESPOND.value,
        ActionType.ANSWER.value,
    ), f"Unexpected action_type for chitchat: {synth.get('action_type')!r}"

    # No tool interrupt was triggered.
    snapshot = graph.get_state(config)
    assert not snapshot.next or "tool_router" not in snapshot.next, (
        f"Chitchat should terminate at END, but graph paused at {snapshot.next}"
    )


# ---------------------------------------------------------------------------
# Scenario 2 — Explicit escalation
# ---------------------------------------------------------------------------

def test_explicit_escalation_routes_to_synthesizer_with_escalate(graph, fresh_state):
    """An explicit human-handoff request should escalate via classifier
    or supervisor and synthesize an ESCALATE response."""
    session, state = fresh_state
    config = _thread_config(session)

    result = _drive_one_turn(
        graph, state,
        "I want to speak to a human supervisor right now please.",
        config,
    )

    synth = result.get("last_synthesized_response")
    assert synth is not None, "No synthesized response on escalation"
    # Either classifier flagged it or supervisor planned ESCALATE.
    escalated = (
        result.get("classifier_escalation_flag") is True
        or result.get("escalation_requested") is True
        or synth.get("action_type") == ActionType.ESCALATE.value
    )
    assert escalated, (
        f"Expected escalation; got action_type={synth.get('action_type')!r}, "
        f"classifier_flag={result.get('classifier_escalation_flag')!r}, "
        f"escalation_requested={result.get('escalation_requested')!r}"
    )


# ---------------------------------------------------------------------------
# Scenario 3 — Informational (RAG path)
# ---------------------------------------------------------------------------

def test_informational_question_invokes_rag_agent(graph, fresh_state):
    """A pure-information question should:
      - classify as INFORMATIONAL,
      - dispatch the RAG agent (along with intent/entity in parallel),
      - produce either a rag_answer or a rag_error (latter is fine —
        what matters is that rag_agent ran),
      - synthesize an ANSWER and terminate.
    """
    session, state = fresh_state
    config = _thread_config(session)

    result = _drive_one_turn(
        graph, state,
        "What is the 2025 IRS contribution limit for a 401k plan?",
        config,
    )

    assert result.get("message_domain") == MessageDomain.INFORMATIONAL, (
        f"Expected INFORMATIONAL, got {result.get('message_domain')!r}"
    )

    # RAG agent must have produced *some* outcome (answer, citations,
    # or an explicit error sentinel).  rag_confidence is None only when
    # rag_agent never ran.
    rag_ran = (
        result.get("rag_answer") is not None
        or result.get("rag_error") is not None
        or result.get("rag_confidence") is not None
    )
    assert rag_ran, (
        "RAG agent did not run for an informational question. "
        f"rag_answer={result.get('rag_answer')!r}, "
        f"rag_confidence={result.get('rag_confidence')!r}, "
        f"rag_error={result.get('rag_error')!r}"
    )

    synth = result.get("last_synthesized_response")
    assert synth and synth.get("full_message"), (
        "Synthesizer did not render a message for informational turn"
    )


# ---------------------------------------------------------------------------
# Scenario 4 — Transactional, unauthenticated -> auth challenge
# ---------------------------------------------------------------------------

def test_transactional_request_triggers_auth_challenge(graph, fresh_state):
    """Asking for a 401k balance with no prior auth should:
      - classify as TRANSACTIONAL,
      - route through intent_agent (-> ACCOUNT_BALANCE_INQUIRY),
      - run auth_agent which issues a challenge,
      - synthesize an AUTH_CHALLENGE message,
      - leave a pending_auth_challenge in scratch,
      - NOT reach the tool_router interrupt (auth not yet satisfied).
    """
    session, state = fresh_state
    config = _thread_config(session)

    result = _drive_one_turn(
        graph, state,
        "Show me my 401k balance please.",
        config,
    )

    # Either TRANSACTIONAL (preferred) or INFORMATIONAL is acceptable —
    # both still flow through intent + auth.  The point of this test is
    # the auth-challenge behavior, not the classifier label.
    assert result.get("message_domain") in (
        MessageDomain.TRANSACTIONAL, MessageDomain.INFORMATIONAL,
    ), f"Unexpected domain: {result.get('message_domain')!r}"

    # Intent agent should have produced an intent on the stack.
    stack = result.get("intent_stack") or []
    assert stack, "Intent agent did not push an intent onto the stack"

    # Auth agent should have set status to PENDING (a challenge was issued).
    assert result.get("auth_status") == AuthStatus.PENDING, (
        f"Expected auth_status=PENDING after challenge issue, "
        f"got {result.get('auth_status')!r}"
    )

    # Synthesizer rendered an auth challenge prompt.  The action_type
    # is the canonical signal that auth_agent's challenge propagated
    # all the way through supervisor + synthesizer.
    synth = result.get("last_synthesized_response")
    assert synth and synth.get("full_message"), "No synthesized auth prompt"
    assert synth.get("action_type") in (
        ActionType.INITIATE_AUTH.value,
        ActionType.AUTH_CHALLENGE.value,
        ActionType.PROCESS_AUTH.value,
    ), f"Unexpected action_type for auth turn: {synth.get('action_type')!r}"

    # Graph terminated at END (auth not satisfied → no tool route).
    snapshot = graph.get_state(config)
    assert not snapshot.next or "tool_router" not in snapshot.next, (
        f"Should not reach tool_router before auth completes; "
        f"paused at {snapshot.next}"
    )


# ---------------------------------------------------------------------------
# Scenario 5 — Transactional with missing slot -> COLLECT_SLOT
# ---------------------------------------------------------------------------

def test_loan_request_without_amount_triggers_slot_collection(graph, fresh_state):
    """A 401k loan request without an amount should run intent_agent +
    entity_extraction, detect the missing required slot, and emit a
    COLLECT_SLOT action via the synthesizer (one question per turn)."""
    session, state = fresh_state
    config = _thread_config(session)

    result = _drive_one_turn(
        graph, state,
        "I'd like to take out a loan from my 401k.",
        config,
    )

    assert result.get("message_domain") == MessageDomain.TRANSACTIONAL, (
        f"Expected TRANSACTIONAL, got {result.get('message_domain')!r}"
    )

    stack = result.get("intent_stack") or []
    assert stack, "Intent agent failed to push the loan intent"
    head = stack[0]
    sub_intent = getattr(head, "sub_intent", None)
    # Accept any plan-loan-family sub_intent; LLM may pick the closest.
    assert sub_intent and "LOAN" in (sub_intent or "").upper(), (
        f"Expected a loan-related sub_intent, got {sub_intent!r}"
    )

    synth = result.get("last_synthesized_response")
    assert synth and synth.get("full_message"), "No synthesized response"

    # The synthesizer should ask for a slot (amount) OR initiate auth
    # (some policies require auth before slot collection on transactional
    # intents).  Either is a legitimate path before tool execution.
    expected_actions = {
        ActionType.COLLECT_SLOT.value,
        ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value,
        ActionType.INITIATE_AUTH.value,
        ActionType.AUTH_CHALLENGE.value,
    }
    assert synth.get("action_type") in expected_actions, (
        f"Expected slot-collection or auth gating, "
        f"got action_type={synth.get('action_type')!r}"
    )

    # No tool interrupt — slots aren't filled yet.
    snapshot = graph.get_state(config)
    assert not snapshot.next or "tool_router" not in snapshot.next, (
        f"Should not reach tool_router with missing slots; "
        f"paused at {snapshot.next}"
    )


# ---------------------------------------------------------------------------
# Scenario 6 — Pre-authenticated transactional -> reaches tool_router
# ---------------------------------------------------------------------------

def test_authenticated_balance_inquiry_pauses_at_tool_router(graph):
    """With auth pre-satisfied (ENHANCED level, recent verification),
    a 401k balance inquiry should:
      - run the full specialized pipeline,
      - have the supervisor plan EXECUTE_TRANSACTION,
      - have the synthesizer render a processing message,
      - then PAUSE at the tool_router interrupt.

    This is the strongest end-to-end signal that every specialized
    agent and the supervisor's transactional planning works correctly,
    without ever invoking a tool.
    """
    session = _new_session("demo-user-001")
    state = initial_state(session)
    _seed_account_context(state, "demo-user-001")

    # Pre-authenticate at ENHANCED so auth_agent treats this as already verified.
    state["auth_state"] = AuthState(
        current_level=AuthLevel.ENHANCED,
        is_locked=False,
        failed_attempts=0,
        verified_at=datetime.now(timezone.utc),
    )
    state["auth_status"] = AuthStatus.VERIFIED
    state["required_auth_level"] = AuthLevel.SESSION  # supervisor will raise as needed

    config = _thread_config(session)
    result = _drive_one_turn(
        graph, state,
        "Pull up my 401k account balance now.",
        config,
    )

    assert result.get("message_domain") in (
        MessageDomain.TRANSACTIONAL, MessageDomain.INFORMATIONAL,
    )

    # The graph should have paused at tool_router.
    snapshot = graph.get_state(config)
    paused_at = set(snapshot.next or ())
    assert "tool_router" in paused_at, (
        "Authenticated transactional flow did not reach the tool_router "
        f"interrupt. Snapshot.next={snapshot.next!r}, "
        f"action_type={(result.get('last_synthesized_response') or {}).get('action_type')!r}"
    )

    # Synthesizer rendered a processing message en route.
    synth = result.get("last_synthesized_response") or {}
    assert synth.get("full_message"), "Synthesizer did not render a message before interrupt"
    assert synth.get("action_type") in (
        ActionType.EXECUTE_TRANSACTION.value,
        ActionType.HITL_APPROVED.value,
        ActionType.PRESENT_HITL.value,
    ), (
        "Expected EXECUTE_TRANSACTION / HITL action before tool; "
        f"got {synth.get('action_type')!r}"
    )

    # Supervisor must have actually run (recorded an iteration).
    final_scratch = result.get("scratch") or {}
    assert final_scratch.get("supervisor_iteration", 0) >= 1, (
        f"Supervisor did not record any iterations: scratch={final_scratch!r}"
    )



# ---------------------------------------------------------------------------
# Scenario 7 — Auth-verification bypass regression (screenshot bug repro)
# ---------------------------------------------------------------------------

def test_ssn_answer_during_auth_challenge_does_not_escalate(graph, fresh_state):
    """Regression test for the screenshot-reported bug.

    Repro: user asks for their balance -> auth_agent eventually issues a
    typed SSN challenge.  User replies with the correct last-4 SSN
    ``"4321"``.  Previously the message_classifier would label that bare
    digit string as ``ESCALATE`` and supervisor H1 would short-circuit
    the entire turn before auth_agent could verify the input.

    Fix B asserted here:
      * classifier short-circuits to TRANSACTIONAL on verification turns,
      * supervisor H1 ignores classifier escalation flags mid-challenge,
      * auth_agent therefore receives the answer and verifies it,
      * auth_status flips to VERIFIED with required_auth_level satisfied,
      * the synthesized response is NOT an ESCALATE action.
    """
    session, state = fresh_state
    config = _thread_config(session)

    # Drive turns until pending_auth_challenge.expected_hash is populated.
    # The supervisor's policy may emit INITIATE_AUTH first ("you'll need
    # to verify"); the typed challenge with expected_hash appears once
    # auth_agent is dispatched (often after the user's acknowledgement).
    state = _drive_one_turn(graph, state, "Show me my 401k balance please.", config)
    primer_messages = ["sure, go ahead", "yes please", "ok"]
    for msg in primer_messages:
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = _drive_one_turn(graph, state, msg, config)

    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No pending_auth_challenge with expected_hash after priming; "
        f"scratch={state.get('scratch')!r}, "
        f"auth_status={state.get('auth_status')!r}"
    )
    assert state.get("auth_status") == AuthStatus.PENDING

    # Decisive turn: answer with the correct SSN last-4.
    result = _drive_one_turn(graph, state, "4321", config)

    # Bug-defining assertion: the bare digit string MUST NOT be labelled
    # ESCALATE by the classifier.  The bypass should force TRANSACTIONAL.
    assert result.get("message_domain") == MessageDomain.TRANSACTIONAL, (
        f"Classifier mis-labelled the SSN reply '4321' as "
        f"{result.get('message_domain')!r}; bypass did not engage."
    )
    assert result.get("classifier_escalation_flag") is not True, (
        "Classifier raised an escalation flag on a bare verification token."
    )

    # Auth agent must have processed the answer and verified the user.
    assert result.get("auth_status") == AuthStatus.VERIFIED, (
        f"Auth agent did not VERIFY a correct SSN answer; "
        f"auth_status={result.get('auth_status')!r}"
    )
    auth_state = result.get("auth_state")
    assert auth_state is not None
    assert getattr(auth_state, "current_level", AuthLevel.SESSION) >= AuthLevel.STRONG, (
        f"Verified auth did not raise current_level to STRONG+; "
        f"got {getattr(auth_state, 'current_level', None)!r}"
    )

    # Synthesizer must NOT render an ESCALATE response on a successful
    # verification turn.
    synth = result.get("last_synthesized_response") or {}
    assert synth.get("action_type") != ActionType.ESCALATE.value, (
        f"Synthesizer rendered ESCALATE on a successful verification turn: "
        f"{synth!r}"
    )

    # Pending challenge has been cleared.
    pending_after = (result.get("scratch") or {}).get("pending_auth_challenge")
    assert not pending_after, (
        f"pending_auth_challenge should be cleared after VERIFIED, "
        f"got {pending_after!r}"
    )
