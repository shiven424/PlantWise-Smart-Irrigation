"""End-to-end auth-surface tests against the FastAPI app.

These tests focus on the boundary between client → server (login, JWT
validation, demo OTP fetch, conversation creation gating) and do NOT
drive the LangGraph (which requires LLM/network).
"""

from __future__ import annotations

from pathlib import Path

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from auth import client as auth_client
from auth import jwt_utils
from auth.providers.memory import MemoryAuthSecretsProvider, MemoryOtpChannel
from config import settings

import main as main_module

FIXTURE = Path(__file__).parent.parent / "fixtures" / "auth_accounts.json"

pytestmark = pytest.mark.asyncio


@pytest.fixture(autouse=True)
def _patch(monkeypatch):
    # Strong JWT secret to avoid library warnings.
    monkeypatch.setattr(
        settings, "auth_jwt_secret",
        "test-secret-1234567890-padding-x" * 2,
    )
    monkeypatch.setattr(jwt_utils, "_runtime_secret", None)
    # Seed providers from the test fixture.
    sp = MemoryAuthSecretsProvider(FIXTURE)
    oc = MemoryOtpChannel(ttl_seconds=300)
    monkeypatch.setattr(auth_client, "_secrets", sp)
    monkeypatch.setattr(auth_client, "_otp", oc)
    # Reset login rate-limit state between tests.
    monkeypatch.setattr(main_module, "_login_attempts", {})
    yield
    auth_client.reset_for_tests()


@pytest_asyncio.fixture
async def client():
    transport = ASGITransport(app=main_module.app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

async def test_login_success(client: AsyncClient) -> None:
    r = await client.post("/auth/login", json={"username": "good", "password": "pw"})
    assert r.status_code == 200
    body = r.json()
    assert body["user_id"] == "test-user-good"
    assert body["username"] == "good"
    assert body["token_type"] == "Bearer"
    assert body["expires_in"] > 0
    assert len(body["access_token"]) > 20


async def test_login_wrong_password(client: AsyncClient) -> None:
    r = await client.post("/auth/login", json={"username": "good", "password": "WRONG"})
    assert r.status_code == 401


async def test_login_unknown_user(client: AsyncClient) -> None:
    r = await client.post("/auth/login", json={"username": "ghost", "password": "pw"})
    assert r.status_code == 401


async def test_login_rate_limit(client: AsyncClient, monkeypatch) -> None:
    monkeypatch.setattr(settings, "auth_login_attempt_limit", 3)
    for _ in range(3):
        await client.post("/auth/login", json={"username": "good", "password": "WRONG"})
    r = await client.post("/auth/login", json={"username": "good", "password": "WRONG"})
    assert r.status_code == 429


# ---------------------------------------------------------------------------
# JWT-gated /conversations
# ---------------------------------------------------------------------------

async def test_start_conversation_requires_jwt(client: AsyncClient) -> None:
    r = await client.post("/conversations", json={"channel": "web"})
    assert r.status_code == 401
    assert r.headers.get("www-authenticate", "").lower().startswith("bearer")


async def test_start_conversation_rejects_bad_jwt(client: AsyncClient) -> None:
    r = await client.post(
        "/conversations",
        json={"channel": "web"},
        headers={"Authorization": "Bearer not-a-real-token"},
    )
    assert r.status_code == 401


async def _login(client: AsyncClient) -> str:
    r = await client.post("/auth/login", json={"username": "good", "password": "pw"})
    return r.json()["access_token"]


async def test_start_conversation_uses_jwt_user_id(client: AsyncClient) -> None:
    token = await _login(client)
    r = await client.post(
        "/conversations",
        # Try to inject another user via body — must be ignored.
        json={"channel": "web", "user_id": "ATTACKER-USER"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 201
    cid = r.json()["conversation_id"]
    meta = main_module._conversations[cid]
    assert meta["session"].user_id == "test-user-good"


async def test_start_conversation_strips_auth_keys(client: AsyncClient) -> None:
    token = await _login(client)
    r = await client.post(
        "/conversations",
        json={
            "channel": "web",
            "account_context": {
                "auth_answer_zip_hash": "deadbeef",
                "AUTH_ANSWER_SSN_HASH": "cafef00d",
                "plan_type_override": "ROTH_IRA",
            },
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 201
    cid = r.json()["conversation_id"]
    ctx = main_module._conversations[cid]["state"]["account_context"]
    assert "auth_answer_zip_hash" not in ctx
    assert "AUTH_ANSWER_SSN_HASH" not in ctx
    # Client-supplied non-auth keys override seeded ones.
    assert ctx["plan_type_override"] == "ROTH_IRA"
    # Seeded CRM context is present.
    assert ctx["plan_type"] == "401K"
    assert ctx["vested_balance"] == 100000.0


# ---------------------------------------------------------------------------
# Demo OTP endpoint
# ---------------------------------------------------------------------------

async def test_demo_otp_requires_jwt(client: AsyncClient) -> None:
    r = await client.get("/demo/last_otp/test-user-good")
    assert r.status_code == 401


async def test_demo_otp_other_user_forbidden(client: AsyncClient) -> None:
    token = await _login(client)
    r = await client.get(
        "/demo/last_otp/some-other-user",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 403


async def test_demo_otp_returns_code_after_issue(client: AsyncClient) -> None:
    token = await _login(client)
    # Issue an OTP via the channel directly (no LangGraph needed).
    code, _ = auth_client.otp_channel().issue_otp("test-user-good")
    r = await client.get(
        "/demo/last_otp/test-user-good",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["code"] == code
    assert "expires_at" in body


async def test_demo_otp_404_when_none(client: AsyncClient) -> None:
    token = await _login(client)
    r = await client.get(
        "/demo/last_otp/test-user-good",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 404
