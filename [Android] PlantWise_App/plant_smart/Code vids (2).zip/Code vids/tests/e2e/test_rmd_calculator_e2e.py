"""End-to-end LangGraph integration tests for the **rmd_calculator**
tool.

Mirrors the depth applied to balance_inquiry —
drives the fully-compiled real graph (real LLM per turn, real
intent/entity/validator/supervisor/synthesizer pipeline, real router
interrupt at ``tool_router``) and asserts both intermediate and
terminal state at every turn.

Coverage map:

GROUP A — RMD_INQUIRY (informational/RAG path)
    Taxonomy marks RMD_INQUIRY as ``is_transactional=False`` so the
    supervisor routes it through ANSWER (RAG), not the tool.
    These tests pin the user-facing contract: a relevant RMD answer
    is synthesized end-to-end.

    RM01  alex asks "When do I have to start taking RMDs?" → ANSWER.
    RM02  morgan asks "What's the penalty for missing my RMD?" → ANSWER.

GROUP B — RMD_CALCULATION happy paths (supervisor → entity_validator →
                                       EXECUTE_TRANSACTION on T1, COMPLETED)
    RMD_CALCULATION is transactional for routing but skips pre-execute
    HITL (policy: illustrative calc only). Validator RMD_START_AGE rule
    is INFORMATIONAL only (never blocks).

    RM03  Elderly 401K (owner age 75) → rmd_required=True, positive
          rmd_amount, account_display matches.
    RM04  Roth IRA → rmd_required=False, reason mentions Roth exempt.
    RM05  Young owner (age 40) → rmd_required=False with first_rmd_year
          populated and reason citing SECURE Act 2.0 §107.
    RM06  Elderly + rmd_deadline_passed=True in account_context →
          penalty_if_missed > 0 at the 25% rate.

GROUP C — HITL no longer used for RM calc
    RM07  Documents obsolete deny-at-HITL path; RMD completes without HITL.

GROUP D — Multi-turn slot collection
    RM08  Bare "calculate my RMD" missing DOB → COLLECT_SLOT /
          RETRY_SLOT / CLARIFY on T1 where needed; T2 supplies
          DOB+plan → EXECUTE_TRANSACTION + COMPLETED or forward progress.

GROUP F — Direct tool invocation (no LLM, fast)
    Bypasses the supervisor to exercise every branch of
    ``RMDCalculatorTool.execute()``.

    RM09  Roth IRA → rmd_required=False, Roth-exempt reason.
    RM10  ROTH_401K → rmd_required=False (SECURE 2.0 §325).
    RM11  Owner age < 73 → rmd_required=False, first_rmd_year populated.
    RM12  Elderly (age 75, prior balance 480000) → rmd_amount ≈
          480000 / 24.6 = 19512.20.
    RM13  Elderly (age 80, prior balance 200000) → rmd_amount ≈
          200000 / 20.2 = 9900.99.
    RM14  YTD distributions reduce remaining_rmd correctly.
    RM15  rmd_deadline_passed → penalty at 25% rate.
    RM16  rmd_deadline_passed + rmd_correction_window → penalty at 10%.
    RM17  Negative prior balance → escalation, FAILED.
    RM18  NaN prior balance → escalation, FAILED.
    RM19  Owner age 121 (above table) → escalation, FAILED.
    RM20  Missing account → "Missing account number" failure.
    RM21  Missing age and DOB → "Owner age or date of birth required"
          failure.
    RM22  date_of_birth entity drives age computation (age-as-of
          Dec 31 of distribution year per IRS Pub 590-B).
    RM23  tax_year override applies the historical age.

Each test is independently runnable.  Real-LLM gating via
OPENAI_API_KEY skipif.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from uuid import uuid4

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from schemas.enums import ActionType

from tests.e2e._rmd_helpers import (
    drive_one_turn,
    drive_turn_with_auto_resume,
    hitl_approve,
    patch_account_context,
    preauth_state,
    seed_elderly_for,
    seed_rmd_account_api,
    synth_action,
    synth_message,
    thread_config,
    tx,
)


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; rmd_calculator e2e tests need a live LLM.",
)


# ─── Shared fixtures ────────────────────────────────────────────────────────


@pytest.fixture(scope="module")
def graph():
    return compile_graph(checkpointer=get_checkpointer())


@pytest.fixture(autouse=True)
def _reseed_api():
    """Re-seed the rmd_calculator's MockAccountAPI before every test
    so test ordering does not leak balance/age state across scenarios.
    Group B/C/D tests further override per-account via ``seed_elderly_for``.
    """
    seed_rmd_account_api()
    yield


# ─── Convenience helpers ────────────────────────────────────────────────────


def _no_transaction_yet(result: dict) -> bool:
    """True when no tool has written transaction_result (None or {})."""
    tr = result.get("transaction_result")
    return tr is None or tr == {}


def _wait_for_hitl(result: dict) -> bool:
    """Synthesizer rendered PRESENT_HITL confirmation; no transaction
    has executed yet."""
    return synth_action(result) == ActionType.PRESENT_HITL.value \
        and _no_transaction_yet(result)


def _rmd_calc_completed_first_turn(result: dict) -> bool:
    """RMD_CALCULATION runs without pre-execute HITL; tool finishes on T1."""
    t = tx(result)
    return (
        synth_action(result) == ActionType.EXECUTE_TRANSACTION.value
        and t.get("status") == "COMPLETED"
        and t.get("operation") == "RMD_CALCULATION"
    )


def _assert_inquiry_answered(result: dict) -> None:
    """RMD_INQUIRY routes via informational/RAG; assert no transaction
    executed and a non-empty answer was synthesized."""
    assert _no_transaction_yet(result), (
        f"Inquiry must not run a tool: {result.get('transaction_result')!r}"
    )
    action = synth_action(result)
    assert action in (
        ActionType.ANSWER.value,
        ActionType.RAG_ANSWER.value if hasattr(ActionType, "RAG_ANSWER") else "ANSWER",
        "ANSWER",
    ), f"Expected ANSWER, got {action!r}"
    assert (synth_message(result) or "").strip(), \
        "Synthesizer must render a non-empty message"


# ============================================================================
# GROUP A — RMD_INQUIRY (RAG/INFORMATIONAL path)
# ============================================================================


def test_rm01_alex_rmd_inquiry_routes_to_answer(graph):
    """alex asks general RMD-rules question → routed via ANSWER (RAG)."""
    session, state = preauth_state("demo-user-001")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(
        graph, state,
        "When do I have to start taking my Required Minimum Distributions?",
        config,
    )
    _assert_inquiry_answered(r)


def test_rm02_morgan_rmd_penalty_inquiry_routes_to_answer(graph):
    """morgan asks penalty-rules question → ANSWER (RAG)."""
    session, state = preauth_state("demo-user-002")
    config = thread_config(session)

    r = drive_turn_with_auto_resume(
        graph, state,
        "What's the penalty if I miss my RMD deadline?",
        config,
    )
    _assert_inquiry_answered(r)


# ============================================================================
# GROUP B — RMD_CALCULATION happy paths (EXECUTE_TRANSACTION on T1, no HITL)
# ============================================================================


def _calc_message(plan: str, dob_natural: str) -> str:
    """Single-message RMD_CALCULATION request providing both required
    slots (plan_type + date_of_birth)."""
    return (
        f"Please calculate my Required Minimum Distribution for my {plan}. "
        f"I was born on {dob_natural}."
    )


def test_rm03_elderly_401k_calculates_positive_rmd(graph):
    """Elderly owner (age 75 in 2026, DOB 1951-03-15) on a 401K with
    $480k prior-year-end balance → COMPLETED with rmd_required=True,
    rmd_amount≈480000/24.6=19512.20.  Allow ±1 age year drift in LLM
    DOB extraction (factor 24.6 vs 25.5 vs 23.7)."""
    session, state = preauth_state("demo-user-001")
    seed_elderly_for("demo-user-001",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        _calc_message("401(k)", "March 15, 1951"),
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1, got action={synth_action(r1)!r}, "
        f"tx={tx(r1)!r}, synth={synth_message(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is True, t
    assert t.get("operation") == "RMD_CALCULATION", t
    assert t.get("account_display") == "****8810", t
    assert float(t.get("rmd_amount", 0)) > 0, t
    # Sanity bounds: 480k / 23.7..25.5 ≈ 18823..20253
    assert 17_000 <= float(t["rmd_amount"]) <= 22_000, t


def test_rm04_roth_ira_returns_exempt(graph):
    """Roth IRA → rmd_required=False with Roth-exempt reason
    (IRC 408A(c)(5))."""
    session, state = preauth_state("demo-user-003")  # Sam, traditional IRA
    # Override: account is now ROTH_IRA, owner is elderly.
    seed_elderly_for("demo-user-003",
                     age=75.0, dob="1951-03-15",
                     prior_balance=120_000.0,
                     account_type="ROTH_IRA")
    patch_account_context(state, age=75.0, dob="1951-03-15")
    state["account_context"]["plan_type"] = "ROTH_IRA"
    state["account_context"]["account_type"] = "ROTH_IRA"
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        _calc_message("Roth IRA", "March 15, 1951"),
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1, got action={synth_action(r1)!r}, "
        f"tx={tx(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is False, t
    reason = (t.get("reason") or "").lower()
    assert "roth" in reason, t


def test_rm05_young_owner_returns_under_age(graph):
    """Owner younger than 73 → rmd_required=False with
    first_rmd_year populated."""
    session, state = preauth_state("demo-user-001")  # alex, age 40
    # Default seeding: age=40, dob=1985-01-01 — already too young.
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        _calc_message("401(k)", "June 12, 1985"),
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1, got action={synth_action(r1)!r}, "
        f"tx={tx(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is False, t
    assert t.get("rmd_amount", -1) == 0.0, t
    # first_rmd_year should be birth_year + 73 = 1985 + 73 = 2058
    assert t.get("first_rmd_year") in (2058, None), t  # tolerate LLM DOB drift
    reason = (t.get("reason") or "").lower()
    assert "73" in reason or "secure" in reason, t


def test_rm06_elderly_deadline_passed_assesses_penalty(graph):
    """Elderly + deadline passed in account_context → penalty_if_missed
    computed at 25% of remaining_rmd."""
    session, state = preauth_state("demo-user-001")
    seed_elderly_for("demo-user-001",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    state["account_context"]["rmd_deadline_passed"] = True
    state["account_context"]["rmd_correction_window"] = False
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        _calc_message("401(k)", "March 15, 1951"),
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1, got action={synth_action(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is True, t
    assert t.get("rmd_deadline_passed") is True, t
    penalty = float(t.get("penalty_if_missed", 0))
    remaining = float(t.get("remaining_rmd", 0))
    assert remaining > 0, t
    # penalty == round(remaining * 0.25, 2)
    assert abs(penalty - round(remaining * 0.25, 2)) < 0.05, t


# ============================================================================
# GROUP C — HITL deny path
# ============================================================================


def test_rm07_rmd_skips_hitl_previous_deny_obsolete(graph):
    """RMD_CALCULATION no longer presents pre-execute HITL—the tool runs on
    the first validated turn (see policy skips_pre_execute_hitl). This test
    documents that the old deny-at-HITL path does not apply; calculation
    completes immediately when slots are satisfied."""
    session, state = preauth_state("demo-user-001")
    seed_elderly_for("demo-user-001",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        _calc_message("401(k)", "March 15, 1951"),
        config,
    )
    assert not _wait_for_hitl(r1), (
        "RMD_CALCULATION must not require PRESENT_HITL before executing"
    )
    assert _rmd_calc_completed_first_turn(r1), (
        synth_action(r1),
        tx(r1),
    )


# ============================================================================
# GROUP D — Multi-turn slot collection
# ============================================================================


def test_rm08_bare_intent_then_full_info(graph):
    """T1: bare 'calculate my RMD' (no DOB / plan) → expected
    COLLECT_SLOT / RETRY_SLOT / CLARIFY / etc.
    T2: provide DOB + plan → EXECUTE_TRANSACTION + COMPLETED (no pre-execute HITL)."""
    session, state = preauth_state("demo-user-001")
    seed_elderly_for("demo-user-001",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state, "Can you calculate my RMD?", config,
    )
    a1 = synth_action(r1)
    allowed_t1 = {
        ActionType.COLLECT_SLOT.value,
        ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value,
        ActionType.PRESENT_HITL.value,
        ActionType.EXECUTE_TRANSACTION.value,
        ActionType.ANSWER.value,  # may answer the 'when do RMDs start' angle
    }
    assert a1 in allowed_t1, f"Unexpected T1 action {a1!r}, tx={tx(r1)!r}"

    r2 = drive_turn_with_auto_resume(
        graph, r1,
        "It's my 401(k), and I was born on March 15, 1951.",
        config,
    )
    a2 = synth_action(r2)
    if _rmd_calc_completed_first_turn(r2):
        return  # OK — full calc on T2
    # Otherwise tolerate any forward-progress action.
    allowed_t2 = allowed_t1 | {
        ActionType.HITL_APPROVED.value,
    }
    assert a2 in allowed_t2 or tx(r2).get("status") == "COMPLETED", (
        f"Unexpected T2 action {a2!r}, tx={tx(r2)!r}"
    )


# ============================================================================
# GROUP F — Direct tool invocation (no LLM, fast)
# ============================================================================


def _make_entity(slot, value, *, vault_token=None):
    from schemas.enums import EntityType
    from schemas.primitives import EntityRecord
    et_map = {
        "account_number": EntityType.ACCOUNT_NUMBER,
        "plan_type": EntityType.PLAN_TYPE,
        "account_type": EntityType.PLAN_TYPE,
        "date_of_birth": EntityType.DATE_OF_BIRTH,
        "tax_year": EntityType.TAX_YEAR,
    }
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=et_map[slot],
        slot_name=slot,
        display_value=str(value),
        vault_token=vault_token,
        is_pii=slot in ("account_number", "date_of_birth"),
        is_confirmed=True,
        confidence=1.0,
    )


def _agent():
    from tools.rmd_calculator.v1.agent import RMDCalculatorTool
    return RMDCalculatorTool()


def _seed_one(account_number: str, *,
              account_type: str = "401K",
              age: float = 75.0,
              dob: str = "1951-01-01",
              prior_balance: float = 480_000.0) -> None:
    """Direct API seed for a single test account (Group F)."""
    from tools.rmd_calculator.v1.agent import _get_account_api
    from tests.mocks.account_api import AccountRecord
    api = _get_account_api()
    api.seed_account(AccountRecord(
        account_number=account_number,
        account_type=account_type,
        owner_name="Test Owner",
        owner_age_years=age,
        owner_dob=dob,
        total_balance=prior_balance,
        vested_balance=prior_balance,
        prior_year_end_balance=prior_balance,
    ))


def test_rm09_direct_roth_ira_exempt():
    _seed_one("acct_roth_ira", account_type="ROTH_IRA",
              age=75.0, prior_balance=120_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "ROTH_IRA"),
        },
        account_context={
            "account_number": "acct_roth_ira",
            "owner_age_years": 75.0,
            "account_type": "ROTH_IRA",
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is True
    assert t["rmd_required"] is False
    assert "roth" in t["reason"].lower()
    assert t["rmd_amount"] == 0.0


def test_rm10_direct_roth_401k_exempt():
    _seed_one("acct_roth_401k", account_type="ROTH_401K",
              age=80.0, prior_balance=200_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "ROTH_401K"),
        },
        account_context={
            "account_number": "acct_roth_401k",
            "owner_age_years": 80.0,
            "account_type": "ROTH_401K",
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["rmd_required"] is False
    assert t["rmd_amount"] == 0.0


def test_rm11_direct_under_age_returns_first_rmd_year():
    _seed_one("acct_young", account_type="401K",
              age=45.0, dob="1981-03-15", prior_balance=150_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1981-03-15"),
        },
        account_context={
            "account_number": "acct_young",
            "owner_age_years": 45.0,
            "owner_dob": "1981-03-15",
            "account_type": "401K",
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is True
    assert t["rmd_required"] is False
    # 1981 + 73 = 2054
    assert t["first_rmd_year"] == 2054
    assert "73" in (t.get("reason") or "")


def test_rm12_direct_age_75_computes_correct_rmd():
    """480000 / 24.6 = 19512.195122 → rounded 19512.20."""
    _seed_one("acct_75_480k", age=75.0, dob="1951-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={
            "account_number": "acct_75_480k",
            "account_type": "401K",
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is True
    assert t["rmd_required"] is True
    assert t["owner_age"] == 75
    assert t["distribution_period"] == 24.6
    assert t["rmd_amount"] == round(480_000.0 / 24.6, 2)
    assert t["account_display"] == "****480k"[-8:] or t["account_display"].startswith("****")
    assert t["penalty_if_missed"] == 0.0


def test_rm13_direct_age_80_computes_correct_rmd():
    """200000 / 20.2 = 9900.99."""
    _seed_one("acct_80_200k", age=80.0, dob="1946-01-01",
              prior_balance=200_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1946-01-01"),
        },
        account_context={"account_number": "acct_80_200k"},
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["owner_age"] == 80
    assert t["distribution_period"] == 20.2
    assert t["rmd_amount"] == round(200_000.0 / 20.2, 2)


def test_rm14_direct_ytd_distributions_reduce_remaining():
    """rmd_amount=19512.20; ytd=10000 → remaining=9512.20."""
    _seed_one("acct_75_ytd", age=75.0, dob="1951-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={
            "account_number": "acct_75_ytd",
            "ytd_distributions": 10_000.0,
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    rmd = t["rmd_amount"]
    assert t["ytd_distributions"] == 10_000.0
    assert t["remaining_rmd"] == round(max(0.0, rmd - 10_000.0), 2)


def test_rm15_direct_deadline_passed_assesses_25pct_penalty():
    _seed_one("acct_75_late", age=75.0, dob="1951-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={
            "account_number": "acct_75_late",
            "rmd_deadline_passed": True,
            "rmd_correction_window": False,
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["rmd_deadline_passed"] is True
    assert t["penalty_rate"] == 0.25
    expected = round(t["remaining_rmd"] * 0.25, 2)
    assert t["penalty_if_missed"] == expected


def test_rm16_direct_correction_window_assesses_10pct_penalty():
    _seed_one("acct_75_corr", age=75.0, dob="1951-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={
            "account_number": "acct_75_corr",
            "rmd_deadline_passed": True,
            "rmd_correction_window": True,
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    expected = round(t["remaining_rmd"] * 0.10, 2)
    assert t["penalty_if_missed"] == expected


def test_rm17_direct_negative_balance_escalates():
    _seed_one("acct_neg", age=75.0, dob="1951-01-01",
              prior_balance=-1.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={"account_number": "acct_neg"},
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is False
    assert t["status"] == "FAILED"
    assert any("negative" in e.lower() for e in t["errors"])
    assert out["escalation_requested"] is True


def test_rm18_direct_nan_balance_escalates():
    """NaN prior-year balance returned by API → escalation."""
    from tools.rmd_calculator.v1.agent import _get_account_api
    from tests.mocks.account_api import AccountRecord
    api = _get_account_api()
    api.seed_account(AccountRecord(
        account_number="acct_nan",
        account_type="401K",
        owner_name="Test",
        owner_age_years=75.0,
        owner_dob="1951-01-01",
        prior_year_end_balance=float("nan"),
    ))
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={"account_number": "acct_nan"},
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is False
    assert any("nan" in e.lower() or "invalid" in e.lower() for e in t["errors"])
    assert out["escalation_requested"] is True


def test_rm19_direct_missing_account_number_fails():
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={},   # no account_number
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is False
    assert any("account number" in e.lower() for e in t["errors"])


def test_rm20_direct_missing_age_and_dob_fails():
    _seed_one("acct_no_age", age=75.0, prior_balance=10_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
        },
        account_context={
            "account_number": "acct_no_age",
            # No owner_age_years / owner_dob keys
        },
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is False
    assert any("age" in e.lower() or "date of birth" in e.lower()
               for e in t["errors"])


def test_rm21_direct_dob_entity_drives_age_computation():
    """Pub 590-B uses age as-of Dec 31 of the distribution year."""
    _seed_one("acct_dob", age=0.0, dob="1900-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-03-15"),
        },
        account_context={"account_number": "acct_dob"},
        auth_token="t",
    )
    t = out["transaction_result"]
    # Current year per environment header is 2026 → ref Dec 31 2026:
    # 2026 - 1951 = 75 (March birthday already passed by Dec 31).
    current_year = datetime.now(timezone.utc).year
    expected_age = current_year - 1951
    assert t["owner_age"] == expected_age, t


def test_rm22_direct_tax_year_override_uses_historical_age():
    """tax_year=2024 → ref Dec 31 2024 → age = 2024-1951 = 73."""
    _seed_one("acct_taxyear", age=0.0, dob="1900-01-01",
              prior_balance=480_000.0)
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-03-15"),
            "tax_year": _make_entity("tax_year", "2024"),
        },
        account_context={"account_number": "acct_taxyear"},
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["owner_age"] == 73, t
    assert t["distribution_period"] == 26.5, t
    assert t["rmd_amount"] == round(480_000.0 / 26.5, 2), t


def test_rm23_direct_account_not_found_escalates():
    """Account API raises → escalation_requested=True."""
    out = _agent().execute(
        validated_entities={
            "plan_type": _make_entity("plan_type", "401K"),
            "date_of_birth": _make_entity("date_of_birth", "1951-01-01"),
        },
        account_context={"account_number": "acct_does_not_exist_xyz"},
        auth_token="t",
    )
    t = out["transaction_result"]
    assert t["success"] is False
    assert out["escalation_requested"] is True


# ============================================================================
# GROUP G — Slot auto-fill from authenticated account_context
# ----------------------------------------------------------------------------
# These exercise the real fix: ``compute_slot_gap`` now treats
# ``date_of_birth`` and ``plan_type`` as already filled when the
# authenticated account_context already knows them, so the supervisor
# stops asking the user to repeat PII it just verified.
# ============================================================================


def test_rm24_single_account_user_skips_all_slots(graph):
    """Single-account elderly user (Alex, only 401K, DOB on file) →
    bare 'calculate my RMD' completes on T1 with EXECUTE_TRANSACTION — no
    COLLECT_SLOT for DOB or plan_type and no pre-execute HITL.

    The agent must not ask for PII that the recordkeeper already owns once
    auth has succeeded.
    """
    session, state = preauth_state("demo-user-001")
    seed_elderly_for("demo-user-001",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state, "Calculate my RMD please.", config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1 (no slot collection); got "
        f"action={synth_action(r1)!r}, tx={tx(r1)!r}, "
        f"synth={synth_message(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is True, t
    assert t.get("account_display") == "****8810", t
    assert 17_000 <= float(t["rmd_amount"]) <= 22_000, t


def test_rm25_multi_account_asks_only_for_plan_type(graph):
    """Multi-account elderly user (Casey: 401K + IRA) → bare
    'calculate my RMD' must ask which account, NOT for DOB.

    T1: only plan_type slot is missing → COLLECT_SLOT.
    T2: user replies '401(k)' → EXECUTE_TRANSACTION + COMPLETED (****7373).
    """
    session, state = preauth_state("demo-user-006")
    seed_elderly_for("demo-user-006",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state, "Can you calculate my RMD?", config,
    )
    a1 = synth_action(r1)
    msg1 = (synth_message(r1) or "").lower()
    # Allowed: collection-style turn that mentions the choice between
    # account types, OR direct PRESENT_HITL if the LLM optimistically
    # auto-picked one.  In any case the prompt must NOT ask for DOB.
    assert "birth" not in msg1 and "born" not in msg1, (
        f"Agent must not ask for DOB after auth; got: {msg1!r}"
    )
    allowed = {
        ActionType.COLLECT_SLOT.value,
        ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value,
        ActionType.EXECUTE_TRANSACTION.value,
    }
    assert a1 in allowed, f"Unexpected T1 action {a1!r}, tx={tx(r1)!r}"

    # Continue with explicit plan disambiguation
    r2 = drive_turn_with_auto_resume(
        graph, r1, "My 401(k) account.", config,
    )
    if not _rmd_calc_completed_first_turn(r2):
        msg2 = (synth_message(r2) or "").lower()
        assert "birth" not in msg2 and "born" not in msg2, (
            f"Agent must not ask for DOB after auth; got: {msg2!r}"
        )
        return  # forward-progress without completed calc still acceptable edge

    t = tx(r2)
    assert t.get("status") == "COMPLETED", t
    assert t.get("account_display") == "****7373", t


def test_rm26_multi_account_with_inline_plan_skips_collection(graph):
    """Multi-account user names plan up front → no collection at all.

    Casey says 'calculate my RMD on my Traditional IRA' → plan_type
    is filled by the LLM (or auto-fill via message-token scan) AND
    DOB is filled from account_context → EXECUTE_TRANSACTION on T1.
    COMPLETED on the IRA account (****7474).
    """
    session, state = preauth_state("demo-user-006")
    seed_elderly_for("demo-user-006",
                     age=75.0, dob="1951-03-15",
                     prior_balance=150_000.0,
                     account_type="TRADITIONAL_IRA")
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        "Calculate my RMD on my Traditional IRA.",
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD EXECUTE_TRANSACTION on T1; got action={synth_action(r1)!r}, "
        f"tx={tx(r1)!r}, synth={synth_message(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    assert t.get("rmd_required") is True, t
    assert t.get("account_display") == "****7474", t
    # 150k / ~24.6 ≈ 6097
    assert 5_500 <= float(t["rmd_amount"]) <= 6_700, t


def test_rm27_multi_account_consecutive_calculations(graph):
    """Two RMD calculations in a row on different accounts (Casey).

    T1: 401(k) → COMPLETED on ****7373 (no pre-execute HITL).
    T2-T3: Traditional IRA → COMPLETED on ****7474.
    Asserts no PII re-elicitation between transactions and that
    plan_type from T1 does not contaminate T2's selection.
    """
    session, state = preauth_state("demo-user-006")
    seed_elderly_for("demo-user-006",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        "Please calculate my RMD for my 401(k).",
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"T1: expected RMD calc; got {synth_action(r1)!r}, tx={tx(r1)!r}"
    )
    t1 = tx(r1)
    assert t1.get("status") == "COMPLETED", t1
    assert t1.get("account_display") == "****7373", t1

    # Re-seed IRA balance for the second calc.
    seed_elderly_for("demo-user-006",
                     age=75.0, dob="1951-03-15",
                     prior_balance=150_000.0)

    r3 = drive_turn_with_auto_resume(
        graph, r1,
        "Now calculate the RMD for my Traditional IRA.",
        config,
    )
    msg3 = (synth_message(r3) or "").lower()
    assert "birth" not in msg3 and "born" not in msg3, (
        f"Second calc must not re-ask DOB; got {msg3!r}"
    )
    assert _rmd_calc_completed_first_turn(r3), (
        synth_action(r3),
        tx(r3),
    )
    t2 = tx(r3)
    assert t2.get("status") == "COMPLETED", t2
    assert t2.get("account_display") == "****7474", t2


def test_rm28_third_party_dob_does_not_override_authenticated_dob(graph):
    """Authenticated user supplies a DOB different from the one on file
    → the **user-supplied** DOB wins (validated_entities take priority
    over account_context).  Auto-fill must not silently shadow the
    explicit user value.

    Casey (DOB on file 1951-03-15, age 75) says 'born March 15, 1955'
    (age 71) → result must reflect age 71, i.e. rmd_required=False
    with first_rmd_year=2028.
    """
    session, state = preauth_state("demo-user-006")
    seed_elderly_for("demo-user-006",
                     age=75.0, dob="1951-03-15",
                     prior_balance=480_000.0)
    patch_account_context(state, age=75.0, dob="1951-03-15")
    config = thread_config(session)

    r1 = drive_turn_with_auto_resume(
        graph, state,
        "Calculate my RMD on my 401(k). I was born March 15, 1955.",
        config,
    )
    assert _rmd_calc_completed_first_turn(r1), (
        f"Expected RMD calc on T1; got {synth_action(r1)!r}"
    )
    t = tx(r1)
    assert t.get("status") == "COMPLETED", t
    # User-supplied DOB drives the decision.
    assert t.get("rmd_required") is False, t
    assert t.get("first_rmd_year") in (2028, None), t


# ============================================================================
# GROUP H — Cross-intent regression (entity-leak between transactions)
# ============================================================================


def test_rm29_balance_to_rmd_pivot_drops_stale_account_type(graph):
    """REGRESSION: pivoting from ACCOUNT_BALANCE_INQUIRY into
    RMD_CALCULATION must NOT leak the prior intent's ``account_type``
    entity into the RMD response (previously the HITL confirmation card).

    Reproduces the Jordan (demo-user-004) live-UI bug:
        T1: 'show me my 401k and brokerage balance' →
            balance inquiry runs, entity_memory holds account_type
            (BROKERAGE was the last write in the multi-account scan).
        T2: 'can you calculate my RMD?' → PIVOT to RMD_CALCULATION;
            agent asks for plan_type (Jordan has 3 accounts).
        T3: '401k' → RMD tool runs; synthesizer output must not mention BROKERAGE.

    Asserts on T3:
      * Message does NOT contain 'BROKERAGE' / 'brokerage'.
      * If HITL is shown (other intents), same rule applies; for RMD,
        expect EXECUTE_TRANSACTION + completed calc when disambiguated.
    """
    # Seed both balance_inquiry and rmd_calculator singletons so T1
    # has data and T3 can complete the calc on Jordan's 401k.
    from tools.balance_inquiry.v1.agent import _get_account_api as _bi_api  # type: ignore
    from auth.client import secrets_provider
    from tests.mocks.account_api import AccountRecord

    # Seed balance_inquiry singleton from demo data (Jordan has
    # 401K/IRA/BROKERAGE).
    bi_api = _bi_api()
    provider = secrets_provider()
    ctx = provider.get_account_context("demo-user-004") or {}
    for atype, acct in (ctx.get("accounts") or {}).items():
        num = acct.get("account_number")
        if not num:
            continue
        vested = float(acct.get("vested_balance", 0.0))
        total = float(acct.get("total_balance", vested))
        bi_api.seed_account(AccountRecord(
            account_number=num,
            account_type=acct.get("account_type", atype),
            owner_name=ctx.get("display_name") or "Jordan",
            owner_age_years=float(ctx.get("owner_age_years", 47)),
            owner_dob=ctx.get("owner_dob") or "1978-11-23",
            total_balance=total,
            vested_balance=vested,
            prior_year_end_balance=float(acct.get("prior_year_end_balance", 0.0)),
            plan_name=acct.get("plan_name", "Demo Plan"),
        ))

    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # T1 — balance inquiry on 401k + brokerage.  This populates
    # entity_memory with account_type (BROKERAGE is typically the
    # final categorical write in the multi-account scan).
    r1 = drive_turn_with_auto_resume(
        graph, state,
        "Show me my 401k and brokerage balance.",
        config,
    )
    # T1 may PRESENT_HITL/ANSWER/COMPLETED — outcome doesn't matter
    # for this regression as long as entity extraction ran.

    # If T1 left an open HITL (multi-account auth, etc.) clear it so
    # the pivot in T2 is observed by the intent_agent at the proper
    # turn boundary.
    if synth_action(r1) == ActionType.PRESENT_HITL.value:
        r1 = hitl_approve(graph, r1, config)

    # T2 — PIVOT to RMD calculation (no plan named).
    r2 = drive_turn_with_auto_resume(
        graph, r1,
        "Can you calculate my RMD?",
        config,
    )

    # T3 — disambiguate to 401k.  If T2 already completed RMD, reuse it.
    if _rmd_calc_completed_first_turn(r2):
        r3 = r2
    else:
        r3 = drive_turn_with_auto_resume(graph, r2, "401k", config)

    # — Primary assertion: response must not contain the leaked BROKERAGE
    # entity from T1.
    msg3 = (synth_message(r3) or "")
    assert "brokerage" not in msg3.lower(), (
        "Leak: 'BROKERAGE' from prior balance-inquiry turn appeared in RMD "
        f"response. msg={msg3!r}"
    )

    if _rmd_calc_completed_first_turn(r3):
        low = msg3.lower()
        assert ("401" in low) or ("rmd" in low) or ("estimate" in low), (
            f"RMD response should reference 401k context or RMD; got {msg3!r}"
        )
    elif _wait_for_hitl(r3):
        low = msg3.lower()
        assert ("401" in low) or ("plan type" in low) or ("plan_type" in low), (
            f"Confirmation must surface plan choice; got {msg3!r}"
        )

    # NOTE: a stale ``account_type=BROKERAGE`` may still survive in
    # ``validated_entities`` because entity_extraction can re-extract
    # it from conversation history on later turns even after the
    # pivot purge clears entity_memory.  That's a deeper extraction
    # concern tracked separately; the user-facing fix lives in the
    # synthesizer HITL filter (Fix 1) which scopes the rendered
    # confirmation card to the active intent's required_slots.

