"""Shared helpers for rmd_calculator e2e tests.

Underscore-prefixed so pytest does not collect this as a test module.

Seeds the rmd_calculator's *own* MockAccountAPI singleton (each tool has
an independent module-level singleton) and supports per-account age,
DOB and prior-year-end-balance overrides — RMD computations require
elderly owners, which the demo dataset lacks.
"""
from __future__ import annotations

from schemas.enums import ActionType
from schemas.primitives import HITLState

# Re-export shared session/turn/auth plumbing from _balance_helpers so
# test modules only need one import line.
from tests.e2e._balance_helpers import (  # noqa: F401
    drive_one_turn,
    drive_turn_with_auto_resume,
    new_session,
    preauth_state,
    seed_account_context,
    thread_config,
)


# ─── Lightweight state-inspection helpers ───────────────────────────────────


def synth_action(result: dict) -> str | None:
    """Return the action_type string from the last synthesized response."""
    synth = result.get("last_synthesized_response") or {}
    return synth.get("action_type")


def synth_message(result: dict) -> str | None:
    """Return the full_message from the last synthesized response."""
    synth = result.get("last_synthesized_response") or {}
    return synth.get("full_message")


def tx(result: dict) -> dict | None:
    """Return the transaction_result dict from a graph invocation result."""
    return result.get("transaction_result")


# ─── HITL resume helpers ─────────────────────────────────────────────────────


def hitl_approve(graph, state: dict, config: dict) -> dict:
    """Resume the graph after a HITL card with user approval (confirmed=True)."""
    hitl = state.get("hitl") or HITLState()
    plan = state.get("current_action_plan")
    resume: dict = dict(state)
    resume["hitl"] = hitl.model_copy(update={
        "pending": False,
        "last_confirmed": True,
        "last_corrections": {},
    })
    if plan is not None:
        resume["current_action_plan"] = plan.model_copy(update={
            "action_type": ActionType.HITL_APPROVED,
        })
    result = graph.invoke(resume, config)
    # Mirror drive_turn_with_auto_resume / main._auto_resume_if_interrupted:
    # compile(interrupt_before=["tool_router"]) pauses before the tool runs.
    plan2 = result.get("current_action_plan")
    action = getattr(plan2, "action_type", None) if plan2 else None
    needs_tool = action in (
        ActionType.HITL_APPROVED,
        ActionType.EXECUTE_TRANSACTION,
    )
    has_result = result.get("transaction_result") is not None
    if needs_tool and not has_result:
        result = graph.invoke(None, config)
    return result


def hitl_deny(graph, state: dict, config: dict, corrections: dict | None = None) -> dict:
    """Resume the graph after a HITL card with user rejection (confirmed=False)."""
    hitl = state.get("hitl") or HITLState()
    plan = state.get("current_action_plan")
    resume: dict = dict(state)
    resume["hitl"] = hitl.model_copy(update={
        "pending": False,
        "last_confirmed": False,
        "last_corrections": corrections or {},
        "attempt_count": hitl.attempt_count + 1,
    })
    if plan is not None:
        resume["current_action_plan"] = plan.model_copy(update={
            "action_type": ActionType.HITL_CORRECTION,
        })
    resume["validated_entities"] = {}
    return graph.invoke(resume, config)


# ─── Mock account API seeding for rmd_calculator ────────────────────────────


def seed_rmd_account_api(
    *,
    age_overrides: dict[str, float] | None = None,
    dob_overrides: dict[str, str] | None = None,
    prior_balance_overrides: dict[str, float] | None = None,
    account_type_overrides: dict[str, str] | None = None,
) -> None:
    """Seed rmd_calculator's MockAccountAPI singleton with every demo
    user's accounts.

    ``age_overrides`` / ``dob_overrides`` / ``prior_balance_overrides``
    / ``account_type_overrides`` are keyed by account_number (e.g.
    ``"tok_acc_8810"``) and let individual scenarios make a particular
    account elderly, Roth, etc. without touching the demo dataset.
    """
    from auth.client import secrets_provider
    from tools.rmd_calculator.v1.agent import _get_account_api
    from tests.mocks.account_api import AccountRecord

    api = _get_account_api()
    provider = secrets_provider()
    age_overrides = age_overrides or {}
    dob_overrides = dob_overrides or {}
    prior_balance_overrides = prior_balance_overrides or {}
    account_type_overrides = account_type_overrides or {}

    for uid in (
        "demo-user-001", "demo-user-002", "demo-user-003",
        "demo-user-004", "demo-user-005", "demo-user-006",
    ):
        ctx = provider.get_account_context(uid) or {}
        ctx_age = float(ctx.get("owner_age_years", 40))
        for atype, acct in (ctx.get("accounts") or {}).items():
            num = acct.get("account_number")
            if not num:
                continue
            vested = float(acct.get("vested_balance", 0.0))
            total = float(acct.get("total_balance", vested))
            api.seed_account(AccountRecord(
                account_number=num,
                account_type=account_type_overrides.get(
                    num, acct.get("account_type", atype)),
                owner_name=ctx.get("display_name") or "Demo User",
                owner_age_years=age_overrides.get(num, ctx_age),
                owner_dob=dob_overrides.get(
                    num, ctx.get("owner_dob") or "1985-01-01"),
                total_balance=total,
                vested_balance=vested,
                prior_year_end_balance=prior_balance_overrides.get(
                    num, float(acct.get("prior_year_end_balance", 0.0))),
                plan_name=acct.get("plan_name", "Demo Plan"),
            ))


def seed_elderly_for(user_id: str, *,
                     age: float = 75.0,
                     dob: str = "1951-01-01",
                     prior_balance: float = 480_000.0,
                     account_type: str | None = None) -> None:
    """Convenience: re-seed every account belonging to one demo user
    with elderly owner age/dob/prior-year balance so RMD tests on that
    user produce a non-trivial calculation."""
    from auth.client import secrets_provider
    provider = secrets_provider()
    ctx = provider.get_account_context(user_id) or {}
    nums = [a.get("account_number") for a in (ctx.get("accounts") or {}).values()
            if a.get("account_number")]
    seed_rmd_account_api(
        age_overrides={n: age for n in nums},
        dob_overrides={n: dob for n in nums},
        prior_balance_overrides={n: prior_balance for n in nums},
        account_type_overrides=(
            {n: account_type for n in nums} if account_type else None),
    )


def patch_account_context(state: dict, *,
                          age: float | None = None,
                          dob: str | None = None) -> None:
    """Force the account_context owner_age_years / owner_dob so the
    entity_validator's RMD_START_AGE rule and the agent's age fallback
    both see the desired age."""
    ctx = dict(state.get("account_context") or {})
    if age is not None:
        ctx["owner_age_years"] = age
    if dob is not None:
        ctx["owner_dob"] = dob
    state["account_context"] = ctx
