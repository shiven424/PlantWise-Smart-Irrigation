"""
**Extended v2** end-to-end LangGraph scenarios for balance_inquiry.

Builds on top of:
  * ``test_balance_inquiry_e2e.py``           (S1-S6,   6 base scenarios)
  * ``test_balance_inquiry_e2e_extended.py``  (S7-S16,  10 scenarios)

This file adds **S17-S26** (10 more) covering angles not previously
exercised:

  EASY (1 turn)
    S17  conversational phrasing ("how much do I have stashed in my
         401k?") -> robust entity extraction
    S18  alias normalisation through punctuation typo "401-k"
    S19  explicit non-Roth disambiguation for a Roth+401K user

  MEDIUM (2 turns)
    S20  ambiguous phrasing ("check on my account") -> slot-collect ->
         natural-language slot reply naming the brokerage account
    S21  alex unauth full journey -> SSN challenge -> 4321 -> ****8810
    S22  jordan: chitchat first, THEN unauth balance request -> SSN ->
         7766 -> IRA ****2200

  COMPLEX (3+ turns)
    S23  jordan: balance success -> "thanks!" chitchat -> graceful end
         (no re-execution, no escalation)
    S24  jordan: same-account repeated twice in a row ("401k" then
         "what's my 401k balance now?") -- proves the
         intent_agent.completed_intent_ids reset works for *same*
         categorical value too, not just different ones
    S25  taylor unauth Roth journey -> SSN 5544 -> ****5500
    S26  jordan asks for an invalid account type ("savings") ->
         clarify / retry -> "401k" -> ****1100

Each test asserts every turn:
  * synthesizer action_type
  * transaction_result success / account_display / total_balance
  * auth_status transitions where relevant
  * absence of escalation on happy paths
  * absence of false-positive transactions on slot-fill turns

Requires OPENAI_API_KEY (real LLM per turn -> slow).
"""
from __future__ import annotations

import os

import pytest

from config import settings
from graph.builder import compile_graph
from graph.checkpointer import get_checkpointer
from schemas.enums import ActionType, AuthStatus, MessageDomain

from tests.e2e._balance_helpers import (
    assert_balance_response,
    drive_one_turn,
    drive_turn_with_auto_resume,
    new_session,
    preauth_state,
    seed_account_context,
    seed_mock_account_api_from_demo_data,
    thread_config,
)
from graph.state import initial_state


pytestmark = pytest.mark.skipif(
    not (os.getenv("OPENAI_API_KEY") or getattr(settings, "openai_api_key", "")),
    reason="OPENAI_API_KEY not set; balance_inquiry e2e tests need a live LLM.",
)


@pytest.fixture(scope="module")
def graph():
    seed_mock_account_api_from_demo_data()
    return compile_graph(checkpointer=get_checkpointer())


# ===========================================================================
# EASY -- 1-turn variations
# ===========================================================================


# --- S17 alex bare "balance?" -- slot-collect then 401k -------------------

def test_s17_conversational_phrasing_with_balance_question(graph):
    """morgan (demo-user-002) asks her balance with a casual,
    conversational phrasing ('how much do I have stashed in my 401k?').
    Tests that the entity extractor handles colloquial English and
    still resolves account_type=401K -> ****5511 / 312,450."""
    session, state = preauth_state("demo-user-002")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state, "How much do I have stashed away in my 401k right now?", config,
    )
    assert_balance_response(result, expected_last4="5511", expected_total=312450.00)
    assert not result.get("escalation_requested")


# --- S18 morgan with "401-k" punctuation typo ------------------------------

def test_s18_dashed_401k_alias_normalises(graph):
    """morgan asks for '401-k'.  The alias normaliser strips
    non-alphanumerics ('401-K' -> '401_K') and resolves to morgan's
    single 401K (****5511 / 312,450)."""
    session, state = preauth_state("demo-user-002")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state, "Could I see my 401-k balance please?", config,
    )
    assert_balance_response(result, expected_last4="5511", expected_total=312450.00)


# --- S19 taylor explicit non-Roth disambiguation ---------------------------

def test_s19_taylor_explicit_traditional_401k(graph):
    """taylor (demo-user-005) has both a 401K and a ROTH_IRA.
    Asking for 'my regular 401(k), not the Roth' must extract
    account_type=401K (NOT ROTH) and return ****4400 / 95,100.40.
    Tests negative disambiguation -- the LLM must understand that
    'not the Roth' eliminates ROTH_IRA from contention."""
    session, state = preauth_state("demo-user-005")
    config = thread_config(session)

    result = drive_turn_with_auto_resume(
        graph, state,
        "Show me my regular 401(k) balance, not the Roth.",
        config,
    )
    assert_balance_response(result, expected_last4="4400", expected_total=95100.40)


# ===========================================================================
# MEDIUM -- 2-turn flows
# ===========================================================================


# --- S20 ambiguous "check my account" -> slot-collect -> natural reply -----

def test_s20_ambiguous_phrasing_then_slot_fill(graph):
    """jordan says 'I want to check on my account please' -- this is
    ambiguous (no account_type token, multi-account user).  The graph
    must COLLECT_SLOT, then on turn 2 the user names brokerage in a
    natural sentence ('the brokerage one would be great').  Final
    result: ****3300 / 156,750.80."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1 -- ambiguous.  LLM nondeterminism: usually slot-collects,
    # but may occasionally emit EXECUTE_TRANSACTION with a guessed
    # account.  Accept either; only check that no WRONG balance fired.
    state = drive_one_turn(graph, state, "I want to check on my account please.", config)
    synth1 = state.get("last_synthesized_response") or {}
    tx1 = state.get("transaction_result") or {}
    if tx1.get("success") is True and tx1.get("account_display") == "****3300":
        # Lucky path -- LLM guessed brokerage correctly.
        return
    assert synth1.get("action_type") in (
        ActionType.COLLECT_SLOT.value, ActionType.RETRY_SLOT.value,
        ActionType.CLARIFY.value, ActionType.EXECUTE_TRANSACTION.value,
        ActionType.HITL_APPROVED.value,
    ), f"Unexpected turn-1 action: {synth1.get('action_type')!r}"

    # Turn 2 -- natural-sentence slot reply, must land on brokerage.
    result = drive_turn_with_auto_resume(
        graph, state, "The brokerage one would be great.", config,
    )
    assert_balance_response(result, expected_last4="3300", expected_total=156750.80)


# --- S21 alex unauth full journey ------------------------------------------

def test_s21_alex_unauth_balance_with_ssn_challenge(graph):
    """alex (demo-user-001) starts UNAUTHENTICATED (default initial
    state without preauth seeding).  Asking for the 401k balance must:
      * trigger an SSN auth challenge (no false transaction),
      * accept SSN '4321',
      * then return ****8810 / 148,980.55.

    Mirrors S6 (same flow) but built on the new shared helpers --
    ensures the helper-extracted version still survives the full
    auth + balance pipeline."""
    session = new_session("demo-user-001")
    state = initial_state(session)
    seed_account_context(state, "demo-user-001")
    config = thread_config(session)

    # Turn 1 -- triggers auth challenge
    state = drive_one_turn(graph, state, "Show me my 401k balance please.", config)
    assert state.get("auth_status") == AuthStatus.PENDING, (
        f"Expected PENDING auth, got {state.get('auth_status')!r}"
    )
    assert state.get("transaction_result") is None
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.AUTH_CHALLENGE.value, ActionType.INITIATE_AUTH.value,
        ActionType.PROCESS_AUTH.value,
    ), f"Expected auth challenge, got {synth1.get('action_type')!r}"

    # Prime the auth challenge until expected_hash is set (mirrors S6).
    for msg in ("sure", "yes please", "go ahead", "ok"):
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = drive_one_turn(graph, state, msg, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )

    # Decisive turn -- supply correct SSN
    result = drive_turn_with_auto_resume(graph, state, "4321", config)
    assert_balance_response(result, expected_last4="8810", expected_total=148980.55)
    assert result.get("auth_status") == AuthStatus.VERIFIED


# --- S22 jordan: chitchat first, then unauth balance -----------------------

def test_s22_jordan_chitchat_then_unauth_balance_with_ssn(graph):
    """Three-turn flow on a single fresh thread (UNAUTHENTICATED):
        Turn 1: 'Hi there!'                   -> CHITCHAT_RESPOND.
        Turn 2: 'Balance on my IRA please.'   -> SSN auth challenge.
        Turn 3: '7766'                        -> IRA balance ****2200.

    Validates that the chitchat turn doesn't accidentally promote
    auth_status, and that on turn 2 the system correctly requests
    SSN before executing the transaction."""
    session = new_session("demo-user-004")
    state = initial_state(session)
    seed_account_context(state, "demo-user-004")
    config = thread_config(session)

    # Turn 1 -- chitchat
    state = drive_one_turn(graph, state, "Hi there!", config)
    assert state.get("transaction_result") is None
    assert state.get("auth_status") != AuthStatus.VERIFIED
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.CHITCHAT_RESPOND.value, ActionType.ANSWER.value,
    )

    # Turn 2 -- transactional, must trigger auth
    state = drive_one_turn(graph, state, "Balance on my IRA please.", config)
    assert state.get("transaction_result") is None
    synth2 = state.get("last_synthesized_response") or {}
    assert synth2.get("action_type") in (
        ActionType.AUTH_CHALLENGE.value, ActionType.INITIATE_AUTH.value,
        ActionType.PROCESS_AUTH.value, ActionType.COLLECT_SLOT.value,
    ), f"Expected auth challenge after transactional ask, got {synth2.get('action_type')!r}"

    # Prime the auth challenge until expected_hash is set.
    for msg in ("sure", "yes please", "go ahead", "ok"):
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = drive_one_turn(graph, state, msg, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )

    # Decisive turn -- supply SSN
    result = drive_turn_with_auto_resume(graph, state, "7766", config)
    assert_balance_response(result, expected_last4="2200", expected_total=78400.00)
    assert result.get("auth_status") == AuthStatus.VERIFIED


# ===========================================================================
# COMPLEX -- 3+ turn flows
# ===========================================================================


# --- S23 success -> thank-you chitchat -> no false re-execute --------------

def test_s23_balance_then_thank_you_then_graceful_end(graph):
    """Three-turn flow:
        Turn 1: jordan asks 401k balance     -> ****1100.
        Turn 2: 'Thanks, that's perfect!'    -> CHITCHAT_RESPOND, no
                new transaction, no escalation.
        Turn 3: 'I'm all done now.'          -> CHITCHAT_RESPOND, no
                spurious tool invocation.

    Validates that a concluded transactional intent doesn't keep
    re-firing on subsequent friendly closing messages and that no
    stale tool_exec causes routing weirdness."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1
    state = drive_turn_with_auto_resume(
        graph, state, "Show me my 401k balance please.", config,
    )
    assert_balance_response(state, expected_last4="1100", expected_total=492100.25)

    # Turn 2 -- thank-you
    state = drive_one_turn(graph, state, "Thanks, that's perfect!", config)
    # Must NOT have re-executed a balance.
    tx2 = state.get("transaction_result")
    assert tx2 is None or tx2.get("success") is False, (
        f"Thank-you should not trigger another balance, got {tx2!r}"
    )
    assert not state.get("escalation_requested"), (
        "Thank-you should not escalate"
    )
    synth2 = state.get("last_synthesized_response") or {}
    assert synth2.get("full_message"), "Turn 2 produced no rendered message"

    # Turn 3 -- closing
    state = drive_one_turn(graph, state, "I'm all done now.", config)
    tx3 = state.get("transaction_result")
    assert tx3 is None or tx3.get("success") is False
    assert not state.get("escalation_requested")
    synth3 = state.get("last_synthesized_response") or {}
    assert synth3.get("full_message")


# --- S24 same-account repeated twice ---------------------------------------

def test_s24_same_account_repeated_executes_twice(graph):
    """Two-turn flow asking for the *same* account twice in a row:
        Turn 1: 'Show me my 401k balance.'      -> ****1100.
        Turn 2: 'Can you check my 401k again?'  -> ****1100.

    The intent_agent's completed_intent_ids reset must allow the
    second execution -- without it, the second turn would short-
    circuit as already-fulfilled and the user would never see the
    refreshed values."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1
    state = drive_turn_with_auto_resume(
        graph, state, "Show me my 401k balance.", config,
    )
    assert_balance_response(state, expected_last4="1100", expected_total=492100.25)

    # Turn 2 -- same account, fresh request
    result = drive_turn_with_auto_resume(
        graph, state, "Can you check my 401k balance again?", config,
    )
    assert_balance_response(result, expected_last4="1100", expected_total=492100.25)


# --- S25 taylor unauth Roth journey ----------------------------------------

def test_s25_taylor_unauth_roth_journey(graph):
    """Three-turn unauth journey for the *second* multi-account demo
    user (taylor / demo-user-005) on her ROTH_IRA:
        Turn 1: 'What's my Roth balance?'  -> SSN challenge.
        Turn 2: '5544'                     -> auth verified, balance
                                              ****5500 / 28,100.

    Verifies the auth + balance pipeline works for a *different*
    multi-account demographic and a different account type (Roth)
    than S6/S15's jordan flows."""
    session = new_session("demo-user-005")
    state = initial_state(session)
    seed_account_context(state, "demo-user-005")
    config = thread_config(session)

    # Turn 1 -- triggers auth
    state = drive_one_turn(graph, state, "What's my Roth balance?", config)
    assert state.get("auth_status") != AuthStatus.VERIFIED
    assert state.get("transaction_result") is None
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("action_type") in (
        ActionType.AUTH_CHALLENGE.value, ActionType.INITIATE_AUTH.value,
        ActionType.PROCESS_AUTH.value, ActionType.COLLECT_SLOT.value,
    )

    # Prime the auth challenge until expected_hash is set.
    for msg in ("sure", "yes please", "go ahead", "ok"):
        pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
        if pending.get("expected_hash"):
            break
        state = drive_one_turn(graph, state, msg, config)
    pending = (state.get("scratch") or {}).get("pending_auth_challenge") or {}
    assert pending.get("expected_hash"), (
        f"No challenge hash after priming; scratch={state.get('scratch')!r}"
    )

    # Decisive turn -- correct SSN
    result = drive_turn_with_auto_resume(graph, state, "5544", config)
    assert_balance_response(result, expected_last4="5500", expected_total=28100.00)
    assert result.get("auth_status") == AuthStatus.VERIFIED


# --- S26 invalid alias 'savings' -> retry/clarify -> recover ---------------

def test_s26_invalid_alias_savings_then_recover(graph):
    """Two/three-turn flow:
        Turn 1: 'What's my savings balance?'  -- 'savings' is NOT a
                supported account_type alias.  System must either:
                  (a) ask the user to clarify which account
                      (COLLECT_SLOT / RETRY_SLOT / CLARIFY), or
                  (b) return a clear non-success transaction_result.
                It MUST NOT silently pick a wrong account.
        Turn 2: '401k please'                 -> ****1100 success.

    Tests robust handling of out-of-vocabulary categorical values
    without crashing or silently mis-resolving."""
    session, state = preauth_state("demo-user-004")
    config = thread_config(session)

    # Turn 1 -- invalid alias
    state = drive_one_turn(graph, state, "What's my savings balance?", config)
    tx1 = state.get("transaction_result")
    if tx1 is not None and tx1.get("success") is True:
        # Tool ran -- it must NOT have silently returned the wrong
        # account.  Acceptable only if it surfaced an error/no-match.
        # ('success' True with an account_display means a wrong pick.)
        pytest.fail(
            f"Invalid 'savings' alias must not silently succeed; got {tx1!r}"
        )
    synth1 = state.get("last_synthesized_response") or {}
    assert synth1.get("full_message"), "Turn 1 produced no rendered message"

    # Turn 2 -- correct alias
    result = drive_turn_with_auto_resume(graph, state, "401k please.", config)
    assert_balance_response(result, expected_last4="1100", expected_total=492100.25)
