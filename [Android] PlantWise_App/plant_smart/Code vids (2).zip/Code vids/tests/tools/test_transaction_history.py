from __future__ import annotations

"""TransactionHistoryTool unit tests."""

from datetime import datetime, timezone
from uuid import uuid4

import pytest

from agents.intent_agent.v1.taxonomy import lookup_intent
from graph.state import compute_slot_gap
from schemas.enums import AuthLevel, EntityType, IntentChangeType, ServiceDomain
from schemas.primitives import EntityRecord, IntentRecord
from tools.balance_inquiry.v1.agent import set_account_api
from tools.transaction_history.v1.agent import (
    TransactionHistoryTool,
    extract_transaction_history_date_bounds,
)
from tests.mocks.account_api import (
    AccountRecord,
    FROZEN_ACCOUNT,
    MockAccountAPI,
    STANDARD_401K,
    Transaction,
    create_mock_account_api,
)


def _acct_type(display: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_TYPE,
        is_pii=False,
        slot_name="account_type",
        display_value=display,
        confidence=0.95,
    )


def _date_range_slot(text: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.DATE_RANGE,
        is_pii=False,
        slot_name="date_range",
        display_value=text,
        confidence=0.91,
    )


def _multi_ctx() -> dict:
    return {
        "accounts": {
            "401K": {
                "account_number": "a401",
                "account_type": "401K",
            },
            "TRADITIONAL_IRA": {
                "account_number": "aira",
                "account_type": "TRADITIONAL_IRA",
            },
        },
    }


def _three_acct_ctx() -> dict:
    """401K + Traditional IRA + Brokerage (numbers match txn_tool_api seeds)."""
    d = _multi_ctx()
    d["accounts"] = dict(d["accounts"])  # copy
    d["accounts"]["BROKERAGE"] = {
        "account_number": "abrok",
        "account_type": "BROKERAGE",
    }
    return d


def _state_tx(accounts_ctx: dict, *, msg: str = "", entity_memory=None) -> dict:
    d = lookup_intent("TRANSACTION_HISTORY_INQUIRY")
    assert d is not None
    intent = IntentRecord(
        intent_id=d.intent_id,
        service_domain=d.domain,
        sub_intent=d.sub_intent_id,
        confidence=0.9,
        change_type=IntentChangeType.NEW,
        requires_auth_level=AuthLevel.STRONG,
        is_transactional=True,
        required_slots=list(d.required_slots),
    )
    return {
        "intent_stack": [intent],
        "active_intent_id": intent.intent_id,
        "validated_entities": {},
        "entity_memory": entity_memory or {},
        "account_context": accounts_ctx,
        "last_user_message": msg,
    }


@pytest.fixture
def txn_tool_api():
    api = MockAccountAPI()
    api.seed_account(STANDARD_401K)
    api.seed_account(
        AccountRecord(
            account_number="a401",
            account_type="401K",
            owner_name="T",
            owner_age_years=40.0,
            owner_dob="1985-01-01",
            total_balance=100_000,
            vested_balance=100_000,
            transactions=[
                Transaction(
                    date="2026-04-01",
                    type="CONTRIBUTION",
                    description="Payroll",
                    amount=800.00,
                    running_balance=100_000.00,
                    reference_id="MULTI-401",
                ),
            ],
        ),
    )
    api.seed_account(
        AccountRecord(
            account_number="aira",
            account_type="TRADITIONAL_IRA",
            owner_name="T",
            owner_age_years=40.0,
            owner_dob="1985-01-01",
            total_balance=50_000,
            vested_balance=50_000,
            transactions=[
                Transaction(
                    date="2026-04-02",
                    type="CONTRIBUTION",
                    description="Contribution",
                    amount=500.00,
                    running_balance=50_000.00,
                    reference_id="MULTI-IRA",
                ),
            ],
        ),
    )
    api.seed_account(FROZEN_ACCOUNT)
    api.seed_account(
        AccountRecord(
            account_number="abrok",
            account_type="BROKERAGE",
            owner_name="T",
            owner_age_years=40.0,
            owner_dob="1985-01-01",
            total_balance=10_000,
            vested_balance=10_000,
            transactions=[
                Transaction(
                    date="2026-04-05",
                    type="BUY",
                    description="Stock buy",
                    amount=-500.00,
                    running_balance=10_000.00,
                    reference_id="BRK-A",
                ),
            ],
        ),
    )
    set_account_api(api)
    yield api
    set_account_api(None)


def test_compute_slot_gap_single_account(txn_tool_api):  # noqa: ARG001
    st = _state_tx(
        {
            "accounts": {
                "401K": {"account_number": "x", "account_type": "401K"},
            },
        },
        msg="show transactions",
    )
    assert compute_slot_gap(st) == []


def test_compute_slot_gap_multi_ambiguous(txn_tool_api):  # noqa: ARG001
    st = _state_tx(_multi_ctx(), msg="show my transactions please")
    assert compute_slot_gap(st) == ["account_type"]


def test_compute_slot_gap_multi_all_transactions(txn_tool_api):  # noqa: ARG001
    st = _state_tx(
        _multi_ctx(),
        msg="show transactions for every account",
    )
    assert compute_slot_gap(st) == []


def test_single_explicit_type_from_standard(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    ent = _acct_type("401K")
    out = tool.execute(
        {"account_type": ent},
        account_context={
            "accounts": {
                "401K": {
                    "account_number": STANDARD_401K.account_number,
                    "account_type": "401K",
                },
            },
        },
        auth_token="tok",
        last_user_message="401k transactions",
    )
    tr = out["transaction_result"]
    assert tr["success"] is True
    assert tr["operation"] == "TRANSACTION_HISTORY"
    assert len(tr["transactions"]) == 1
    assert tr["transactions"][0]["reference_id"].startswith("T-STD401K")


def test_default_window_excludes_old_row(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {},
        account_context={
            "accounts": {
                "401K": {
                    "account_number": STANDARD_401K.account_number,
                    "account_type": "401K",
                },
            },
        },
        auth_token="tok",
        last_user_message="recent transactions",
    )
    refs = [r["reference_id"] for r in out["transaction_result"]["transactions"]]
    assert "T-STD401K-0428" in refs
    assert "T-STD401K-OLD" not in refs


def test_date_range_includes_explicit_span(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {"date_range": _date_range_slot("2024-01-01 to 2024-06-05")},
        account_context={
            "accounts": {
                "401K": {
                    "account_number": STANDARD_401K.account_number,
                    "account_type": "401K",
                },
            },
        },
        auth_token="tok",
        last_user_message="transactions in range",
        current_turn=1,
    )
    refs = [r["reference_id"] for r in out["transaction_result"]["transactions"]]
    assert "T-STD401K-OLD" in refs


def test_multi_accounts_all_branch(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {},
        account_context=_multi_ctx(),
        auth_token="tok",
        last_user_message="show transactions for every account please",
        current_turn=1,
    )
    tr = out["transaction_result"]
    assert tr["success"] is True
    assert tr["operation"] == "TRANSACTION_HISTORY_MULTI"
    assert tr["account_count"] == 2
    ids = {(a["account_type"], len(a["transactions"])) for a in tr["accounts"]}
    assert ("401K", 1) in ids
    assert ("TRADITIONAL_IRA", 1) in ids


def test_multi_accounts_prior_turn_iras_and_401_post_auth_digit_turn(
    txn_tool_api,
):  # noqa: ARG001
    """Simulate STRONG auth: original ask names IRA + 401(k); execute turn is digits only."""
    tool = TransactionHistoryTool()
    recent = "\n".join(
        (
            "I want to see my IRA and 401(k) transaction history",
            "ok",
            "7766",
        ),
    )
    out = tool.execute(
        {},
        account_context=_multi_ctx(),
        auth_token="tok",
        last_user_message="7766",
        recent_user_queries_text=recent,
        current_turn=4,
    )
    tr = out["transaction_result"]
    assert tr["success"] is True
    assert tr["operation"] == "TRANSACTION_HISTORY_MULTI"
    assert tr["account_count"] == 2


def test_extract_bounds_nl_from_april_first():
    """Phrases like 'from 1st April, 2026' yield a start bound and today as end."""
    fixed_now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "Show my 401k and IRA transaction history from 1st april, 2026",
        fixed_now,
    )
    assert st == "2026-04-01"
    assert ed == "2026-05-03"


def test_truncated_three_digit_year_paired_with_full_end_year():
    """Typos like 'jan, 202' still pair with explicit '..., 2026' for a sane span."""
    fixed_now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "transactions from 1st jan, 202 to 1st april, 2026",
        fixed_now,
    )
    assert st == "2024-01-01"
    assert ed == "2026-04-01"


def test_last_calendar_month_range():
    now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "show transaction history last month",
        now,
    )
    assert st == "2026-04-01"
    assert ed == "2026-04-30"


def test_past_two_months_rolling_window():
    now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "transactions for the past 2 months",
        now,
    )
    assert st == "2026-03-03"
    assert ed == "2026-05-03"


def test_last_or_two_months_uses_longer_span():
    now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "past 1 or 2 months of activity",
        now,
    )
    assert st == "2026-03-03"
    assert ed == "2026-05-03"


def test_prior_calendar_year_phrase():
    now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds({}, "last calendar year", now)
    assert st == "2025-01-01"
    assert ed == "2025-12-31"


def test_past_three_years_rolling():
    now = datetime(2026, 5, 3, 12, 0, tzinfo=timezone.utc)
    st, ed = extract_transaction_history_date_bounds(
        {},
        "transactions last 3 years",
        now,
    )
    assert st == "2023-05-03"
    assert ed == "2026-05-03"


def test_compute_slot_gap_all_accounts_via_message_history(txn_tool_api):  # noqa: ARG001
    """Slot soft-fill scans message_history — auth digit turns alone must not re-open gaps."""
    st = _state_tx(_three_acct_ctx(), msg="7766")
    st["message_history"] = [
        {"role": "user", "content": "Show all my accounts transaction history"},
        {"role": "user", "content": "ok"},
    ]
    assert compute_slot_gap(st) == []


def test_multi_three_accounts_when_all_requested(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {},
        account_context=_three_acct_ctx(),
        auth_token="tok",
        last_user_message="all my accounts transactions please",
        current_turn=1,
    )
    tr = out["transaction_result"]
    assert tr["success"] is True
    assert tr["operation"] == "TRANSACTION_HISTORY_MULTI"
    types = {a["account_type"] for a in tr["accounts"]}
    assert types == {"401K", "TRADITIONAL_IRA", "BROKERAGE"}


def test_unknown_account_type_error(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {"account_type": _acct_type("ROTH_IRA")},
        account_context=_multi_ctx(),
        auth_token="tok",
        last_user_message="show my roth",
    )
    assert out["transaction_result"]["success"] is False


def test_frozen_account_error(txn_tool_api):  # noqa: ARG001
    tool = TransactionHistoryTool()
    out = tool.execute(
        {"account_type": _acct_type("401K")},
        account_context={
            "accounts": {
                "401K": {
                    "account_number": FROZEN_ACCOUNT.account_number,
                    "account_type": "401K",
                },
            },
        },
        auth_token="tok",
        last_user_message="401k transactions",
    )
    assert out["transaction_result"]["success"] is False


def test_missing_account_returns_failure():
    api = create_mock_account_api(preload=False)
    set_account_api(api)
    try:
        tool = TransactionHistoryTool()
        out = tool.execute(
            {"account_type": _acct_type("401K")},
            account_context={
                "accounts": {
                    "401K": {"account_number": "nothing-here"},
                },
            },
            auth_token="tok",
            last_user_message="show 401k",
        )
        assert out["transaction_result"]["success"] is False
    finally:
        set_account_api(None)


def test_mock_api_invalid_range():
    api = create_mock_account_api(preload=False)
    api.seed_account(STANDARD_401K)
    with pytest.raises(ValueError):
        api.get_transaction_history(
            STANDARD_401K.account_number,
            auth_token="t",
            start_date="2099-01-01",
            end_date="2000-01-01",
        )
