"""Unit tests for tools._account_resolution account-scope NLP."""

from __future__ import annotations

from tools._account_resolution import detect_requested_account_types


def _three_accounts() -> dict:
    return dict.fromkeys(("401K", "TRADITIONAL_IRA", "BROKERAGE"))


def test_tail_all_balances_overrides_prior_ira_tokens():
    blob = (
        "show me my IRA and 401k transaction history from april 2026\n"
        "ok\n"
        "7766\n"
        "Show all my accounts balances\n"
    )
    assert detect_requested_account_types(blob, _three_accounts()) == ["ALL"]


def test_tail_all_transactions_include_history_nouns():
    blob = (
        "401k transactions last week\n"
        "show all accounts transaction history please\n"
    )
    got = detect_requested_account_types(blob, _three_accounts(), include_history_nouns=True)
    assert got == ["ALL"]


def test_negative_tail_still_lists_explicit_types_when_narrow_last_line():
    blob = (
        "all my accounts balances\n"
        "just my 401k balance now please\n"
    )
    assert detect_requested_account_types(blob, _three_accounts()) == ["401K"]


def test_tail_fresh_explicit_ignores_account_types_from_prior_turns():
    """Prior 'IRA and brokerage' must not expand a later 401k+IRA balance ask."""
    blob = (
        "show me last month balance for IRA and brokerage account\n"
        "show my 401k and IRA account balance\n"
    )
    got = detect_requested_account_types(blob, _three_accounts())
    assert got is not None
    assert set(got) == {"401K", "TRADITIONAL_IRA"}