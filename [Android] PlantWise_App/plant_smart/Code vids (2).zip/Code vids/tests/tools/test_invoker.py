"""Unit tests for ``tools.invoker.invoke_tool``.

These tests pin the cross-cutting contract that the invoker enforces on
behalf of every transactional tool:

  * empty validated_entities raises RuntimeError (unless the tool opts in)
  * the tool's execute() receives validated_entities, account_context, auth_token
  * optional context kwargs (last_user_message, current_turn) are forwarded
    only when the tool's signature declares them
  * stable idempotency keys are injected into tool_exec
  * completed-intent IDs are appended only when transaction_result.status
    == "COMPLETED"
  * ``BaseTool.run(state)`` is a thin shim that delegates to invoke_tool
"""

from __future__ import annotations

import inspect
from typing import ClassVar
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from schemas.enums import EntityType, ToolExecutionStatus
from schemas.primitives import EntityRecord, ToolExecutionState
from schemas.enums import AuthLevel
from tools.base import BaseTool
from tools.invoker import _stable_idempotency_key, invoke_tool


# ---------------------------------------------------------------------------
# Fake tool helpers
# ---------------------------------------------------------------------------


class _RecordingTool(BaseTool):
    """Test double that records its execute() call args and returns a
    configurable result."""

    name: ClassVar[str] = "fake_tool"
    version: ClassVar[str] = "1.0.0"
    description: ClassVar[str] = "Test recording tool."
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.SESSION
    requires_hitl: ClassVar[bool] = False
    allow_empty_validated_entities: ClassVar[bool] = False

    def __init__(self, return_value: dict | None = None) -> None:
        super().__init__()
        self.return_value = return_value if return_value is not None else {}
        self.last_call: dict | None = None

    def execute(self, validated_entities, account_context, auth_token) -> dict:
        self.last_call = {
            "validated_entities": validated_entities,
            "account_context": account_context,
            "auth_token": auth_token,
        }
        return dict(self.return_value)

    def health_check(self) -> bool:
        return True


class _ContextAwareTool(_RecordingTool):
    """Tool whose ``execute`` declares the optional context kwargs."""

    name: ClassVar[str] = "ctx_tool"

    def execute(  # type: ignore[override]
        self,
        validated_entities,
        account_context,
        auth_token,
        last_user_message: str = "",
        current_turn: int = 0,
    ) -> dict:
        self.last_call = {
            "validated_entities": validated_entities,
            "account_context": account_context,
            "auth_token": auth_token,
            "last_user_message": last_user_message,
            "current_turn": current_turn,
        }
        return dict(self.return_value)


class _AllowEmptyTool(_RecordingTool):
    name: ClassVar[str] = "allow_empty_tool"
    allow_empty_validated_entities: ClassVar[bool] = True


@pytest.fixture
def install_tool(monkeypatch):
    """Install a fake tool into the TOOL_REGISTRY for the duration of a test."""

    def _install(tool: BaseTool) -> BaseTool:
        from tools import registry as registry_module

        # Patch a fresh dict so other tests are unaffected
        new_registry = dict(registry_module.TOOL_REGISTRY)
        new_registry[tool.name] = tool
        monkeypatch.setattr(registry_module, "TOOL_REGISTRY", new_registry)
        return tool

    return _install


def _entity(value: str = "401K") -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_TYPE,
        is_pii=False,
        display_value=value,
        confidence=1.0,
    )


def _exec_state() -> ToolExecutionState:
    return ToolExecutionState(
        in_flight=True,
        status=ToolExecutionStatus.SUCCEEDED,
        idempotency_key="ORIGINAL_RANDOM_KEY",
    )


# ---------------------------------------------------------------------------
# Gate enforcement
# ---------------------------------------------------------------------------


def test_invoke_tool_raises_on_empty_validated_entities(install_tool):
    install_tool(_RecordingTool())
    state = {"validated_entities": {}}
    with pytest.raises(RuntimeError, match="empty validated_entities"):
        invoke_tool("fake_tool", state)


def test_invoke_tool_allows_empty_when_tool_opts_in(install_tool):
    tool = install_tool(_AllowEmptyTool(return_value={"transaction_result": {}}))
    invoke_tool("allow_empty_tool", {"validated_entities": {}})
    assert tool.last_call is not None
    assert tool.last_call["validated_entities"] == {}


def test_invoke_tool_unknown_name_raises(install_tool):
    install_tool(_RecordingTool())
    with pytest.raises(RuntimeError, match="unknown tool 'does_not_exist'"):
        invoke_tool("does_not_exist", {"validated_entities": {"x": _entity()}})


# ---------------------------------------------------------------------------
# Argument plumbing
# ---------------------------------------------------------------------------


def test_invoke_tool_forwards_core_inputs(install_tool):
    tool = install_tool(_RecordingTool())
    entity = _entity("401K")
    state = {
        "validated_entities": {"account_type": entity},
        "account_context": {"primary_account_number": "tok_acc_1"},
        "auth_token": "TOKEN_42",
    }
    invoke_tool("fake_tool", state)
    assert tool.last_call == {
        "validated_entities": {"account_type": entity},
        "account_context": {"primary_account_number": "tok_acc_1"},
        "auth_token": "TOKEN_42",
    }


def test_invoke_tool_forwards_optional_context_kwargs_when_declared(install_tool):
    tool = install_tool(_ContextAwareTool())
    state = {
        "validated_entities": {"account_type": _entity()},
        "last_user_message": "what's my balance",
        "current_turn": 7,
    }
    invoke_tool("ctx_tool", state)
    assert tool.last_call is not None
    assert tool.last_call["last_user_message"] == "what's my balance"
    assert tool.last_call["current_turn"] == 7


def test_invoke_tool_skips_optional_kwargs_when_not_declared(install_tool):
    tool = install_tool(_RecordingTool())
    state = {
        "validated_entities": {"account_type": _entity()},
        "last_user_message": "ignored",
        "current_turn": 3,
    }
    # Must not raise even though state contains the optional fields
    invoke_tool("fake_tool", state)
    assert tool.last_call is not None
    assert "last_user_message" not in tool.last_call
    assert "current_turn" not in tool.last_call


# ---------------------------------------------------------------------------
# Idempotency key injection
# ---------------------------------------------------------------------------


def test_invoke_tool_injects_stable_idempotency_key(install_tool):
    install_tool(_RecordingTool(return_value={"tool_exec": _exec_state()}))
    intent = MagicMock()
    intent.intent_id = "intent-abc"
    state = {
        "validated_entities": {"account_type": _entity()},
        "conversation_id": "conv-1",
        "current_turn": 5,
        "intent_stack": [intent],
    }
    result = invoke_tool("fake_tool", state)
    expected = _stable_idempotency_key("conv-1", 5, "intent-abc", "fake_tool")
    assert result["tool_exec"].idempotency_key == expected


def test_invoke_tool_idempotency_key_is_deterministic_across_retries(install_tool):
    install_tool(_RecordingTool(return_value={"tool_exec": _exec_state()}))
    intent = MagicMock()
    intent.intent_id = "intent-abc"
    state = {
        "validated_entities": {"account_type": _entity()},
        "conversation_id": "conv-1",
        "current_turn": 5,
        "intent_stack": [intent],
    }
    first = invoke_tool("fake_tool", state)
    second = invoke_tool("fake_tool", state)
    assert (
        first["tool_exec"].idempotency_key
        == second["tool_exec"].idempotency_key
    )


def test_invoke_tool_skips_idempotency_when_no_tool_exec(install_tool):
    install_tool(_RecordingTool(return_value={"transaction_result": {"status": "FAILED"}}))
    state = {"validated_entities": {"account_type": _entity()}}
    result = invoke_tool("fake_tool", state)
    assert "tool_exec" not in result


# ---------------------------------------------------------------------------
# Completed-intent bookkeeping
# ---------------------------------------------------------------------------


def test_invoke_tool_marks_completed_intent(install_tool):
    install_tool(
        _RecordingTool(
            return_value={"transaction_result": {"status": "COMPLETED"}},
        )
    )
    intent = MagicMock()
    intent.intent_id = "intent-completed"
    state = {
        "validated_entities": {"account_type": _entity()},
        "intent_stack": [intent],
        "completed_intent_ids": ["earlier-intent"],
    }
    result = invoke_tool("fake_tool", state)
    assert result["completed_intent_ids"] == ["earlier-intent", "intent-completed"]


def test_invoke_tool_does_not_remark_already_completed(install_tool):
    install_tool(
        _RecordingTool(
            return_value={"transaction_result": {"status": "COMPLETED"}},
        )
    )
    intent = MagicMock()
    intent.intent_id = "intent-completed"
    state = {
        "validated_entities": {"account_type": _entity()},
        "intent_stack": [intent],
        "completed_intent_ids": ["intent-completed"],
    }
    result = invoke_tool("fake_tool", state)
    assert result["completed_intent_ids"] == ["intent-completed"]


def test_invoke_tool_does_not_mark_failed_intent(install_tool):
    install_tool(
        _RecordingTool(
            return_value={"transaction_result": {"status": "FAILED"}},
        )
    )
    intent = MagicMock()
    intent.intent_id = "intent-failed"
    state = {
        "validated_entities": {"account_type": _entity()},
        "intent_stack": [intent],
    }
    result = invoke_tool("fake_tool", state)
    assert "completed_intent_ids" not in result


# ---------------------------------------------------------------------------
# BaseTool.run() shim
# ---------------------------------------------------------------------------


def test_base_tool_run_delegates_to_invoke_tool(install_tool):
    tool = install_tool(_RecordingTool(return_value={"transaction_result": {"ok": True}}))
    state = {
        "validated_entities": {"account_type": _entity()},
        "account_context": {"x": 1},
        "auth_token": "T",
    }
    result = tool.run(state)
    assert result == {"transaction_result": {"ok": True}}
    assert tool.last_call is not None
    assert tool.last_call["account_context"] == {"x": 1}


def test_base_tool_run_signature_is_thin(monkeypatch):
    """``BaseTool.run`` should be a one-liner around invoke_tool."""
    src = inspect.getsource(BaseTool.run).strip().splitlines()
    body = [ln for ln in src if "invoke_tool" in ln]
    assert body, "BaseTool.run must delegate to invoke_tool"


# ---------------------------------------------------------------------------
# _stable_idempotency_key direct unit
# ---------------------------------------------------------------------------


def test_stable_idempotency_key_is_pure_function():
    a = _stable_idempotency_key("conv", 1, "intent", "tool")
    b = _stable_idempotency_key("conv", 1, "intent", "tool")
    c = _stable_idempotency_key("conv", 2, "intent", "tool")
    assert a == b
    assert a != c


def test_stable_idempotency_key_handles_none_inputs():
    # Should not raise on None conversation_id or intent_id
    key = _stable_idempotency_key(None, 0, None, "tool")
    assert isinstance(key, str) and len(key) == 64  # sha256 hex
