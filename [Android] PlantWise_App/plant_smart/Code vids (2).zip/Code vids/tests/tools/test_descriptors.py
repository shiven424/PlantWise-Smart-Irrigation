"""Unit tests for tool descriptor declarations and invoker auth-level
enforcement.

These tests pin two complementary contracts:

  * Every concrete tool in TOOL_REGISTRY declares the required descriptor
    fields (`description`, `required_auth_level`, `requires_hitl`) with
    sensible values.
  * The invoker enforces ``required_auth_level`` against
    ``state["auth_state"].current_level`` as a defense-in-depth gate.
"""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from schemas.enums import AuthLevel, EntityType
from schemas.primitives import AuthState, EntityRecord
from tools.base import BaseTool
from tools.invoker import invoke_tool
from tools.registry import TOOL_REGISTRY


# ---------------------------------------------------------------------------
# Per-tool descriptor declarations
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("tool_name", sorted(TOOL_REGISTRY))
def test_tool_declares_non_empty_description(tool_name: str) -> None:
    tool = TOOL_REGISTRY[tool_name]
    assert isinstance(tool.description, str)
    assert tool.description.strip(), (
        f"{tool_name}: description must be a non-empty string"
    )


@pytest.mark.parametrize("tool_name", sorted(TOOL_REGISTRY))
def test_tool_declares_auth_level(tool_name: str) -> None:
    tool = TOOL_REGISTRY[tool_name]
    assert isinstance(tool.required_auth_level, AuthLevel), (
        f"{tool_name}: required_auth_level must be AuthLevel enum"
    )


@pytest.mark.parametrize("tool_name", sorted(TOOL_REGISTRY))
def test_tool_declares_requires_hitl_bool(tool_name: str) -> None:
    tool = TOOL_REGISTRY[tool_name]
    assert isinstance(tool.requires_hitl, bool), (
        f"{tool_name}: requires_hitl must be bool"
    )


def test_known_write_tools_require_hitl() -> None:
    """Write/transactional tools must advertise that they need HITL."""
    write_tools = {"plan_loan"}
    for name in write_tools:
        assert TOOL_REGISTRY[name].requires_hitl is True, (
            f"{name} writes state -> must declare requires_hitl=True"
        )


def test_known_readonly_tools_do_not_require_hitl() -> None:
    """Pure read/calculation tools should not advertise HITL."""
    readonly = {"balance_inquiry", "rmd_calculator"}
    for name in readonly:
        assert TOOL_REGISTRY[name].requires_hitl is False, (
            f"{name} is read-only -> requires_hitl should be False"
        )


# ---------------------------------------------------------------------------
# Concrete-class declaration enforcement
# ---------------------------------------------------------------------------


def test_concrete_tool_missing_description_raises() -> None:
    with pytest.raises(TypeError, match="non-empty `description`"):
        class _BadTool(BaseTool):  # noqa: F841
            name: ClassVar[str] = "bad_tool"
            version: ClassVar[str] = "1.0.0"
            # description intentionally omitted
            required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
            requires_hitl: ClassVar[bool] = False

            def execute(self, validated_entities, account_context, auth_token):
                return {}

            def health_check(self) -> bool:
                return True


def test_concrete_tool_wrong_auth_level_type_raises() -> None:
    with pytest.raises(TypeError, match="required_auth_level"):
        class _BadTool(BaseTool):  # noqa: F841
            name: ClassVar[str] = "bad_tool2"
            version: ClassVar[str] = "1.0.0"
            description: ClassVar[str] = "x"
            required_auth_level: ClassVar = "STRONG"  # type: ignore[assignment]
            requires_hitl: ClassVar[bool] = False

            def execute(self, validated_entities, account_context, auth_token):
                return {}

            def health_check(self) -> bool:
                return True


# ---------------------------------------------------------------------------
# Invoker auth-level gate
# ---------------------------------------------------------------------------


class _StrongAuthTool(BaseTool):
    name: ClassVar[str] = "strong_auth_tool"
    version: ClassVar[str] = "1.0.0"
    description: ClassVar[str] = "Test tool requiring STRONG auth."
    required_auth_level: ClassVar[AuthLevel] = AuthLevel.STRONG
    requires_hitl: ClassVar[bool] = False

    def execute(self, validated_entities, account_context, auth_token):
        return {"transaction_result": {"status": "OK"}}

    def health_check(self) -> bool:
        return True


@pytest.fixture
def install_tool(monkeypatch):
    def _install(tool: BaseTool) -> BaseTool:
        from tools import registry as registry_module

        new_registry = dict(registry_module.TOOL_REGISTRY)
        new_registry[tool.name] = tool
        monkeypatch.setattr(registry_module, "TOOL_REGISTRY", new_registry)
        return tool

    return _install


def _entity() -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_TYPE,
        is_pii=False,
        display_value="401K",
        confidence=1.0,
    )


def test_invoker_blocks_when_auth_level_below_required(install_tool):
    install_tool(_StrongAuthTool())
    state = {
        "validated_entities": {"account_type": _entity()},
        "auth_state": AuthState(current_level=AuthLevel.SESSION),
    }
    with pytest.raises(RuntimeError, match="requires auth level STRONG"):
        invoke_tool("strong_auth_tool", state)


def test_invoker_allows_when_auth_level_meets_required(install_tool):
    install_tool(_StrongAuthTool())
    state = {
        "validated_entities": {"account_type": _entity()},
        "auth_state": AuthState(current_level=AuthLevel.STRONG),
    }
    result = invoke_tool("strong_auth_tool", state)
    assert result == {"transaction_result": {"status": "OK"}}


def test_invoker_allows_when_auth_level_exceeds_required(install_tool):
    install_tool(_StrongAuthTool())
    state = {
        "validated_entities": {"account_type": _entity()},
        "auth_state": AuthState(current_level=AuthLevel.ENHANCED),
    }
    result = invoke_tool("strong_auth_tool", state)
    assert result == {"transaction_result": {"status": "OK"}}


def test_invoker_skips_auth_check_when_state_has_no_auth_state(install_tool):
    """If state lacks auth_state, invoker skips the auth gate (relying on
    the supervisor's H3 hard rule).  This mirrors how unit tests construct
    minimal states."""
    install_tool(_StrongAuthTool())
    state = {"validated_entities": {"account_type": _entity()}}
    result = invoke_tool("strong_auth_tool", state)
    assert result == {"transaction_result": {"status": "OK"}}
