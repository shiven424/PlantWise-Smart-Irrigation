"""Tests for the HS256 JWT helpers."""

from __future__ import annotations

import time

import jwt
import pytest

from auth import jwt_utils
from config import settings


@pytest.fixture(autouse=True)
def _set_secret(monkeypatch):
    monkeypatch.setattr(settings, "auth_jwt_secret", "test-secret-1234567890-padding-x" * 2)
    # Reset module-level cache too.
    monkeypatch.setattr(jwt_utils, "_runtime_secret", None)


def test_round_trip() -> None:
    token, ttl = jwt_utils.issue_token("alice")
    assert ttl > 0
    assert jwt_utils.decode_token(token) == "alice"


def test_decode_rejects_expired() -> None:
    token, _ = jwt_utils.issue_token("alice", ttl_seconds=1)
    time.sleep(1.2)
    with pytest.raises(jwt_utils.InvalidTokenError):
        jwt_utils.decode_token(token)


def test_decode_rejects_bad_signature() -> None:
    bad = jwt.encode({"sub": "alice", "exp": int(time.time()) + 60},
                     "different-secret-different-different-padding", algorithm="HS256")
    with pytest.raises(jwt_utils.InvalidTokenError):
        jwt_utils.decode_token(bad)


def test_decode_rejects_missing_sub() -> None:
    bad = jwt.encode({"exp": int(time.time()) + 60},
                     "test-secret-1234567890-padding-x" * 2, algorithm="HS256")
    with pytest.raises(jwt_utils.InvalidTokenError):
        jwt_utils.decode_token(bad)


def test_decode_rejects_garbage() -> None:
    with pytest.raises(jwt_utils.InvalidTokenError):
        jwt_utils.decode_token("not-a-token")


def test_autogen_secret_when_unset(monkeypatch) -> None:
    monkeypatch.setattr(settings, "auth_jwt_secret", "")
    monkeypatch.setattr(jwt_utils, "_runtime_secret", None)
    token, _ = jwt_utils.issue_token("bob")
    # Same process can decode using the cached ephemeral secret.
    assert jwt_utils.decode_token(token) == "bob"
