"""Tests for the in-memory AuthSecretsProvider + OtpChannel."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest

from agents.auth_agent.v1.evaluator import hash_answer
from auth.providers.memory import MemoryAuthSecretsProvider, MemoryOtpChannel
from schemas.enums import ChallengeType

FIXTURE = Path(__file__).parent.parent / "fixtures" / "auth_accounts.json"


@pytest.fixture
def provider() -> MemoryAuthSecretsProvider:
    return MemoryAuthSecretsProvider(FIXTURE)


def test_loads_fixture(provider: MemoryAuthSecretsProvider) -> None:
    h = provider.get_expected_hash("test-user-good", ChallengeType.ZIP_CODE)
    assert h is not None and len(h) == 64


def test_hash_matches_evaluator(provider: MemoryAuthSecretsProvider) -> None:
    expected = hash_answer("ZIP_CODE", "94107")
    assert provider.get_expected_hash("test-user-good", ChallengeType.ZIP_CODE) == expected


def test_unknown_user_returns_none(provider: MemoryAuthSecretsProvider) -> None:
    assert provider.get_expected_hash("nope", ChallengeType.ZIP_CODE) is None


def test_unknown_challenge_returns_none(provider: MemoryAuthSecretsProvider) -> None:
    assert provider.get_expected_hash("test-user-good", ChallengeType.MOTHER_MAIDEN) is None


def test_empty_secrets_returns_none(provider: MemoryAuthSecretsProvider) -> None:
    assert provider.get_expected_hash("test-user-empty", ChallengeType.ZIP_CODE) is None


def test_verify_password_ok(provider: MemoryAuthSecretsProvider) -> None:
    assert provider.verify_password("good", "pw") == "test-user-good"


def test_verify_password_case_insensitive_username(
    provider: MemoryAuthSecretsProvider,
) -> None:
    assert provider.verify_password("GOOD", "pw") == "test-user-good"


def test_verify_password_wrong_password(
    provider: MemoryAuthSecretsProvider,
) -> None:
    assert provider.verify_password("good", "WRONG") is None


def test_verify_password_unknown_user(
    provider: MemoryAuthSecretsProvider,
) -> None:
    assert provider.verify_password("nobody", "pw") is None


def test_get_account_context(provider: MemoryAuthSecretsProvider) -> None:
    ctx = provider.get_account_context("test-user-good")
    assert ctx and ctx["plan_type"] == "401K"


def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        MemoryAuthSecretsProvider(tmp_path / "missing.json")


def test_otp_issue_format() -> None:
    ch = MemoryOtpChannel(ttl_seconds=10)
    code, ttl = ch.issue_otp("u1")
    assert len(code) == 6 and code.isdigit() and ttl == 10


def test_otp_get_last() -> None:
    ch = MemoryOtpChannel(ttl_seconds=10)
    code, _ = ch.issue_otp("u1")
    last = ch.get_last_otp_for_demo("u1")
    assert last is not None
    assert last[0] == code
    assert isinstance(last[1], datetime)


def test_otp_get_last_unknown_user() -> None:
    ch = MemoryOtpChannel(ttl_seconds=10)
    assert ch.get_last_otp_for_demo("nobody") is None
