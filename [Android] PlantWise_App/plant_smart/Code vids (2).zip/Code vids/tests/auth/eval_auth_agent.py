"""Multi-turn auth agent eval.

Runs the deterministic state machine through scripted scenarios and asserts
the final outcome and intermediate transitions. No LLM, no FastAPI, no
LangGraph — exercises the agent end-to-end across turns.

Gates:
  - 100% scenarios pass.
  - 0 unintended LOCKED outcomes (only scenarios marked expect_locked=True
    may end in LOCKED).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest

from agents.auth_agent.v1.agent import AuthAgent
from auth import client as auth_client
from auth.providers.memory import MemoryAuthSecretsProvider, MemoryOtpChannel
from config import settings
from schemas.enums import (
    AuthLevel,
    AuthStatus,
    EscalationReason,
)
from schemas.primitives import AuthChallenge, AuthState, SessionContext

FIXTURE = Path(__file__).parent.parent / "fixtures" / "auth_accounts.json"


# ---------------------------------------------------------------------------
# Scenario harness
# ---------------------------------------------------------------------------

@dataclass
class Scenario:
    name: str
    user_id: str
    required_level: AuthLevel
    inputs: list[str | None]            # one per turn
    expected_final_status: AuthStatus
    expected_escalation: EscalationReason | None = None
    expect_otp: bool = False
    initial_auth_state: AuthState | None = None
    user_profile: dict[str, Any] = field(default_factory=dict)
    fraud_risk_score: float = 0.0
    device_fingerprint: str | None = None


def _run_scenario(s: Scenario) -> dict[str, Any]:
    agent = AuthAgent()
    auth_state = s.initial_auth_state or AuthState()
    pending_dict: dict[str, Any] = {}
    last_out: dict[str, Any] = {}

    for turn_idx, raw in enumerate(s.inputs):
        # OTP scenarios: substitute the special token "<otp>" with the
        # current code from the demo channel.
        verification_input: str | None = raw
        if raw == "<otp>":
            last = auth_client.otp_channel().get_last_otp_for_demo(s.user_id)
            assert last is not None, f"{s.name}: OTP requested but none issued"
            verification_input = last[0]

        state: dict[str, Any] = {
            "session": SessionContext(
                session_id=uuid.uuid4(),
                user_id=s.user_id,
                channel="web",
                started_at=datetime.now(timezone.utc),
            ),
            "auth_state": auth_state,
            "required_auth_level": s.required_level,
            "scratch": (
                {"pending_auth_challenge": pending_dict} if pending_dict else {}
            ),
            "verification_input": verification_input,
            "fraud_risk_score": s.fraud_risk_score,
            "device_fingerprint": s.device_fingerprint,
            "user_profile": s.user_profile,
            "message_history": [],
        }

        out = agent.run(state)
        last_out = out

        # Carry forward the post-turn auth_state and pending challenge.
        auth_state = out["auth_state"]
        scratch = out.get("scratch") or {}
        pending_dict = scratch.get("pending_auth_challenge") or {}

        # Stop early on terminal states.
        if out["auth_status"] in (AuthStatus.VERIFIED, AuthStatus.LOCKED):
            break

    return last_out


SCENARIOS: list[Scenario] = [
    Scenario(
        name="happy_zip_one_turn",
        user_id="test-user-good",
        required_level=AuthLevel.SOFT,
        inputs=[None, "94107"],
        expected_final_status=AuthStatus.VERIFIED,
    ),
    Scenario(
        name="happy_ssn_strong",
        user_id="test-user-good",
        required_level=AuthLevel.STRONG,
        inputs=[None, "4321"],
        expected_final_status=AuthStatus.VERIFIED,
    ),
    Scenario(
        name="happy_dob_strong_alt_format",
        user_id="test-user-good",
        required_level=AuthLevel.STRONG,
        # First turn issues SSN; user enters wrong, then we re-issue and
        # recover — exercises retry path.
        inputs=[None, "0000", "4321"],
        expected_final_status=AuthStatus.VERIFIED,
    ),
    Scenario(
        name="otp_enhanced",
        user_id="test-user-good",
        required_level=AuthLevel.ENHANCED,
        inputs=[None, "<otp>"],
        expected_final_status=AuthStatus.VERIFIED,
        expect_otp=True,
    ),
    Scenario(
        name="lockout_three_wrong_zip",
        user_id="test-user-good",
        required_level=AuthLevel.SOFT,
        inputs=[None, "00000", "11111", "22222"],
        expected_final_status=AuthStatus.LOCKED,
        expected_escalation=EscalationReason.AUTH_LOCKED,
    ),
    Scenario(
        name="missing_secrets_immediate_lock",
        user_id="test-user-empty",
        required_level=AuthLevel.SOFT,
        inputs=[None],
        expected_final_status=AuthStatus.LOCKED,
        expected_escalation=EscalationReason.AUTH_MISCONFIGURED,
    ),
    Scenario(
        name="session_level_no_challenge",
        user_id="test-user-good",
        required_level=AuthLevel.SESSION,
        inputs=[None],
        expected_final_status=AuthStatus.VERIFIED,
    ),
    Scenario(
        name="expedited_recent_verify",
        user_id="test-user-good",
        required_level=AuthLevel.SOFT,
        inputs=[None],
        expected_final_status=AuthStatus.VERIFIED,
        user_profile={
            "last_verified_at":
                (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat(),
            "last_verified_level": "SOFT",
        },
    ),
    Scenario(
        name="expedited_blocked_by_fraud",
        user_id="test-user-good",
        required_level=AuthLevel.SOFT,
        inputs=[None, "94107"],
        expected_final_status=AuthStatus.VERIFIED,
        user_profile={
            "last_verified_at":
                (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat(),
            "last_verified_level": "SOFT",
        },
        fraud_risk_score=0.99,
    ),
    Scenario(
        name="reverify_after_ttl_expires",
        user_id="test-user-good",
        required_level=AuthLevel.STRONG,
        inputs=[None, "4321"],
        expected_final_status=AuthStatus.VERIFIED,
        initial_auth_state=AuthState(
            current_level=AuthLevel.STRONG,
            verified_at=datetime.now(timezone.utc) - timedelta(hours=24),
        ),
    ),
]


@pytest.fixture(autouse=True)
def _seed_providers(monkeypatch):
    sp = MemoryAuthSecretsProvider(FIXTURE)
    oc = MemoryOtpChannel(ttl_seconds=settings.auth_otp_ttl_seconds)
    monkeypatch.setattr(auth_client, "_secrets", sp)
    monkeypatch.setattr(auth_client, "_otp", oc)
    yield
    auth_client.reset_for_tests()


@pytest.mark.parametrize("scenario", SCENARIOS, ids=lambda s: s.name)
def test_scenario(scenario: Scenario) -> None:
    out = _run_scenario(scenario)
    assert out["auth_status"] == scenario.expected_final_status, scenario.name

    if scenario.expected_escalation is not None:
        assert out.get("escalation_requested") is True
        assert out["escalation_context"].reason == scenario.expected_escalation
    elif scenario.expected_final_status != AuthStatus.LOCKED:
        # No unexpected escalations on non-LOCKED outcomes.
        assert out.get("escalation_requested") in (False, None), scenario.name


def test_no_unintended_lockouts() -> None:
    """Aggregate gate: only scenarios that explicitly expect LOCKED may LOCK."""
    expected_locked = {s.name for s in SCENARIOS
                       if s.expected_final_status == AuthStatus.LOCKED}
    actual_locked: set[str] = set()
    for s in SCENARIOS:
        out = _run_scenario(s)
        if out["auth_status"] == AuthStatus.LOCKED:
            actual_locked.add(s.name)
    assert actual_locked == expected_locked
