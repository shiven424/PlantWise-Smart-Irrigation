"""Shared pytest fixtures."""
from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

import pytest

from schemas.primitives import SessionContext


@pytest.fixture
def session() -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id="test-user",
        channel="web",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def make_state(session: SessionContext, message: str, history: list[dict] | None = None) -> dict:
    """Build a minimal GraphState-shaped dict for classifier tests."""
    msgs = list(history or [])
    msgs.append({"role": "user", "content": message})
    return {
        "session": session,
        "message_history": msgs,
        "current_turn": len(msgs),
    }


@pytest.fixture
def state_factory(session):
    def _make(message: str, history: list[dict] | None = None) -> dict:
        return make_state(session, message, history)
    return _make
