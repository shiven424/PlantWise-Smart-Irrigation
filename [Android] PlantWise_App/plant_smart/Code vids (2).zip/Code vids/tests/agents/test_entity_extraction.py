"""Comprehensive unit tests for EntityExtractionAgent.

Covers:
  * Numeric/categorical/PII extraction across EVERY canonical EntityType
  * Slot-name → entity_type recovery when LLM returns an unknown type label
  * Numeric-amount guard: amount entities without digits dropped
  * PII vault tokenisation: raw_value cleared, vault_token set
  * Old vault token cleanup on re-extraction (Fix 25)
  * Vault failure → entity dropped + escalation_requested (Fix 83)
  * Regex PII override: misclassified PII upgraded by pattern (SSN/phone/email)
  * Contradiction detection vs confirmed prior entity
  * No-op when LLM returns no entities
  * Slot-gap awareness: only required slots prioritised
  * No active intent → graceful handling
"""
from __future__ import annotations

from unittest.mock import patch
from uuid import uuid4

import pytest

from agents.entity_extraction.v1 import agent as ext_module
from agents.entity_extraction.v1.agent import (
    EntityExtractionAgent,
    _LLMEntity,
    _LLMExtractionResponse,
)
from agents.intent_agent.v1.taxonomy import lookup_intent
from schemas.enums import (
    EntityType,
    EscalationReason,
    IntentChangeType,
    PII_ENTITY_TYPES,
)
from schemas.primitives import EntityRecord, IntentRecord


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def agent() -> EntityExtractionAgent:
    return EntityExtractionAgent()


def _intent_record(sub_intent: str) -> IntentRecord:
    defn = lookup_intent(sub_intent)
    assert defn is not None
    return IntentRecord(
        intent_id=defn.intent_id,
        service_domain=defn.domain,
        sub_intent=defn.sub_intent_id,
        confidence=0.95,
        change_type=IntentChangeType.NEW,
        requires_auth_level=defn.auth_level,
        is_transactional=defn.is_transactional,
        escalation_flag=defn.escalation_flag,
        required_slots=list(defn.required_slots),
        turn_number=1,
    )


def _state(
    session,
    message: str,
    *,
    sub_intent: str | None = None,
    entity_memory: dict[str, EntityRecord] | None = None,
    last_requested_slot: str | None = None,
    current_turn: int = 1,
) -> dict:
    intent_stack: list[IntentRecord] = (
        [_intent_record(sub_intent)] if sub_intent else []
    )
    return {
        "session": session,
        "message_history": [{"role": "user", "content": message}],
        "intent_stack": intent_stack,
        "active_intent_id": intent_stack[0].intent_id if intent_stack else None,
        "entity_memory": entity_memory or {},
        "last_requested_slot": last_requested_slot,
        "current_turn": current_turn,
        "user_profile": {},
    }


def _patch_llm(*entities: _LLMEntity, contradiction_notes: list[str] | None = None):
    response = _LLMExtractionResponse(
        entities=list(entities),
        contradiction_notes=contradiction_notes or [],
    )
    return patch.object(ext_module, "call_llm", return_value=response)


def _patch_vault(token_prefix: str = "vault-tok-", fail: bool = False):
    """Patch vault_client.tokenize/delete; track calls via the returned mock."""
    class _Mock:
        tokenized: list[dict] = []
        deleted: list[str] = []

    def _tokenize(*, entity_type, raw_value, session_id):
        if fail:
            raise RuntimeError("vault offline")
        _Mock.tokenized.append({
            "entity_type": entity_type, "raw_value": raw_value, "session_id": session_id,
        })
        return f"{token_prefix}{len(_Mock.tokenized)}"

    def _delete(token):
        _Mock.deleted.append(token)
        return True

    return patch.multiple(
        ext_module.vault_client,
        tokenize=_tokenize,
        delete=_delete,
    ), _Mock


# ---------------------------------------------------------------------------
# 1. Plain numeric/categorical extraction
# ---------------------------------------------------------------------------

class TestNumericAndCategoricalExtraction:
    def test_dollar_amount_extracted(self, agent, session):
        ent = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT",
            slot_name="withdrawal_amount",
            display_value="$5000",
            raw_value="$5000",
            confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "withdraw $5000",
                                      sub_intent="WITHDRAWAL_REQUEST"))
        mem = result["entity_memory"]
        assert "withdrawal_amount" in mem
        rec = mem["withdrawal_amount"]
        assert rec.entity_type == EntityType.WITHDRAWAL_AMOUNT
        assert rec.display_value == "$5000"
        assert rec.is_pii is False
        assert rec.vault_token is None

    def test_plan_type_categorical_extracted(self, agent, session):
        ent = _LLMEntity(
            entity_type="PLAN_TYPE", slot_name="plan_type",
            display_value="401K", raw_value="401k", confidence=0.9,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "from my 401k",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        assert result["entity_memory"]["plan_type"].display_value == "401K"

    def test_skips_llm_when_no_slot_gap_preserves_prior_plan_type(
        self, agent, session,
    ):
        """REGRESSION HITL: compliance-heavy assistant text must not overwrite
        categorical slots when all required entities are already captured."""
        plan_ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.PLAN_TYPE,
            is_pii=False,
            slot_name="plan_type",
            display_value="401K",
            raw_value=None,
            confidence=0.9,
            is_confirmed=False,
        )
        amt_ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.LOAN_AMOUNT,
            is_pii=False,
            slot_name="loan_amount",
            display_value="$25,000",
            raw_value=None,
            confidence=0.9,
            is_confirmed=False,
        )
        term_ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.TERM_MONTHS,
            is_pii=False,
            slot_name="repayment_term",
            display_value="20",
            raw_value=None,
            confidence=0.9,
            is_confirmed=False,
        )
        st = _state(
            session,
            "20000",
            sub_intent="PLAN_LOAN_REQUEST",
            entity_memory={
                "plan_type": plan_ent,
                "loan_amount": amt_ent,
                "repayment_term": term_ent,
            },
        )
        st["message_history"] = [
            {"role": "user", "content": "plan a loan"},
            {
                "role": "assistant",
                "content": (
                    "Traditional IRA accounts cannot offer loans. "
                    "Your 401(k) may support participant loans under IRC 72(p)."
                ),
            },
            {"role": "user", "content": "20000"},
        ]
        st["scratch"] = {
            "suppress_ambient_entity_llm_when_slot_gap_empty": True,
        }

        with patch.object(ext_module, "call_llm") as llm_mock:
            llm_mock.side_effect = AssertionError(
                "call_llm must not run when slot_gap is empty"
            )
            result = agent.run(st)

        llm_mock.assert_not_called()
        assert result["entity_memory"] == {}
        # Suppress flag must not be cleared in the node return; graph reducer
        # keeps prior scratch True for later supervisor iterations.
        assert "scratch" not in result

    def test_skips_llm_hitl_correction_plan_autofill_empty_gap_without_plan_memory(
        self, agent, session,
    ):
        """REGRESSION POST /hitl: validator treats plan_type as filled via loan
        autofill — entity_memory may omit plan_type entirely. Memory-only gaps
        used to invoke the LLM and hallucinate PLAN_TYPE/IRA."""
        amt_ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.LOAN_AMOUNT,
            is_pii=False,
            slot_name="loan_amount",
            display_value="$20,000",
            raw_value=None,
            confidence=0.9,
            is_confirmed=False,
        )
        term_ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.TERM_MONTHS,
            is_pii=False,
            slot_name="repayment_term",
            display_value="20",
            raw_value=None,
            confidence=0.9,
            is_confirmed=False,
        )
        st = _state(
            session,
            "20000",
            sub_intent="PLAN_LOAN_REQUEST",
            entity_memory={
                "loan_amount": amt_ent,
                "repayment_term": term_ent,
            },
        )
        st["validated_entities"] = {}
        st["account_context"] = {
            "accounts": {"401K": {"plan_allows_loans": True}},
        }
        st["scratch"] = {
            "suppress_ambient_entity_llm_when_slot_gap_empty": True,
        }
        st["message_history"] = [
            {"role": "user", "content": "plan a loan"},
            {
                "role": "assistant",
                "content": (
                    "Federal withholding of 20% applies unless rolled over to "
                    "another eligible plan or IRA."
                ),
            },
            {"role": "user", "content": "20000"},
        ]

        with patch.object(ext_module, "call_llm") as llm_mock:
            llm_mock.side_effect = AssertionError(
                "must not invoke LLM; slot_gap aligns with autofilled plan_type"
            )
            result = agent.run(st)

        llm_mock.assert_not_called()
        assert result["entity_memory"] == {}
        assert "scratch" not in result

    def test_percentage_extracted(self, agent, session):
        ent = _LLMEntity(
            entity_type="WITHHOLDING_PERCENT",
            slot_name="withholding_percentage",
            display_value="10%", raw_value="10", confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "withhold 10%",
                                       sub_intent="WITHHOLDING_UPDATE"))
        rec = result["entity_memory"]["withholding_percentage"]
        assert rec.entity_type == EntityType.WITHHOLDING_PERCENT


# ---------------------------------------------------------------------------
# 2. PII vaulting
# ---------------------------------------------------------------------------

class TestPIIVaulting:
    def test_pii_value_vaulted_and_raw_cleared(self, agent, session):
        ent = _LLMEntity(
            entity_type="DATE_OF_BIRTH", slot_name="date_of_birth",
            display_value="1965-03-15", raw_value="1965-03-15",
            confidence=0.95,
        )
        patcher, vault_mock = _patch_vault()
        with patcher, _patch_llm(ent):
            result = agent.run(_state(session, "my DOB is 1965-03-15",
                                       sub_intent="RMD_CALCULATION"))

        rec = result["entity_memory"]["date_of_birth"]
        assert rec.is_pii is True
        assert rec.vault_token is not None
        assert rec.raw_value is None
        assert "escalation_requested" not in result
        # tokenize was called once
        assert len(vault_mock.tokenized) == 1
        assert vault_mock.tokenized[0]["entity_type"] == EntityType.DATE_OF_BIRTH.value

    def test_old_vault_token_cleaned_up_on_reextraction(self, agent, session):
        """Fix 25: re-extracting an entity must delete the previous token."""
        old_record = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.PHONE_NUMBER,
            is_pii=True,
            slot_name="new_phone",
            vault_token="vault-tok-OLD",
            display_value="(XXX) XXX-1111",
            confidence=0.9,
            is_confirmed=False,
        )
        new_ent = _LLMEntity(
            entity_type="PHONE_NUMBER", slot_name="new_phone",
            display_value="555-222-3333", raw_value="5552223333",
            confidence=0.95,
        )
        patcher, vault_mock = _patch_vault()
        with patcher, _patch_llm(new_ent):
            agent.run(_state(
                session, "actually 555-222-3333",
                sub_intent="PHONE_UPDATE",
                entity_memory={"new_phone": old_record},
            ))
        assert "vault-tok-OLD" in vault_mock.deleted

    def test_vault_failure_drops_entity_and_escalates(self, agent, session):
        """Fix 83: vault tokenize raising → entity dropped + escalation."""
        ent = _LLMEntity(
            entity_type="SSN", slot_name=None,
            display_value="123-45-6789", raw_value="123-45-6789",
            confidence=0.95,
        )
        patcher, _vm = _patch_vault(fail=True)
        with patcher, _patch_llm(ent):
            result = agent.run(_state(
                session, "my ssn is 123-45-6789",
                sub_intent="ADDRESS_UPDATE",
            ))
        # The PII entity must NOT enter state
        assert all(e.entity_type != EntityType.SSN
                   for e in result["entity_memory"].values())
        # And escalation must be raised
        assert result.get("escalation_requested") is True
        ec = result["escalation_context"]
        assert ec.reason == EscalationReason.SYSTEM_ERROR
        assert ec.triggered_by == "entity_extraction"


# ---------------------------------------------------------------------------
# 3. Regex PII override (defense-in-depth)
# ---------------------------------------------------------------------------

class TestPIIRegexOverride:
    @pytest.mark.parametrize("raw,description", [
        ("123-45-6789", "SSN formatted"),
        ("123456789", "SSN plain 9 digits"),
        ("555-123-4567", "phone formatted"),
        ("5551234567", "phone plain"),
        ("john@example.com", "email"),
    ])
    def test_misclassified_pii_upgraded_via_regex(self, agent, session, raw, description):
        """LLM tags PII as a non-PII type → regex must upgrade is_pii=True."""
        # Use FUND_NAME (free-text, non-categorical) so the categorical-from-
        # digits guard doesn't drop the entity before the PII regex runs.
        ent = _LLMEntity(
            entity_type="FUND_NAME",  # WRONG type — not PII, not categorical
            slot_name="fund_name",
            display_value=raw, raw_value=raw, confidence=0.9,
        )
        patcher, _vm = _patch_vault()
        with patcher, _patch_llm(ent):
            result = agent.run(_state(
                session, raw, sub_intent="WITHDRAWAL_REQUEST",
            ))
        rec = list(result["entity_memory"].values())[0]
        assert rec.is_pii is True, f"{description} should be flagged as PII"
        assert rec.vault_token is not None
        assert rec.raw_value is None


# ---------------------------------------------------------------------------
# 4. Slot-name → entity_type recovery
# ---------------------------------------------------------------------------

class TestUnknownTypeRecovery:
    def test_bad_entity_type_recovered_from_slot_name(self, agent, session):
        """LLM returns a category label as entity_type but a valid slot_name."""
        ent = _LLMEntity(
            entity_type="Financial",  # not a real EntityType
            slot_name="plan_type",
            display_value="401K", raw_value="401k", confidence=0.9,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "401k",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        # Entity recovered via slot-name lookup
        assert "plan_type" in result["entity_memory"]
        rec = result["entity_memory"]["plan_type"]
        assert rec.entity_type == EntityType.PLAN_TYPE

    def test_bad_entity_type_no_slot_name_dropped(self, agent, session):
        ent = _LLMEntity(
            entity_type="Financial", slot_name=None,
            display_value="something", raw_value="something",
            confidence=0.9,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "huh",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        assert result["entity_memory"] == {}


# ---------------------------------------------------------------------------
# 5. Numeric-amount guard
# ---------------------------------------------------------------------------

class TestAmountWithoutDigitsDropped:
    @pytest.mark.parametrize("etype,slot", [
        ("WITHDRAWAL_AMOUNT", "withdrawal_amount"),
        ("ROLLOVER_AMOUNT", "rollover_amount"),
        ("LOAN_AMOUNT", "loan_amount"),
        ("CONTRIBUTION_AMOUNT", "contribution_amount"),
        ("PERCENTAGE", "withholding_percentage"),
        ("WITHHOLDING_PERCENT", "withholding_percentage"),
        ("DOLLAR_AMOUNT", None),
    ])
    def test_amount_entity_without_digits_dropped(self, agent, session, etype, slot):
        ent = _LLMEntity(
            entity_type=etype, slot_name=slot,
            display_value="some money", raw_value="money",
            confidence=0.8,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "withdraw money",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        assert result["entity_memory"] == {}

    def test_amount_with_digits_kept(self, agent, session):
        ent = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT", slot_name="withdrawal_amount",
            display_value="$5,000", raw_value="5000",
            confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "five thousand dollars",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        assert "withdrawal_amount" in result["entity_memory"]


# ---------------------------------------------------------------------------
# 6. Contradiction detection
# ---------------------------------------------------------------------------

class TestContradictionDetection:
    def test_contradicts_confirmed_prior_value(self, agent, session):
        old = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.WITHDRAWAL_AMOUNT,
            is_pii=False,
            slot_name="withdrawal_amount",
            display_value="$10,000",
            confidence=0.95,
            is_confirmed=True,  # confirmed prior value
            turn_confirmed=2,
        )
        ent = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT", slot_name="withdrawal_amount",
            display_value="$15,000", raw_value="15000", confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(
                session, "actually $15000",
                sub_intent="WITHDRAWAL_REQUEST",
                entity_memory={"withdrawal_amount": old},
            ))
        rec = result["entity_memory"]["withdrawal_amount"]
        assert rec.contradicts == old.entity_id
        assert rec.is_confirmed is False
        assert str(old.entity_id) in result["contradictions"]

    def test_no_contradiction_against_unconfirmed_prior(self, agent, session):
        """Replacing a not-yet-confirmed value is NOT a contradiction."""
        old = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.WITHDRAWAL_AMOUNT,
            is_pii=False,
            slot_name="withdrawal_amount",
            display_value="$10,000",
            confidence=0.7,
            is_confirmed=False,
        )
        ent = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT", slot_name="withdrawal_amount",
            display_value="$15,000", raw_value="15000", confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(
                session, "$15000", sub_intent="WITHDRAWAL_REQUEST",
                entity_memory={"withdrawal_amount": old},
            ))
        rec = result["entity_memory"]["withdrawal_amount"]
        assert rec.contradicts is None
        assert result["contradictions"] == []


# ---------------------------------------------------------------------------
# 7. Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_no_entities_returned(self, agent, session):
        with _patch_llm():  # zero entities
            result = agent.run(_state(session, "hello",
                                       sub_intent="WITHDRAWAL_REQUEST"))
        assert result["entity_memory"] == {}
        assert result["contradictions"] == []

    def test_no_active_intent(self, agent, session):
        ent = _LLMEntity(
            entity_type="DOLLAR_AMOUNT", slot_name=None,
            ambient_key="amount",
            display_value="$1000", raw_value="1000", confidence=0.9,
        )
        with _patch_llm(ent):
            result = agent.run(_state(session, "$1000"))  # no sub_intent
        # Stored under ambient_key since no slot
        assert "amount" in result["entity_memory"]

    def test_multiple_entities_in_one_message(self, agent, session):
        e1 = _LLMEntity(
            entity_type="PLAN_TYPE", slot_name="plan_type",
            display_value="401K", raw_value="401k", confidence=0.9,
        )
        e2 = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT", slot_name="withdrawal_amount",
            display_value="$5000", raw_value="5000", confidence=0.95,
        )
        e3 = _LLMEntity(
            entity_type="DISTRIBUTION_TYPE", slot_name="distribution_type",
            display_value="NORMAL", raw_value="normal", confidence=0.9,
        )
        with _patch_llm(e1, e2, e3):
            result = agent.run(_state(
                session, "withdraw $5000 from my 401k normal distribution",
                sub_intent="WITHDRAWAL_REQUEST",
            ))
        mem = result["entity_memory"]
        assert {"plan_type", "withdrawal_amount", "distribution_type"} <= set(mem.keys())

    def test_existing_entities_preserved_in_partial_state(self, agent, session):
        """Agent returns ONLY new entities — supervisor merges with existing."""
        old = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.PLAN_TYPE,
            is_pii=False,
            slot_name="plan_type",
            display_value="401K",
            confidence=0.95,
            is_confirmed=True,
        )
        ent = _LLMEntity(
            entity_type="WITHDRAWAL_AMOUNT", slot_name="withdrawal_amount",
            display_value="$5000", raw_value="5000", confidence=0.95,
        )
        with _patch_llm(ent):
            result = agent.run(_state(
                session, "$5000", sub_intent="WITHDRAWAL_REQUEST",
                entity_memory={"plan_type": old},
            ))
        # Result returns NEW entities only — existing slot not duplicated.
        assert "withdrawal_amount" in result["entity_memory"]
        # plan_type should NOT appear in the returned delta (existing already)
        assert "plan_type" not in result["entity_memory"]


# ---------------------------------------------------------------------------
# 8. Health check
# ---------------------------------------------------------------------------

class TestHealthCheck:
    def test_health_check_returns_bool(self, agent):
        assert isinstance(agent.health_check(), bool)
