"""
Exhaustive *integration* scenarios for the BalanceInquiryTool.

Unlike ``test_balance_inquiry_multi_account.py`` (which focuses on
slot-gap and account selection), this file walks through **every
realistic runtime path** the agent can take when invoked with a fully
prepared GraphState — covering:

  Account resolution
    - Single-account auto-select
    - Multi-account explicit type (canonical key)
    - Alias resolution: "IRA", "Roth", "401(k)", "401-K", "401k"
                        "Brokerage Account", "Taxable", whitespace,
                        lowercase, mixed case
    - Disambiguation: bare "ROTH" with both ROTH_IRA + ROTH_401K
    - Unknown / not-owned account_type
    - Vault-tokenised account_number takes priority over account_type
    - Legacy flat ``account_context`` shape
    - Empty accounts map fails cleanly
    - Missing both account_number and accounts map fails cleanly

  API behaviour & error paths
    - Frozen account     -> failure with escalate=True
    - Inactive account   -> failure with escalate=True
    - Account not found  -> failure with escalate=True
    - Missing auth_token -> AuthorizationError -> escalate=True
    - Vault dereference KeyError -> failure (no escalate)
    - Vault dereference PermissionError -> failure

  Derived value computation
    - vested_percentage rounded to 1dp
    - vested clamped when API returns vested > total
    - employer_match_remaining clamped to 0 when ytd > max
    - account_display always last-4 of *raw* number
    - as_of populated (preserved from API or now())
    - Zero-balance account renders 0% vested without ZeroDivisionError

  Result schema
    - ToolExecutionState.status SUCCEEDED on success / FAILED on failure
    - tool_exec.in_flight is False
    - transaction_result has every documented field
    - account_type echoed from entity (preferred) or API

  Concurrency / isolation
    - Module-level singleton replaced by set_account_api()
    - Independent calls do not leak vested values across users

These tests exercise the **agent in isolation** (no LLM, no graph)
but assert the full integration contract that the LangGraph router and
synthesizer rely on.
"""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

import pytest

from schemas.enums import EntityType, ToolExecutionStatus
from schemas.primitives import EntityRecord
from tools.balance_inquiry.v1.agent import BalanceInquiryTool, set_account_api
from tests.mocks.account_api import (
    AccountFrozenError,
    AccountNotFoundError,
    AccountRecord,
    AuthorizationError,
    MockAccountAPI,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _record(
    account_number: str,
    account_type: str = "401K",
    *,
    total: float = 100_000.0,
    vested: float = 90_000.0,
    unvested: float = 10_000.0,
    ytd_contrib: float = 5_000.0,
    ytd_match: float = 2_000.0,
    annual_match_max: float = 6_000.0,
    outstanding_loan: float = 0.0,
    plan_name: str | None = None,
    is_frozen: bool = False,
    is_active: bool = True,
) -> AccountRecord:
    return AccountRecord(
        account_number=account_number,
        account_type=account_type,
        owner_name="Test User",
        owner_age_years=40.0,
        owner_dob="1985-01-01",
        is_active=is_active,
        is_frozen=is_frozen,
        total_balance=total,
        vested_balance=vested,
        unvested_balance=unvested,
        ytd_contributions=ytd_contrib,
        ytd_employer_match=ytd_match,
        annual_match_max=annual_match_max,
        outstanding_loan_balance=outstanding_loan,
        plan_name=plan_name or f"{account_type} Plan",
    )


@pytest.fixture
def api():
    """Fresh seeded MockAccountAPI for every test."""
    api = MockAccountAPI()
    # Single-account demo-user-001 (alex)
    api.seed_account(_record("tok_acc_8810", "401K",
                             total=148980.55, vested=145230.55, unvested=3750.00,
                             ytd_contrib=12500.00, ytd_match=4500.00,
                             annual_match_max=6000.00,
                             plan_name="ACME Corp 401(k) Plan"))
    # Multi-account demo-user-004 (jordan)
    api.seed_account(_record("tok_acc_1100", "401K",
                             total=492100.25, vested=487300.25, unvested=4800.00,
                             ytd_contrib=22500.00, ytd_match=8200.00,
                             annual_match_max=10000.00,
                             plan_name="Initech 401(k) Plan"))
    api.seed_account(_record("tok_acc_2200", "TRADITIONAL_IRA",
                             total=78400.00, vested=78400.00, unvested=0.00,
                             ytd_contrib=6500.00, ytd_match=0.0,
                             annual_match_max=0.0,
                             plan_name="Self-Directed Traditional IRA"))
    api.seed_account(_record("tok_acc_3300", "BROKERAGE",
                             total=156750.80, vested=156750.80, unvested=0.00,
                             ytd_contrib=0.0, ytd_match=0.0,
                             annual_match_max=0.0,
                             plan_name="Individual Brokerage Account"))
    # Taylor (401K + ROTH_IRA)
    api.seed_account(_record("tok_acc_4400", "401K",
                             total=95100.40, vested=92850.40, unvested=2250.00,
                             ytd_contrib=14200.00, ytd_match=5680.00,
                             annual_match_max=7000.00,
                             plan_name="Hooli 401(k) Plan"))
    api.seed_account(_record("tok_acc_5500", "ROTH_IRA",
                             total=28100.00, vested=28100.00,
                             plan_name="Self-Directed Roth IRA"))
    # Edge cases
    api.seed_account(_record("tok_acc_FROZ", "401K", is_frozen=True,
                             plan_name="Frozen Plan"))
    api.seed_account(_record("tok_acc_INAC", "401K", is_active=False,
                             plan_name="Inactive Plan"))
    api.seed_account(_record("tok_acc_OVRV", "401K",
                             total=100_000.0, vested=120_000.0,  # vested > total
                             unvested=0.0, plan_name="OverVested Plan"))
    api.seed_account(_record("tok_acc_OVMA", "401K",
                             total=50_000.0, vested=50_000.0,
                             ytd_match=9_999.0, annual_match_max=8_000.0,
                             plan_name="OverMatch Plan"))
    api.seed_account(_record("tok_acc_ZERO", "401K",
                             total=0.0, vested=0.0, unvested=0.0,
                             plan_name="Zero Plan"))
    api.seed_account(_record("tok_acc_VLT9", "TRADITIONAL_IRA",
                             total=10_000.0, vested=10_000.0,
                             plan_name="Vault-Token IRA"))
    set_account_api(api)
    yield api
    set_account_api(None)


def _ent_account_type(value: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_TYPE,
        is_pii=False,
        slot_name="account_type",
        display_value=value,
        confidence=0.95,
    )


def _ent_account_number_vault(vault_token: str, last4: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_NUMBER,
        is_pii=True,
        slot_name="account_number",
        display_value=f"****{last4}",
        raw_value=None,
        vault_token=vault_token,
        confidence=0.99,
    )


def _ctx_single() -> dict:
    return {
        "primary_account_type": "401K",
        "available_account_types": ["401K"],
        "accounts": {
            "401K": {
                "account_number": "tok_acc_8810",
                "account_type": "401K",
                "plan_name": "ACME Corp 401(k) Plan",
            }
        },
        "account_number": "tok_acc_8810",
    }


def _ctx_multi() -> dict:
    return {
        "primary_account_type": "401K",
        "available_account_types": ["401K", "TRADITIONAL_IRA", "BROKERAGE"],
        "accounts": {
            "401K":            {"account_number": "tok_acc_1100"},
            "TRADITIONAL_IRA": {"account_number": "tok_acc_2200"},
            "BROKERAGE":       {"account_number": "tok_acc_3300"},
        },
    }


def _ctx_taylor() -> dict:
    return {
        "available_account_types": ["401K", "ROTH_IRA"],
        "accounts": {
            "401K":     {"account_number": "tok_acc_4400"},
            "ROTH_IRA": {"account_number": "tok_acc_5500"},
        },
    }


def _ctx_legacy_flat() -> dict:
    return {"account_number": "tok_acc_8810", "plan_type": "401K"}


def _ctx_zero() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_ZERO"}}}


def _ctx_frozen() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_FROZ"}}}


def _ctx_inactive() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_INAC"}}}


def _ctx_not_seeded() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_DOES_NOT_EXIST"}}}


def _ctx_overvested() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_OVRV"}}}


def _ctx_overmatch() -> dict:
    return {"accounts": {"401K": {"account_number": "tok_acc_OVMA"}}}


def _ctx_two_roths() -> dict:
    return {
        "available_account_types": ["ROTH_IRA", "ROTH_401K"],
        "accounts": {
            "ROTH_IRA":  {"account_number": "tok_acc_5500"},
            "ROTH_401K": {"account_number": "tok_acc_NA"},
        },
    }


# ---------------------------------------------------------------------------
# 1.  Account resolution — happy paths
# ---------------------------------------------------------------------------


class TestResolutionHappyPaths:

    def test_single_account_auto_selected(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****8810"
        assert tx["total_balance"] == 148980.55
        assert tx["vested_balance"] == 145230.55
        assert tx["plan_name"] == "ACME Corp 401(k) Plan"

    @pytest.mark.parametrize(
        "atype, expected_last4, expected_total",
        [
            ("401K",            "1100", 492100.25),
            ("TRADITIONAL_IRA", "2200",  78400.00),
            ("BROKERAGE",       "3300", 156750.80),
        ],
    )
    def test_multi_account_explicit_canonical_type(
        self, api, atype, expected_last4, expected_total,
    ):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type(atype)},
            account_context=_ctx_multi(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == f"****{expected_last4}"
        assert tx["total_balance"] == expected_total

    def test_legacy_flat_context(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_legacy_flat(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****8810"


# ---------------------------------------------------------------------------
# 2.  Alias resolution
# ---------------------------------------------------------------------------


class TestAliases:

    @pytest.mark.parametrize(
        "user_says, expected_last4",
        [
            ("IRA",                 "2200"),     # bare IRA -> only Traditional present
            ("Traditional",         "2200"),
            ("traditional ira",     "2200"),
            (" TRADITIONAL_IRA ",   "2200"),     # whitespace
            ("401(k)",              "1100"),
            ("401-K",               "1100"),
            ("401k",                "1100"),
            ("brokerage_account",   "3300"),
            ("Taxable",             "3300"),
            ("BROKERAGE",           "3300"),
        ],
    )
    def test_alias_variants_for_jordan(self, api, user_says, expected_last4):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type(user_says)},
            account_context=_ctx_multi(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True, (
            f"Alias {user_says!r} should resolve, got {tx.get('errors')}"
        )
        assert tx["account_display"] == f"****{expected_last4}"

    def test_bare_roth_resolves_when_only_roth_ira_present(self, api):
        # Taylor has ROTH_IRA + 401K; "ROTH" is unambiguous.
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type("ROTH")},
            account_context=_ctx_taylor(), auth_token="t",
        )
        assert result["transaction_result"]["account_display"] == "****5500"

    def test_bare_roth_ambiguous_when_both_roths_present_fails(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type("ROTH")},
            account_context=_ctx_two_roths(), auth_token="t",
        )
        assert result["transaction_result"]["success"] is False


# ---------------------------------------------------------------------------
# 3.  Failure / negative paths (account-resolution layer)
# ---------------------------------------------------------------------------


class TestResolutionFailures:

    def test_unknown_account_type_returns_failure_with_available_list(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type("ROTH_IRA")},
            account_context=_ctx_multi(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is False
        assert tx["status"] == "FAILED"
        joined = " ".join(tx.get("errors") or [])
        assert "ROTH_IRA" in joined
        # Available list mentions at least one real account
        assert any(t in joined for t in ("401K", "TRADITIONAL_IRA", "BROKERAGE"))
        # Resolution-layer failures are user-correctable, not escalations.
        assert result["escalation_requested"] is False
        assert result["tool_exec"].status == ToolExecutionStatus.FAILED

    def test_empty_accounts_map_returns_missing_account_number(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context={"accounts": {}}, auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is False
        assert "Missing account_number" in " ".join(tx.get("errors") or [])

    def test_no_accounts_no_legacy_returns_missing_account_number(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context={}, auth_token="t",
        )
        assert result["transaction_result"]["success"] is False


# ---------------------------------------------------------------------------
# 4.  Vault-tokenised account_number entity
# ---------------------------------------------------------------------------


class TestVaultDereference:

    def test_vault_token_takes_priority_over_account_type(self, api):
        from vault.client import vault_client
        token = vault_client.tokenize("ACCOUNT_NUMBER", "tok_acc_VLT9", "sess-1")
        try:
            ent_num = _ent_account_number_vault(token, "VLT9")
            # account_type also present but should be ignored when number is.
            result = BalanceInquiryTool().execute(
                validated_entities={
                    "account_number": ent_num,
                    "account_type":   _ent_account_type("401K"),
                },
                account_context=_ctx_multi(), auth_token="auth",
            )
            tx = result["transaction_result"]
            assert tx["success"] is True
            assert tx["account_display"] == "****VLT9"
        finally:
            vault_client.delete(token)

    def test_vault_dereference_missing_token_returns_failure(self, api):
        ent_num = _ent_account_number_vault("vault:not_a_real_token", "0000")
        result = BalanceInquiryTool().execute(
            validated_entities={"account_number": ent_num},
            account_context=_ctx_multi(), auth_token="auth",
        )
        tx = result["transaction_result"]
        assert tx["success"] is False
        assert "Unable to verify account identity" in " ".join(tx.get("errors") or [])

    def test_vault_dereference_missing_auth_token_returns_failure(self, api):
        from vault.client import vault_client
        token = vault_client.tokenize("ACCOUNT_NUMBER", "tok_acc_VLT9", "sess-2")
        try:
            ent_num = _ent_account_number_vault(token, "VLT9")
            result = BalanceInquiryTool().execute(
                validated_entities={"account_number": ent_num},
                account_context=_ctx_multi(), auth_token="",  # empty -> Permission
            )
            assert result["transaction_result"]["success"] is False
        finally:
            vault_client.delete(token)


# ---------------------------------------------------------------------------
# 5.  API-layer error paths -> escalation
# ---------------------------------------------------------------------------


class TestApiErrors:

    def test_frozen_account_escalates(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_frozen(), auth_token="t",
        )
        assert result["transaction_result"]["success"] is False
        assert result["escalation_requested"] is True
        assert result["tool_exec"].status == ToolExecutionStatus.FAILED

    def test_inactive_account_escalates(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_inactive(), auth_token="t",
        )
        assert result["transaction_result"]["success"] is False
        assert result["escalation_requested"] is True

    def test_account_not_found_escalates(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_not_seeded(), auth_token="t",
        )
        assert result["transaction_result"]["success"] is False
        assert result["escalation_requested"] is True

    def test_missing_auth_token_escalates(self, api):
        # Empty auth_token -> MockAccountAPI raises AuthorizationError.
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="",
        )
        assert result["transaction_result"]["success"] is False
        assert result["escalation_requested"] is True


# ---------------------------------------------------------------------------
# 6.  Derived value computation
# ---------------------------------------------------------------------------


class TestDerivedValues:

    def test_vested_percentage_rounds_to_one_decimal(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        tx = result["transaction_result"]
        # 145230.55 / 148980.55 = 97.4828... -> 97.5
        assert tx["vested_percentage"] == 97.5

    def test_vested_clamped_when_exceeds_total(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_overvested(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["total_balance"] == 100_000.0
        # API returned vested=120k; clamp drops it to total.
        assert tx["vested_balance"] == 100_000.0
        assert tx["vested_percentage"] == 100.0

    def test_match_remaining_clamped_to_zero(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_overmatch(), auth_token="t",
        )
        # ytd=9999, max=8000  ->  remaining = max(8000-9999, 0) = 0
        assert result["transaction_result"]["employer_match_remaining"] == 0.0

    def test_zero_balance_account_no_zero_division(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_zero(), auth_token="t",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["total_balance"] == 0.0
        assert tx["vested_percentage"] == 0.0

    def test_account_display_is_last4_of_raw_number(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type("401K")},
            account_context=_ctx_multi(), auth_token="t",
        )
        # raw=tok_acc_1100  ->  last4 of *raw* is "1100"
        assert result["transaction_result"]["account_display"] == "****1100"

    def test_as_of_is_iso_string(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        as_of = result["transaction_result"]["as_of"]
        # Round-trips as ISO format
        datetime.fromisoformat(as_of.replace("Z", "+00:00"))


# ---------------------------------------------------------------------------
# 7.  Result schema / contract
# ---------------------------------------------------------------------------


class TestResultSchema:

    REQUIRED_KEYS = {
        "success", "status", "account_display", "account_type", "plan_name",
        "total_balance", "vested_balance", "unvested_balance",
        "vested_percentage", "ytd_contributions", "ytd_employer_match",
        "employer_match_remaining", "outstanding_loan_balance", "as_of",
    }

    def test_success_result_has_all_documented_keys(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        tx = result["transaction_result"]
        missing = self.REQUIRED_KEYS - set(tx.keys())
        assert not missing, f"transaction_result missing keys: {missing}"

    def test_success_tool_exec_state(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        tx_state = result["tool_exec"]
        assert tx_state.status == ToolExecutionStatus.SUCCEEDED
        assert tx_state.in_flight is False
        assert tx_state.tool_agent_name == "balance_inquiry"
        assert tx_state.last_updated_at is not None

    def test_failure_tool_exec_state(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_frozen(), auth_token="t",
        )
        tx_state = result["tool_exec"]
        assert tx_state.status == ToolExecutionStatus.FAILED
        assert tx_state.in_flight is False
        assert tx_state.error_message

    def test_account_type_echoed_from_entity_when_present(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={"account_type": _ent_account_type("BROKERAGE")},
            account_context=_ctx_multi(), auth_token="t",
        )
        assert result["transaction_result"]["account_type"] == "BROKERAGE"

    def test_account_type_falls_back_to_api_when_no_entity(self, api):
        result = BalanceInquiryTool().execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        assert result["transaction_result"]["account_type"] == "401K"


# ---------------------------------------------------------------------------
# 8.  Isolation between sequential calls
# ---------------------------------------------------------------------------


class TestCallIsolation:

    def test_sequential_calls_do_not_leak_balances(self, api):
        agent = BalanceInquiryTool()
        r_alex = agent.execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        r_jordan = agent.execute(
            validated_entities={"account_type": _ent_account_type("BROKERAGE")},
            account_context=_ctx_multi(), auth_token="t",
        )
        assert r_alex["transaction_result"]["account_display"] == "****8810"
        assert r_jordan["transaction_result"]["account_display"] == "****3300"
        assert (
            r_alex["transaction_result"]["vested_balance"]
            != r_jordan["transaction_result"]["vested_balance"]
        )

    def test_failure_does_not_poison_subsequent_call(self, api):
        agent = BalanceInquiryTool()
        bad = agent.execute(
            validated_entities={}, account_context=_ctx_frozen(), auth_token="t",
        )
        good = agent.execute(
            validated_entities={}, account_context=_ctx_single(), auth_token="t",
        )
        assert bad["transaction_result"]["success"] is False
        assert good["transaction_result"]["success"] is True


# ---------------------------------------------------------------------------
# 9.  Health check
# ---------------------------------------------------------------------------


def test_health_check_returns_true():
    assert BalanceInquiryTool().health_check() is True
