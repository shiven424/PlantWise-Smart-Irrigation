"""Unit tests for the auth challenge evaluator.

These tests pin down the candidate-normalisation behaviour added so that
verification answers embedded inside a sentence (e.g. ``"my SSN is 4321"``)
still validate.  This is required because the message-classifier's
auth-verification bypass forwards the user's entire utterance as the
``verification_input``.
"""
from __future__ import annotations

import pytest

from agents.auth_agent.v1.evaluator import evaluate, hash_answer


SESSION_ID = "test-session"


# ---------------------------------------------------------------------------
# LAST_4_SSN
# ---------------------------------------------------------------------------

class TestSSNEvaluator:
    EXPECTED = hash_answer("LAST_4_SSN", "4321")

    @pytest.mark.parametrize("response", [
        "4321",
        " 4321 ",
        "4321\n",
        "my ssn is 4321",
        "My SNN is 4321 and i want to check my 401k account balance",
        "It's 4321, thanks.",
        "ssn last 4 = 4321",
        "the digits are 4-3-2-1",  # legacy strict path strips dashes
    ])
    def test_correct_answer_in_various_phrasings(self, response):
        assert evaluate("LAST_4_SSN", response, SESSION_ID, self.EXPECTED) is True

    @pytest.mark.parametrize("response", [
        "1234",
        "my ssn is 1234",
        "I want to check my 401k account balance",  # "401" only 3 digits
        "9999",
        "",
        "   ",
    ])
    def test_wrong_or_missing_answer_fails(self, response):
        assert evaluate("LAST_4_SSN", response, SESSION_ID, self.EXPECTED) is False

    def test_embedded_correct_with_other_4digit_noise(self):
        """If a 4-digit decoy comes BEFORE the correct token, we must still
        accept the message — every standalone 4-digit run is tried."""
        msg = "my zip is 9410 oh wait no, ssn is 4321"
        assert evaluate("LAST_4_SSN", msg, SESSION_ID, self.EXPECTED) is True

    def test_no_match_when_expected_hash_empty(self):
        assert evaluate("LAST_4_SSN", "4321", SESSION_ID, "") is False


# ---------------------------------------------------------------------------
# ACCOUNT_LAST4
# ---------------------------------------------------------------------------

class TestAccountLast4Evaluator:
    EXPECTED = hash_answer("ACCOUNT_LAST4", "8810")

    @pytest.mark.parametrize("response", [
        "8810",
        "account ending 8810",
        "ending in 8810 i think",
        "my account number ends in 8810 please",
    ])
    def test_correct_answer_accepted(self, response):
        assert evaluate("ACCOUNT_LAST4", response, SESSION_ID, self.EXPECTED) is True

    def test_wrong_4digit_token_rejected(self):
        assert evaluate("ACCOUNT_LAST4", "ending 1234", SESSION_ID, self.EXPECTED) is False


# ---------------------------------------------------------------------------
# ZIP_CODE
# ---------------------------------------------------------------------------

class TestZipEvaluator:
    EXPECTED = hash_answer("ZIP_CODE", "94107")

    @pytest.mark.parametrize("response", [
        "94107",
        "94107-1234",  # ZIP+4 — legacy strict path keeps first 5
        "my zip is 94107",
        "94107 san francisco",
    ])
    def test_correct_answer_accepted(self, response):
        assert evaluate("ZIP_CODE", response, SESSION_ID, self.EXPECTED) is True

    def test_wrong_zip_rejected(self):
        assert evaluate("ZIP_CODE", "my zip is 10001", SESSION_ID, self.EXPECTED) is False


# ---------------------------------------------------------------------------
# DATE_OF_BIRTH
# ---------------------------------------------------------------------------

class TestDobEvaluator:
    EXPECTED = hash_answer("DATE_OF_BIRTH", "1985-06-12")

    @pytest.mark.parametrize("response", [
        "1985-06-12",
        "06/12/1985",
        "06-12-1985",
        "i was born on 1985-06-12",
        "my dob is 06/12/1985 hope that helps",
    ])
    def test_correct_answer_accepted(self, response):
        assert evaluate("DATE_OF_BIRTH", response, SESSION_ID, self.EXPECTED) is True

    def test_wrong_dob_rejected(self):
        assert evaluate("DATE_OF_BIRTH", "1990-01-01", SESSION_ID, self.EXPECTED) is False


# ---------------------------------------------------------------------------
# MOTHER_MAIDEN
# ---------------------------------------------------------------------------

class TestMotherMaidenEvaluator:
    EXPECTED = hash_answer("MOTHER_MAIDEN", "rivera")

    @pytest.mark.parametrize("response", [
        "rivera",
        "Rivera",
        "her name is rivera",
        "it's rivera, sorry for the typo",
    ])
    def test_correct_answer_accepted(self, response):
        assert evaluate("MOTHER_MAIDEN", response, SESSION_ID, self.EXPECTED) is True

    def test_wrong_maiden_rejected(self):
        assert evaluate("MOTHER_MAIDEN", "her name is smith", SESSION_ID, self.EXPECTED) is False


# ---------------------------------------------------------------------------
# OTP
# ---------------------------------------------------------------------------

class TestOtpEvaluator:
    EXPECTED = hash_answer("OTP", "123456")

    @pytest.mark.parametrize("response", [
        "123456",
        "the code is 123456",
        "got it: 123456 — thanks",
    ])
    def test_correct_otp_accepted(self, response):
        assert evaluate("OTP", response, SESSION_ID, self.EXPECTED) is True

    def test_wrong_otp_rejected(self):
        assert evaluate("OTP", "the code is 654321", SESSION_ID, self.EXPECTED) is False
