"""Golden-set evaluation for EntityExtractionAgent against the REAL LLM.

Replays multi-turn fixtures, carrying entity_memory across turns. Per turn checks:
  - Each expected slot is present in entity_memory after the turn
  - The display_value matches the expected value (case-insensitive substring match;
    digits-only comparison for amount/percent slots)
  - PII slots have vault_token set and raw_value cleared
  - "must_not_fill" slots are absent
  - Contradictions are flagged when expected

Run:
    python -m tests.agents.eval_entity_extraction
    python -m tests.agents.eval_entity_extraction --only-id rmd-calculation-dob
    python -m tests.agents.eval_entity_extraction --json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from agents.entity_extraction.v1.agent import EntityExtractionAgent
from agents.intent_agent.v1.taxonomy import lookup_intent
from schemas.enums import IntentChangeType
from schemas.primitives import EntityRecord, IntentRecord, SessionContext


FIXTURES_PATH = Path(__file__).parent / "golden_entities.json"

_AMOUNT_SLOTS = {
    "withdrawal_amount", "rollover_amount", "loan_amount",
    "contribution_amount", "withholding_percentage",
    "beneficiary_percentage", "repayment_term", "order_quantity",
    "order_price", "tax_year",
}


def _new_session() -> SessionContext:
    return SessionContext(
        session_id=uuid4(), user_id="eval-user", channel="eval",
        client_tier="STANDARD", locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _intent_record(sub_intent: str) -> IntentRecord:
    defn = lookup_intent(sub_intent)
    return IntentRecord(
        intent_id=defn.intent_id,
        service_domain=defn.domain,
        sub_intent=defn.sub_intent_id,
        confidence=0.95,
        change_type=IntentChangeType.NEW,
        requires_auth_level=defn.auth_level,
        is_transactional=defn.is_transactional,
        escalation_flag=defn.escalation_flag,
        required_slots=list(defn.required_slots),
        turn_number=1,
    )


def _value_match(expected: str, actual: str | None, slot: str) -> bool:
    if actual is None:
        return False
    a = str(actual).strip().lower()
    e = str(expected).strip().lower()
    if e == a:
        return True
    if slot in _AMOUNT_SLOTS:
        # Digits-only comparison: "5,000" == "5000" == "$5000"
        ed = re.sub(r"\D", "", e)
        ad = re.sub(r"\D", "", a)
        return ed != "" and ed == ad
    # Substring match (e.g. "401K" in "401K plan")
    return e in a or a in e


def run_eval(fixtures: list[dict], only_id: str | None = None) -> dict:
    agent = EntityExtractionAgent()
    fixture_results = []
    latencies: list[float] = []
    slot_total = slot_ok = 0
    pii_total = pii_ok = 0
    contradiction_total = contradiction_ok = 0
    forbidden_total = forbidden_ok = 0

    for fx in fixtures:
        if only_id and fx["id"] != only_id:
            continue

        session = _new_session()
        intent = _intent_record(fx["sub_intent"])
        entity_memory: dict[str, EntityRecord] = {}
        turn_outputs = []

        for i, turn in enumerate(fx["turns"], start=1):
            state = {
                "session": session,
                "message_history": [{"role": "user", "content": turn["message"]}],
                "intent_stack": [intent],
                "active_intent_id": intent.intent_id,
                "entity_memory": entity_memory,
                "last_requested_slot": turn.get("last_requested_slot"),
                "current_turn": i,
                "user_profile": {},
            }
            t0 = time.perf_counter()
            try:
                result = agent.run(state)
                err = None
            except Exception as e:
                result = {}
                err = repr(e)
            dt_ms = (time.perf_counter() - t0) * 1000
            latencies.append(dt_ms)

            new_mem = result.get("entity_memory", {})

            # --- Slot value checks
            slot_results = {}
            for slot, expected in turn.get("expected_slots", {}).items():
                rec = new_mem.get(slot) or entity_memory.get(slot)
                ok = rec is not None and _value_match(expected, rec.display_value, slot)
                slot_results[slot] = {
                    "expected": expected,
                    "actual": getattr(rec, "display_value", None),
                    "ok": ok,
                }
                slot_total += 1
                slot_ok += int(ok)

            # --- PII checks
            pii_results = {}
            for slot in turn.get("expected_pii_slots", []):
                rec = new_mem.get(slot) or entity_memory.get(slot)
                ok = (
                    rec is not None
                    and rec.is_pii is True
                    and bool(rec.vault_token)
                    and rec.raw_value is None
                )
                pii_results[slot] = {
                    "is_pii": getattr(rec, "is_pii", None),
                    "has_token": bool(getattr(rec, "vault_token", None)),
                    "raw_cleared": getattr(rec, "raw_value", "...") is None,
                    "ok": ok,
                }
                pii_total += 1
                pii_ok += int(ok)

            # --- Forbidden slots
            forbidden_results = {}
            for slot in turn.get("must_not_fill", []):
                ok = slot not in new_mem
                forbidden_results[slot] = {"ok": ok}
                forbidden_total += 1
                forbidden_ok += int(ok)

            # --- Contradictions
            contradiction_result = None
            if "expected_contradiction_slot" in turn:
                cs = turn["expected_contradiction_slot"]
                rec = new_mem.get(cs)
                ok = rec is not None and rec.contradicts is not None
                contradiction_result = {"slot": cs, "ok": ok}
                contradiction_total += 1
                contradiction_ok += int(ok)

            # Carry forward state: merge new entities, mark confirms
            entity_memory = {**entity_memory, **new_mem}
            for s in turn.get("confirm_slots", []):
                if s in entity_memory:
                    rec = entity_memory[s]
                    entity_memory[s] = EntityRecord(
                        **{**rec.model_dump(), "is_confirmed": True, "turn_confirmed": i}
                    )

            turn_outputs.append({
                "turn": i,
                "message": turn["message"],
                "ms": round(dt_ms, 1),
                "error": err,
                "slot_results": slot_results,
                "pii_results": pii_results,
                "forbidden_results": forbidden_results,
                "contradiction_result": contradiction_result,
            })

        fixture_ok = all(
            all(s["ok"] for s in t["slot_results"].values())
            and all(p["ok"] for p in t["pii_results"].values())
            and all(f["ok"] for f in t["forbidden_results"].values())
            and (t["contradiction_result"] is None or t["contradiction_result"]["ok"])
            for t in turn_outputs
        )
        fixture_results.append({
            "id": fx["id"],
            "description": fx.get("description", ""),
            "ok": fixture_ok,
            "turns": turn_outputs,
        })

    def _pct(xs: list[float], p: float) -> float:
        if not xs:
            return 0.0
        s = sorted(xs)
        k = max(0, min(len(s) - 1, int(round((p / 100.0) * (len(s) - 1)))))
        return s[k]

    return {
        "fixture_count": len(fixture_results),
        "fixture_pass": sum(1 for f in fixture_results if f["ok"]),
        "slot_accuracy": round(slot_ok / slot_total, 3) if slot_total else 0.0,
        "pii_accuracy": round(pii_ok / pii_total, 3) if pii_total else 0.0,
        "forbidden_accuracy": round(forbidden_ok / forbidden_total, 3) if forbidden_total else 0.0,
        "contradiction_accuracy": (
            round(contradiction_ok / contradiction_total, 3) if contradiction_total else 0.0
        ),
        "latency_p50_ms": round(_pct(latencies, 50), 1),
        "latency_p95_ms": round(_pct(latencies, 95), 1),
        "fixtures": fixture_results,
    }


def print_report(report: dict, verbose: bool = False) -> None:
    print("=" * 72)
    print(f"Entity Extraction Eval — {report['fixture_pass']}/{report['fixture_count']} fixtures fully correct")
    print(f"  slot value     accuracy : {report['slot_accuracy']:.1%}")
    print(f"  PII vaulting   accuracy : {report['pii_accuracy']:.1%}")
    print(f"  forbidden-slot accuracy : {report['forbidden_accuracy']:.1%}")
    print(f"  contradiction  accuracy : {report['contradiction_accuracy']:.1%}")
    print(f"  latency p50/p95         : {report['latency_p50_ms']}ms / {report['latency_p95_ms']}ms")

    failures = [f for f in report["fixtures"] if not f["ok"]]
    if failures:
        print("-" * 72)
        print(f"FAILED FIXTURES ({len(failures)}):")
        for f in failures:
            print(f"\n  [{f['id']}] {f.get('description','')}")
            for t in f["turns"]:
                msgs = []
                for slot, r in t["slot_results"].items():
                    if not r["ok"]:
                        msgs.append(f"slot[{slot}] expected={r['expected']!r} got={r['actual']!r}")
                for slot, r in t["pii_results"].items():
                    if not r["ok"]:
                        msgs.append(
                            f"pii[{slot}] is_pii={r['is_pii']} token={r['has_token']} "
                            f"raw_cleared={r['raw_cleared']}"
                        )
                for slot, r in t["forbidden_results"].items():
                    if not r["ok"]:
                        msgs.append(f"forbidden[{slot}] was filled")
                if t["contradiction_result"] and not t["contradiction_result"]["ok"]:
                    msgs.append(f"contradiction[{t['contradiction_result']['slot']}] not flagged")
                if msgs:
                    print(f"     T{t['turn']} FAIL  {t['message']!r}")
                    for m in msgs:
                        print(f"            - {m}")

    if verbose:
        print("-" * 72)
        for f in report["fixtures"]:
            print(f"\n  [{f['id']}] ok={f['ok']}")
            for t in f["turns"]:
                print(f"    T{t['turn']} {t['message']!r}  ({t['ms']}ms)")
                for slot, r in t["slot_results"].items():
                    mark = "OK " if r["ok"] else "FAIL"
                    print(f"       {mark} slot[{slot}] expected={r['expected']!r} got={r['actual']!r}")
                for slot, r in t["pii_results"].items():
                    mark = "OK " if r["ok"] else "FAIL"
                    print(f"       {mark} pii[{slot}]")
    print("=" * 72)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixtures", default=str(FIXTURES_PATH))
    ap.add_argument("--only-id", default=None)
    ap.add_argument("--min-slot", type=float, default=0.85)
    ap.add_argument("--min-pii", type=float, default=1.0)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
    report = run_eval(fixtures, only_id=args.only_id)

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print_report(report, verbose=args.verbose)

    pass_gate = (
        report["slot_accuracy"] >= args.min_slot
        and report["pii_accuracy"] >= args.min_pii
    )
    return 0 if pass_gate else 1


if __name__ == "__main__":
    sys.exit(main())
