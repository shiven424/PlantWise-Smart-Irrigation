"""Golden-set evaluation for IntentAgent against the REAL LLM.

Replays each multi-turn fixture against the live agent and reports:
  - Per-fixture per-turn correctness (sub_intent, change_type, escalation)
  - Aggregate sub_intent accuracy
  - Aggregate change_type accuracy
  - Confusion matrix for change_type
  - Latency p50 / p95
  - Listing of every misclassification

Run:
    python -m tests.agents.eval_intent_agent
    python -m tests.agents.eval_intent_agent --only-id pivot-loan-to-balance
    python -m tests.agents.eval_intent_agent --json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import defaultdict, Counter
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from agents.intent_agent.v1.agent import IntentAgent
from agents.intent_agent.v1.taxonomy import lookup_intent
from schemas.enums import IntentChangeType
from schemas.primitives import IntentRecord, SessionContext


FIXTURES_PATH = Path(__file__).parent / "golden_intents.json"


def _new_session() -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id="eval-user",
        channel="eval",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _build_state(session: SessionContext, message: str,
                 intent_stack: list[IntentRecord], turn: int) -> dict:
    return {
        "session": session,
        "message_history": [{"role": "user", "content": message}],
        "intent_stack": list(intent_stack),
        "active_intent_id": intent_stack[0].intent_id if intent_stack else None,
        "completed_intent_ids": [],
        "entity_memory": {},
        "current_turn": turn,
        "user_profile": {},
    }


def _evaluate_turn(turn_spec: dict, result: dict) -> dict:
    expected_sub = turn_spec["expected_sub_intent"]
    expected_ct = turn_spec.get("expected_change_type")
    expected_esc = turn_spec.get("expected_escalation", False)
    accept_alts = turn_spec.get("accept_alts", [])
    accept_alt_cts = turn_spec.get("accept_alt_change_types", [])

    stack = result.get("intent_stack", []) or []
    if not stack:
        return {
            "sub_intent_ok": False, "change_type_ok": False, "escalation_ok": not expected_esc,
            "predicted_sub": None, "predicted_ct": None, "predicted_esc": False,
        }

    head = stack[0]
    sub_ok = (head.sub_intent == expected_sub) or (head.sub_intent in accept_alts)
    ct_ok = True
    if expected_ct is not None:
        ct_ok = (head.change_type.value == expected_ct) or (head.change_type.value in accept_alt_cts)
    esc_ok = bool(head.escalation_flag) == bool(expected_esc)

    return {
        "sub_intent_ok": sub_ok,
        "change_type_ok": ct_ok,
        "escalation_ok": esc_ok,
        "predicted_sub": head.sub_intent,
        "predicted_ct": head.change_type.value,
        "predicted_esc": bool(head.escalation_flag),
    }


def run_eval(fixtures: list[dict], only_id: str | None = None) -> dict:
    agent = IntentAgent()
    fixture_results = []
    latencies: list[float] = []
    sub_total = sub_ok = 0
    ct_total = ct_ok = 0
    esc_total = esc_ok = 0
    ct_cm: dict[str, Counter] = defaultdict(Counter)  # ct_cm[expected][predicted]

    for fx in fixtures:
        if only_id and fx["id"] != only_id:
            continue

        session = _new_session()
        stack: list[IntentRecord] = []
        turn_outputs = []

        for i, turn in enumerate(fx["turns"], start=1):
            state = _build_state(session, turn["message"], stack, turn=i)
            t0 = time.perf_counter()
            try:
                result = agent.run(state)
                err = None
            except Exception as e:  # pragma: no cover
                result = {}
                err = repr(e)
            dt_ms = (time.perf_counter() - t0) * 1000
            latencies.append(dt_ms)

            judgement = _evaluate_turn(turn, result)
            turn_outputs.append({
                "turn": i,
                "message": turn["message"],
                "expected_sub": turn["expected_sub_intent"],
                "expected_ct": turn.get("expected_change_type"),
                "expected_esc": turn.get("expected_escalation", False),
                "ms": round(dt_ms, 1),
                "error": err,
                **judgement,
            })

            sub_total += 1
            sub_ok += int(judgement["sub_intent_ok"])
            if turn.get("expected_change_type") is not None:
                ct_total += 1
                ct_ok += int(judgement["change_type_ok"])
                ct_cm[turn["expected_change_type"]][judgement["predicted_ct"] or "NONE"] += 1
            esc_total += 1
            esc_ok += int(judgement["escalation_ok"])

            # Carry the agent's resulting stack into the next turn.
            stack = result.get("intent_stack", stack)

        fixture_ok = all(
            t["sub_intent_ok"] and t["change_type_ok"] and t["escalation_ok"]
            for t in turn_outputs
        )
        fixture_results.append({
            "id": fx["id"],
            "description": fx.get("description", ""),
            "ok": fixture_ok,
            "turns": turn_outputs,
        })

    def _pct(xs: list[float], p: float) -> float:
        if not xs:
            return 0.0
        s = sorted(xs)
        k = max(0, min(len(s) - 1, int(round((p / 100.0) * (len(s) - 1)))))
        return s[k]

    return {
        "fixture_count": len(fixture_results),
        "fixture_pass": sum(1 for f in fixture_results if f["ok"]),
        "sub_intent_accuracy": round(sub_ok / sub_total, 3) if sub_total else 0.0,
        "change_type_accuracy": round(ct_ok / ct_total, 3) if ct_total else 0.0,
        "escalation_accuracy": round(esc_ok / esc_total, 3) if esc_total else 0.0,
        "latency_p50_ms": round(_pct(latencies, 50), 1),
        "latency_p95_ms": round(_pct(latencies, 95), 1),
        "change_type_cm": {k: dict(v) for k, v in ct_cm.items()},
        "fixtures": fixture_results,
    }


def print_report(report: dict, verbose: bool = False) -> None:
    print("=" * 72)
    print(f"Intent Agent Eval — {report['fixture_pass']}/{report['fixture_count']} fixtures fully correct")
    print(f"  sub_intent  accuracy : {report['sub_intent_accuracy']:.1%}")
    print(f"  change_type accuracy : {report['change_type_accuracy']:.1%}")
    print(f"  escalation  accuracy : {report['escalation_accuracy']:.1%}")
    print(f"  latency p50/p95      : {report['latency_p50_ms']}ms / {report['latency_p95_ms']}ms")
    print("-" * 72)
    print("Change-type confusion matrix (rows=expected, cols=predicted):")
    cm = report["change_type_cm"]
    cts = [c.value for c in IntentChangeType] + ["NONE"]
    present_cts = sorted(set(cm.keys()) | {p for row in cm.values() for p in row.keys()})
    cts = [c for c in cts if c in present_cts]
    if cts:
        print(f"{'':<14}" + "".join(f"{c:>14}" for c in cts))
        for r in cts:
            print(f"{r:<14}" + "".join(f"{cm.get(r, {}).get(c, 0):>14}" for c in cts))

    failures = [f for f in report["fixtures"] if not f["ok"]]
    if failures:
        print("-" * 72)
        print(f"FAILED FIXTURES ({len(failures)}):")
        for f in failures:
            print(f"\n  [{f['id']}] {f.get('description','')}")
            for t in f["turns"]:
                marks = []
                if not t["sub_intent_ok"]:
                    marks.append(f"sub={t['predicted_sub']}!=exp={t['expected_sub']}")
                if not t["change_type_ok"]:
                    marks.append(f"ct={t['predicted_ct']}!=exp={t['expected_ct']}")
                if not t["escalation_ok"]:
                    marks.append(f"esc={t['predicted_esc']}!=exp={t['expected_esc']}")
                tag = "OK " if not marks else "FAIL"
                detail = " | ".join(marks) if marks else ""
                print(f"     T{t['turn']} {tag} {t['message']!r}  {detail}")

    if verbose:
        print("-" * 72)
        for f in report["fixtures"]:
            print(f"\n  [{f['id']}] ok={f['ok']}")
            for t in f["turns"]:
                print(f"     T{t['turn']} sub={t['predicted_sub']} ct={t['predicted_ct']} "
                      f"esc={t['predicted_esc']} ms={t['ms']}  {t['message']!r}")
    print("=" * 72)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixtures", default=str(FIXTURES_PATH))
    ap.add_argument("--only-id", default=None, help="Run only one fixture by id")
    ap.add_argument("--min-sub-accuracy", type=float, default=0.85)
    ap.add_argument("--min-ct-accuracy", type=float, default=0.75)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
    report = run_eval(fixtures, only_id=args.only_id)

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print_report(report, verbose=args.verbose)

    pass_gate = (
        report["sub_intent_accuracy"] >= args.min_sub_accuracy
        and report["change_type_accuracy"] >= args.min_ct_accuracy
    )
    return 0 if pass_gate else 1


if __name__ == "__main__":
    sys.exit(main())
