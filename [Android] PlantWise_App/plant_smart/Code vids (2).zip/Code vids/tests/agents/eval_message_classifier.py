"""Golden-set evaluation for MessageClassifierAgent against the REAL LLM.

This is NOT a unit test. It hits the configured LLM provider and reports
accuracy / per-class precision-recall / confusion matrix / latency.

Run:
    python -m tests.agents.eval_message_classifier
    python -m tests.agents.eval_message_classifier --only ESCALATE
    python -m tests.agents.eval_message_classifier --fixtures path/to/file.json

Exit code is 0 if overall accuracy >= --min-accuracy (default 0.85),
else 1. Useful as a CI smoke gate for prompt regressions.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from agents.message_classifier.v1.agent import MessageClassifierAgent
from schemas.enums import MessageDomain
from schemas.primitives import SessionContext


FIXTURES_PATH = Path(__file__).parent / "golden_messages.json"


def _build_state(message: str) -> dict:
    session = SessionContext(
        session_id=uuid4(),
        user_id="eval-user",
        channel="eval",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )
    return {
        "session": session,
        "message_history": [{"role": "user", "content": message}],
        "current_turn": 1,
    }


def run_eval(fixtures: list[dict], only: str | None = None) -> dict:
    agent = MessageClassifierAgent()
    rows: list[dict] = []
    cm: dict[str, Counter] = defaultdict(Counter)  # cm[expected][predicted] = count

    for fx in fixtures:
        if only and fx["expected_domain"] != only:
            continue
        msg = fx["message"]
        expected = fx["expected_domain"]

        t0 = time.perf_counter()
        try:
            out = agent.run(_build_state(msg))
            err = None
        except Exception as e:  # pragma: no cover — defensive
            out = {}
            err = repr(e)
        dt_ms = (time.perf_counter() - t0) * 1000

        predicted = out.get("message_domain")
        predicted_str = predicted.value if isinstance(predicted, MessageDomain) else str(predicted)
        confidence = out.get("classifier_confidence")
        reason = out.get("classifier_escalation_reason")

        ok = predicted_str == expected or predicted_str in fx.get("accept_alts", [])
        cm[expected][predicted_str] += 1

        rows.append({
            "id": fx["id"],
            "message": msg,
            "expected": expected,
            "predicted": predicted_str,
            "confidence": confidence,
            "reason": reason,
            "ok": ok,
            "ms": round(dt_ms, 1),
            "error": err,
        })

    # Aggregate metrics
    total = len(rows)
    correct = sum(1 for r in rows if r["ok"])
    accuracy = correct / total if total else 0.0

    per_class = {}
    domains = set(r["expected"] for r in rows) | set(r["predicted"] for r in rows if r["predicted"])
    for d in domains:
        tp = sum(1 for r in rows if r["expected"] == d and r["predicted"] == d)
        fp = sum(1 for r in rows if r["expected"] != d and r["predicted"] == d)
        fn = sum(1 for r in rows if r["expected"] == d and r["predicted"] != d)
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        per_class[d] = {"precision": round(precision, 3), "recall": round(recall, 3),
                        "f1": round(f1, 3), "support": tp + fn}

    return {
        "total": total,
        "correct": correct,
        "accuracy": round(accuracy, 3),
        "per_class": per_class,
        "confusion_matrix": {k: dict(v) for k, v in cm.items()},
        "latency_p50_ms": round(_pct([r["ms"] for r in rows], 50), 1) if rows else None,
        "latency_p95_ms": round(_pct([r["ms"] for r in rows], 95), 1) if rows else None,
        "rows": rows,
    }


def _pct(xs: list[float], p: float) -> float:
    if not xs:
        return 0.0
    s = sorted(xs)
    k = max(0, min(len(s) - 1, int(round((p / 100.0) * (len(s) - 1)))))
    return s[k]


def print_report(report: dict, verbose: bool = False) -> None:
    print("=" * 70)
    print(f"Message Classifier Eval — accuracy={report['accuracy']:.1%}  "
          f"({report['correct']}/{report['total']})")
    print(f"Latency: p50={report['latency_p50_ms']}ms  p95={report['latency_p95_ms']}ms")
    print("-" * 70)
    print(f"{'class':<16} {'precision':>10} {'recall':>10} {'f1':>10} {'support':>10}")
    for cls, m in sorted(report["per_class"].items()):
        print(f"{cls:<16} {m['precision']:>10.3f} {m['recall']:>10.3f} "
              f"{m['f1']:>10.3f} {m['support']:>10d}")

    print("-" * 70)
    print("Confusion matrix (rows=expected, cols=predicted):")
    cm = report["confusion_matrix"]
    domains = sorted(set(cm.keys()) | {p for v in cm.values() for p in v.keys()})
    print(f"{'':<16}" + "".join(f"{d:>16}" for d in domains))
    for r in domains:
        print(f"{r:<16}" + "".join(f"{cm.get(r, {}).get(c, 0):>16}" for c in domains))

    misses = [r for r in report["rows"] if not r["ok"]]
    if misses:
        print("-" * 70)
        print(f"MISCLASSIFIED ({len(misses)}):")
        for r in misses:
            print(f"  [{r['id']}] expected={r['expected']:<14} predicted={r['predicted']:<14} "
                  f"conf={r['confidence']}  msg={r['message']!r}")

    if verbose:
        print("-" * 70)
        print("ALL ROWS:")
        for r in report["rows"]:
            mark = "OK " if r["ok"] else "FAIL"
            print(f"  {mark} [{r['id']}] {r['expected']}->{r['predicted']} "
                  f"conf={r['confidence']} ms={r['ms']}  {r['message']!r}")
    print("=" * 70)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixtures", default=str(FIXTURES_PATH))
    ap.add_argument("--only", default=None,
                    choices=[d.value for d in MessageDomain],
                    help="Only run cases with this expected domain")
    ap.add_argument("--min-accuracy", type=float, default=0.85)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--json", action="store_true",
                    help="Emit machine-readable JSON instead of human report")
    args = ap.parse_args()

    fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
    report = run_eval(fixtures, only=args.only)

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print_report(report, verbose=args.verbose)

    return 0 if report["accuracy"] >= args.min_accuracy else 1


if __name__ == "__main__":
    sys.exit(main())
