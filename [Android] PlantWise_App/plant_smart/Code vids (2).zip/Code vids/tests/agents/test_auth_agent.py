"""Auth Agent v1 - deep unit tests using a seeded MemoryAuthSecretsProvider.

These tests bypass FastAPI / LangGraph entirely. They build a state dict and
call AuthAgent.run() directly, verifying the deterministic state machine.

LLM is never invoked.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from agents.auth_agent.v1 import agent as agent_module
from agents.auth_agent.v1.agent import AuthAgent
from agents.auth_agent.v1.evaluator import hash_answer
from auth import client as auth_client
from auth.providers.memory import MemoryAuthSecretsProvider, MemoryOtpChannel
from config import settings
from schemas.enums import (
    AuthLevel,
    AuthStatus,
    ChallengeType,
    EscalationReason,
)
from schemas.primitives import AuthChallenge, AuthState, SessionContext

FIXTURE = Path(__file__).parent.parent / "fixtures" / "auth_accounts.json"
USER_GOOD = "test-user-good"
USER_EMPTY = "test-user-empty"


# ---------------------------------------------------------------------------
# Fixtures + helpers
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_providers(monkeypatch):
    """Replace the global secrets/OTP singletons with seeded test instances."""
    sp = MemoryAuthSecretsProvider(FIXTURE)
    oc = MemoryOtpChannel(ttl_seconds=settings.auth_otp_ttl_seconds)
    monkeypatch.setattr(auth_client, "_secrets", sp)
    monkeypatch.setattr(auth_client, "_otp", oc)
    yield
    auth_client.reset_for_tests()


def _session(user_id: str | None = USER_GOOD) -> SessionContext:
    return SessionContext(
        session_id=uuid.uuid4(),
        user_id=user_id,
        channel="web",
        started_at=datetime.now(timezone.utc),
    )


def _state(
    *,
    auth_state: AuthState | None = None,
    required_level: AuthLevel = AuthLevel.SOFT,
    pending: AuthChallenge | None = None,
    verification_input: str | None = None,
    user_id: str | None = USER_GOOD,
    fraud_risk_score: float = 0.0,
    device_fingerprint: str | None = None,
    user_profile: dict | None = None,
    message_history: list | None = None,
) -> dict:
    return {
        "session": _session(user_id),
        "auth_state": auth_state or AuthState(),
        "required_auth_level": required_level,
        "scratch": (
            {"pending_auth_challenge": pending.model_dump(mode="json")}
            if pending
            else {}
        ),
        "verification_input": verification_input,
        "fraud_risk_score": fraud_risk_score,
        "device_fingerprint": device_fingerprint,
        "user_profile": user_profile or {},
        "message_history": message_history or [],
    }


# ---------------------------------------------------------------------------
# Tier 1: trivial / control flow
# ---------------------------------------------------------------------------

class TestControlFlow:
    def test_session_level_returns_verified(self) -> None:
        out = AuthAgent().run(_state(required_level=AuthLevel.SESSION))
        assert out["auth_status"] == AuthStatus.VERIFIED

    def test_already_verified_returns_verified(self) -> None:
        out = AuthAgent().run(_state(
            auth_state=AuthState(
                current_level=AuthLevel.STRONG,
                verified_at=datetime.now(timezone.utc),
            ),
            required_level=AuthLevel.STRONG,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED

    def test_locked_returns_locked_escalation(self) -> None:
        out = AuthAgent().run(_state(
            auth_state=AuthState(is_locked=True, failed_attempts=3),
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.LOCKED
        assert out["escalation_requested"] is True
        assert out["escalation_context"].reason == EscalationReason.AUTH_LOCKED

    def test_health_check_ok(self) -> None:
        assert AuthAgent().health_check() is True


# ---------------------------------------------------------------------------
# Tier 2: issue a fresh challenge
# ---------------------------------------------------------------------------

class TestIssueChallenge:
    def test_issues_zip_for_soft(self) -> None:
        out = AuthAgent().run(_state(required_level=AuthLevel.SOFT))
        assert out["auth_status"] == AuthStatus.PENDING
        ch = out["scratch"]["pending_auth_challenge"]
        assert ch["challenge_type"] == "ZIP_CODE"
        assert len(ch["expected_hash"]) == 64
        assert ch["expires_at"] is None

    def test_issues_ssn_for_strong(self) -> None:
        out = AuthAgent().run(_state(required_level=AuthLevel.STRONG))
        ch = out["scratch"]["pending_auth_challenge"]
        assert ch["challenge_type"] == "LAST_4_SSN"

    def test_issues_otp_for_enhanced_with_expiry(self) -> None:
        out = AuthAgent().run(_state(required_level=AuthLevel.ENHANCED))
        ch = out["scratch"]["pending_auth_challenge"]
        assert ch["challenge_type"] == "ONE_TIME_CODE"
        assert ch["expires_at"] is not None  # ISO string

    def test_missing_secret_locks_immediately(self) -> None:
        out = AuthAgent().run(_state(
            user_id=USER_EMPTY,
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.LOCKED
        assert (
            out["escalation_context"].reason == EscalationReason.AUTH_MISCONFIGURED
        )
        # No retry was wasted.
        assert out["auth_state"].failed_attempts == 0

    def test_missing_user_id_locks_with_misconfigured(self) -> None:
        out = AuthAgent().run(_state(
            user_id=None,
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.LOCKED
        assert (
            out["escalation_context"].reason == EscalationReason.AUTH_MISCONFIGURED
        )


# ---------------------------------------------------------------------------
# Tier 3: evaluate response
# ---------------------------------------------------------------------------

def _challenge(challenge_type: ChallengeType, plaintext: str) -> AuthChallenge:
    return AuthChallenge(
        challenge_type=challenge_type,
        prompt_text=f"Please provide your {challenge_type.value}?",
        expected_hash=hash_answer(challenge_type.value, plaintext),
        max_attempts=settings.max_auth_retries,
    )


class TestEvaluateResponse:
    def test_correct_zip_promotes_level(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch,
            verification_input="94107",
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED
        assert out["auth_state"].current_level == AuthLevel.SOFT
        assert out["auth_state"].failed_attempts == 0
        assert out["auth_state"].verified_at is not None
        assert out["scratch"]["pending_auth_challenge"] == {}

    def test_zip_with_extension_normalised(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input="94107-1234",
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED

    @pytest.mark.parametrize("user_input", [
        "4321", " 4321 ", "*4321", "***4321", "4-3-2-1", "  4321  ",
    ])
    def test_ssn_normalisation(self, user_input: str) -> None:
        ch = _challenge(ChallengeType.LAST_4_SSN, "4321")
        out = AuthAgent().run(_state(
            pending=ch, verification_input=user_input,
            required_level=AuthLevel.STRONG,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED, user_input

    @pytest.mark.parametrize("dob_input", [
        "06/12/1985", "06-12-1985", "1985-06-12", "1985/06/12",
        "06121985", "19850612",
    ])
    def test_dob_normalisation(self, dob_input: str) -> None:
        ch = _challenge(ChallengeType.DATE_OF_BIRTH, "1985-06-12")
        out = AuthAgent().run(_state(
            pending=ch, verification_input=dob_input,
            required_level=AuthLevel.STRONG,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED, dob_input

    def test_wrong_answer_increments_attempts(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input="00000",
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.FAILED
        assert out["auth_state"].failed_attempts == 1
        # Challenge is retained for another attempt.
        assert out["scratch"]["pending_auth_challenge"]["challenge_type"] == "ZIP_CODE"

    def test_third_wrong_answer_locks(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            auth_state=AuthState(failed_attempts=settings.max_auth_retries - 1),
            pending=ch, verification_input="00000",
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.LOCKED
        assert out["escalation_context"].reason == EscalationReason.AUTH_LOCKED

    def test_no_input_re_presents(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input=None,
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.PENDING
        assert out["scratch"]["pending_auth_challenge"]["challenge_type"] == "ZIP_CODE"

    def test_history_fallback_when_input_blank(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input="",
            message_history=[{"role": "user", "content": "94107"}],
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED

    def test_history_ignored_when_role_not_user(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input=None,
            message_history=[{"role": "assistant", "content": "94107"}],
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.PENDING

    def test_typed_input_takes_priority_over_history(self) -> None:
        ch = _challenge(ChallengeType.ZIP_CODE, "94107")
        out = AuthAgent().run(_state(
            pending=ch, verification_input="00000",
            message_history=[{"role": "user", "content": "94107"}],
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.FAILED


# ---------------------------------------------------------------------------
# Tier 4: OTP path
# ---------------------------------------------------------------------------

class TestOtpFlow:
    def test_otp_correct_within_ttl_verifies(self) -> None:
        # Issue.
        out = AuthAgent().run(_state(required_level=AuthLevel.ENHANCED))
        ch = out["scratch"]["pending_auth_challenge"]
        # Fetch the plaintext code from the demo channel.
        last = auth_client.otp_channel().get_last_otp_for_demo(USER_GOOD)
        assert last is not None
        code, _ = last
        # Submit.
        ch_obj = AuthChallenge(**ch)
        out2 = AuthAgent().run(_state(
            pending=ch_obj, verification_input=code,
            required_level=AuthLevel.ENHANCED,
        ))
        assert out2["auth_status"] == AuthStatus.VERIFIED

    def test_otp_expired_does_not_count_against_attempts(self) -> None:
        ch = AuthChallenge(
            challenge_type=ChallengeType.ONE_TIME_CODE,
            prompt_text="Code?",
            expected_hash=hash_answer("ONE_TIME_CODE", "123456"),
            max_attempts=3,
            expires_at=datetime.now(timezone.utc) - timedelta(seconds=5),
        )
        out = AuthAgent().run(_state(
            pending=ch, verification_input="123456",
            required_level=AuthLevel.ENHANCED,
        ))
        assert out["auth_status"] == AuthStatus.FAILED
        assert out["auth_state"].failed_attempts == 0
        # Pending cleared so a fresh OTP is issued next turn.
        assert out["scratch"]["pending_auth_challenge"] == {}


# ---------------------------------------------------------------------------
# Tier 5: expedited path + reverify TTL + fraud signals
# ---------------------------------------------------------------------------

class TestExpeditedAndTtl:
    def _profile(self, hours_ago: float = 1.0,
                 level: str = "SOFT",
                 device: str | None = None) -> dict:
        ts = (datetime.now(timezone.utc)
              - timedelta(hours=hours_ago)).isoformat()
        prof: dict = {"last_verified_at": ts, "last_verified_level": level}
        if device:
            prof["last_device_fingerprint"] = device
        return prof

    def test_expedited_grants_soft(self) -> None:
        out = AuthAgent().run(_state(
            user_profile=self._profile(hours_ago=1),
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.VERIFIED
        assert "pending_auth_challenge" not in (out.get("scratch") or {})

    def test_expedited_blocked_when_too_old(self) -> None:
        out = AuthAgent().run(_state(
            user_profile=self._profile(hours_ago=48),
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.PENDING

    def test_expedited_blocked_by_fraud(self) -> None:
        out = AuthAgent().run(_state(
            user_profile=self._profile(hours_ago=1),
            required_level=AuthLevel.SOFT,
            fraud_risk_score=0.95,
        ))
        assert out["auth_status"] == AuthStatus.PENDING

    def test_expedited_blocked_by_device_mismatch(self) -> None:
        out = AuthAgent().run(_state(
            user_profile=self._profile(hours_ago=1, device="device-A"),
            device_fingerprint="device-B",
            required_level=AuthLevel.SOFT,
        ))
        assert out["auth_status"] == AuthStatus.PENDING

    def test_expedited_not_offered_for_strong(self) -> None:
        out = AuthAgent().run(_state(
            user_profile=self._profile(hours_ago=1, level="STRONG"),
            required_level=AuthLevel.STRONG,
        ))
        # No fall-through grant for STRONG/ENHANCED — must challenge.
        assert out["auth_status"] == AuthStatus.PENDING

    def test_reverify_ttl_expired_issues_fresh_challenge(
        self, monkeypatch
    ) -> None:
        # verified_at far in the past → should re-challenge.
        old = datetime.now(timezone.utc) - timedelta(hours=24)
        out = AuthAgent().run(_state(
            auth_state=AuthState(
                current_level=AuthLevel.STRONG,
                verified_at=old,
            ),
            required_level=AuthLevel.STRONG,
        ))
        assert out["auth_status"] == AuthStatus.PENDING
        assert out["scratch"]["pending_auth_challenge"]["challenge_type"] == "LAST_4_SSN"


# ---------------------------------------------------------------------------
# Tier 6: evaluator security primitive
# ---------------------------------------------------------------------------

class TestEvaluatorPrimitives:
    def test_uses_compare_digest(self, monkeypatch) -> None:
        from agents.auth_agent.v1 import evaluator
        called = {"n": 0}
        real = evaluator.hmac.compare_digest

        def spy(a, b):
            called["n"] += 1
            return real(a, b)

        monkeypatch.setattr(evaluator.hmac, "compare_digest", spy)
        evaluator.evaluate(
            "ZIP_CODE", "94107", "sid",
            hash_answer("ZIP_CODE", "94107"),
        )
        assert called["n"] == 1

    def test_empty_expected_hash_always_false(self) -> None:
        from agents.auth_agent.v1 import evaluator
        assert evaluator.evaluate("ZIP_CODE", "any", "sid", "") is False
