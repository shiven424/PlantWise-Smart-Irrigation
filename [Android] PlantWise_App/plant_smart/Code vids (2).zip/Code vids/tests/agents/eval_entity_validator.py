"""Golden-set evaluation for the Entity Validator against the REAL LLM.

For each fixture:
  - Build state with the configured intent + entities + account_context
  - Run the full agent (real LLM called for customer messages)
  - Verify expected_status, the expected violation fires, severity, and
    that the LLM-authored customer_message:
      * is non-empty and reasonably short (<= 400 chars)
      * contains at least one substring from `must_contain_any`
      * contains none of the forbidden substrings in `must_not_contain`
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from agents.entity_validator.v1.agent import EntityValidatorAgent
from agents.intent_agent.v1.taxonomy import lookup_intent
from schemas.enums import EntityType, IntentChangeType
from schemas.primitives import EntityRecord, IntentRecord, SessionContext


FIXTURES_PATH = Path(__file__).parent / "golden_validations.json"


def _new_session() -> SessionContext:
    return SessionContext(
        session_id=uuid4(), user_id="eval-user", channel="eval",
        client_tier="STANDARD", locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _intent_for(sub_intent: str) -> IntentRecord:
    defn = lookup_intent(sub_intent)
    return IntentRecord(
        intent_id=defn.intent_id,
        service_domain=defn.domain,
        sub_intent=defn.sub_intent_id,
        confidence=0.95,
        change_type=IntentChangeType.NEW,
        requires_auth_level=defn.auth_level,
        is_transactional=defn.is_transactional,
        escalation_flag=defn.escalation_flag,
        required_slots=list(defn.required_slots),
        turn_number=1,
    )


def _build_entity(slot_name: str, type_str: str, value: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType(type_str),
        is_pii=False,
        slot_name=slot_name,
        display_value=value,
        confidence=0.95,
    )


def run_eval(fixtures: list[dict], only_id: str | None = None) -> dict:
    agent = EntityValidatorAgent()
    fx_results = []
    latencies: list[float] = []
    msg_total = msg_pass = 0
    rule_total = rule_pass = 0
    status_total = status_pass = 0

    for fx in fixtures:
        if only_id and fx["id"] != only_id:
            continue

        entities = {
            slot: _build_entity(
                cfg.get("slot_name", slot), cfg["type"], cfg["value"],
            )
            for slot, cfg in fx.get("entities", {}).items()
        }
        intent = _intent_for(fx["sub_intent"])

        state = {
            "session": _new_session(),
            "message_history": [{"role": "user", "content": "eval"}],
            "intent_stack": [intent],
            "active_intent_id": intent.intent_id,
            "entity_memory": entities,
            "validated_entities": {},
            "account_context": fx.get("account_context", {}),
            "current_turn": 1,
            "user_profile": {},
        }

        t0 = time.perf_counter()
        try:
            out = agent.run(state)
            err = None
        except Exception as e:
            out = {"validation_status": "ERROR", "violations": []}
            err = repr(e)
        dt_ms = (time.perf_counter() - t0) * 1000
        latencies.append(dt_ms)

        # Status check
        actual_status = (
            out["validation_status"].value
            if hasattr(out["validation_status"], "value")
            else str(out["validation_status"])
        )
        status_ok = actual_status == fx["expected_status"]
        status_total += 1
        status_pass += int(status_ok)

        # Find target violation
        violations = out.get("violations", [])
        target = next(
            (v for v in violations if v.rule_id == fx["expected_rule_id"]), None,
        )
        rule_ok = target is not None and target.severity.value == fx["expected_severity"]
        rule_total += 1
        rule_pass += int(rule_ok)

        # Message content checks
        msg = (target.customer_message if target else "") or ""
        contain_any = fx.get("must_contain_any", [])
        must_not = fx.get("must_not_contain", [])
        contains_ok = (
            not contain_any
            or any(sub.lower() in msg.lower() for sub in contain_any)
        )
        forbidden_ok = all(sub.lower() not in msg.lower() for sub in must_not)
        not_empty = bool(msg.strip())
        not_too_long = len(msg) <= 400
        msg_ok = contains_ok and forbidden_ok and not_empty and not_too_long
        msg_total += 1
        msg_pass += int(msg_ok)

        fx_results.append({
            "id": fx["id"],
            "ms": round(dt_ms, 1),
            "error": err,
            "expected_status": fx["expected_status"],
            "actual_status": actual_status,
            "status_ok": status_ok,
            "rule_id": fx["expected_rule_id"],
            "rule_fired": target is not None,
            "severity_ok": target is not None and target.severity.value == fx["expected_severity"],
            "rule_ok": rule_ok,
            "message": msg,
            "msg_ok": msg_ok,
            "contains_ok": contains_ok,
            "forbidden_ok": forbidden_ok,
            "not_empty": not_empty,
            "not_too_long": not_too_long,
            "must_contain_any": contain_any,
            "must_not_contain": must_not,
        })

    def _pct(xs, p):
        if not xs:
            return 0.0
        s = sorted(xs)
        k = max(0, min(len(s) - 1, int(round((p / 100.0) * (len(s) - 1)))))
        return s[k]

    return {
        "fixture_count": len(fx_results),
        "fixture_pass": sum(1 for f in fx_results if f["status_ok"] and f["rule_ok"] and f["msg_ok"]),
        "status_accuracy": round(status_pass / status_total, 3) if status_total else 0.0,
        "rule_fire_accuracy": round(rule_pass / rule_total, 3) if rule_total else 0.0,
        "message_accuracy": round(msg_pass / msg_total, 3) if msg_total else 0.0,
        "latency_p50_ms": round(_pct(latencies, 50), 1),
        "latency_p95_ms": round(_pct(latencies, 95), 1),
        "fixtures": fx_results,
    }


def print_report(report: dict, verbose: bool = False) -> None:
    print("=" * 72)
    print(
        f"Entity Validator Eval — {report['fixture_pass']}/{report['fixture_count']} "
        f"fixtures fully correct"
    )
    print(f"  validation_status accuracy : {report['status_accuracy']:.1%}")
    print(f"  rule fire+severity accy    : {report['rule_fire_accuracy']:.1%}")
    print(f"  customer message accuracy  : {report['message_accuracy']:.1%}")
    print(f"  latency p50/p95            : {report['latency_p50_ms']}ms / {report['latency_p95_ms']}ms")

    failures = [f for f in report["fixtures"] if not (f["status_ok"] and f["rule_ok"] and f["msg_ok"])]
    if failures:
        print("-" * 72)
        print(f"FAILED FIXTURES ({len(failures)}):")
        for f in failures:
            print(f"\n  [{f['id']}]")
            if not f["status_ok"]:
                print(f"     status: expected {f['expected_status']!r}, got {f['actual_status']!r}")
            if not f["rule_fired"]:
                print(f"     rule {f['rule_id']!r} did NOT fire")
            elif not f["severity_ok"]:
                print(f"     rule {f['rule_id']} fired but severity mismatch")
            if not f["msg_ok"]:
                if not f["not_empty"]:
                    print("     message: empty")
                if not f["not_too_long"]:
                    print(f"     message: too long ({len(f['message'])} chars)")
                if not f["contains_ok"]:
                    print(f"     message missing any of {f['must_contain_any']}")
                if not f["forbidden_ok"]:
                    print(f"     message contains forbidden substring from {f['must_not_contain']}")
                print(f"     msg = {f['message']!r}")
    if verbose:
        print("-" * 72)
        for f in report["fixtures"]:
            print(f"  [{f['id']}] status={f['actual_status']} rule_fired={f['rule_fired']}")
            print(f"     msg = {f['message']!r}")
    print("=" * 72)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixtures", default=str(FIXTURES_PATH))
    ap.add_argument("--only-id", default=None)
    ap.add_argument("--min-status", type=float, default=1.0)
    ap.add_argument("--min-rule", type=float, default=1.0)
    ap.add_argument("--min-message", type=float, default=0.85)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
    report = run_eval(fixtures, only_id=args.only_id)

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print_report(report, verbose=args.verbose)

    pass_gate = (
        report["status_accuracy"] >= args.min_status
        and report["rule_fire_accuracy"] >= args.min_rule
        and report["message_accuracy"] >= args.min_message
    )
    return 0 if pass_gate else 1


if __name__ == "__main__":
    sys.exit(main())
