"""Unit tests for supervisor hard rules — focused on the H1 escalation
guard that suppresses classifier-flag escalations during a live auth
challenge.

These are pure-Python tests; no LLM is involved.
"""
from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

import pytest

from agents.supervisor.v1.hard_rules import evaluate_hard_rules
from schemas.enums import (
    ActionType,
    AuthLevel,
    AuthStatus,
    EscalationReason,
    MessageDomain,
)
from schemas.primitives import (
    AgentOutputSummary,
    AuthState,
    EscalationContext,
    SessionContext,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _session() -> SessionContext:
    return SessionContext(
        session_id=uuid4(),
        user_id="test-user",
        channel="web",
        client_tier="STANDARD",
        locale="en-US",
        started_at=datetime.now(timezone.utc),
    )


def _summary(escalation: bool) -> AgentOutputSummary:
    return AgentOutputSummary(
        classifier_domain=MessageDomain.TRANSACTIONAL,
        classifier_confidence=0.95,
        classifier_escalation=escalation,
        last_message="4321",
    )


def _verifying_state(*, classifier_escalation: bool = True) -> dict:
    """A state mid-auth-challenge with verification_input set — exactly the
    shape produced by main.process_turn on a challenge-answer turn."""
    return {
        "session": _session(),
        "message_history": [
            {"role": "assistant", "content": "What are the last 4 digits of your SSN?"},
            {"role": "user", "content": "4321"},
        ],
        "auth_status": AuthStatus.PENDING,
        "auth_state": AuthState(
            current_level=AuthLevel.SESSION,
            failed_attempts=0,
            is_locked=False,
        ),
        "required_auth_level": AuthLevel.STRONG,
        "verification_input": "4321",
        "scratch": {
            "pending_auth_challenge": {
                "challenge_type": "LAST_4_SSN",
                "expected_hash": "a" * 64,
                "max_attempts": 3,
            },
        },
        "classifier_escalation_flag": classifier_escalation,
        "classifier_escalation_reason": "human_agent_request" if classifier_escalation else None,
        "escalation_requested": False,
    }


# ---------------------------------------------------------------------------
# H1 — Auth-verification guard
# ---------------------------------------------------------------------------

class TestH1AuthVerificationGuard:
    def test_classifier_escalation_suppressed_during_live_challenge(self):
        """The classifier-flag branch of H1 must NOT fire when the user
        is mid-challenge — otherwise auth is bypassed by an LLM
        misclassification on a bare numeric token."""
        state = _verifying_state(classifier_escalation=True)
        plan = evaluate_hard_rules(state, _summary(escalation=True))

        # H1 must not have fired with action_type=ESCALATE.
        # Either H2 (auth gate) returns a different ActionPlan, or no
        # rule fires (None).  Either way: NOT escalation from H1.
        assert plan is None or plan.hard_rule_fired != "H1", (
            f"H1 incorrectly fired during live auth challenge: {plan!r}"
        )
        if plan is not None:
            assert plan.action_type != ActionType.ESCALATE, (
                f"Expected non-escalation plan, got {plan.action_type!r}"
            )

    def test_explicit_escalation_requested_still_fires_during_challenge(self):
        """``escalation_requested=True`` is set deterministically (e.g. by
        entity_validator on a BLOCKING violation) — this branch must
        ALWAYS fire, even mid-auth, otherwise auth becomes a black hole."""
        state = _verifying_state(classifier_escalation=False)
        state["escalation_requested"] = True
        state["escalation_context"] = EscalationContext(
            reason=EscalationReason.BLOCKING_VIOLATION,
            triggered_by="entity_validator.test",
        )

        plan = evaluate_hard_rules(state, _summary(escalation=False))

        assert plan is not None, "H1 should have fired on explicit escalation_requested"
        assert plan.action_type == ActionType.ESCALATE
        assert plan.hard_rule_fired == "H1"
        assert plan.escalation_context.reason == EscalationReason.BLOCKING_VIOLATION

    def test_classifier_escalation_fires_when_not_in_challenge(self):
        """Outside the auth-verification window, H1 still works."""
        state = _verifying_state(classifier_escalation=True)
        # Break the verification predicate: no pending challenge.
        state["scratch"] = {}
        state["verification_input"] = None

        plan = evaluate_hard_rules(state, _summary(escalation=True))

        assert plan is not None
        assert plan.action_type == ActionType.ESCALATE
        assert plan.hard_rule_fired == "H1"

    def test_classifier_escalation_fires_after_verification_succeeds(self):
        """Once auth is VERIFIED, the predicate flips False → H1 resumes
        normal behavior."""
        state = _verifying_state(classifier_escalation=True)
        state["auth_status"] = AuthStatus.VERIFIED
        state["auth_state"] = AuthState(
            current_level=AuthLevel.STRONG,
            failed_attempts=0,
            is_locked=False,
        )

        plan = evaluate_hard_rules(state, _summary(escalation=True))

        # Predicate: auth_status != PENDING -> False -> H1 fires.
        # But H2 (locked / auth gate) may not fire either, so H1 is the
        # one we expect.
        assert plan is not None
        assert plan.action_type == ActionType.ESCALATE
        assert plan.hard_rule_fired == "H1"

    def test_predicate_requires_verification_input(self):
        """If verification_input is None (e.g. user spoke before any
        challenge was issued and the classifier still flagged
        escalation), the guard does NOT engage."""
        state = _verifying_state(classifier_escalation=True)
        state["verification_input"] = None  # break predicate

        plan = evaluate_hard_rules(state, _summary(escalation=True))

        assert plan is not None
        assert plan.hard_rule_fired == "H1"

    def test_predicate_requires_pending_challenge_with_hash(self):
        """A scratch dict with an empty pending_auth_challenge does
        NOT engage the guard (this is the conversation-start case)."""
        state = _verifying_state(classifier_escalation=True)
        state["scratch"] = {"pending_auth_challenge": {}}  # no expected_hash

        plan = evaluate_hard_rules(state, _summary(escalation=True))

        assert plan is not None
        assert plan.hard_rule_fired == "H1"
