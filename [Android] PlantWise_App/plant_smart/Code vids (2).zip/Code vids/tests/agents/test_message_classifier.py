"""Comprehensive unit tests for MessageClassifierAgent.

These tests mock the LLM, so they are fast, deterministic, and run offline.
They exercise every branch of the agent's logic:

  * Empty / whitespace messages         (M9 guard)
  * Distress – immediate keywords       (zero-latency escalation)
  * Distress – ambiguous keywords       (LLM-confirmed true positive)
  * Distress – ambiguous keywords       (LLM-rejected false positive)
  * Distress keyword case-insensitivity
  * Each MessageDomain returned by LLM
  * Confidence-based downgrade (TRANSACTIONAL threshold = 0.50)
  * Confidence-based downgrade (default threshold = 0.70)
  * ESCALATE never downgraded regardless of confidence
  * CHITCHAT never downgraded regardless of confidence
  * LLM returns extra/unknown JSON keys (Fix C1: extra="ignore")
  * LLM total failure – fallback path
  * escalation_flag / escalation_reason passthrough
  * History truncation to last 6 messages
  * Health check
"""
from __future__ import annotations

from typing import Any
from unittest.mock import patch

import pytest

from agents.message_classifier.v1 import agent as classifier_module
from agents.message_classifier.v1.agent import (
    MessageClassifierAgent,
    _DistressConfirmation,
    _LLMClassifierRaw,
)
from schemas.enums import MessageDomain


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_llm(domain: MessageDomain, confidence: float = 0.95, **extra: Any):
    """Return a side_effect for `call_llm` that yields a classifier response."""
    def _side_effect(*, response_model, fallback, **_):
        if response_model is _DistressConfirmation:
            # Default: confirm distress when asked
            return _DistressConfirmation(is_genuine_distress=True)
        return _LLMClassifierRaw(
            domain=domain,
            confidence=confidence,
            escalation_flag=extra.get("escalation_flag", False),
            escalation_reason=extra.get("escalation_reason"),
            reasoning=extra.get("reasoning"),
        )
    return _side_effect


def _mock_distress_confirmation(is_genuine: bool, classifier_domain=MessageDomain.INFORMATIONAL):
    """side_effect for the ambiguous-distress flow.

    First call → _DistressConfirmation. Subsequent classifier call returns INFORMATIONAL.
    """
    def _side_effect(*, response_model, fallback, **_):
        if response_model is _DistressConfirmation:
            return _DistressConfirmation(is_genuine_distress=is_genuine)
        return _LLMClassifierRaw(
            domain=classifier_domain,
            confidence=0.95,
        )
    return _side_effect


@pytest.fixture
def patched_call_llm():
    """Patch the call_llm symbol used inside the classifier module."""
    with patch.object(classifier_module, "call_llm") as m:
        yield m


@pytest.fixture
def agent() -> MessageClassifierAgent:
    return MessageClassifierAgent()


# ---------------------------------------------------------------------------
# 1. Empty / whitespace guard (M9)
# ---------------------------------------------------------------------------

class TestEmptyMessageGuard:
    def test_empty_string_returns_chitchat_without_llm(self, agent, state_factory, patched_call_llm):
        state = state_factory("")
        result = agent.run(state)
        assert result["message_domain"] == MessageDomain.CHITCHAT
        assert result["classifier_confidence"] == 1.0
        assert result["classifier_escalation_flag"] is False
        patched_call_llm.assert_not_called()

    @pytest.mark.parametrize("ws", ["   ", "\n", "\t\t", "  \n  \t  "])
    def test_whitespace_only_returns_chitchat(self, agent, state_factory, patched_call_llm, ws):
        result = agent.run(state_factory(ws))
        assert result["message_domain"] == MessageDomain.CHITCHAT
        patched_call_llm.assert_not_called()

    def test_no_history_at_all(self, agent, session, patched_call_llm):
        state = {"session": session, "message_history": [], "current_turn": 0}
        result = agent.run(state)
        assert result["message_domain"] == MessageDomain.CHITCHAT
        patched_call_llm.assert_not_called()


# ---------------------------------------------------------------------------
# 2. Distress – immediate keywords (zero-latency)
# ---------------------------------------------------------------------------

class TestImmediateDistress:
    @pytest.mark.parametrize("msg", [
        "I want to kill myself",
        "I'm thinking about suicide",
        "feeling suicidal today",
        "I might self harm",
        "I just want to die",
        "I'm going to hurt myself",
        # case-insensitive
        "I WANT TO KILL MYSELF",
        "Suicide is on my mind",
    ])
    def test_immediate_distress_escalates_without_llm(self, agent, state_factory, patched_call_llm, msg):
        result = agent.run(state_factory(msg))
        assert result["message_domain"] == MessageDomain.ESCALATE
        assert result["classifier_escalation_flag"] is True
        assert result["classifier_escalation_reason"] == "distress_signal"
        assert result["classifier_confidence"] == 1.0
        # No LLM call at all for unambiguous distress
        patched_call_llm.assert_not_called()


# ---------------------------------------------------------------------------
# 3. Distress – ambiguous keywords (LLM gating)
# ---------------------------------------------------------------------------

class TestAmbiguousDistress:
    @pytest.mark.parametrize("msg", [
        "I just can't go on like this anymore",
        "I want to end it all",
        "I might end my life soon",
        "there's no reason to live",
    ])
    def test_ambiguous_distress_confirmed_escalates(
        self, agent, state_factory, patched_call_llm, msg,
    ):
        patched_call_llm.side_effect = _mock_distress_confirmation(is_genuine=True)
        result = agent.run(state_factory(msg))
        assert result["message_domain"] == MessageDomain.ESCALATE
        assert result["classifier_escalation_reason"] == "distress_signal"
        # Exactly one LLM call: the distress confirmation
        assert patched_call_llm.call_count == 1

    @pytest.mark.parametrize("msg", [
        "I can't go on vacation until my loan is approved",
        "I want to end it all and start fresh with a new portfolio",
        "There's no reason to live with this old plan, let's roll over",
    ])
    def test_ambiguous_distress_rejected_falls_through(
        self, agent, state_factory, patched_call_llm, msg,
    ):
        patched_call_llm.side_effect = _mock_distress_confirmation(
            is_genuine=False, classifier_domain=MessageDomain.TRANSACTIONAL,
        )
        result = agent.run(state_factory(msg))
        assert result["message_domain"] == MessageDomain.TRANSACTIONAL
        # Two calls: distress confirmation + classification
        assert patched_call_llm.call_count == 2

    def test_word_court_does_not_trigger_distress(self, agent, state_factory, patched_call_llm):
        """'courtesy' must NOT match any distress keyword (false-positive guard)."""
        patched_call_llm.side_effect = _mock_llm(MessageDomain.INFORMATIONAL)
        result = agent.run(state_factory("As a courtesy, can you explain RMDs?"))
        assert result["message_domain"] == MessageDomain.INFORMATIONAL
        # Only classifier call — no distress confirmation
        assert patched_call_llm.call_count == 1


# ---------------------------------------------------------------------------
# 4. LLM classification – each domain
# ---------------------------------------------------------------------------

class TestDomainClassification:
    @pytest.mark.parametrize("domain", list(MessageDomain))
    def test_high_confidence_passes_through(self, agent, state_factory, patched_call_llm, domain):
        patched_call_llm.side_effect = _mock_llm(domain, confidence=0.95)
        result = agent.run(state_factory("some user message"))
        assert result["message_domain"] == domain
        assert result["classifier_confidence"] == 0.95


# ---------------------------------------------------------------------------
# 5. Confidence-based downgrade
# ---------------------------------------------------------------------------

class TestConfidenceDowngrade:
    def test_low_confidence_informational_stays_informational(self, agent, state_factory, patched_call_llm):
        # INFORMATIONAL below 0.70 -> still INFORMATIONAL (because downgrade target is INFORMATIONAL)
        patched_call_llm.side_effect = _mock_llm(MessageDomain.INFORMATIONAL, confidence=0.40)
        result = agent.run(state_factory("ambiguous text"))
        assert result["message_domain"] == MessageDomain.INFORMATIONAL

    def test_low_confidence_transactional_below_050_downgrades(self, agent, state_factory, patched_call_llm):
        patched_call_llm.side_effect = _mock_llm(MessageDomain.TRANSACTIONAL, confidence=0.30)
        result = agent.run(state_factory("maybe a transaction"))
        assert result["message_domain"] == MessageDomain.INFORMATIONAL

    def test_transactional_at_threshold_not_downgraded(self, agent, state_factory, patched_call_llm):
        # 0.50 == threshold; should NOT downgrade (strict <)
        patched_call_llm.side_effect = _mock_llm(MessageDomain.TRANSACTIONAL, confidence=0.50)
        result = agent.run(state_factory("borderline"))
        assert result["message_domain"] == MessageDomain.TRANSACTIONAL

    def test_transactional_above_threshold_not_downgraded(self, agent, state_factory, patched_call_llm):
        patched_call_llm.side_effect = _mock_llm(MessageDomain.TRANSACTIONAL, confidence=0.51)
        result = agent.run(state_factory("withdraw money"))
        assert result["message_domain"] == MessageDomain.TRANSACTIONAL

    def test_escalate_never_downgraded(self, agent, state_factory, patched_call_llm):
        # ESCALATE at 0.10 confidence — must remain ESCALATE.
        patched_call_llm.side_effect = _mock_llm(
            MessageDomain.ESCALATE, confidence=0.10,
            escalation_flag=True, escalation_reason="legal_threat",
        )
        result = agent.run(state_factory("I'll sue you"))
        assert result["message_domain"] == MessageDomain.ESCALATE
        assert result["classifier_escalation_flag"] is True
        assert result["classifier_escalation_reason"] == "legal_threat"

    def test_chitchat_never_downgraded(self, agent, state_factory, patched_call_llm):
        patched_call_llm.side_effect = _mock_llm(MessageDomain.CHITCHAT, confidence=0.20)
        result = agent.run(state_factory("hello"))
        assert result["message_domain"] == MessageDomain.CHITCHAT


# ---------------------------------------------------------------------------
# 6. Permissive parsing (Fix C1)
# ---------------------------------------------------------------------------

class TestPermissiveLLMParsing:
    def test_extra_keys_ignored_no_fallback(self, agent, state_factory):
        """Verifies _LLMClassifierRaw uses extra='ignore' (Fix C1)."""
        # _LLMClassifierRaw should accept extra keys silently.
        raw = _LLMClassifierRaw.model_validate({
            "domain": "TRANSACTIONAL",
            "confidence": 0.91,
            "escalation_flag": False,
            "escalation_reason": None,
            "reasoning": "user wants to act",
            # Unknown keys that real LLMs sometimes include:
            "raw_reasoning": "longer chain of thought",
            "model_version": "v3",
            "trace_id": "abc-123",
        })
        assert raw.domain == MessageDomain.TRANSACTIONAL
        assert raw.confidence == 0.91


# ---------------------------------------------------------------------------
# 7. LLM total failure → fallback
# ---------------------------------------------------------------------------

class TestLLMFallback:
    def test_fallback_returned_when_call_llm_returns_fallback(self, agent, state_factory, patched_call_llm):
        # Simulate call_llm returning the provided fallback (its real behavior on error).
        def _raise_through(*, response_model, fallback, **_):
            return fallback
        patched_call_llm.side_effect = _raise_through

        result = agent.run(state_factory("anything"))
        assert result["message_domain"] == MessageDomain.INFORMATIONAL
        # The fallback uses confidence=0.50 — INFORMATIONAL stays INFORMATIONAL
        assert result["classifier_confidence"] == 0.50


# ---------------------------------------------------------------------------
# 8. Escalation reason passthrough
# ---------------------------------------------------------------------------

class TestEscalationPassthrough:
    @pytest.mark.parametrize("reason", [
        "human_agent_request",
        "legal_threat",
        "personalised_advice",
        "tax_advice",
    ])
    def test_escalation_reason_propagates(self, agent, state_factory, patched_call_llm, reason):
        patched_call_llm.side_effect = _mock_llm(
            MessageDomain.ESCALATE, confidence=0.92,
            escalation_flag=True, escalation_reason=reason,
        )
        result = agent.run(state_factory("…"))
        assert result["message_domain"] == MessageDomain.ESCALATE
        assert result["classifier_escalation_flag"] is True
        assert result["classifier_escalation_reason"] == reason


# ---------------------------------------------------------------------------
# 9. History truncation (prompt builder receives last 6 only)
# ---------------------------------------------------------------------------

class TestHistoryHandling:
    def test_long_history_truncated_to_last_six(self, agent, state_factory, patched_call_llm):
        captured: dict = {}

        def _capture(*, system_prompt, user_prompt, response_model, fallback, **_):
            if response_model is _LLMClassifierRaw:
                captured["user_prompt"] = user_prompt
                return _LLMClassifierRaw(domain=MessageDomain.INFORMATIONAL, confidence=0.9)
            return fallback

        patched_call_llm.side_effect = _capture

        history = [
            {"role": "user" if i % 2 == 0 else "assistant", "content": f"msg-{i}"}
            for i in range(20)
        ]
        agent.run(state_factory("current question", history=history))

        prompt = captured["user_prompt"]
        # Agent slices history[-6:] before passing to prompt builder. Including
        # the just-appended current message that's 6 entries: msg-15..msg-19 +
        # the current user question. msg-14 and earlier must NOT appear.
        for i in range(15, 20):
            assert f"msg-{i}" in prompt
        assert "current question" in prompt
        assert "msg-14" not in prompt
        assert "msg-0" not in prompt


# ---------------------------------------------------------------------------
# 10. Health check
# ---------------------------------------------------------------------------

class TestHealthCheck:
    def test_health_check_returns_bool(self, agent):
        # Should not raise; type must be bool
        assert isinstance(agent.health_check(), bool)


# ---------------------------------------------------------------------------
# 11. Auth-verification bypass (Step 1b)
# ---------------------------------------------------------------------------

class TestAuthVerificationBypass:
    """When the user is mid-challenge and verification_input is set, the
    classifier MUST short-circuit to TRANSACTIONAL without calling the
    LLM.  Distress keywords still take precedence (safety > flow)."""

    @staticmethod
    def _verifying_state(session, message: str) -> dict:
        from schemas.enums import AuthLevel, AuthStatus
        from schemas.primitives import AuthState
        return {
            "session": session,
            "message_history": [
                {"role": "assistant", "content": "What are the last 4 of your SSN?"},
                {"role": "user", "content": message},
            ],
            "current_turn": 2,
            "auth_status": AuthStatus.PENDING,
            "auth_state": AuthState(
                current_level=AuthLevel.SESSION,
                failed_attempts=0,
                is_locked=False,
            ),
            "required_auth_level": AuthLevel.STRONG,
            "verification_input": message,
            "scratch": {
                "pending_auth_challenge": {
                    "challenge_type": "LAST_4_SSN",
                    "expected_hash": "a" * 64,
                    "max_attempts": 3,
                },
            },
        }

    @pytest.mark.parametrize("token", ["4321", "94107", "1985-06-12", "rivera", "sure", "123456"])
    def test_bypass_returns_transactional_without_llm(
        self, agent, session, patched_call_llm, token,
    ):
        state = self._verifying_state(session, token)
        result = agent.run(state)
        assert result["message_domain"] == MessageDomain.TRANSACTIONAL
        assert result["classifier_confidence"] == 1.0
        assert result["classifier_escalation_flag"] is False
        assert result["classifier_escalation_reason"] is None
        patched_call_llm.assert_not_called()

    def test_bypass_does_not_engage_at_conversation_start(
        self, agent, state_factory, patched_call_llm,
    ):
        """Empty scratch → predicate False → LLM runs as usual."""
        patched_call_llm.side_effect = _mock_llm(MessageDomain.CHITCHAT)
        result = agent.run(state_factory("hi"))
        assert result["message_domain"] == MessageDomain.CHITCHAT
        patched_call_llm.assert_called()  # LLM was invoked

    def test_bypass_does_not_engage_when_already_verified(
        self, agent, session, patched_call_llm,
    ):
        from schemas.enums import AuthLevel, AuthStatus
        from schemas.primitives import AuthState
        state = self._verifying_state(session, "4321")
        # Auth already succeeded; required level satisfied.
        state["auth_status"] = AuthStatus.VERIFIED
        state["auth_state"] = AuthState(
            current_level=AuthLevel.STRONG,
            failed_attempts=0,
            is_locked=False,
        )
        patched_call_llm.side_effect = _mock_llm(MessageDomain.TRANSACTIONAL)
        agent.run(state)
        patched_call_llm.assert_called()  # bypass off → LLM ran

    def test_bypass_does_not_engage_with_empty_pending_challenge(
        self, agent, session, patched_call_llm,
    ):
        """A scratch dict with `{}` for pending_auth_challenge (the
        post-clear state) does NOT engage the bypass."""
        state = self._verifying_state(session, "4321")
        state["scratch"] = {"pending_auth_challenge": {}}
        patched_call_llm.side_effect = _mock_llm(MessageDomain.TRANSACTIONAL)
        agent.run(state)
        patched_call_llm.assert_called()

    def test_distress_keyword_still_escalates_during_challenge(
        self, agent, session, patched_call_llm,
    ):
        """Safety keywords beat the auth-verification bypass."""
        state = self._verifying_state(session, "I want to kill myself")
        result = agent.run(state)
        assert result["message_domain"] == MessageDomain.ESCALATE
        assert result["classifier_escalation_reason"] == "distress_signal"
        patched_call_llm.assert_not_called()

