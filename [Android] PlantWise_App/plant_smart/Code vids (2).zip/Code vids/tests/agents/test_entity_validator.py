"""Deep unit-test suite for `EntityValidatorAgent`.

The validator is *deterministic* (pure-Python rules) plus one LLM call per
violation to author the customer-facing message. These tests:

  - Exercise EVERY rule in agents/entity_validator/v1/rules/ across pass /
    fail / boundary / missing-context paths
  - Verify the agent's overall control flow:
      * INCOMPLETE when no active intent
      * PASSED  when no rules apply
      * PASSED  when all rules pass
      * WARNING when only WARNING/INFO violations
      * FAILED  when a BLOCKING violation
      * INCOMPLETE when slot_gap is non-empty (and no blocking)
  - Verify validated_entities excludes blocked ones
  - Verify HITL disclosures emitted only for WARNING/INFO violations,
    requires_ack flag matches severity
  - Verify LLM customer-message integration + fallback on exception
  - Verify health_check
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from unittest.mock import patch
from uuid import uuid4

import pytest

import agents.entity_validator.v1.agent as validator_module
from agents.entity_validator.v1.agent import EntityValidatorAgent
from agents.entity_validator.v1.rules import ALL_RULES, get_rules_for_intent
from agents.entity_validator.v1.rules.estate_rules import (
    BeneficiaryPercentageRule,
    ERISASpousalConsentRule,
    TrustEINRule,
)
from agents.entity_validator.v1.rules.investment_rules import (
    AccreditedInvestorRule,
    ConcentrationRiskRule,
    SuitabilityCheckRule,
)
from agents.entity_validator.v1.rules.retirement_rules import (
    IRARolloverOncePerYearRule,
    IRC72PLoanLimitRule,
    IRC72PRepaymentTermRule,
    IRC72TEarlyWithdrawalRule,
    IRC402GContributionLimitRule,
    IRC415TotalLimitRule,
    RMDRequirementRule,
    RolloverSixtyDayRule,
)
from agents.entity_validator.v1.rules.tax_rules import (
    StateWithholdingRule,
    TaxAdviceDetectionRule,
    WithholdingElectionRule,
)
from regulatory.irs_limits import IRS_LIMITS
from schemas.enums import (
    AuthLevel,
    EntityType,
    IntentChangeType,
    ServiceDomain,
    ValidationSeverity,
    ValidationStatus,
)
from schemas.primitives import EntityRecord, IntentRecord, SessionContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TODAY = date.today()


def _entity(
    *,
    entity_type: EntityType,
    display_value: str,
    slot_name: str | None = None,
    is_pii: bool = False,
) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=entity_type,
        is_pii=is_pii,
        slot_name=slot_name,
        display_value=display_value,
        confidence=0.99,
    )


def _intent(sub_intent: str, required_slots: list[str] | None = None) -> IntentRecord:
    return IntentRecord(
        intent_id=f"INT_{sub_intent}",
        service_domain=ServiceDomain.RETIREMENT_SERVICES,
        sub_intent=sub_intent,
        confidence=0.95,
        change_type=IntentChangeType.NEW,
        requires_auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=False,
        required_slots=required_slots or [],
        turn_number=1,
    )


def _state(
    session: SessionContext,
    *,
    intent: IntentRecord | None,
    entities: dict[str, EntityRecord] | None = None,
    account_context: dict | None = None,
) -> dict:
    intent_stack = [intent] if intent else []
    return {
        "session": session,
        "message_history": [{"role": "user", "content": "test"}],
        "intent_stack": intent_stack,
        "active_intent_id": intent.intent_id if intent else None,
        "entity_memory": entities or {},
        "validated_entities": {},
        "account_context": account_context or {},
        "current_turn": 1,
        "user_profile": {},
    }


def _patch_llm(text: str = "Customer-facing message."):
    """Patch the validator's call_llm_text to return a canned string."""
    return patch.object(validator_module, "call_llm_text", return_value=text)


# ===========================================================================
# Top-level agent control flow
# ===========================================================================

class TestAgentControlFlow:
    def test_no_active_intent_returns_incomplete(self, session):
        st = _state(session, intent=None, entities={})
        with _patch_llm():
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.INCOMPLETE
        assert out["violations"] == []
        assert out["hitl_disclosures"] == []

    def test_intent_with_no_mapped_rules_passes(self, session):
        # ADDRESS_UPDATE has zero mapped rules
        st = _state(session, intent=_intent("ADDRESS_UPDATE"))
        with _patch_llm():
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.PASSED
        assert out["violations"] == []

    def test_all_rules_pass_returns_passed(self, session):
        intent = _intent("PLAN_LOAN_REQUEST", required_slots=[])
        # No loan_amount / repayment_term entities → both rules pass vacuously
        st = _state(session, intent=intent, entities={})
        with _patch_llm():
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.PASSED
        assert out["violations"] == []

    def test_blocking_violation_returns_failed_and_excludes_entity(self, session):
        loan = _entity(
            entity_type=EntityType.LOAN_AMOUNT,
            display_value="$45,000",
            slot_name="loan_amount",
        )
        intent = _intent("PLAN_LOAN_REQUEST")
        ctx = {"vested_balance": 20_000, "outstanding_loan_balance": 0}
        st = _state(session, intent=intent, entities={"loan_amount": loan}, account_context=ctx)
        with _patch_llm("Loan exceeds limit."):
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.FAILED
        assert any(v.rule_id == "IRS_72P_LOAN_LIMIT" for v in out["violations"])
        # Blocked entity excluded
        assert "loan_amount" not in out["validated_entities"]

    def test_warning_only_returns_warning_status(self, session):
        # WITHDRAWAL_REQUEST + early-age + EARLY distribution → 72(t) WARNING
        dist = _entity(
            entity_type=EntityType.DISTRIBUTION_TYPE,
            display_value="EARLY",
            slot_name="distribution_type",
        )
        intent = _intent("WITHDRAWAL_REQUEST")
        ctx = {"owner_age_years": 45}
        st = _state(session, intent=intent, entities={"distribution_type": dist}, account_context=ctx)
        with _patch_llm("Heads up: 10% penalty may apply."):
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.WARNING
        assert all(v.severity != ValidationSeverity.BLOCKING for v in out["violations"])
        # WARNING violations produce HITL disclosure with requires_ack=True
        assert out["hitl_disclosures"]
        d = out["hitl_disclosures"][0]
        assert d.requires_ack is True
        assert d.display_text  # filled by patched LLM

    def test_informational_only_emits_disclosure_no_ack(self, session):
        # RMD_CALCULATION + owner_age >= 73 → INFORMATIONAL violation only
        intent = _intent("RMD_CALCULATION")
        ctx = {"owner_age_years": 75}
        st = _state(session, intent=intent, account_context=ctx)
        with _patch_llm("RMD reminder."):
            out = EntityValidatorAgent().run(st)
        # No blocking, no warning, slot_gap empty → PASSED but disclosure emitted
        assert out["validation_status"] == ValidationStatus.PASSED
        assert out["violations"]
        d = out["hitl_disclosures"][0]
        assert d.requires_ack is False  # INFORMATIONAL → no ack required

    def test_slot_gap_with_no_blocking_returns_incomplete(self, session):
        intent = _intent(
            "WITHDRAWAL_REQUEST",
            required_slots=["distribution_type", "withdrawal_amount"],
        )
        st = _state(session, intent=intent, entities={})
        with _patch_llm():
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.INCOMPLETE
        assert out["slot_gap"] == ["distribution_type", "withdrawal_amount"]

    def test_blocking_overrides_slot_gap(self, session):
        loan = _entity(
            entity_type=EntityType.LOAN_AMOUNT, display_value="$80,000", slot_name="loan_amount",
        )
        intent = _intent("PLAN_LOAN_REQUEST", required_slots=["repayment_term"])
        ctx = {"vested_balance": 20_000}
        st = _state(session, intent=intent, entities={"loan_amount": loan}, account_context=ctx)
        with _patch_llm("Too much."):
            out = EntityValidatorAgent().run(st)
        assert out["validation_status"] == ValidationStatus.FAILED


# ===========================================================================
# Health check
# ===========================================================================

class TestHealthCheck:
    def test_returns_true_when_rules_loaded(self):
        assert EntityValidatorAgent().health_check() is True

    def test_all_rule_ids_in_intent_map_exist_in_registry(self):
        from agents.entity_validator.v1.rules import INTENT_RULE_MAP
        for sub_intent, rule_ids in INTENT_RULE_MAP.items():
            for rid in rule_ids:
                assert rid in ALL_RULES, f"{sub_intent} references missing {rid}"

    def test_get_rules_for_unknown_intent_returns_empty(self):
        assert get_rules_for_intent("DOES_NOT_EXIST") == []


# ===========================================================================
# LLM message integration
# ===========================================================================

class TestLLMMessageIntegration:
    def test_customer_message_filled_from_llm(self, session):
        loan = _entity(
            entity_type=EntityType.LOAN_AMOUNT, display_value="$80,000", slot_name="loan_amount",
        )
        st = _state(
            session,
            intent=_intent("PLAN_LOAN_REQUEST"),
            entities={"loan_amount": loan},
            account_context={"vested_balance": 20_000},
        )
        with _patch_llm("Sorry, that loan amount is over your limit."):
            out = EntityValidatorAgent().run(st)
        assert out["violations"][0].customer_message == (
            "Sorry, that loan amount is over your limit."
        )

    def test_llm_failure_uses_static_fallback(self, session):
        loan = _entity(
            entity_type=EntityType.LOAN_AMOUNT, display_value="$80,000", slot_name="loan_amount",
        )
        st = _state(
            session,
            intent=_intent("PLAN_LOAN_REQUEST"),
            entities={"loan_amount": loan},
            account_context={"vested_balance": 20_000},
        )
        with patch.object(validator_module, "call_llm_text", side_effect=RuntimeError("boom")):
            out = EntityValidatorAgent().run(st)
        msg = out["violations"][0].customer_message
        assert "IRC Section 72(p)(2)(A)" in msg  # fallback includes regulatory_ref

    def test_llm_returns_empty_string_uses_fallback(self, session):
        loan = _entity(
            entity_type=EntityType.LOAN_AMOUNT, display_value="$80,000", slot_name="loan_amount",
        )
        st = _state(
            session,
            intent=_intent("PLAN_LOAN_REQUEST"),
            entities={"loan_amount": loan},
            account_context={"vested_balance": 20_000},
        )
        with _patch_llm("   "):
            out = EntityValidatorAgent().run(st)
        msg = out["violations"][0].customer_message
        assert "IRC Section 72(p)(2)(A)" in msg


# ===========================================================================
# Retirement rules
# ===========================================================================

class TestIRC72PLoanLimitRule:
    rule = IRC72PLoanLimitRule()

    def test_no_loan_amount_passes(self):
        ok, v = self.rule.evaluate({}, {}, TODAY)
        assert ok and v is None

    def test_within_limit_passes(self):
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$10,000")
        ok, _ = self.rule.evaluate({"loan_amount": loan}, {"vested_balance": 100_000}, TODAY)
        assert ok

    def test_exceeds_50pct_vested_blocks(self):
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$30,000")
        # 50% of vested = $25k; > requested $30k → block
        ok, v = self.rule.evaluate({"loan_amount": loan}, {"vested_balance": 50_000}, TODAY)
        assert not ok
        assert v.severity == ValidationSeverity.BLOCKING
        assert v.correctable

    def test_exceeds_50k_ceiling_blocks(self):
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$60,000")
        ok, v = self.rule.evaluate({"loan_amount": loan}, {"vested_balance": 1_000_000}, TODAY)
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_10k_floor_when_vested_low(self):
        # 50% of $5K vested = $2.5K, but floor is $10K → $10K loan should pass
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$9,000")
        ok, _ = self.rule.evaluate({"loan_amount": loan}, {"vested_balance": 5_000}, TODAY)
        assert ok

    def test_outstanding_loan_reduces_capacity(self):
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$45,000")
        ctx = {"vested_balance": 200_000, "outstanding_loan_balance": 20_000}
        ok, v = self.rule.evaluate({"loan_amount": loan}, ctx, TODAY)
        # Limit A: 50_000 - 0 (excess) = 50_000; Limit B: 100_000; effective max = 50_000-20_000=30_000
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_prior_12mo_high_reduces_50k_ceiling(self):
        loan = _entity(entity_type=EntityType.LOAN_AMOUNT, display_value="$45,000")
        ctx = {
            "vested_balance": 500_000,
            "outstanding_loan_balance": 0,
            "highest_loan_balance_prior_12mo": 30_000,
        }
        # excess = 30_000; limit_a = 50_000 - 30_000 = 20_000 → block
        ok, _ = self.rule.evaluate({"loan_amount": loan}, ctx, TODAY)
        assert not ok


class TestIRC72PRepaymentTermRule:
    rule = IRC72PRepaymentTermRule()

    def test_no_term_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_60_months_passes(self):
        term = _entity(entity_type=EntityType.REPAYMENT_TERM, display_value="60")
        ok, _ = self.rule.evaluate({"repayment_term": term}, {}, TODAY)
        assert ok

    def test_61_months_general_blocks(self):
        term = _entity(entity_type=EntityType.REPAYMENT_TERM, display_value="61")
        ok, v = self.rule.evaluate({"repayment_term": term}, {}, TODAY)
        assert not ok and v.suggested_fix == "60"

    def test_360_months_home_loan_passes(self):
        term = _entity(entity_type=EntityType.REPAYMENT_TERM, display_value="360")
        ctx = {"loan_purpose": "PRIMARY_RESIDENCE"}
        ok, _ = self.rule.evaluate({"repayment_term": term}, ctx, TODAY)
        assert ok

    def test_zero_term_blocks(self):
        term = _entity(entity_type=EntityType.REPAYMENT_TERM, display_value="0")
        ok, v = self.rule.evaluate({"repayment_term": term}, {}, TODAY)
        assert not ok and v.correctable

    def test_non_numeric_term_blocks(self):
        term = _entity(entity_type=EntityType.REPAYMENT_TERM, display_value="abc")
        ok, _ = self.rule.evaluate({"repayment_term": term}, {}, TODAY)
        assert not ok


class TestIRC72TEarlyWithdrawalRule:
    rule = IRC72TEarlyWithdrawalRule()

    def test_no_dist_type_passes(self):
        ok, _ = self.rule.evaluate({}, {"owner_age_years": 30}, TODAY)
        assert ok

    def test_age_60_passes(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="EARLY")
        ok, _ = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 60}, TODAY)
        assert ok

    def test_age_59_5_boundary_passes(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="EARLY")
        ok, _ = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 59.5}, TODAY)
        assert ok

    def test_under_age_early_warns(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="EARLY")
        ok, v = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 40}, TODAY)
        assert not ok and v.severity == ValidationSeverity.WARNING and not v.correctable

    def test_under_age_rmd_passes(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="RMD")
        ok, _ = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 40}, TODAY)
        assert ok

    @pytest.mark.parametrize("exemption", sorted(IRC72TEarlyWithdrawalRule.EARLY_EXEMPTIONS))
    def test_exemptions_pass(self, exemption):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value=exemption)
        ok, _ = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 40}, TODAY)
        assert ok

    def test_under_age_normal_warns(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        ok, v = self.rule.evaluate({"distribution_type": d}, {"owner_age_years": 40}, TODAY)
        assert not ok and v.severity == ValidationSeverity.WARNING

    def test_default_age_100_passes(self):
        # When account_context omits owner_age, default=100 → no penalty
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="EARLY")
        ok, _ = self.rule.evaluate({"distribution_type": d}, {}, TODAY)
        assert ok


class TestRMDRequirementRule:
    rule = RMDRequirementRule()

    def test_under_age_passes(self):
        ok, _ = self.rule.evaluate({}, {"owner_age_years": 70}, TODAY)
        assert ok

    def test_at_rmd_age_fires_informational(self):
        ok, v = self.rule.evaluate({}, {"owner_age_years": IRS_LIMITS["RMD_START_AGE"]}, TODAY)
        assert not ok
        assert v.severity == ValidationSeverity.INFORMATIONAL

    def test_no_age_in_context_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok


class TestIRC402GContributionLimitRule:
    rule = IRC402GContributionLimitRule()
    base = IRS_LIMITS["401K_CONTRIBUTION_LIMIT"]
    catchup_50 = IRS_LIMITS["401K_CATCHUP_LIMIT"]
    catchup_60 = IRS_LIMITS["401K_CATCHUP_LIMIT_60_63"]

    def test_no_contribution_passes(self):
        ok, _ = self.rule.evaluate({}, {"owner_age_years": 30}, TODAY)
        assert ok

    def test_under_50_at_limit_passes(self):
        c = _entity(entity_type=EntityType.CONTRIBUTION_AMOUNT, display_value=f"${self.base}")
        ok, _ = self.rule.evaluate({"contribution_amount": c}, {"owner_age_years": 30}, TODAY)
        assert ok

    def test_under_50_over_limit_blocks(self):
        c = _entity(entity_type=EntityType.CONTRIBUTION_AMOUNT, display_value=f"${self.base + 1}")
        ok, v = self.rule.evaluate({"contribution_amount": c}, {"owner_age_years": 30}, TODAY)
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_age_50_catchup_allowed(self):
        c = _entity(
            entity_type=EntityType.CONTRIBUTION_AMOUNT,
            display_value=f"${self.base + self.catchup_50}",
        )
        ok, _ = self.rule.evaluate({"contribution_amount": c}, {"owner_age_years": 55}, TODAY)
        assert ok

    def test_age_60_super_catchup(self):
        c = _entity(
            entity_type=EntityType.CONTRIBUTION_AMOUNT,
            display_value=f"${self.base + self.catchup_60}",
        )
        ok, _ = self.rule.evaluate({"contribution_amount": c}, {"owner_age_years": 62}, TODAY)
        assert ok

    def test_ytd_reduces_remaining(self):
        c = _entity(entity_type=EntityType.CONTRIBUTION_AMOUNT, display_value="$10,000")
        ctx = {"owner_age_years": 40, "ytd_contributions": self.base - 5_000}
        # Remaining = 5_000; requested 10_000 → block
        ok, _ = self.rule.evaluate({"contribution_amount": c}, ctx, TODAY)
        assert not ok

    def test_percentage_contribution_resolves_against_compensation(self):
        c = _entity(entity_type=EntityType.PERCENTAGE, display_value="10%")
        # 10% of 100_000 = 10_000 → under limit
        ctx = {"owner_age_years": 40, "annual_compensation": 100_000}
        ok, _ = self.rule.evaluate({"contribution_amount": c}, ctx, TODAY)
        assert ok

    def test_percentage_contribution_over_limit_blocks(self):
        c = _entity(entity_type=EntityType.PERCENTAGE, display_value="50%")
        ctx = {"owner_age_years": 40, "annual_compensation": 200_000}  # → 100_000 > 23_500
        ok, _ = self.rule.evaluate({"contribution_amount": c}, ctx, TODAY)
        assert not ok


class TestIRARolloverOncePerYearRule:
    rule = IRARolloverOncePerYearRule()

    def test_no_rollover_type_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_direct_rollover_always_passes(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="DIRECT")
        ok, _ = self.rule.evaluate(
            {"rollover_type": r},
            {"last_indirect_rollover_date": (TODAY - timedelta(days=30)).isoformat()},
            TODAY,
        )
        assert ok

    def test_indirect_no_prior_passes(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ok, _ = self.rule.evaluate({"rollover_type": r}, {}, TODAY)
        assert ok

    def test_indirect_prior_within_year_blocks(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"last_indirect_rollover_date": (TODAY - timedelta(days=100)).isoformat()}
        ok, v = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok and v.suggested_fix == "DIRECT"

    def test_indirect_prior_over_year_passes(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"last_indirect_rollover_date": (TODAY - timedelta(days=400)).isoformat()}
        ok, _ = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert ok

    def test_unparseable_date_blocks(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"last_indirect_rollover_date": "not-a-date"}
        ok, v = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok and v.correctable

    def test_date_object_works(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"last_indirect_rollover_date": TODAY - timedelta(days=10)}
        ok, _ = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok


class TestRolloverSixtyDayRule:
    rule = RolloverSixtyDayRule()

    def test_no_rollover_type_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_direct_passes(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="DIRECT")
        ok, _ = self.rule.evaluate(
            {"rollover_type": r},
            {"distribution_date": (TODAY - timedelta(days=200)).isoformat()},
            TODAY,
        )
        assert ok

    def test_indirect_within_60_days_passes(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"distribution_date": (TODAY - timedelta(days=30)).isoformat()}
        ok, _ = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert ok

    def test_indirect_over_60_days_blocks(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"distribution_date": (TODAY - timedelta(days=70)).isoformat()}
        ok, v = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok and not v.correctable

    def test_future_distribution_date_blocks(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"distribution_date": (TODAY + timedelta(days=10)).isoformat()}
        ok, v = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok and "future" in (v.suggested_fix or "").lower()

    def test_unparseable_date_blocks(self):
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="INDIRECT")
        ctx = {"distribution_date": "garbage"}
        ok, _ = self.rule.evaluate({"rollover_type": r}, ctx, TODAY)
        assert not ok


class TestIRC415TotalLimitRule:
    rule = IRC415TotalLimitRule()
    total_cap = IRS_LIMITS["401K_TOTAL_LIMIT"]

    def test_no_contribution_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_within_total_passes(self):
        c = _entity(entity_type=EntityType.CONTRIBUTION_AMOUNT, display_value="$10,000")
        ok, _ = self.rule.evaluate({"contribution_amount": c}, {"annual_compensation": 200_000}, TODAY)
        assert ok

    def test_over_415_total_blocks(self):
        c = _entity(
            entity_type=EntityType.CONTRIBUTION_AMOUNT,
            display_value=f"${self.total_cap + 1}",
        )
        ok, v = self.rule.evaluate(
            {"contribution_amount": c}, {"annual_compensation": 999_999}, TODAY,
        )
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_compensation_cap_overrides_415(self):
        # If annual_comp = $30k, that's the effective cap
        c = _entity(entity_type=EntityType.CONTRIBUTION_AMOUNT, display_value="$40,000")
        ok, _ = self.rule.evaluate(
            {"contribution_amount": c}, {"annual_compensation": 30_000}, TODAY,
        )
        assert not ok


# ===========================================================================
# Investment rules
# ===========================================================================

class TestAccreditedInvestorRule:
    rule = AccreditedInvestorRule()

    def test_no_product_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_unrestricted_product_passes(self):
        p = _entity(entity_type=EntityType.FUND_NAME, display_value="VANGUARD_VTI")
        ok, _ = self.rule.evaluate({"investment_product": p}, {}, TODAY)
        assert ok

    @pytest.mark.parametrize("product", sorted(AccreditedInvestorRule.RESTRICTED_PRODUCTS))
    def test_restricted_product_non_accredited_blocks(self, product):
        p = _entity(entity_type=EntityType.FUND_NAME, display_value=product)
        ok, v = self.rule.evaluate({"investment_product": p}, {"is_accredited_investor": False}, TODAY)
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_restricted_product_accredited_passes(self):
        p = _entity(entity_type=EntityType.FUND_NAME, display_value="HEDGE_FUND")
        ok, _ = self.rule.evaluate({"investment_product": p}, {"is_accredited_investor": True}, TODAY)
        assert ok


class TestConcentrationRiskRule:
    rule = ConcentrationRiskRule()

    def test_missing_qty_passes(self):
        price = _entity(entity_type=EntityType.ORDER_PRICE, display_value="$100")
        ok, _ = self.rule.evaluate({"order_price": price}, {"total_portfolio_value": 100_000}, TODAY)
        assert ok

    def test_zero_portfolio_passes(self):
        q = _entity(entity_type=EntityType.ORDER_QUANTITY, display_value="100")
        p = _entity(entity_type=EntityType.ORDER_PRICE, display_value="$50")
        ok, _ = self.rule.evaluate(
            {"order_quantity": q, "order_price": p},
            {"total_portfolio_value": 0},
            TODAY,
        )
        assert ok

    def test_under_25pct_passes(self):
        q = _entity(entity_type=EntityType.ORDER_QUANTITY, display_value="100")
        p = _entity(entity_type=EntityType.ORDER_PRICE, display_value="$100")
        # order=10_000 / portfolio=100_000 = 10% → ok
        ok, _ = self.rule.evaluate(
            {"order_quantity": q, "order_price": p},
            {"total_portfolio_value": 100_000},
            TODAY,
        )
        assert ok

    def test_over_25pct_warns(self):
        q = _entity(entity_type=EntityType.ORDER_QUANTITY, display_value="500")
        p = _entity(entity_type=EntityType.ORDER_PRICE, display_value="$100")
        # 50_000 / 100_000 = 50% → warn
        ok, v = self.rule.evaluate(
            {"order_quantity": q, "order_price": p},
            {"total_portfolio_value": 100_000},
            TODAY,
        )
        assert not ok and v.severity == ValidationSeverity.WARNING

    def test_non_numeric_quantity_warns_with_correctable_fix(self):
        q = _entity(entity_type=EntityType.ORDER_QUANTITY, display_value="abc")
        p = _entity(entity_type=EntityType.ORDER_PRICE, display_value="$100")
        ok, v = self.rule.evaluate(
            {"order_quantity": q, "order_price": p},
            {"total_portfolio_value": 100_000},
            TODAY,
        )
        assert not ok and v.correctable


class TestSuitabilityCheckRule:
    rule = SuitabilityCheckRule()

    def test_missing_inputs_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_conservative_in_bond_passes(self):
        risk = _entity(entity_type=EntityType.RISK_TOLERANCE, display_value="CONSERVATIVE")
        prod = _entity(entity_type=EntityType.FUND_NAME, display_value="BOND_FUND")
        ok, _ = self.rule.evaluate(
            {"risk_tolerance": risk, "investment_product": prod}, {}, TODAY,
        )
        assert ok

    def test_conservative_in_growth_warns(self):
        risk = _entity(entity_type=EntityType.RISK_TOLERANCE, display_value="CONSERVATIVE")
        prod = _entity(entity_type=EntityType.FUND_NAME, display_value="HIGH_GROWTH")
        ok, v = self.rule.evaluate(
            {"risk_tolerance": risk, "investment_product": prod}, {}, TODAY,
        )
        assert not ok and v.severity == ValidationSeverity.WARNING


# ===========================================================================
# Estate rules
# ===========================================================================

class TestBeneficiaryPercentageRule:
    rule = BeneficiaryPercentageRule()

    def test_single_primary_100_passes(self):
        e = _entity(
            entity_type=EntityType.BENEFICIARY_PERCENTAGE,
            display_value="100%",
            slot_name="beneficiary_percentage_1",
        )
        ok, _ = self.rule.evaluate({"beneficiary_percentage_1": e}, {}, TODAY)
        assert ok

    def test_primary_under_100_blocks(self):
        e = _entity(
            entity_type=EntityType.BENEFICIARY_PERCENTAGE,
            display_value="60%",
            slot_name="beneficiary_percentage_1",
        )
        ok, v = self.rule.evaluate({"beneficiary_percentage_1": e}, {}, TODAY)
        assert not ok and "100" in (v.suggested_fix or "")

    def test_two_primaries_summing_100_passes(self):
        a = _entity(
            entity_type=EntityType.BENEFICIARY_PERCENTAGE,
            display_value="60%",
            slot_name="beneficiary_percentage_1",
        )
        b = _entity(
            entity_type=EntityType.BENEFICIARY_PERCENTAGE,
            display_value="40%",
            slot_name="beneficiary_percentage_2",
        )
        ok, _ = self.rule.evaluate(
            {"beneficiary_percentage_1": a, "beneficiary_percentage_2": b}, {}, TODAY,
        )
        assert ok

    def test_primary_overflow_blocks(self):
        a = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="60%",
                    slot_name="beneficiary_percentage_1")
        b = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="60%",
                    slot_name="beneficiary_percentage_2")
        ok, _ = self.rule.evaluate(
            {"beneficiary_percentage_1": a, "beneficiary_percentage_2": b}, {}, TODAY,
        )
        assert not ok

    def test_contingent_independent_split(self):
        # Primary 100, contingent split 50/50 → ok
        p = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="100%",
                    slot_name="beneficiary_percentage_1")
        c1 = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="50%",
                     slot_name="beneficiary_percentage_2")
        c2 = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="50%",
                     slot_name="beneficiary_percentage_3")
        designations = {
            "beneficiary_percentage_1": "PRIMARY",
            "beneficiary_percentage_2": "CONTINGENT",
            "beneficiary_percentage_3": "CONTINGENT",
        }
        # Designation entities keyed so the rule's strategy 1 finds them
        d_entities = {
            "beneficiary_designation_1": _entity(
                entity_type=EntityType.BENEFICIARY_TYPE, display_value="PRIMARY",
                slot_name="beneficiary_designation_1",
            ),
            "beneficiary_designation_2": _entity(
                entity_type=EntityType.BENEFICIARY_TYPE, display_value="CONTINGENT",
                slot_name="beneficiary_designation_2",
            ),
            "beneficiary_designation_3": _entity(
                entity_type=EntityType.BENEFICIARY_TYPE, display_value="CONTINGENT",
                slot_name="beneficiary_designation_3",
            ),
        }
        ents = {
            "beneficiary_percentage_1": p,
            "beneficiary_percentage_2": c1,
            "beneficiary_percentage_3": c2,
            **d_entities,
        }
        ok, _ = self.rule.evaluate(ents, {}, TODAY)
        assert ok

    def test_contingent_under_100_blocks(self):
        p = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="100%",
                    slot_name="beneficiary_percentage_1")
        c1 = _entity(entity_type=EntityType.BENEFICIARY_PERCENTAGE, display_value="40%",
                     slot_name="beneficiary_percentage_2")
        d = _entity(entity_type=EntityType.BENEFICIARY_TYPE, display_value="CONTINGENT",
                    slot_name="beneficiary_designation_2")
        ok, _ = self.rule.evaluate(
            {
                "beneficiary_percentage_1": p,
                "beneficiary_percentage_2": c1,
                "beneficiary_designation_2": d,
            },
            {},
            TODAY,
        )
        assert not ok

    def test_no_beneficiaries_blocks_under_100(self):
        # No entities → primary_total = 0 ≠ 100 → block
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert not ok


class TestERISASpousalConsentRule:
    rule = ERISASpousalConsentRule()

    def test_no_plan_type_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_non_erisa_passes(self):
        p = _entity(entity_type=EntityType.PLAN_TYPE, display_value="ROTH_IRA")
        ok, _ = self.rule.evaluate(
            {"plan_type": p}, {"marital_status": "MARRIED"}, TODAY,
        )
        assert ok

    def test_unmarried_passes(self):
        p = _entity(entity_type=EntityType.PLAN_TYPE, display_value="401K")
        ok, _ = self.rule.evaluate(
            {"plan_type": p}, {"marital_status": "SINGLE"}, TODAY,
        )
        assert ok

    def test_married_naming_spouse_passes(self):
        p = _entity(entity_type=EntityType.PLAN_TYPE, display_value="401K")
        rel = _entity(
            entity_type=EntityType.BENEFICIARY_RELATION, display_value="SPOUSE",
            slot_name="beneficiary_relation",
        )
        ctx = {"marital_status": "MARRIED"}
        ok, _ = self.rule.evaluate(
            {"plan_type": p, "beneficiary_relation": rel}, ctx, TODAY,
        )
        assert ok

    def test_married_naming_non_spouse_no_consent_blocks(self):
        p = _entity(entity_type=EntityType.PLAN_TYPE, display_value="401K")
        rel = _entity(
            entity_type=EntityType.BENEFICIARY_RELATION, display_value="CHILD",
            slot_name="beneficiary_relation",
        )
        ctx = {"marital_status": "MARRIED", "spousal_consent_obtained": False}
        ok, v = self.rule.evaluate(
            {"plan_type": p, "beneficiary_relation": rel}, ctx, TODAY,
        )
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_married_non_spouse_with_consent_passes(self):
        p = _entity(entity_type=EntityType.PLAN_TYPE, display_value="401K")
        rel = _entity(
            entity_type=EntityType.BENEFICIARY_RELATION, display_value="CHILD",
            slot_name="beneficiary_relation",
        )
        ctx = {"marital_status": "MARRIED", "spousal_consent_obtained": True}
        ok, _ = self.rule.evaluate(
            {"plan_type": p, "beneficiary_relation": rel}, ctx, TODAY,
        )
        assert ok


class TestTrustEINRule:
    rule = TrustEINRule()

    def test_no_relation_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_non_trust_passes(self):
        rel = _entity(entity_type=EntityType.BENEFICIARY_RELATION, display_value="SPOUSE")
        ok, _ = self.rule.evaluate({"beneficiary_relation": rel}, {}, TODAY)
        assert ok

    def test_trust_without_ein_blocks(self):
        rel = _entity(entity_type=EntityType.BENEFICIARY_RELATION, display_value="TRUST")
        ok, v = self.rule.evaluate({"beneficiary_relation": rel}, {}, TODAY)
        assert not ok and not v.correctable

    def test_trust_with_ein_passes(self):
        rel = _entity(entity_type=EntityType.BENEFICIARY_RELATION, display_value="TRUST")
        ok, _ = self.rule.evaluate(
            {"beneficiary_relation": rel}, {"trust_ein": "12-3456789"}, TODAY,
        )
        assert ok


# ===========================================================================
# Tax rules
# ===========================================================================

class TestWithholdingElectionRule:
    rule = WithholdingElectionRule()

    def test_no_dist_type_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_rmd_skipped(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="RMD")
        ok, _ = self.rule.evaluate({"distribution_type": d}, {}, TODAY)
        assert ok

    def test_direct_rollover_skipped(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        r = _entity(entity_type=EntityType.ROLLOVER_TYPE, display_value="DIRECT")
        ok, _ = self.rule.evaluate(
            {"distribution_type": d, "rollover_type": r}, {}, TODAY,
        )
        assert ok

    def test_no_withholding_election_warns(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        ok, v = self.rule.evaluate({"distribution_type": d}, {}, TODAY)
        assert not ok and v.suggested_fix == "20%"

    def test_under_minimum_warns(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        w = _entity(entity_type=EntityType.WITHHOLDING_PERCENT, display_value="5%")
        ok, v = self.rule.evaluate(
            {"distribution_type": d, "withholding_percent": w}, {}, TODAY,
        )
        assert not ok and "10" in (v.suggested_fix or "")

    def test_at_minimum_passes(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        w = _entity(entity_type=EntityType.WITHHOLDING_PERCENT, display_value="10%")
        ok, _ = self.rule.evaluate(
            {"distribution_type": d, "withholding_percent": w}, {}, TODAY,
        )
        assert ok

    def test_non_numeric_withholding_warns(self):
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        w = _entity(entity_type=EntityType.WITHHOLDING_PERCENT, display_value="abc")
        ok, _ = self.rule.evaluate(
            {"distribution_type": d, "withholding_percent": w}, {}, TODAY,
        )
        assert not ok


class TestTaxAdviceDetectionRule:
    rule = TaxAdviceDetectionRule()

    def test_safe_intent_passes(self):
        ok, _ = self.rule.evaluate({}, {"intent_id": "WITHDRAWAL_REQUEST"}, TODAY)
        assert ok

    @pytest.mark.parametrize("advice", sorted(TaxAdviceDetectionRule.TAX_ADVICE_INTENTS))
    def test_advice_intent_blocks(self, advice):
        ok, v = self.rule.evaluate({}, {"intent_id": advice}, TODAY)
        assert not ok and v.severity == ValidationSeverity.BLOCKING

    def test_substring_match_blocks(self):
        ok, _ = self.rule.evaluate({}, {"intent_id": "PREFIX_TAX_STRATEGY_SUFFIX"}, TODAY)
        assert not ok


class TestStateWithholdingRule:
    rule = StateWithholdingRule()

    def test_missing_inputs_passes(self):
        ok, _ = self.rule.evaluate({}, {}, TODAY)
        assert ok

    def test_non_mandatory_state_passes(self):
        s = _entity(entity_type=EntityType.STATE, display_value="TX")
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        ok, _ = self.rule.evaluate({"state": s, "distribution_type": d}, {}, TODAY)
        assert ok

    def test_mandatory_state_no_election_warns(self):
        s = _entity(entity_type=EntityType.STATE, display_value="CA")
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        ok, v = self.rule.evaluate(
            {"state": s, "distribution_type": d}, {}, TODAY,
        )
        assert not ok and v.severity == ValidationSeverity.WARNING

    def test_mandatory_state_with_election_passes(self):
        s = _entity(entity_type=EntityType.STATE, display_value="CA")
        d = _entity(entity_type=EntityType.DISTRIBUTION_TYPE, display_value="NORMAL")
        ok, _ = self.rule.evaluate(
            {"state": s, "distribution_type": d},
            {"state_withholding_elected": True},
            TODAY,
        )
        assert ok
