"""Comprehensive unit tests for IntentAgent.

Covers:
  * Every taxonomy intent classifies correctly (parametrised over all 47).
  * Each IntentChangeType produces the correct intent stack mutation:
      - NEW       → fresh stack
      - REFINEMENT → head replaced, paused intents preserved
      - CORRECTION → head replaced
      - PIVOT     → old head pushed to paused, new head on top
      - RESUME    → paused intent brought back to head
      - RESUME (not found) → graceful fallback to REFINEMENT (M7)
  * Taxonomy is the source of truth — required_slots / auth_level /
    is_transactional / compliance flags come from the registry, NOT the LLM.
  * Unknown sub_intent → safe fallback (keeps existing stack or empty).
  * Escalation intents set escalation_context with correct EscalationReason.
  * `escalation_flag=True` mid-flow propagates from LLM even on
    non-escalation intents.
  * Repeating a NEW/PIVOT intent clears it from completed_intent_ids
    so the supervisor will re-execute it.
  * slot_gap is recomputed after stack mutation and excludes already-filled
    slots in entity_memory.
  * Confidence is clamped to [0.0, 1.0].
  * Invalid change_type strings degrade to NEW.
  * Empty intent stack + REFINEMENT → still produces a valid NEW stack.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import patch
from uuid import uuid4

import pytest

from agents.intent_agent.v1 import agent as intent_module
from agents.intent_agent.v1.agent import IntentAgent, _LLMIntentFallback
from agents.intent_agent.v1.taxonomy import (
    INTENT_TAXONOMY,
    ESCALATION_INTENTS,
    all_sub_intent_ids,
    lookup_intent,
)
from schemas.enums import (
    EscalationReason,
    IntentChangeType,
    ServiceDomain,
)
from schemas.primitives import EntityRecord, IntentRecord
from schemas.enums import EntityType


# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------

ALL_SUB_INTENTS = all_sub_intent_ids()


@pytest.fixture
def agent() -> IntentAgent:
    return IntentAgent()


def _state(
    session,
    message: str,
    *,
    intent_stack: list[IntentRecord] | None = None,
    completed_intent_ids: list[str] | None = None,
    entity_memory: dict[str, EntityRecord] | None = None,
    current_turn: int = 1,
) -> dict:
    return {
        "session": session,
        "message_history": [{"role": "user", "content": message}],
        "intent_stack": intent_stack or [],
        "active_intent_id": intent_stack[0].intent_id if intent_stack else None,
        "completed_intent_ids": completed_intent_ids or [],
        "entity_memory": entity_memory or {},
        "current_turn": current_turn,
        "user_profile": {},
    }


def _llm_response(
    *,
    sub_intent: str,
    change_type: str = "NEW",
    confidence: float = 0.95,
    escalation_flag: bool = False,
    escalation_reason: str | None = None,
) -> _LLMIntentFallback:
    """Build a synthetic LLM payload. Taxonomy fields will overwrite anything
    that touches state, so we only need sub_intent + control fields here."""
    defn = lookup_intent(sub_intent)
    return _LLMIntentFallback(
        intent_id=defn.intent_id if defn else "",
        service_domain=defn.domain.value if defn else "",
        sub_intent=sub_intent,
        confidence=confidence,
        change_type=change_type,
        required_slots=list(defn.required_slots) if defn else [],
        is_transactional=defn.is_transactional if defn else False,
        requires_auth_level=int(defn.auth_level) if defn else 1,
        escalation_flag=escalation_flag,
        escalation_reason=escalation_reason,
        reasoning="",
    )


def _patch_llm(response: _LLMIntentFallback):
    """Helper: patch call_llm to return the given response."""
    return patch.object(
        intent_module,
        "call_llm",
        return_value=response,
    )


def _existing_intent(sub_intent: str, *, paused_at_turn: int | None = None,
                     turn_number: int = 0) -> IntentRecord:
    defn = lookup_intent(sub_intent)
    assert defn is not None
    return IntentRecord(
        intent_id=defn.intent_id,
        service_domain=defn.domain,
        sub_intent=defn.sub_intent_id,
        confidence=0.9,
        change_type=IntentChangeType.NEW,
        requires_auth_level=defn.auth_level,
        is_transactional=defn.is_transactional,
        escalation_flag=defn.escalation_flag,
        required_slots=list(defn.required_slots),
        paused_at_turn=paused_at_turn,
        turn_number=turn_number,
    )


# ---------------------------------------------------------------------------
# 1. Taxonomy coverage — every sub_intent classifies cleanly
# ---------------------------------------------------------------------------

class TestTaxonomyCoverage:
    @pytest.mark.parametrize("sub_intent", ALL_SUB_INTENTS)
    def test_every_sub_intent_classifies(self, agent, session, sub_intent):
        """All 47 taxonomy entries must produce a valid IntentRecord whose
        fields come from the taxonomy, not the LLM payload."""
        defn = lookup_intent(sub_intent)
        with _patch_llm(_llm_response(sub_intent=sub_intent)):
            result = agent.run(_state(session, "test"))

        stack = result["intent_stack"]
        assert len(stack) == 1
        rec = stack[0]
        assert rec.sub_intent == sub_intent
        assert rec.intent_id == defn.intent_id
        # Source-of-truth fields come from taxonomy:
        assert rec.service_domain == defn.domain
        assert rec.requires_auth_level == defn.auth_level
        assert rec.is_transactional == defn.is_transactional
        assert rec.required_slots == list(defn.required_slots)


# ---------------------------------------------------------------------------
# 2. Change-type stack mutations
# ---------------------------------------------------------------------------

class TestChangeTypeNEW:
    def test_new_replaces_entire_stack(self, agent, session):
        existing = [_existing_intent("PLAN_LOAN_REQUEST")]
        with _patch_llm(_llm_response(sub_intent="ACCOUNT_BALANCE_INQUIRY", change_type="NEW")):
            result = agent.run(_state(session, "balance?", intent_stack=existing))
        stack = result["intent_stack"]
        assert len(stack) == 1
        assert stack[0].sub_intent == "ACCOUNT_BALANCE_INQUIRY"
        assert stack[0].change_type == IntentChangeType.NEW

    def test_new_with_empty_stack(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY", change_type="NEW")):
            result = agent.run(_state(session, "tell me about RMDs"))
        assert len(result["intent_stack"]) == 1
        assert result["intent_stack"][0].sub_intent == "RMD_INQUIRY"


class TestChangeTypeREFINEMENT:
    def test_refinement_replaces_head_keeps_paused(self, agent, session):
        active = _existing_intent("WITHDRAWAL_REQUEST")
        paused = _existing_intent("PLAN_LOAN_REQUEST", paused_at_turn=2)
        with _patch_llm(_llm_response(sub_intent="WITHDRAWAL_REQUEST",
                                      change_type="REFINEMENT")):
            result = agent.run(_state(session, "actually $5000",
                                       intent_stack=[active, paused]))
        stack = result["intent_stack"]
        assert len(stack) == 2
        assert stack[0].sub_intent == "WITHDRAWAL_REQUEST"
        assert stack[0].change_type == IntentChangeType.REFINEMENT
        assert stack[1].sub_intent == "PLAN_LOAN_REQUEST"
        assert stack[1].paused_at_turn == 2  # preserved

    def test_refinement_with_empty_stack_treated_as_new(self, agent, session):
        # Edge case: REFINEMENT but no existing stack — agent treats as NEW.
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY",
                                      change_type="REFINEMENT")):
            result = agent.run(_state(session, "RMD?"))
        assert len(result["intent_stack"]) == 1
        assert result["intent_stack"][0].sub_intent == "RMD_INQUIRY"


class TestChangeTypeCORRECTION:
    def test_correction_replaces_head(self, agent, session):
        active = _existing_intent("WITHDRAWAL_REQUEST")
        with _patch_llm(_llm_response(sub_intent="WITHDRAWAL_REQUEST",
                                      change_type="CORRECTION")):
            result = agent.run(_state(session, "actually $15000 not $10000",
                                       intent_stack=[active]))
        stack = result["intent_stack"]
        assert len(stack) == 1
        assert stack[0].change_type == IntentChangeType.CORRECTION


class TestChangeTypePIVOT:
    def test_pivot_pushes_old_to_paused(self, agent, session):
        active = _existing_intent("PLAN_LOAN_REQUEST")
        with _patch_llm(_llm_response(sub_intent="ACCOUNT_BALANCE_INQUIRY",
                                      change_type="PIVOT")):
            result = agent.run(_state(
                session, "wait, what's my balance?",
                intent_stack=[active], current_turn=3,
            ))
        stack = result["intent_stack"]
        assert len(stack) == 2
        assert stack[0].sub_intent == "ACCOUNT_BALANCE_INQUIRY"
        assert stack[0].change_type == IntentChangeType.PIVOT
        # Old head paused with paused_at_turn set to current_turn
        assert stack[1].sub_intent == "PLAN_LOAN_REQUEST"
        assert stack[1].paused_at_turn == 3

    def test_pivot_three_levels_deep(self, agent, session):
        a = _existing_intent("PLAN_LOAN_REQUEST")
        b = _existing_intent("WITHDRAWAL_REQUEST", paused_at_turn=2)
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY",
                                      change_type="PIVOT")):
            result = agent.run(_state(
                session, "what about my RMD?",
                intent_stack=[a, b], current_turn=4,
            ))
        stack = result["intent_stack"]
        assert [r.sub_intent for r in stack] == [
            "RMD_INQUIRY", "PLAN_LOAN_REQUEST", "WITHDRAWAL_REQUEST",
        ]
        assert stack[1].paused_at_turn == 4
        assert stack[2].paused_at_turn == 2  # original preserved


class TestChangeTypeRESUME:
    def test_resume_brings_paused_to_head(self, agent, session):
        active = _existing_intent("ACCOUNT_BALANCE_INQUIRY")
        paused = _existing_intent("PLAN_LOAN_REQUEST", paused_at_turn=2)
        with _patch_llm(_llm_response(sub_intent="PLAN_LOAN_REQUEST",
                                      change_type="RESUME")):
            result = agent.run(_state(
                session, "back to my loan",
                intent_stack=[active, paused],
            ))
        stack = result["intent_stack"]
        assert stack[0].sub_intent == "PLAN_LOAN_REQUEST"
        assert stack[0].change_type == IntentChangeType.RESUME
        # 401K_BALANCE_INQUIRY should remain in the stack (it wasn't the
        # resumed one). Order: resumed first, others in original order.
        assert any(r.sub_intent == "ACCOUNT_BALANCE_INQUIRY" for r in stack)

    def test_resume_not_found_falls_back_to_refinement(self, agent, session):
        """M7: RESUME for an intent not in the paused list → REFINEMENT."""
        active = _existing_intent("ACCOUNT_BALANCE_INQUIRY")
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY",
                                      change_type="RESUME")):
            result = agent.run(_state(
                session, "RMD please", intent_stack=[active],
            ))
        stack = result["intent_stack"]
        # Replaces head (REFINEMENT semantics) — does not crash.
        assert stack[0].sub_intent == "RMD_INQUIRY"


# ---------------------------------------------------------------------------
# 3. Unknown sub_intent → safe fallback
# ---------------------------------------------------------------------------

class TestUnknownSubIntent:
    def test_unknown_sub_intent_with_existing_stack_keeps_stack(self, agent, session):
        active = _existing_intent("PLAN_LOAN_REQUEST")
        bad = _LLMIntentFallback(
            sub_intent="DEFINITELY_NOT_A_REAL_INTENT",
            confidence=0.9, change_type="NEW",
        )
        with _patch_llm(bad):
            result = agent.run(_state(
                session, "?", intent_stack=[active],
            ))
        # Existing stack preserved
        assert result["intent_stack"][0].sub_intent == "PLAN_LOAN_REQUEST"
        assert result["active_intent_id"] == active.intent_id

    def test_unknown_sub_intent_with_empty_stack_returns_empty(self, agent, session):
        bad = _LLMIntentFallback(
            sub_intent="GARBAGE", confidence=0.5, change_type="NEW",
        )
        with _patch_llm(bad):
            result = agent.run(_state(session, "??"))
        assert result["intent_stack"] == []
        assert result["active_intent_id"] is None
        assert result["slot_gap"] == []


# ---------------------------------------------------------------------------
# 4. Escalation handling
# ---------------------------------------------------------------------------

class TestEscalation:
    @pytest.mark.parametrize("sub_intent", sorted(ESCALATION_INTENTS))
    def test_escalation_intent_sets_context(self, agent, session, sub_intent):
        with _patch_llm(_llm_response(sub_intent=sub_intent)):
            result = agent.run(_state(session, "..."))
        assert "escalation_context" in result
        ec = result["escalation_context"]
        assert ec.triggered_by == "intent_agent"
        assert isinstance(ec.reason, EscalationReason)
        # The active intent must have escalation_flag=True
        assert result["intent_stack"][0].escalation_flag is True

    def test_non_escalation_intent_no_context(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY")):
            result = agent.run(_state(session, "what's an RMD?"))
        assert "escalation_context" not in result

    def test_llm_escalation_flag_on_normal_intent_propagates(self, agent, session):
        """Even on a normal intent, if the LLM raises escalation_flag the
        agent must surface escalation_context."""
        with _patch_llm(_llm_response(
            sub_intent="RMD_INQUIRY",
            escalation_flag=True,
            escalation_reason="personalised_advice",
        )):
            result = agent.run(_state(session, "edge case"))
        assert "escalation_context" in result
        assert result["intent_stack"][0].escalation_flag is True


# ---------------------------------------------------------------------------
# 5. completed_intent_ids reset on NEW / PIVOT
# ---------------------------------------------------------------------------

class TestCompletedReset:
    def test_repeat_new_clears_completed(self, agent, session):
        defn = lookup_intent("ACCOUNT_BALANCE_INQUIRY")
        with _patch_llm(_llm_response(sub_intent="ACCOUNT_BALANCE_INQUIRY",
                                      change_type="NEW")):
            result = agent.run(_state(
                session, "balance again",
                completed_intent_ids=[defn.intent_id, "OTHER.INTENT"],
            ))
        assert "completed_intent_ids" in result
        assert defn.intent_id not in result["completed_intent_ids"]
        assert "OTHER.INTENT" in result["completed_intent_ids"]

    def test_pivot_to_already_completed_clears_it(self, agent, session):
        defn = lookup_intent("RMD_INQUIRY")
        active = _existing_intent("PLAN_LOAN_REQUEST")
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY",
                                      change_type="PIVOT")):
            result = agent.run(_state(
                session, "RMD please",
                intent_stack=[active],
                completed_intent_ids=[defn.intent_id],
            ))
        assert defn.intent_id not in result.get("completed_intent_ids", [])

    def test_refinement_does_not_clear_completed(self, agent, session):
        active = _existing_intent("WITHDRAWAL_REQUEST")
        defn = lookup_intent("WITHDRAWAL_REQUEST")
        with _patch_llm(_llm_response(sub_intent="WITHDRAWAL_REQUEST",
                                      change_type="REFINEMENT")):
            result = agent.run(_state(
                session, "$5000",
                intent_stack=[active],
                completed_intent_ids=[defn.intent_id],
            ))
        # When the active intent is *already* in completed_intent_ids and
        # the user re-asks (any change_type), the agent must clear it so
        # the supervisor will execute the intent again.  Without this,
        # repeating a completed transactional intent in the same session
        # is silently short-circuited (e.g. "show 401k balance" then
        # "show IRA balance" — the second request would never run).
        assert defn.intent_id not in result.get("completed_intent_ids", [])


# ---------------------------------------------------------------------------
# 5b. entity_memory purge on NEW / PIVOT (Bug A+B fix)
# ---------------------------------------------------------------------------

class TestEntityMemoryPurgeOnIntentChange:
    """When a fresh transactional intent enters, slot-bound non-PII
    entities from the previous instance must NOT bleed through to the
    new instance — otherwise a multi-account user who first asked for
    BROKERAGE balance would silently get BROKERAGE again when they next
    ask for their 401k balance."""

    def _slot_entity(self, slot: str, etype: EntityType, value: str):
        return EntityRecord(
            entity_id=uuid4(),
            entity_type=etype,
            is_pii=False,
            slot_name=slot,
            display_value=value,
            confidence=0.9,
            is_confirmed=False,
        )

    def _pii_entity(self, slot: str):
        return EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.SSN,
            is_pii=True,
            slot_name=slot,
            display_value="***-**-7766",
            vault_token="vault:abc",
            raw_value=None,
            confidence=0.95,
            is_confirmed=True,
        )

    def test_new_intent_purges_non_pii_slot_entity(self, agent, session):
        ent = self._slot_entity("account_type", EntityType.ACCOUNT_TYPE, "BROKERAGE")
        with _patch_llm(_llm_response(
            sub_intent="ACCOUNT_BALANCE_INQUIRY", change_type="NEW",
        )):
            result = agent.run(_state(
                session, "whats my 401k balance?",
                entity_memory={"account_type": ent},
            ))
        # entity_memory delta marks the stale account_type for deletion.
        from schemas.graph_state import DELETE
        assert result.get("entity_memory", {}).get("account_type") is DELETE

    def test_pivot_intent_purges_non_pii_slot_entity(self, agent, session):
        ent = self._slot_entity("plan_type", EntityType.PLAN_TYPE, "401K")
        with _patch_llm(_llm_response(
            sub_intent="WITHDRAWAL_REQUEST", change_type="PIVOT",
        )):
            result = agent.run(_state(
                session, "actually I want to roll over",
                entity_memory={"plan_type": ent},
            ))
        from schemas.graph_state import DELETE
        assert result.get("entity_memory", {}).get("plan_type") is DELETE

    def test_refinement_does_not_purge(self, agent, session):
        ent = self._slot_entity("account_type", EntityType.ACCOUNT_TYPE, "401K")
        with _patch_llm(_llm_response(
            sub_intent="ACCOUNT_BALANCE_INQUIRY", change_type="REFINEMENT",
        )):
            result = agent.run(_state(
                session, "what about my balance?",
                entity_memory={"account_type": ent},
            ))
        # No entity_memory delta means the existing slot survives.
        assert "entity_memory" not in result

    def test_pii_entity_preserved_across_new_intent(self, agent, session):
        """Vault-tokenised PII (SSN, DOB) must NOT be purged — otherwise
        the user is forced to re-authenticate on every fresh request."""
        pii = self._pii_entity("ssn_last4")
        non_pii = self._slot_entity("account_type", EntityType.ACCOUNT_TYPE, "BROKERAGE")
        with _patch_llm(_llm_response(
            sub_intent="ACCOUNT_BALANCE_INQUIRY", change_type="NEW",
        )):
            result = agent.run(_state(
                session, "whats my 401k balance?",
                entity_memory={"ssn_last4": pii, "account_type": non_pii},
            ))
        from schemas.graph_state import DELETE
        em_delta = result.get("entity_memory", {})
        assert em_delta.get("account_type") is DELETE
        assert "ssn_last4" not in em_delta  # PII untouched

    def test_purge_recomputes_slot_gap(self, agent, session):
        """slot_gap returned alongside the purge must reflect the cleared
        state — otherwise the supervisor would skip COLLECT_SLOT thinking
        account_type is still filled by the entity we just dropped."""
        ent = self._slot_entity("account_type", EntityType.ACCOUNT_TYPE, "BROKERAGE")
        with _patch_llm(_llm_response(
            sub_intent="ACCOUNT_BALANCE_INQUIRY", change_type="NEW",
        )):
            result = agent.run(_state(
                session, "whats my balance?",
                entity_memory={"account_type": ent},
            ))
        # Without an account_context indicating multi-account, soft-fill
        # in compute_slot_gap treats account_type as filled (single-acct
        # path).  This test focuses on the no-context default case where
        # accounts_map is empty -> soft-filled.
        assert "account_type" not in result.get("slot_gap", [])


# ---------------------------------------------------------------------------
# 6. slot_gap computation
# ---------------------------------------------------------------------------

class TestSlotGap:
    def test_slot_gap_equals_required_slots_when_empty_memory(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="WITHDRAWAL_REQUEST")):
            result = agent.run(_state(session, "withdraw"))
        # WITHDRAWAL_REQUEST requires plan_type, distribution_type, withdrawal_amount
        assert set(result["slot_gap"]) == {
            "plan_type", "distribution_type", "withdrawal_amount",
        }

    def test_slot_gap_excludes_filled_slots(self, agent, session):
        # Pre-fill plan_type via entity_memory.  Use change_type=REFINEMENT
        # because intent_agent now purges non-PII slot entities on NEW/PIVOT
        # transitions (so the user's *new* utterance owns the slot values).
        # Slot persistence across mid-flow turns of the same intent is
        # what this test exercises.
        ent = EntityRecord(
            entity_id=uuid4(),
            entity_type=EntityType.PLAN_TYPE,
            is_pii=False,
            slot_name="plan_type",
            display_value="401K",
            confidence=0.9,
            is_confirmed=True,
        )
        with _patch_llm(_llm_response(
            sub_intent="WITHDRAWAL_REQUEST", change_type="REFINEMENT",
        )):
            result = agent.run(_state(
                session, "withdraw",
                entity_memory={str(ent.entity_id): ent},
            ))
        assert "plan_type" not in result["slot_gap"]
        assert "withdrawal_amount" in result["slot_gap"]

    def test_slot_gap_empty_for_no_required_slots(self, agent, session):
        # PERSONALISED_ADVICE has no required_slots
        with _patch_llm(_llm_response(sub_intent="PERSONALISED_ADVICE")):
            result = agent.run(_state(session, "what should I buy?"))
        assert result["slot_gap"] == []


# ---------------------------------------------------------------------------
# 7. Defensive value handling
# ---------------------------------------------------------------------------

class TestDefensiveValueHandling:
    def test_confidence_above_one_clamped(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY", confidence=99.0)):
            result = agent.run(_state(session, "RMD?"))
        assert result["intent_stack"][0].confidence == 1.0

    def test_negative_confidence_clamped(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY", confidence=-0.5)):
            result = agent.run(_state(session, "RMD?"))
        assert result["intent_stack"][0].confidence == 0.0

    def test_invalid_change_type_falls_back_to_new(self, agent, session):
        with _patch_llm(_llm_response(sub_intent="RMD_INQUIRY",
                                      change_type="GIBBERISH_TYPE")):
            result = agent.run(_state(session, "RMD?"))
        assert result["intent_stack"][0].change_type == IntentChangeType.NEW

    def test_llm_extra_keys_ignored(self):
        """_LLMIntentFallback must accept extra keys (real LLMs add them)."""
        raw = _LLMIntentFallback.model_validate({
            "intent_id": "RETIREMENT_SERVICES.RMD_INQUIRY",
            "sub_intent": "RMD_INQUIRY",
            "confidence": 0.9,
            "change_type": "NEW",
            # Unknown keys:
            "raw_thought": "...",
            "model_version": "v3",
        })
        assert raw.sub_intent == "RMD_INQUIRY"


# ---------------------------------------------------------------------------
# 8. LLM total fallback
# ---------------------------------------------------------------------------

class TestLLMFallback:
    def test_llm_fallback_with_existing_stack_keeps_stack(self, agent, session):
        """If call_llm returns the fallback (sub_intent=''), result is the
        unknown-intent fallback path which preserves the existing stack."""
        active = _existing_intent("PLAN_LOAN_REQUEST")
        # Default fallback has sub_intent="" → unknown
        fallback = _LLMIntentFallback(sub_intent="", reasoning="llm_fallback")
        with _patch_llm(fallback):
            result = agent.run(_state(session, "...", intent_stack=[active]))
        assert result["intent_stack"][0].sub_intent == "PLAN_LOAN_REQUEST"


# ---------------------------------------------------------------------------
# 9. Health check
# ---------------------------------------------------------------------------

class TestHealthCheck:
    def test_health_check_returns_bool(self, agent):
        assert isinstance(agent.health_check(), bool)
