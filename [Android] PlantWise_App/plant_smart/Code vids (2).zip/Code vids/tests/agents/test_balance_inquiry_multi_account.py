"""
Unit tests for multi-account support in BalanceInquiryTool and
``compute_slot_gap`` for ACCOUNT_BALANCE_INQUIRY.

These cover:
  - Single-account user: balance returned without asking account_type.
  - Multi-account user with no account_type entity: slot_gap requests it.
  - Multi-account user with account_type entity: correct account selected.
  - Multi-account user requesting a type they don't own: graceful failure.
  - Legacy flat ``account_context`` shape: still works.
"""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

import pytest

from agents.intent_agent.v1.taxonomy import lookup_intent
from graph.state import compute_slot_gap
from schemas.enums import AuthLevel, EntityType, IntentChangeType, ServiceDomain
from schemas.primitives import EntityRecord, IntentRecord
from tools.balance_inquiry.v1.agent import BalanceInquiryTool, set_account_api
from tests.mocks.account_api import AccountRecord, MockAccountAPI


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _multi_account_context() -> dict:
    """Mirror demo-user-004's account_context (401K + IRA + BROKERAGE)."""
    return {
        "primary_account_type": "401K",
        "available_account_types": ["401K", "TRADITIONAL_IRA", "BROKERAGE"],
        "accounts": {
            "401K": {
                "account_number": "tok_acc_1100",
                "account_type": "401K",
                "plan_type": "401K",
                "plan_name": "Initech 401(k) Plan",
                "vested_balance": 487300.25,
                "total_balance": 492100.25,
                "unvested_balance": 4800.00,
                "ytd_contributions": 22500.00,
                "ytd_employer_match": 8200.00,
                "annual_match_max": 10000.00,
                "outstanding_loan_balance": 0,
                "plan_allows_loans": True,
            },
            "TRADITIONAL_IRA": {
                "account_number": "tok_acc_2200",
                "account_type": "TRADITIONAL_IRA",
                "plan_type": "TRADITIONAL_IRA",
                "plan_name": "Self-Directed Traditional IRA",
                "vested_balance": 78400.00,
                "total_balance": 78400.00,
            },
            "BROKERAGE": {
                "account_number": "tok_acc_3300",
                "account_type": "BROKERAGE",
                "plan_type": "BROKERAGE",
                "plan_name": "Individual Brokerage Account",
                "vested_balance": 156750.80,
                "total_balance": 156750.80,
            },
        },
        "account_number": "tok_acc_1100",  # legacy primary
        "plan_type": "401K",
    }


def _single_account_context() -> dict:
    """Mirror demo-user-001's account_context (single 401K)."""
    return {
        "primary_account_type": "401K",
        "available_account_types": ["401K"],
        "accounts": {
            "401K": {
                "account_number": "tok_acc_8810",
                "account_type": "401K",
                "plan_type": "401K",
                "plan_name": "ACME Corp 401(k) Plan",
                "vested_balance": 145230.55,
                "total_balance": 148980.55,
                "unvested_balance": 3750.00,
                "ytd_contributions": 12500.00,
                "ytd_employer_match": 4500.00,
                "annual_match_max": 6000.00,
                "outstanding_loan_balance": 0,
                "plan_allows_loans": True,
            },
        },
        "account_number": "tok_acc_8810",
        "plan_type": "401K",
    }


def _legacy_context() -> dict:
    """Pre-multi-account flat shape (no nested ``accounts`` map)."""
    return {
        "account_number": "tok_acc_9999",
        "plan_type": "401K",
        "vested_balance": 50000.00,
    }


def _account_record(account_number: str, account_type: str, vested: float) -> AccountRecord:
    return AccountRecord(
        account_number=account_number,
        account_type=account_type,
        owner_name="Test User",
        owner_age_years=40.0,
        owner_dob="1985-01-01",
        total_balance=vested + 1000.0,
        vested_balance=vested,
        unvested_balance=1000.0,
        plan_name=f"{account_type} Plan",
    )


@pytest.fixture
def seeded_api():
    """Inject a fresh MockAccountAPI seeded with the multi-account user
    demo-user-004's three accounts plus the single-account user-001."""
    api = MockAccountAPI()
    api.seed_account(_account_record("tok_acc_1100", "401K", 487300.25))
    api.seed_account(_account_record("tok_acc_2200", "TRADITIONAL_IRA", 78400.00))
    api.seed_account(_account_record("tok_acc_3300", "BROKERAGE", 156750.80))
    api.seed_account(_account_record("tok_acc_8810", "401K", 145230.55))
    api.seed_account(_account_record("tok_acc_9999", "401K", 50000.00))
    set_account_api(api)
    yield api
    set_account_api(None)


def _account_type_entity(value: str) -> EntityRecord:
    return EntityRecord(
        entity_id=uuid4(),
        entity_type=EntityType.ACCOUNT_TYPE,
        is_pii=False,
        slot_name="account_type",
        display_value=value,
        confidence=0.95,
    )


def _state_for_balance_inquiry(account_context: dict, entities: dict | None = None) -> dict:
    """Minimal GraphState for compute_slot_gap testing."""
    intent_def = lookup_intent("ACCOUNT_BALANCE_INQUIRY")
    intent = IntentRecord(
        intent_id=intent_def.intent_id,
        service_domain=ServiceDomain.RETIREMENT_SERVICES,
        sub_intent="ACCOUNT_BALANCE_INQUIRY",
        confidence=0.9,
        change_type=IntentChangeType.NEW,
        requires_auth_level=AuthLevel.STRONG,
        is_transactional=True,
        required_slots=list(intent_def.required_slots),
    )
    return {
        "intent_stack": [intent],
        "active_intent_id": intent.intent_id,
        "validated_entities": {},
        "entity_memory": entities or {},
        "account_context": account_context,
    }


# ---------------------------------------------------------------------------
# 1. compute_slot_gap behaviour for ACCOUNT_BALANCE_INQUIRY
# ---------------------------------------------------------------------------


class TestSlotGapForBalanceInquiry:

    def test_single_account_user_does_not_need_account_type(self):
        state = _state_for_balance_inquiry(_single_account_context())
        assert compute_slot_gap(state) == [], (
            "Single-account users must not be asked which account; "
            "compute_slot_gap should treat account_type as filled."
        )

    def test_multi_account_user_needs_account_type(self):
        state = _state_for_balance_inquiry(_multi_account_context())
        assert compute_slot_gap(state) == ["account_type"], (
            "Multi-account users must be prompted for account_type."
        )

    def test_multi_account_user_with_extracted_type_has_no_gap(self):
        ent = _account_type_entity("401K")
        state = _state_for_balance_inquiry(
            _multi_account_context(),
            entities={ent.entity_id: ent},
        )
        assert compute_slot_gap(state) == []

    def test_legacy_flat_context_has_no_gap(self):
        state = _state_for_balance_inquiry(_legacy_context())
        # No nested accounts map → treated as <=1 → soft-filled.
        assert compute_slot_gap(state) == []

    def test_empty_accounts_map_does_not_block(self):
        state = _state_for_balance_inquiry({"accounts": {}})
        # Edge case: zero accounts.  We don't want to loop forever asking
        # for an account_type the user doesn't have.  The tool will
        # fail cleanly downstream with a "missing account_number" error.
        assert compute_slot_gap(state) == []


# ---------------------------------------------------------------------------
# 2. BalanceInquiryTool account selection
# ---------------------------------------------------------------------------


class TestBalanceInquirySelection:

    def test_single_account_user_auto_selects(self, seeded_api):
        agent = BalanceInquiryTool()
        result = agent.execute(
            validated_entities={},
            account_context=_single_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****8810"
        assert tx["vested_balance"] == 145230.55

    def test_multi_account_user_with_explicit_type_401k(self, seeded_api):
        agent = BalanceInquiryTool()
        ent = _account_type_entity("401K")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****1100"
        assert tx["vested_balance"] == 487300.25

    def test_multi_account_user_with_explicit_type_ira(self, seeded_api):
        agent = BalanceInquiryTool()
        ent = _account_type_entity("TRADITIONAL_IRA")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****2200"
        assert tx["vested_balance"] == 78400.00

    def test_multi_account_user_with_explicit_type_brokerage(self, seeded_api):
        agent = BalanceInquiryTool()
        ent = _account_type_entity("BROKERAGE")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****3300"
        assert tx["vested_balance"] == 156750.80

    def test_narrow_balance_ask_ignores_brokerage_from_prior_turn(self, seeded_api):
        """Regression: merged history must not add brokerage to 401k+IRA balance."""
        agent = BalanceInquiryTool()
        recent = "show me last month balance for IRA and brokerage account\n"
        result = agent.execute(
            validated_entities={},
            account_context=_multi_account_context(),
            auth_token="token",
            recent_user_queries_text=recent,
            last_user_message="show my 401k and IRA account balance",
            current_turn=6,
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx.get("operation") == "BALANCE_INQUIRY_MULTI"
        assert tx.get("account_count") == 2
        types = {a.get("account_type") for a in tx.get("accounts") or []}
        assert types == {"401K", "TRADITIONAL_IRA"}

    def test_tail_line_all_balances_after_prior_iras_includes_three(self, seeded_api):
        """Latest line scopes 'all'; prior IRA/401k mentions must not cap at two."""
        agent = BalanceInquiryTool()
        recent = (
            "show me my IRA and 401k transaction history from april 2026\n"
            "ok\n"
            "7766\n"
        )
        result = agent.execute(
            validated_entities={},
            account_context=_multi_account_context(),
            auth_token="token",
            recent_user_queries_text=recent,
            last_user_message="Show all my accounts balances",
            current_turn=5,
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx.get("operation") == "BALANCE_INQUIRY_MULTI"
        assert tx.get("account_count") == 3

    def test_alias_bare_ira_resolves_to_traditional_ira(self, seeded_api):
        """User answers 'IRA' (LLM normalises to display_value='IRA');
        balance_inquiry must map this to TRADITIONAL_IRA when that's the
        only IRA-flavoured account the user owns."""
        agent = BalanceInquiryTool()
        ent = _account_type_entity("IRA")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****2200"

    def test_alias_401k_with_parens_resolves(self, seeded_api):
        agent = BalanceInquiryTool()
        ent = _account_type_entity("401(K)")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****1100"

    def test_alias_ambiguous_roth_with_two_roth_accounts_fails(self, seeded_api):
        """When user has both ROTH_IRA and ROTH_401K, bare 'ROTH' is
        ambiguous and must NOT silently pick one — return the standard
        failure so the synthesizer can re-prompt."""
        agent = BalanceInquiryTool()
        ctx = {
            "available_account_types": ["ROTH_IRA", "ROTH_401K"],
            "accounts": {
                "ROTH_IRA": {"account_number": "tok_acc_7777"},
                "ROTH_401K": {"account_number": "tok_acc_8888"},
            },
        }
        ent = _account_type_entity("ROTH")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=ctx,
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is False

    def test_unknown_account_type_returns_failure(self, seeded_api):
        agent = BalanceInquiryTool()
        # User asks for ROTH_IRA but only has 401K, IRA, BROKERAGE.
        ent = _account_type_entity("ROTH_IRA")
        result = agent.execute(
            validated_entities={"account_type": ent},
            account_context=_multi_account_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is False
        assert tx["status"] == "FAILED"
        # Error message mentions what the user actually has.
        joined = " ".join(tx.get("errors", []))
        assert "ROTH_IRA" in joined
        assert "401K" in joined or "TRADITIONAL_IRA" in joined or "BROKERAGE" in joined

    def test_legacy_flat_context_still_works(self, seeded_api):
        agent = BalanceInquiryTool()
        result = agent.execute(
            validated_entities={},
            account_context=_legacy_context(),
            auth_token="token",
        )
        tx = result["transaction_result"]
        assert tx["success"] is True
        assert tx["account_display"] == "****9999"


# ---------------------------------------------------------------------------
# 3. compute_slot_gap for PLAN_LOAN_* (loan-eligible account parity)
# ---------------------------------------------------------------------------


def _state_for_plan_loan(
    sub_intent: str,
    account_context: dict,
    *,
    entity_memory: dict | None = None,
    last_user_message: str | None = None,
) -> dict:
    intent_def = lookup_intent(sub_intent)
    assert intent_def is not None
    intent = IntentRecord(
        intent_id=intent_def.intent_id,
        service_domain=ServiceDomain.RETIREMENT_SERVICES,
        sub_intent=sub_intent,
        confidence=0.9,
        change_type=IntentChangeType.NEW,
        requires_auth_level=AuthLevel.STRONG,
        is_transactional=True,
        required_slots=list(intent_def.required_slots),
    )
    st: dict = {
        "intent_stack": [intent],
        "active_intent_id": intent.intent_id,
        "validated_entities": {},
        "entity_memory": entity_memory or {},
        "account_context": account_context,
    }
    if last_user_message is not None:
        st["last_user_message"] = last_user_message
    return st


def _two_erisa_loan_accounts_context() -> dict:
    """Two DC plan types that both allow loans — user must disambiguate."""
    return {
        "accounts": {
            "401K": {
                "account_number": "tok_a",
                "plan_allows_loans": True,
                "vested_balance": 100000.0,
            },
            "403B": {
                "account_number": "tok_b",
                "plan_allows_loans": True,
                "vested_balance": 50000.0,
            },
        }
    }


class TestSlotGapForPlanLoan:
    def test_single_account_user_skips_plan_type_on_request(self):
        state = _state_for_plan_loan("PLAN_LOAN_REQUEST", _single_account_context())
        assert "plan_type" not in compute_slot_gap(state)

    def test_multi_user_one_loan_eligible_skips_plan_type(self):
        state = _state_for_plan_loan("PLAN_LOAN_REQUEST", _multi_account_context())
        gap = compute_slot_gap(state)
        assert "plan_type" not in gap
        assert "loan_amount" in gap

    def test_two_erisa_accounts_still_need_plan_type(self):
        state = _state_for_plan_loan(
            "PLAN_LOAN_ELIGIBILITY", _two_erisa_loan_accounts_context()
        )
        assert compute_slot_gap(state) == ["plan_type"]

    def test_two_erisa_accounts_named_in_message_skips_plan_type(self):
        state = _state_for_plan_loan(
            "PLAN_LOAN_ELIGIBILITY",
            _two_erisa_loan_accounts_context(),
            last_user_message="from my 401k",
        )
        assert compute_slot_gap(state) == []

    def test_legacy_flat_context_skips_plan_type(self):
        state = _state_for_plan_loan("PLAN_LOAN_STATUS", _legacy_context())
        assert compute_slot_gap(state) == []


# ---------------------------------------------------------------------------
# 4. Demo data integrity
# ---------------------------------------------------------------------------


class TestDemoDataShape:
    """Catch regressions in demo_data/accounts.json before runtime."""

    @pytest.fixture(autouse=True)
    def _load(self):
        import json
        from pathlib import Path
        path = Path(__file__).resolve().parents[2] / "demo_data" / "accounts.json"
        with path.open() as f:
            self.users = json.load(f)

    def test_all_users_have_account_context(self):
        for uid, data in self.users.items():
            assert "account_context" in data, f"{uid} missing account_context"

    def test_all_users_have_accounts_map(self):
        for uid, data in self.users.items():
            ctx = data["account_context"]
            assert "accounts" in ctx, f"{uid} missing accounts map"
            assert isinstance(ctx["accounts"], dict)
            assert len(ctx["accounts"]) >= 1, f"{uid} has empty accounts map"

    def test_account_numbers_are_unique(self):
        seen: set[str] = set()
        for uid, data in self.users.items():
            for atype, acct in data["account_context"]["accounts"].items():
                num = acct["account_number"]
                assert num not in seen, f"Duplicate account_number {num} in {uid}/{atype}"
                seen.add(num)

    def test_multi_account_user_has_distinct_types(self):
        jordan = self.users["demo-user-004"]
        types = set(jordan["account_context"]["accounts"].keys())
        assert {"401K", "TRADITIONAL_IRA", "BROKERAGE"}.issubset(types)

    def test_taylor_has_roth_ira(self):
        taylor = self.users["demo-user-005"]
        types = set(taylor["account_context"]["accounts"].keys())
        assert {"401K", "ROTH_IRA"}.issubset(types)

    def test_available_types_match_accounts_map(self):
        for uid, data in self.users.items():
            ctx = data["account_context"]
            available = set(ctx.get("available_account_types") or [])
            accounts = set(ctx.get("accounts", {}).keys())
            assert available == accounts, (
                f"{uid}: available_account_types {available} does not match "
                f"accounts map keys {accounts}"
            )
