"""Parity: in-process mock vs HTTP client return identical payloads.

Spins up the FastAPI service in-thread on a free port so the real
``HttpAccountAPI`` (which uses a sync ``httpx.Client``) can be exercised
against it. Compares each response shape against the in-process call,
ignoring the per-call ``as_of`` timestamp.
"""

from __future__ import annotations

import socket
import threading
import time
import urllib.request

import pytest
import uvicorn

import config as cfg
from auth.jwt_utils import issue_token
from mock_services.account_service import store
from mock_services.account_service.main import app
from mock_services.inprocess.account_api import AccountNotFoundError
from tools.clients.http.account_api import HttpAccountAPI


def _strip(d: dict) -> dict:
    return {k: v for k, v in d.items() if k != "as_of"}


@pytest.fixture(scope="module")
def live_service():
    """Run the FastAPI app on a free port for the duration of the module."""
    store.reset()
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    config = uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning", lifespan="on",
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    deadline = time.time() + 5.0
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=0.2)
            break
        except Exception:  # noqa: BLE001
            time.sleep(0.05)
    else:
        server.should_exit = True
        raise RuntimeError("account_service did not become ready")

    prev_url = cfg.settings.account_api_base_url
    prev_provider = cfg.settings.tool_api_provider
    cfg.settings.account_api_base_url = f"http://127.0.0.1:{port}"
    cfg.settings.tool_api_provider = "http"

    yield port

    cfg.settings.account_api_base_url = prev_url
    cfg.settings.tool_api_provider = prev_provider
    server.should_exit = True
    thread.join(timeout=2.0)


def test_get_balance_parity(live_service):
    token, _ = issue_token("demo-user-001")
    ip = store.account_api()
    http_api = HttpAccountAPI()
    assert _strip(ip.get_balance("tok_acc_8810", token)) == _strip(
        http_api.get_balance("tok_acc_8810", token)
    )


def test_account_details_parity(live_service):
    token, _ = issue_token("demo-user-001")
    ip = store.account_api()
    http_api = HttpAccountAPI()
    assert _strip(ip.get_account_details("tok_acc_8810", token)) == _strip(
        http_api.get_account_details("tok_acc_8810", token)
    )


def test_not_found_raises_same_exception(live_service):
    token, _ = issue_token("demo-user-001")
    http_api = HttpAccountAPI()
    with pytest.raises(AccountNotFoundError):
        http_api.get_balance("tok_acc_DOES_NOT_EXIST", token)
