"""Account-service authentication tests."""

from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_health_no_auth(client):
    r = await client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"


@pytest.mark.asyncio
async def test_missing_token_returns_401(client):
    r = await client.get("/v1/accounts/tok_acc_8810/balance")
    assert r.status_code == 401
    # FastAPI returns HTTPException details under "detail"
    assert r.json()["detail"]["error_code"] == "MISSING_TOKEN"


@pytest.mark.asyncio
async def test_malformed_bearer_returns_401(client):
    r = await client.get(
        "/v1/accounts/tok_acc_8810/balance",
        headers={"Authorization": "Token foo"},
    )
    assert r.status_code == 401
    assert r.json()["detail"]["error_code"] == "MISSING_TOKEN"


@pytest.mark.asyncio
async def test_invalid_token_returns_401(client):
    r = await client.get(
        "/v1/accounts/tok_acc_8810/balance",
        headers={"Authorization": "Bearer junk"},
    )
    assert r.status_code == 401
    assert r.json()["detail"]["error_code"] == "INVALID_TOKEN"
