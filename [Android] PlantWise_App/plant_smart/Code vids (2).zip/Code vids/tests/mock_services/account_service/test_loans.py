"""Account-service loan endpoint tests."""

from __future__ import annotations

import pytest


_ELIG_BODY = {
    "account_number": "tok_acc_8810",
    "vested_balance": 145000.0,
    "outstanding_loan_balance": 0.0,
    "highest_loan_balance_12m": 0.0,
    "plan_allows_loans": True,
}


@pytest.mark.asyncio
async def test_loan_eligibility_success(client, auth_headers):
    r = await client.post(
        "/v1/loans/eligibility", headers=auth_headers, json=_ELIG_BODY,
    )
    assert r.status_code == 200
    body = r.json()
    assert body["eligible"] is True
    # max loan = min(50% of vested, $50k) = $50k here
    assert body["max_loan_amount"] == 50000.0


@pytest.mark.asyncio
async def test_loan_eligibility_plan_disallows(client, auth_headers):
    body = {**_ELIG_BODY, "plan_allows_loans": False}
    r = await client.post("/v1/loans/eligibility", headers=auth_headers, json=body)
    # Eligibility check returns 200 with eligible=False; only initiation raises.
    assert r.status_code == 200
    out = r.json()
    assert out["eligible"] is False
    assert out["max_loan_amount"] == 0.0
    assert "Plan" in out["rejection_reason"]


@pytest.mark.asyncio
async def test_initiate_loan_success(client, auth_headers):
    body = {
        "account_number": "tok_acc_8810",
        "amount": 10000.0,
        "term_months": 36,
        "vested_balance": 145000.0,
        "plan_allows_loans": True,
    }
    r = await client.post(
        "/v1/loans",
        headers={**auth_headers, "Idempotency-Key": "test-loan-1"},
        json=body,
    )
    assert r.status_code == 200
    out = r.json()
    assert out["confirmation_number"].startswith("LN-")
    assert out["monthly_payment"] > 0


@pytest.mark.asyncio
async def test_initiate_loan_idempotency_replay_returns_409(client, auth_headers):
    body = {
        "account_number": "tok_acc_8810",
        "amount": 10000.0,
        "term_months": 36,
        "vested_balance": 145000.0,
        "plan_allows_loans": True,
    }
    headers = {**auth_headers, "Idempotency-Key": "test-loan-dup"}
    r1 = await client.post("/v1/loans", headers=headers, json=body)
    assert r1.status_code == 200
    r2 = await client.post("/v1/loans", headers=headers, json=body)
    assert r2.status_code == 409
    assert r2.json()["error_code"] == "DUPLICATE_LOAN"
