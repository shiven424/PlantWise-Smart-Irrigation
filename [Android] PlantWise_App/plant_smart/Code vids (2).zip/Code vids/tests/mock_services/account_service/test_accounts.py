"""Account-service account endpoint tests."""

from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_get_balance_success(client, auth_headers):
    r = await client.get("/v1/accounts/tok_acc_8810/balance", headers=auth_headers)
    assert r.status_code == 200
    body = r.json()
    assert body["total_balance"] == 148980.55
    assert body["vested_balance"] == 145230.55
    assert body["account_type"] == "401K"
    assert "as_of" in body


@pytest.mark.asyncio
async def test_get_balance_account_not_found(client, auth_headers):
    r = await client.get("/v1/accounts/tok_acc_NOPE/balance", headers=auth_headers)
    assert r.status_code == 404
    body = r.json()
    assert body["error_code"] == "ACCOUNT_NOT_FOUND"
    assert "trace_id" in body
    assert r.headers.get("X-Trace-Id")


@pytest.mark.asyncio
async def test_get_account_details_success(client, auth_headers):
    r = await client.get("/v1/accounts/tok_acc_8810", headers=auth_headers)
    assert r.status_code == 200
    body = r.json()
    assert body["account_type"] == "401K"
    assert body["account_number_last4"] == "8810"
    assert body["is_active"] is True


@pytest.mark.asyncio
async def test_get_prior_year_balance(client, auth_headers):
    r = await client.get(
        "/v1/accounts/tok_acc_8810/prior-year-balance", headers=auth_headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert "prior_year_end_balance" in body
    assert body["prior_year_end_balance"] > 0


@pytest.mark.asyncio
async def test_get_beneficiaries(client, auth_headers):
    r = await client.get(
        "/v1/accounts/tok_acc_8810/beneficiaries", headers=auth_headers,
    )
    assert r.status_code == 200
    body = r.json()
    assert "beneficiaries" in body
    assert "count" in body


@pytest.mark.asyncio
async def test_update_beneficiaries_total_must_be_100(client, auth_headers):
    r = await client.put(
        "/v1/accounts/tok_acc_8810/beneficiaries",
        headers=auth_headers,
        json={
            "beneficiaries": [
                {
                    "name": "Spouse",
                    "relationship": "SPOUSE",
                    "percentage": 50,
                    "beneficiary_type": "PRIMARY",
                },
            ],
        },
    )
    assert r.status_code == 400
    assert r.json()["error_code"] == "VALIDATION_ERROR"


@pytest.mark.asyncio
async def test_update_beneficiaries_success(client, auth_headers):
    r = await client.put(
        "/v1/accounts/tok_acc_8810/beneficiaries",
        headers=auth_headers,
        json={
            "beneficiaries": [
                {
                    "name": "Spouse",
                    "relationship": "SPOUSE",
                    "percentage": 100,
                    "beneficiary_type": "PRIMARY",
                },
            ],
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "UPDATED"
    assert body["beneficiary_count"] == 1
