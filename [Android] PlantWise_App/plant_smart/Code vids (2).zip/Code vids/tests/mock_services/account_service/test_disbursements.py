"""Account-service disbursement endpoint tests."""

from __future__ import annotations

import pytest


_ACH_BODY = {
    "account_number": "tok_acc_8810",
    "bank_routing_number": "021000021",  # passes ABA checksum
    "bank_account_number": "12345",
    "amount": 1000.0,
    "owner_age": 40.0,
}


@pytest.mark.asyncio
async def test_submit_ach_success(client, auth_headers):
    r = await client.post("/v1/disbursements/ach", headers=auth_headers, json=_ACH_BODY)
    assert r.status_code == 200
    body = r.json()
    assert body["net_disbursement"] > 0
    # Owner is under 59.5 -> 10% early-withdrawal penalty applies
    assert body["early_withdrawal_penalty"] == pytest.approx(100.0)


@pytest.mark.asyncio
async def test_submit_ach_invalid_routing(client, auth_headers):
    body = {**_ACH_BODY, "bank_routing_number": "123456789"}  # fails ABA
    r = await client.post("/v1/disbursements/ach", headers=auth_headers, json=body)
    assert r.status_code == 400
    assert r.json()["error_code"] == "INVALID_ROUTING_NUMBER"


@pytest.mark.asyncio
async def test_submit_ach_idempotency_replay_returns_409(client, auth_headers):
    headers = {**auth_headers, "Idempotency-Key": "ach-dup-1"}
    r1 = await client.post("/v1/disbursements/ach", headers=headers, json=_ACH_BODY)
    assert r1.status_code == 200
    r2 = await client.post("/v1/disbursements/ach", headers=headers, json=_ACH_BODY)
    assert r2.status_code == 409
    assert r2.json()["error_code"] == "DUPLICATE_REQUEST"


@pytest.mark.asyncio
async def test_submit_check_requires_mailing_address(client, auth_headers):
    # Missing mailing_address -> 422 from Pydantic
    r = await client.post(
        "/v1/disbursements/check",
        headers=auth_headers,
        json={"account_number": "tok_acc_8810", "amount": 500.0, "owner_age": 65.0},
    )
    assert r.status_code == 422
