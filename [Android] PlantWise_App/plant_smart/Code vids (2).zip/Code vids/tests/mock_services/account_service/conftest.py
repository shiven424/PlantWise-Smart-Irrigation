"""Shared fixtures for account-service tests."""

from __future__ import annotations

import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from auth.jwt_utils import issue_token
from mock_services.account_service import store
from mock_services.account_service.main import app


@pytest_asyncio.fixture
async def client():
    """Fresh HTTP client backed by the in-memory FastAPI app.

    The store is reset before each test so seed data and idempotency
    caches start clean.
    """
    store.reset()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://t") as c:
        yield c


@pytest_asyncio.fixture
async def auth_headers():
    """Headers carrying a valid JWT for demo-user-001 (Alex Patel)."""
    token, _ = issue_token("demo-user-001")
    return {"Authorization": f"Bearer {token}"}


@pytest_asyncio.fixture
async def alt_auth_headers():
    """Headers for demo-user-002 (Maya Robinson)."""
    token, _ = issue_token("demo-user-002")
    return {"Authorization": f"Bearer {token}"}
