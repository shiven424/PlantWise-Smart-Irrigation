"""Backward-compat shim. Real implementation: ``mock_services.inprocess.loan_api``."""

from mock_services.inprocess.loan_api import (  # noqa: F401
    AmortizationEntry,
    AuthorizationError,
    DEFAULT_INTEREST_RATE,
    DuplicateLoanError,
    GENERAL_PURPOSE_MAX_TERM_MONTHS,
    IRC_72P_ABSOLUTE_MAX,
    IRC_72P_FLOOR,
    IRC_72P_VESTED_PCT,
    LoanEligibility,
    LoanNotFoundError,
    LoanRecord,
    LoanRejectedError,
    MINIMUM_LOAN_AMOUNT,
    MockLoanAPI,
    PRIMARY_RESIDENCE_MAX_TERM_MONTHS,
    PlanDoesNotAllowLoansError,
    calculate_monthly_payment,
    create_mock_loan_api,
    generate_amortization_schedule,
)
