"""Backward-compat shim. Real implementation: ``mock_services.inprocess.account_api``."""

from mock_services.inprocess.account_api import (  # noqa: F401
    AccountFrozenError,
    AccountNotFoundError,
    AccountRecord,
    AuthorizationError,
    Beneficiary,
    FROZEN_ACCOUNT,
    HIGH_BALANCE_401K,
    INACTIVE_ACCOUNT,
    InsufficientBalanceError,
    MockAccountAPI,
    RMD_ELIGIBLE_ACCOUNT,
    ROTH_IRA,
    STANDARD_401K,
    STANDARD_IRA,
    Transaction,
    create_mock_account_api,
)
