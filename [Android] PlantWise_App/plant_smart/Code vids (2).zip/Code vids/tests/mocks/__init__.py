"""Backward-compat shim package.

The mock implementations were moved to ``mock_services.inprocess`` so
the FastAPI mock service and the ``api_factory`` HTTP backend can share
them without depending on the test tree. This package now only re-exports
the same symbols so existing test imports keep working unchanged.
"""
