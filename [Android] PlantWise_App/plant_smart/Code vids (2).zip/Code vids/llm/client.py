from __future__ import annotations

"""
Centralised LLM client utility.

All agent LLM calls go through this module — never instantiate SDK clients
directly in agents.

Provides:
  call_llm()      — structured JSON -> Pydantic model
  call_llm_text() — raw text response

Design principles:
  - Provider-agnostic: Anthropic, Bedrock, OpenAI, GitHub
  - Config-driven: model, tokens, timeout from settings
  - Safe fallback: returns caller-supplied default on any failure
  - Observable: logs all calls and failures via structured logger
  - Testable: @patch("llm.client.get_client") in tests
"""

import json
from typing import TypeVar, Type

from pydantic import BaseModel, ValidationError
from tenacity import retry, stop_after_attempt, wait_exponential, wait_random, retry_if_exception_type

import anthropic
import openai

from config import settings
from observability.logger import log

T = TypeVar("T", bound=BaseModel)

# -- Singleton Client ---------------------------------------------------------

import threading

_client = None
_client_lock = threading.Lock()


def get_client():
    """
    Lazy singleton for the LLM SDK client.

    Reads ``settings.llm_provider`` to choose between Anthropic, Bedrock,
    and OpenAI.  Client is cached after first creation.  Use
    ``reset_client()`` in tests.
    """
    global _client
    if _client is not None:
        return _client

    with _client_lock:
        if _client is not None:          # double-check inside lock
            return _client

        provider = settings.llm_provider
        timeout = float(settings.llm_timeout_seconds)

        if provider == "anthropic":
            from anthropic import Anthropic
            _client = Anthropic(
                api_key=settings.anthropic_api_key,
                timeout=timeout,
            )
        elif provider == "bedrock":
            from anthropic import AnthropicBedrock
            _client = AnthropicBedrock(
                aws_region=settings.aws_region,
                aws_access_key=settings.aws_access_key_id or None,
                aws_secret_key=settings.aws_secret_access_key or None,
                timeout=timeout,
            )
        elif provider == "openai":
            from openai import OpenAI
            _client = OpenAI(
                api_key=settings.openai_api_key,
                timeout=timeout,
            )
        elif provider == "github":
            from openai import OpenAI
            _client = OpenAI(
                api_key=settings.github_token,
                base_url="https://models.inference.ai.azure.com",
                timeout=timeout,
            )
        else:
            raise ValueError(
                f"Unsupported llm_provider={provider!r}. "
                f"Must be 'anthropic', 'bedrock', 'openai', or 'github'."
            )

        log.info("llm_client_created", provider=provider, model=settings.llm_model)
        return _client


def reset_client() -> None:
    """Clear the cached client.  Call in test teardown or when settings change."""
    global _client
    _client = None


# -- Structured JSON -> Pydantic Call -----------------------------------------

def call_llm(
    *,
    system_prompt: str,
    user_prompt: str,
    response_model: Type[T],
    fallback: T,
    model: str | None = None,
    max_tokens: int | None = None,
    temperature: float = 0.0,
    cacheable: bool = False,
) -> T:
    """
    Call the LLM, parse the JSON response, and validate into *response_model*.

    On ANY failure (network, timeout, JSON parse, Pydantic validation),
    logs a warning and returns *fallback*.  Agents should always provide a
    safe default so the graph never crashes on an LLM hiccup.

    Args:
        system_prompt:  System-level instruction (must end with
                        "Respond ONLY with valid JSON" per coding rules).
        user_prompt:    User-level input (message + context).
        response_model: Pydantic model class to validate the JSON into.
        fallback:       Instance of *response_model* returned on failure.
        model:          Override ``settings.llm_model`` for this call.
        max_tokens:     Override ``settings.llm_max_tokens`` for this call.
        temperature:    Defaults to 0.0 (deterministic).
        cacheable:      When True and provider is anthropic/bedrock, attach
                        cache_control to the system prompt block so the prefix
                        is eligible for prompt caching.

    Returns:
        Validated *response_model* instance, or *fallback* on any error.
    """
    _model = model or settings.llm_model
    _max_tokens = max_tokens or settings.llm_max_tokens
    text = None

    try:
        text = _raw_call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model=_model,
            max_tokens=_max_tokens,
            temperature=temperature,
            cacheable=cacheable,
        )
        data = json.loads(text)
        return response_model(**data)

    except json.JSONDecodeError as exc:
        log.warning(
            "llm_json_parse_error",
            model=_model,
            error=str(exc),
            raw_snippet=text[:200] if text else "N/A",
        )
        return fallback

    except ValidationError as exc:
        log.warning(
            "llm_validation_error",
            model=_model,
            error=str(exc),
            raw_snippet=text[:200] if text else "N/A",
        )
        return fallback

    except Exception as exc:
        log.warning("llm_call_failed", model=_model, error=str(exc))
        return fallback


# -- Plain-Text Call ----------------------------------------------------------

def call_llm_text(
    *,
    system_prompt: str,
    user_prompt: str,
    fallback: str = "",
    model: str | None = None,
    max_tokens: int | None = None,
    temperature: float = 0.0,
    cacheable: bool = False,
) -> str:
    """
    Call the LLM and return the raw text response.

    Used for free-form outputs:
      - Synthesizer opening frame (Layer 1)
      - Auth Agent challenge text
      - Entity Validator customer_message on violations

    On any failure, logs a warning and returns *fallback*.
    """
    _model = model or settings.llm_model
    _max_tokens = max_tokens or settings.llm_max_tokens

    try:
        return _raw_call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model=_model,
            max_tokens=_max_tokens,
            temperature=temperature,
            cacheable=cacheable,
        )
    except Exception as exc:
        log.warning("llm_text_call_failed", model=_model, error=str(exc))
        return fallback


# -- Internal: Provider Dispatch ----------------------------------------------

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=30) + wait_random(0, 2),
    retry=retry_if_exception_type((
        ConnectionError, TimeoutError, OSError,
        anthropic.APIConnectionError, anthropic.APITimeoutError,
        anthropic.RateLimitError, anthropic.InternalServerError,
        openai.APIConnectionError, openai.APITimeoutError,
        openai.RateLimitError, openai.InternalServerError,
    )),
    reraise=True,
)
def _raw_call(
    *,
    system_prompt: str,
    user_prompt: str,
    model: str,
    max_tokens: int,
    temperature: float,
    cacheable: bool = False,
) -> str:
    """
    Dispatch to the configured provider and return the raw text content.
    Raises on network/timeout/API errors — caller handles fallback.
    """
    client = get_client()
    provider = settings.llm_provider

    if provider in ("anthropic", "bedrock"):
        system_param: str | list
        if cacheable:
            system_param = [
                {
                    "type": "text",
                    "text": system_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        else:
            system_param = system_prompt
        raw = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_param,
            messages=[{"role": "user", "content": user_prompt}],
        )
        if not raw.content or not raw.content[0].text:
            raise ValueError(f"LLM returned empty content ({provider})")
        usage = raw.usage
        log.info(
            "llm_usage",
            provider=provider,
            model=model,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            cache_creation_tokens=getattr(usage, "cache_creation_input_tokens", 0) or 0,
            cache_read_tokens=getattr(usage, "cache_read_input_tokens", 0) or 0,
        )
        return raw.content[0].text

    if provider in ("openai", "github"):
        raw = client.chat.completions.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        if not raw.choices:
            raise ValueError("LLM returned empty choices (OpenAI)")
        content = raw.choices[0].message.content
        if not content:
            raise ValueError("LLM returned empty content (OpenAI)")
        return content

    raise ValueError(f"Unsupported provider: {provider}")
