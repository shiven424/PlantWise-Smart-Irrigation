# Contact Center AI — Demo Scripts (Simple → Complex)

This document is a **director's script** for live demos. Each scenario lists:

- **What to type** in the chat UI (`http://localhost:3000`) or send via API
- **Which demo account** to log in as (from [demo_data/accounts.json](demo_data/accounts.json))
- **What to expect** at each step (intent, auth status, HITL, response shape)
- **What to look for in metadata** (`active_intent`, `auth_status`, `slot_gap`, `policy_path`)

> **Setup pre-flight (run once):**
> 1. Backend: `python main.py` → `http://localhost:8000` (verify `/ready` returns `{"status":"ready"}`)
> 2. Index KB: `python -c "from knowledge_base.indexer import Indexer; print(Indexer().index_all())"`
> 3. Frontend: `cd frontend && npm run dev` → `http://localhost:3000`
> 4. Demo accounts: `alex / demo123`, `morgan / demo123`, `noauth / demo123`

> **Auth seed values** (from [demo_data/accounts.json](demo_data/accounts.json)):
> - **alex** (40 yo, single, 401K, $145,230.55 vested) — ZIP `94107`, SSN last4 `4321`, DOB `1985-06-12`
> - **morgan** (53 yo, married, 401K, $312,450.00 vested) — ZIP `10001`, SSN last4 `9988`, DOB `1972-03-04`
> - **noauth** (30 yo, IRA, $5,000) — **no auth secrets configured** (negative-path account)
>
> **OTP** (for ENHANCED-auth scenarios) is fetched from `GET /demo/last_otp/{user_id}` after the agent issues the challenge.

---

## Scenario 0 — Health & readiness sanity check

```powershell
curl http://localhost:8000/health   # → {"status":"ok",...}
curl http://localhost:8000/ready    # → {"status":"ready",...}
```

**Expected:** Both return `200`. `/ready` only succeeds when all 8 core agents are loaded (see [agents/registry.py](agents/registry.py)).

---

## Scenario 1 — Simple informational RAG (NO auth required)

**Goal:** Show the RAG agent answering a regulatory question with citations, no PII or auth needed.

**Login:** `alex`
**Type:** `What is the 2025 401(k) employee contribution limit and the catch-up amount for age 50+?`

**Expected:**
- `metadata.active_intent.sub_intent` = `CONTRIBUTION_INQUIRY` (or general RAG if classifier routes to informational)
- `metadata.auth_status` = `SOFT` or `SESSION` (no challenge issued — domain is informational)
- `action_type` = `INFORMATIONAL_RESPONSE`
- `response.full_message` cites IRS Publication 590-A and shows **$23,500** base + **$7,500** catch-up (50+) and the new **$11,250** catch-up window for ages 60–63 under SECURE 2.0
- `metadata.rag_confidence` ≥ ~0.7
- Response includes a `RETIREMENT_GENERAL` compliance disclosure tail

**Talking points:** RAG retrieved from `knowledge_base/documents/retirement/irs_pub_590a_ira_contributions.txt` and `secure_act_2_0_summary.txt`. No vault tokens issued.

---

## Scenario 2 — SOFT auth challenge (ZIP code) on a borderline informational ask

**Login:** `alex`
**Type:** `Can you confirm what plan I'm enrolled in?`

**Expected — Turn 1:**
- Supervisor routes to **auth_agent** because intent (account-tier inquiry) requires `SOFT`.
- `metadata.auth_status` = `PENDING`
- `action_type` = `AUTH_CHALLENGE`
- Bot asks: **"Please confirm the ZIP code on file."**

**Type — Turn 2:** `94107`

**Expected:**
- `metadata.auth_status` = `SOFT`
- Bot answers with the plan_type from `account_context` (401K) and a brief confirmation.

**Negative variant:** Type `00000` first → bot rejects, asks again. After 3 failures supervisor escalates (`escalation.reason` populated).

---

## Scenario 3 — STRONG auth → 401(k) balance inquiry (tool execution, no HITL)

**Login:** `alex`
**Type:** `What is my current 401(k) vested balance?`

**Expected — Turn 1:**
- Intent = `RETIREMENT_SERVICES.401K_BALANCE_INQUIRY` (auth_level = STRONG)
- Bot challenges for **last 4 of SSN**.
- `metadata.active_intent.sub_intent` = `401K_BALANCE_INQUIRY`

**Type — Turn 2:** `4321`

**Expected:**
- `metadata.auth_status` = `STRONG`
- `action_type` = `EXECUTE_TRANSACTION` → auto-resumed past `interrupt_before=["tool_router"]` because `balance_inquiry` is a **read-only** tool (no HITL gate).
- Response shows: **Vested balance $145,230.55**, plan_type `401K`, account ending in `8810`.
- `policy_path` includes `supervisor → auth_agent → entity_validator → tool_router → balance_inquiry → response_synthesizer`.

> **Note:** The pre-seeded demo account `DEMO-401K-12345` (from `_seed_demo_accounts` in [main.py](main.py)) returns a different balance; the exact figure depends on whether the frontend forwards `account_context.account_number`. Match against `account_context.vested_balance` from the demo accounts file.

---

## Scenario 4 — Multi-slot collection + HITL confirmation → IRA Rollover (transactional)

**Goal:** Demonstrate intent classification and graceful escalation for unsupported operations.

**Login:** `alex`

**Turn 1 — Type:** `I want to roll over my 401(k) into a Roth IRA`

**Expected:**
- Intent = `IRA_ROLLOVER` (correctly classified).
- Auth challenge first (STRONG → SSN last4). Provide `4321`.
- Supervisor routes `IRA_ROLLOVER` → `escalate` (rollover tool has been removed).
- Response: warm hand-off message directing alex to a specialist.
- `action_type` = `ESCALATE`; no tool execution, no HITL card.

---

## Scenario 5 — ENHANCED auth (OTP) → Withdrawal escalation

**Goal:** Demonstrate ENHANCED auth step-up and graceful escalation for unsupported withdrawal operations.

**Login:** `alex`

**Turn 1 — Type:** `I need a hardship withdrawal of $10,000 to cover medical bills`

**Expected:**
- Intent = `HARDSHIP_WITHDRAWAL` (auth_level = ENHANCED).
- Auth flow steps up: SSN last4 first (STRONG), then **One-Time Code** for ENHANCED.
- Provide `4321` when asked.

**Turn 2:** Bot says: **"I've sent a one-time code. Please enter it."**

**Fetch the OTP** (demo helper):
```powershell
# Use the JWT from /auth/login as the bearer
curl -H "Authorization: Bearer <JWT>" http://localhost:8000/demo/last_otp/demo-user-001
# → {"code":"123456","expires_at":"..."}
```

**Turn 3 — Type:** the code returned above

**Expected:**
- `metadata.auth_status` = `ENHANCED`.
- Supervisor routes `HARDSHIP_WITHDRAWAL` → `escalate` (withdrawal tool has been removed).
- Response: warm hand-off message directing alex to a specialist who can process the withdrawal.
- `action_type` = `ESCALATE`; no tool execution, no HITL card.

---

## Scenario 6 — RMD Calculation (age-gated, deterministic regulatory math)

**Login:** `morgan` (53 yo — **below 73**, RMDs do not apply yet)

**Type:** `What is my RMD for this year?`

**Expected:**
- Intent = `RMD_CALCULATION`. Auth challenge first (STRONG, SSN last4 `9988`).
- Tool `rmd_calculator` consults [regulatory/uniform_lifetime_table.py](regulatory/uniform_lifetime_table.py) and detects owner_age 53 < 73.
- Response: **"You are not yet subject to RMDs. RMDs begin at age 73 under SECURE 2.0."** plus `RMD_PENALTY_WARNING` disclosure.
- `transaction_result.computed_rmd` = `0.00` or `null`.

**Variant — eligible user (synthetic):** Set `account_context.owner_age_years = 75` in the **Start Conversation** payload (the frontend exposes this via the session-setup form). Re-run the same prompt. Expect a positive RMD computed from `vested_balance / divisor` where the divisor comes from the Uniform Lifetime Table for age 75 (24.6).

---

## Scenario 7 — Plan Loan with spousal-consent edge case

**Login:** `morgan` (married, `spousal_consent_obtained: false`)

**Turn 1 — Type:** `I want to take a $30,000 loan from my 401(k) for 5 years`

**Expected:**
- Intent = `PLAN_LOAN_REQUEST`, slots: `plan_type, loan_amount=30000, repayment_term=5`.
- Auth = STRONG. Provide `9988`.
- Validator + tool see `marital_status=MARRIED` and `spousal_consent_obtained=false`.
- Bot returns a **violation / escalation** or asks to obtain spousal consent first; `policy_path` shows entity_validator surfacing the violation, supervisor either escalating or routing back to slot-collection for `spousal_consent`.
- Disclosures include `LOAN_DEFAULT_WARNING`, `TAX_CONSEQUENCE`.

**Compare:** Run the same prompt as `alex` (single) → loan proceeds normally to HITL.

---

## Scenario 8 — Beneficiary update (escalation path)

**Login:** `alex`

**Turn 1 — Type:** `I want to add my sister Priya Patel as a 100% primary beneficiary`

**Expected:**
- Intent = `BENEFICIARY_UPDATE`. Slots collected: `beneficiary_name`, `beneficiary_relation`, `beneficiary_percentage`, `beneficiary_type`, `plan_type`.
- Entity extraction fills `beneficiary_name="Priya Patel"`, `beneficiary_relation="sister"`, `beneficiary_percentage=100`, `beneficiary_type="PRIMARY"`. plan_type=401K from context.
- Auth = STRONG. Provide `4321`.
- Supervisor routes `BENEFICIARY_UPDATE` → `escalate` (beneficiary_manager tool has been removed).
- Response: warm hand-off message directing alex to a specialist for beneficiary changes.

---

## Scenario 9 — Out-of-scope / escalation

**Login:** `alex`

**Type:** `I'd like to file a formal complaint about a fraudulent transaction on my account`

**Expected:**
- Intent agent maps to an `ESCALATION_INTENTS` entry → `escalation_flag=True`.
- `escalation` block populated in response with a `reason` (e.g. `FRAUD_REPORT` / `OUT_OF_SCOPE` / `COMPLAINT`) and `triggered_by="intent_agent"`.
- `action_type` = `ESCALATE_TO_HUMAN`. Response is a warm hand-off message; no tool runs, no HITL.

---

## Scenario 10 — Mid-conversation intent switch (intent stack)

**Login:** `alex`

**Turn 1:** `What's the 2025 IRA contribution limit?` → informational answer (Scenario 1 shape).

**Turn 2 (without ending session):** `Actually, can you check my 401(k) balance instead?`

**Expected:**
- Intent agent pushes a new `IntentRecord` onto `intent_stack`; `metadata.active_intent.sub_intent` switches to `401K_BALANCE_INQUIRY`.
- Auth requirement re-evaluated (STRONG required) → SSN challenge.
- After auth, balance returned. The earlier intent remains on the stack but is no longer active.

**Talking point:** This is the supervisor's intent-stack feature — see `agents/supervisor/v1/`.

---

## Scenario 11 — Re-auth TTL (skip the challenge on the next request)

**Login:** `alex`

**Turn 1:** `Show my 401(k) balance` → SSN challenge → answer `4321` → balance returned.

**Turn 2 (within `auth_reverify_ttl_seconds`):** `What's my YTD employer match?`

**Expected:**
- No new auth challenge. `metadata.auth_status` stays at `STRONG`. Auth agent returns immediately because the prior verification is still within the TTL window (see `agents/auth_agent/v1/agent.py` lines 7–117).

**Variant:** Wait beyond `auth_reverify_ttl_seconds` (default ~300s; can be lowered in [config.py](config.py) for the demo). Issue another STRONG-protected request → expect a fresh challenge.

---

## Scenario 12 — HITL timeout

**Login:** `alex`

Set up the rollover from Scenario 4 up to the HITL pending state. **Wait** longer than `hitl_timeout_seconds` (default 300; lower it in `.env` to ~30 seconds for the demo). Then send the HITL approval.

**Expected:**
- `POST /conversations/{id}/hitl` returns **HTTP 408 REQUEST_TIMEOUT** with the message:
  `"HITL confirmation timed out after Ns (limit: 30s). Please restart the transaction."`

---

## Scenario 13 — Auth-failure account (no secrets configured)

**Login:** `noauth` (`demo-user-003`)

**Type:** `What is my IRA balance?`

**Expected:**
- Intent classification works; auth agent issues a STRONG challenge (SSN last4).
- Any answer fails because `auth_secrets_plain` is empty for this account.
- After 3 failed attempts the conversation **escalates** with `escalation.reason = AUTH_FAILED` (or similar) and the tool never runs.

**Talking point:** Demonstrates that auth secrets are server-side only; client cannot bypass by sending values in the request body (see the `auth_*` strip in `start_conversation`, [main.py](main.py) line ~890).

---

## Scenario 14 — Session-token enforcement (security demo, API only)

After starting a conversation, swap the bearer token:

```powershell
# Start conversation correctly
$jwt  = (curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json" -d '{"username":"alex","password":"demo123"}' | ConvertFrom-Json).access_token
$conv = (curl -X POST http://localhost:8000/conversations -H "Authorization: Bearer $jwt" -H "Content-Type: application/json" -d '{}' | ConvertFrom-Json)

# Try to send a turn with the WRONG token (e.g. a UUID you made up)
curl -X POST "http://localhost:8000/conversations/$($conv.conversation_id)/turns" -H "Authorization: Bearer deadbeef" -H "Content-Type: application/json" -d '{"message":"hello"}'
```

**Expected:** **HTTP 403** — `"Invalid session token for this conversation."` (constant-time compare via `hmac.compare_digest`, see `_validate_session_token`).

---

## Scenario 15 — End-of-session profile persistence (cross-session memory)

**Run Scenario 4 fully as `alex`. Then:**

```powershell
curl -X POST "http://localhost:8000/conversations/$($conv.conversation_id)/end" -H "Authorization: Bearer $($conv.session_token)"
```

**Start a new conversation as `alex`** and ask anything.

**Expected:**
- Server log line `user_profile_loaded user_id=demo-user-001 display_name=...` (see `_persist_profile_updates` in [main.py](main.py) ~line 670–760).
- `recent_intents` contains the intent from the previous session; `past_transaction_count` reflects completed turns.
- Vault tokens for the previous session were cleaned up (see log lines `vault_cleanup_*`); any persisted PII is removed.

---

## Quick API dial-string (PowerShell) — full conversation in one block

```powershell
$base = "http://localhost:8000"

# 1. Login
$jwt = (Invoke-RestMethod -Method Post -Uri "$base/auth/login" `
        -ContentType "application/json" `
        -Body '{"username":"alex","password":"demo123"}').access_token

# 2. Start conversation
$conv = Invoke-RestMethod -Method Post -Uri "$base/conversations" `
        -Headers @{ Authorization = "Bearer $jwt" } `
        -ContentType "application/json" `
        -Body '{"channel":"web","client_tier":"STANDARD"}'

$cid = $conv.conversation_id
$tok = $conv.session_token
$hdr = @{ Authorization = "Bearer $tok" }

# 3. Send a turn
function Send-Turn($msg) {
    Invoke-RestMethod -Method Post -Uri "$base/conversations/$cid/turns" `
        -Headers $hdr -ContentType "application/json" `
        -Body (@{ message = $msg } | ConvertTo-Json)
}

Send-Turn "I want to roll over my 401k to a Roth IRA"
Send-Turn "4321"          # SSN challenge answer
Send-Turn "50000"         # rollover amount

# 4. Approve the HITL
Invoke-RestMethod -Method Post -Uri "$base/conversations/$cid/hitl" `
    -Headers $hdr -ContentType "application/json" `
    -Body '{"approved": true, "corrections": {}}'

# 5. End
Invoke-RestMethod -Method Post -Uri "$base/conversations/$cid/end" -Headers $hdr
```

---

## What to watch in the backend logs

| Log key | Meaning |
|---|---|
| `conversation_started` | Session created |
| `turn_start` / `turn_complete` | Each user message |
| `auth_challenge_issued` / `auth_verified` | Challenge lifecycle |
| `slot_gap` (in turn responses) | Required slots still missing |
| `hitl_pending` | Graph paused at `interrupt_before=["tool_router"]` |
| `auto_resume_interrupt` | Tool executing after HITL approval |
| `transaction_result` | Tool finished |
| `vault_cleanup_*` | PII tokens deleted at session end |
| `user_profile_saved` | Cross-session memory persisted |
| `escalation_*` | Routed to human |

---

## Demo-day order recommendation (≈ 15 min)

1. **Sc 0** — sanity (30 s)
2. **Sc 1** — RAG with citations (1 min) ← *the "wow"*
3. **Sc 3** — auth + balance (2 min)
4. **Sc 4** — multi-slot + HITL approve (3 min) ← *the multi-agent showcase*
5. **Sc 4 variant** — HITL correction (1 min)
6. **Sc 7** — spousal-consent edge case (2 min) ← *shows policy/regulatory teeth*
7. **Sc 9** — escalation (1 min)
8. **Sc 10** — intent switch (1 min)
9. **Sc 14** — session-token security (1 min) ← *for the security folks*
10. **Sc 15** — cross-session memory (1 min)

Skip 5/6/11/12/13 unless asked — they shine in deeper technical Q&A.
