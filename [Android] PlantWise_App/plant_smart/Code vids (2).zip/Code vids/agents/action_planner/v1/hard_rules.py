"""Backward-compatibility re-export.

The canonical implementation moved to ``agents/supervisor/v1/hard_rules.py``.
This stub preserves existing import paths used by tests and verification
scripts.
"""

from agents.supervisor.v1.hard_rules import evaluate_hard_rules  # noqa: F401

__all__ = ["evaluate_hard_rules"]
