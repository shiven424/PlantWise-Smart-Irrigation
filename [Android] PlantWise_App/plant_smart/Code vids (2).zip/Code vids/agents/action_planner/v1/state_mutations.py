"""Backward-compatibility re-export.

The canonical implementation moved to ``agents/supervisor/v1/state_mutations.py``.
This stub preserves existing import paths used by tests and verification
scripts.
"""

from agents.supervisor.v1.state_mutations import apply_state_mutations  # noqa: F401

__all__ = ["apply_state_mutations"]
