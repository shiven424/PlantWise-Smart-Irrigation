"""Action Planner v1 - prompt module (intentionally empty).

The Action Planner is 100% deterministic: hard_rules.py + policy.py.
No LLM calls are made. This module exists for structural consistency
with other agents (every agent has agent.py, prompt.py, schema.py).
"""
