"""Action Planner v1 - backward-compatibility wrapper.

The core logic has moved to ``agents/supervisor/v1/``:

 - ``hard_rules.py``           -> evaluate_hard_rules()
 - ``policy.py``               -> apply_routing_policy()
 - ``summary.py``              -> build_summary()
 - ``state_mutations.py``      -> apply_state_mutations()

This class is kept for backward compatibility with existing tests.
It is NOT used in the live graph - the SupervisorAgent handles
orchestration instead.
"""

from __future__ import annotations

from agents.base import BaseAgent
from agents.supervisor.v1.hard_rules import evaluate_hard_rules
from agents.supervisor.v1.policy import apply_routing_policy
from agents.supervisor.v1.state_mutations import apply_state_mutations
from agents.supervisor.v1.summary import build_summary
from graph.state import GraphState
from observability.logger import log
from observability.tracer import trace_agent
from schemas.primitives import AgentOutputSummary


class ActionPlannerAgent(BaseAgent):
    name = "action_planner"
    version = "1.0.0"

    @trace_agent("action_planner")
    def run(self, state: GraphState) -> dict:
        summary = self._build_summary(state)
        session = state.get("session")
        session_id = str(session.session_id) if session else "unknown"

        # Hard rules first - deterministic, no LLM
        plan = evaluate_hard_rules(state, summary)
        hard_rule_fired = plan.hard_rule_fired if plan else None

        # If no hard rule fired, apply policy routing
        if plan is None:
            plan = apply_routing_policy(state, summary)

        policy_path = hard_rule_fired or plan.action_type.value

        log.info(
            "action_planner_decision",
            action_type=plan.action_type.value,
            hard_rule=hard_rule_fired,
            policy_path=policy_path,
            session_id=session_id,
        )

        # Build partial state update
        result: dict = {
            "current_action_plan": plan,
            "policy_path": policy_path,
            "planner_reasoning": hard_rule_fired or plan.action_type.value,
            "slot_gap": summary.slot_gap,
        }

        # Delegate state mutations (escalation, counters, HITL, validation
        # resets, state_delta) to the shared utility.
        mutations = apply_state_mutations(plan, state)
        result.update(mutations)

        return result

    # Summary builder -----------------------------------------------------
    # Delegates to the shared module. Kept as a static method on the
    # class so that existing call sites like
    # ActionPlannerAgent._build_summary(state)
    # in tests continue to work without changes.
    
    @staticmethod
    def _build_summary(state: GraphState) -> AgentOutputSummary:
        """Build AgentOutputSummary from the merged post-parallel state."""
        return build_summary(state)

    def health_check(self) -> bool:
        return True
