"""Backward-compatibility re-export.

The canonical implementation moved to ``agents/supervisor/v1/summary.py``.
This stub preserves existing import paths used by tests and verification
scripts.
"""

from agents.supervisor.v1.summary import build_summary  # noqa: F401

__all__ = ["build_summary"]
