"""Backward-compatibility re-export.

The canonical implementation moved to ``agents/supervisor/v1/policy.py``.
This stub preserves existing import paths used by tests and verification
scripts.
"""

from agents.supervisor.v1.policy import apply_routing_policy  # noqa: F401

__all__ = ["apply_routing_policy"]
