"""
Policy layer – only runs when NO hard rule fired.
Determines the appropriate action based on conversation state.

Originally in ``agents/action_planner/v1/policy.py``; moved here
when the supervisor agent absorbed the action planner.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from config import settings
from graph.state import GraphState, get_active_intent
from schemas.enums import (
    ActionType,
    AuthStatus,
    EscalationReason,
    MessageDomain,
    ValidationSeverity,
    ValidationStatus,
)
from schemas.primitives import (
    ActionPlan,
    AgentOutputSummary,
    EscalationContext,
    IntentRecord,
    ResponseDirective,
)


def apply_routing_policy(
    state: GraphState,
    summary: AgentOutputSummary,
) -> ActionPlan:
    """
    Deterministic policy routing – only called when no hard rule fired.

    Returns an ActionPlan for every code path (never ``None``).
    """
    domain = summary.classifier_domain
    active_intent = get_active_intent(state)

    # When the user has an authenticated transactional intent in flight, the
    # transaction must take precedence over the message domain.  Otherwise a
    # follow-up like "What's my balance?" gets classified INFORMATIONAL and
    # routed to RAG, bypassing the balance_inquiry tool that's the whole
    # point of the active intent.
    completed_ids = state.get("completed_intent_ids", []) or []
    has_pending_transaction = (
        active_intent is not None
        and active_intent.is_transactional
        and state.get("auth_status") == AuthStatus.VERIFIED
        # An intent that has already been executed successfully this
        # conversation is NOT pending — it was fulfilled.  Subsequent
        # turns ("Ok thanks", "got it") must fall through to the
        # CHITCHAT/INFORMATIONAL branches instead of re-executing.
        and active_intent.intent_id not in completed_ids
    )

    # Informational intents (e.g. RMD_INQUIRY) must be answered via RAG /
    # synthesizer even when the message classifier flagged the user's
    # message as TRANSACTIONAL.  Without this guard, the policy falls into
    # the TRANSACTIONAL path and the router dispatches a tool
    # (rmd_calculator) whose required slots the informational intent never
    # collected, producing a confusing "Transaction Failed" outcome.
    informational_intent_override = (
        active_intent is not None
        and not active_intent.is_transactional
        and not has_pending_transaction
    )

    # — ESCALATE domain (safety net – H1 normally catches this) ————
    if domain == MessageDomain.ESCALATE:
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="EMPATHETIC"),
            escalation_context=EscalationContext(
                reason=EscalationReason.CLIENT_REQUESTED,
                triggered_by="policy.escalate_domain",
            ),
        )

    # — CHITCHAT path ———————————————————————————————————————————————
    if domain == MessageDomain.CHITCHAT and not has_pending_transaction:
        return ActionPlan(
            action_type=ActionType.CHITCHAT_RESPOND,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                content_hints=_re_anchor_hint(active_intent),
            ),
        )

    # — INFORMATIONAL path —————————————————————————————————————————
    if (
        domain == MessageDomain.INFORMATIONAL or informational_intent_override
    ) and not has_pending_transaction:
        return ActionPlan(
            action_type=ActionType.ANSWER,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="informational",
                compliance_tail_ids=_merge_compliance_tails(
                    _get_compliance_tails(active_intent),
                    state.get("rag_caveats", []),
                ),
            ),
        )

    # — TRANSACTIONAL path —————————————————————————————————————————

    # Stage 0: No intent identified yet
    if not active_intent:
        return ActionPlan(
            action_type=ActionType.CLARIFY,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                content_hints=["Ask client to clarify their request"],
            ),
        )

    # Stage 1: Collect missing slots – H4 enforced: ONLY slot_gap[0]
    if summary.slot_gap:
        return ActionPlan(
            action_type=ActionType.COLLECT_SLOT,
            target_slot=summary.slot_gap[0],  # H4: first slot only, never ask two
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="slot_collection",
            ),
        )

    # Stage 2: Validate all entities
    if summary.validation_status is None:
        return ActionPlan(
            action_type=ActionType.VALIDATE_ENTITIES,
            response_directive=ResponseDirective(tone="PROFESSIONAL"),
        )

    # Stage 2b: Validation failed with BLOCKING violation → collect corrected slot
    if summary.has_blocking_violations:
        correctable = _first_correctable_slot(state)
        if correctable is None:
            return ActionPlan(
                action_type=ActionType.ESCALATE,
                response_directive=ResponseDirective(tone="PROFESSIONAL"),
                escalation_context=EscalationContext(
                    reason=EscalationReason.BLOCKING_VIOLATION,
                    triggered_by="policy.no_correctable_slot",
                ),
            )
        return ActionPlan(
            action_type=ActionType.COLLECT_SLOT,
            target_slot=correctable,
            response_directive=ResponseDirective(
                tone="GENTLE",
                template_id="slot_collection",
            ),
        )

    # Stage 2c: Validation FAILED or INCOMPLETE without blocking violations
    # (safety net – should not happen in normal flow, but prevents
    #  accidental execution with an unresolved validation state)
    if summary.validation_status in (
        ValidationStatus.FAILED,
        ValidationStatus.INCOMPLETE,
    ):
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="PROFESSIONAL"),
            escalation_context=EscalationContext(
                reason=EscalationReason.BLOCKING_VIOLATION,
                triggered_by="policy.validation_failed_no_correctable",
            ),
        )

    # — Resolve HITL state (used by Stage 3 and Stage 4) ————————————
    hitl = state.get("hitl")
    # True = user confirmed, False = user denied/corrected, None = not yet responded
    hitl_responded = hitl is not None and hitl.last_confirmed is not None

    # HITL timeout enforcement – if HITL has been pending longer than
    # hitl_timeout_seconds, end the session.  This defends against
    # abandoned HITL screens even when the graph is invoked directly
    # (bypassing main.py's endpoint-level timeout check).
    if hitl and hitl.pending and hitl.pending_since:
        try:
            pending_since = hitl.pending_since
            if isinstance(pending_since, str):
                pending_since = datetime.fromisoformat(pending_since)
            # ISSUE-7 fix: Ensure pending_since is tz-aware before
            # comparing with utcnow.  Naive datetimes raise TypeError.
            if pending_since.tzinfo is None:
                pending_since = pending_since.replace(tzinfo=timezone.utc)
            elapsed = (datetime.now(timezone.utc) - pending_since).total_seconds()
            if elapsed > settings.hitl_timeout_seconds:
                return ActionPlan(
                    action_type=ActionType.END_SESSION,
                    response_directive=ResponseDirective(
                        tone="PROFESSIONAL",
                        content_hints=[
                            f"HITL confirmation timed out after {int(elapsed)}s. "
                            "Transaction cancelled for security."
                        ],
                    ),
                )
        except (ValueError, TypeError):
            # Unparseable timestamp – fail-safe: end session rather than
            # silently allowing a potentially stale HITL to proceed.
            from observability.logger import log
            log.warning(
                "hitl_timestamp_unparseable_policy",
                raw_timestamp=str(hitl.pending_since),
            )
            return ActionPlan(
                action_type=ActionType.END_SESSION,
                response_directive=ResponseDirective(
                    tone="PROFESSIONAL",
                    content_hints=[
                        "Unable to verify HITL timing. "
                        "Transaction cancelled for security."
                    ],
                ),
            )

    # Stage 3: Validation passed or WARNING → present HITL confirmation
    # Only present HITL when:
    #   - HITL is not already being shown (hitl_pending = False)
    #   - User has NOT already responded (last_confirmed is None)
    # After HITL approval/correction, last_confirmed is True/False, so
    # Stage 3 is skipped and control falls through to Stage 4.
    if summary.validation_status in (
        ValidationStatus.PASSED,
        ValidationStatus.WARNING,
    ):
        # Read-only inquiries (balance, status, eligibility) and illustrative
        # RMD_CALCULATION (tool has requires_hitl=False) do not book trades or
        # distributions — HITL would be empty friction.  Route straight to
        # EXECUTE_TRANSACTION → tool_router.
        skips_pre_execute_hitl = (
            active_intent.sub_intent.endswith("_INQUIRY")
            or active_intent.sub_intent.endswith("_STATUS")
            or active_intent.sub_intent.endswith("_ELIGIBILITY")
            or active_intent.sub_intent == "RMD_CALCULATION"
        )
        if skips_pre_execute_hitl:
            return ActionPlan(
                action_type=ActionType.EXECUTE_TRANSACTION,
                response_directive=ResponseDirective(
                    tone="PROFESSIONAL",
                    template_id="transaction_complete",
                    compliance_tail_ids=_merge_compliance_tails(
                        _get_compliance_tails(active_intent),
                        state.get("rag_caveats", []),
                    ),
                ),
            )

        if not summary.hitl_pending and not hitl_responded:
            return ActionPlan(
                action_type=ActionType.PRESENT_HITL,
                response_directive=ResponseDirective(
                    tone="PROFESSIONAL",
                    template_id="hitl_confirmation",
                    compliance_tail_ids=_merge_compliance_tails(
                        _get_compliance_tails(active_intent),
                        state.get("rag_caveats", []),
                    ),
                ),
            )

    # Stage 4: HITL was presented – check user response

    # 4a: User explicitly denied / cancelled
    if hitl and hitl.last_confirmed is False and not hitl.last_corrections:
        return ActionPlan(
            action_type=ActionType.END_SESSION,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                content_hints=["Acknowledge cancellation, confirm no changes made"],
            ),
        )

    # 4b: User requested corrections → re-present HITL with corrected values
    # The corrections have been applied to entity_memory and re-validated.
    # Re-presenting PRESENT_HITL (not HITL_CORRECTION) lets the synthesizer
    # show the updated parameters so the user can review and approve or
    # correct again, rather than leaving them on a dead "corrections noted"
    # screen with no action available.
    if hitl and hitl.last_corrections:
        return ActionPlan(
            action_type=ActionType.PRESENT_HITL,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="hitl_confirmation",
                content_hints=[
                    "Corrections have been applied. Show the UPDATED parameters "
                    "and ask the client to review and confirm (or correct again)."
                ],
                compliance_tail_ids=_merge_compliance_tails(
                    _get_compliance_tails(active_intent),
                    state.get("rag_caveats", []),
                ),
            ),
        )

    # 4c: HITL still pending – user hasn't responded yet → re-present
    if hitl and hitl.pending and not hitl_responded:
        return ActionPlan(
            action_type=ActionType.PRESENT_HITL,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="hitl_confirmation",
                compliance_tail_ids=_merge_compliance_tails(
                    _get_compliance_tails(active_intent),
                    state.get("rag_caveats", []),
                ),
            ),
        )

    # 4d: HITL approved → execute
    # Fix 154: Explicit guard – only execute when user has confirmed.
    # Without this, any unhandled HITL state would fall through to
    # EXECUTE_TRANSACTION, bypassing approval.
    if hitl and hitl.last_confirmed is True:
        return ActionPlan(
            action_type=ActionType.EXECUTE_TRANSACTION,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="transaction_complete",
                compliance_tail_ids=_merge_compliance_tails(
                    _get_compliance_tails(active_intent),
                    state.get("rag_caveats", []),
                ),
            ),
        )

    # 4e: Unhandled HITL state – safe fallback.
    # If hitl is None or in an unexpected state, escalate rather than
    # re-presenting HITL (which could crash downstream if hitl is None).
    if hitl:
        return ActionPlan(
            action_type=ActionType.PRESENT_HITL,
            response_directive=ResponseDirective(
                tone="PROFESSIONAL",
                template_id="hitl_confirmation",
                content_hints=["Please confirm or correct the details above."],
                compliance_tail_ids=_merge_compliance_tails(
                    _get_compliance_tails(active_intent),
                    state.get("rag_caveats", []),
                ),
            ),
        )

    # 4f: hitl is None in TRANSACTIONAL + all slots filled + validated
    # – should not happen, but escalate instead of silently proceeding.
    return ActionPlan(
        action_type=ActionType.ESCALATE,
        response_directive=ResponseDirective(tone="PROFESSIONAL"),
        escalation_context=EscalationContext(
            reason=EscalationReason.BLOCKING_VIOLATION,
            triggered_by="policy.hitl_state_missing",
        ),
    )


# — Helpers ————————————————————————————————————————————————————————

def _merge_compliance_tails(
    taxonomy_tails: list[str],
    rag_caveats: list[str],
) -> list[str]:
    """Merge taxonomy compliance tails with RAG-generated caveats, deduplicated."""
    return list(dict.fromkeys(taxonomy_tails + rag_caveats))


def _get_compliance_tails(intent: IntentRecord | None) -> list[str]:
    """
    Return compliance tail IDs for the intent.

    Delegates to the taxonomy – single source of truth.
    """
    if not intent:
        return []
    from agents.intent_agent.v1.taxonomy import get_compliance_tails
    return get_compliance_tails(intent.sub_intent)


def _re_anchor_hint(active_intent: IntentRecord | None) -> list[str]:
    """Produce a hint reminding the synthesizer to re-anchor to the active intent."""
    if not active_intent:
        return []
    return [f"Re-anchor to active intent: {active_intent.sub_intent}"]


def _first_correctable_slot(state: GraphState) -> Optional[str]:
    """
    Return the slot_name of the first BLOCKING-violated correctable entity,
    or ``None`` if none found (caller escalates).

    IMPORTANT: Only violations with ``correctable=True`` are eligible.
    Non-correctable BLOCKING violations (e.g. AccreditedInvestorRule,
    TrustEINRule) must escalate – re-collecting the slot won't fix them.
    """
    violations = state.get("violations", [])
    for v in violations:
        if (
            v.severity == ValidationSeverity.BLOCKING
            and v.correctable
            and v.violated_entity
        ):
            entity_memory = state.get("entity_memory", {})
            for _key, entity in entity_memory.items():
                if str(entity.entity_id) == v.violated_entity and entity.slot_name:
                    return entity.slot_name
    return None  # No correctable slot found – caller will escalate
