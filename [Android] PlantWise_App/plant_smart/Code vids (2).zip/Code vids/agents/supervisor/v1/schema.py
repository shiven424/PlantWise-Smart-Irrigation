"""Supervisor v1 – Pydantic schemas for LLM orchestration decisions.

A permissive internal model (``_SupervisorLLMRaw``) absorbs unexpected
keys that some providers inject into their JSON output, then gets
re-validated into the strict ``SupervisorDecision`` for downstream use.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, PrivateAttr


# — Permissive model for raw LLM parsing ————————————————————————————
# LLMs sometimes return extra keys (e.g. "model_version", "raw_reasoning").
# Using ``extra="ignore"`` prevents Pydantic validation errors without
# silently losing the fields we DO care about.

class _SupervisorLLMRaw(BaseModel, extra="ignore"):
    """Internal permissive model – absorbs unexpected LLM output keys."""
    next_step: str = "synthesize"
    agents: list[str] = Field(default_factory=list)
    parallelize: bool = False
    reasoning: str = ""
    # Fix M4: Use PrivateAttr so the fallback flag survives model_copy()
    # and serialization.  Plain underscore-prefixed attrs in Pydantic v2
    # are treated as class variables, not instance attributes.
    _is_fallback: bool = PrivateAttr(default=False)


# — Strict model for downstream use ————————————————————————————————

class SupervisorDecision(BaseModel):
    """Validated supervisor routing decision.

    Fields:
        next_step:    ``"invoke_agents"`` to call specialist agents,
                      ``"synthesize"`` to produce a response.
        agents:       Agent names to invoke (only when next_step == invoke_agents).
        parallelize:  Whether the agents can run simultaneously.
        reasoning:    Free-text LLM reasoning trace for observability.
    """
    next_step: Literal["invoke_agents", "synthesize"]
    agents: list[str] = Field(default_factory=list)
    parallelize: bool = False
    reasoning: str = ""
