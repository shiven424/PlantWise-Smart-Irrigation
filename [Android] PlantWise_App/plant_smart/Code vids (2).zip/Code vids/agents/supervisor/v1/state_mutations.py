"""
State mutations driven by an ActionPlan.

After an ActionPlan is produced (by hard rules or policy), this function
computes the side-effect state updates that must accompany it:
    - escalation propagation
    - validation_status reset on re-collection
    - retry / correction counter increments
    - HITL lifecycle (pending flag, pending_since timestamp)
    - state_delta propagation (e.g. required_auth_level from H2)

Usage:
    from agents.supervisor.v1.state_mutations import apply_state_mutations
    mutations = apply_state_mutations(plan, state)
"""

from __future__ import annotations

from datetime import datetime, timezone

from graph.state import GraphState
from schemas.enums import ActionType
from schemas.primitives import ActionPlan, HITLState


def apply_state_mutations(plan: ActionPlan, state: GraphState) -> dict:
    """Return the partial state dict of side-effects for *plan*.

    The caller is expected to merge these into its own return dict
    alongside the ``current_action_plan`` and other fields.

    This function is pure (no I/O, no logging) – the caller handles
    observability.
    """
    result: dict = {}

    # — Escalation propagation ——————————————————————————————————————
    if plan.action_type == ActionType.ESCALATE:
        result["escalation_requested"] = True
        if plan.escalation_context:
            result["escalation_context"] = plan.escalation_context

    # — Validation reset on slot re-collection ——————————————————————
    # When re-collecting a slot after a blocking violation, reset
    # validation_status so the entity validator re-runs after new data.
    if plan.action_type in (
        ActionType.COLLECT_SLOT,
        ActionType.RETRY_SLOT,
        ActionType.CORRECTION_ACK,
        ActionType.HITL_CORRECTION,
    ):
        if state.get("validation_status") is not None:
            result["validation_status"] = None

    # — Persist last_requested_slot so the NEXT turn knows which slot
    # the assistant just asked the user about.  Without this, the
    # intent_agent and entity_extraction LLMs have no awareness that
    # the user's reply is a slot answer — they re-classify it as a
    # fresh intent (e.g. "both IRA and 401k" answered to a plan_type
    # COLLECT_SLOT gets misread as a new ACCOUNT_BALANCE_INQUIRY).
    if plan.action_type in (
        ActionType.COLLECT_SLOT,
        ActionType.RETRY_SLOT,
    ) and plan.target_slot:
        result["last_requested_slot"] = plan.target_slot
    elif plan.action_type in (
        ActionType.EXECUTE_TRANSACTION,
        ActionType.PRESENT_HITL,
        ActionType.CHITCHAT_RESPOND,
        ActionType.ANSWER,
        ActionType.ESCALATE,
        ActionType.END_SESSION,
    ):
        # Slot collection no longer active — clear the stale value so
        # it doesn't bias subsequent turns.
        if state.get("last_requested_slot") is not None:
            result["last_requested_slot"] = None

    # — Retry counter ———————————————————————————————————————————————
    if plan.action_type == ActionType.RETRY_SLOT:
        result["retry_count"] = state.get("retry_count", 0) + 1

    # — Correction counter + HITL reset —————————————————————————————
    # Increment correction_count and clear last_confirmed / last_corrections
    # so Stage 3 in policy.py will present a fresh HITL confirmation
    # screen for the corrected values.
    if plan.action_type == ActionType.HITL_CORRECTION:
        result["correction_count"] = state.get("correction_count", 0) + 1
        existing_hitl = state.get("hitl") or HITLState()
        result["hitl"] = existing_hitl.model_copy(update={
            "last_confirmed": None,
            "last_corrections": {},
        })

    # — HITL pending flag ———————————————————————————————————————————
    if plan.action_type == ActionType.PRESENT_HITL:
        existing_hitl = state.get("hitl") or HITLState()
        result["hitl"] = existing_hitl.model_copy(update={
            "pending": True,
            "pending_since": datetime.now(timezone.utc),
            # Clear correction state so Stage 4b doesn't re-trigger when the
            # user is shown this (re-)presentation — applies both to the first
            # PRESENT_HITL and to the re-presentation after corrections.
            "last_confirmed": None,
            "last_corrections": {},
        })

    # — state_delta propagation ————————————————————————————————————
    # Plans can carry arbitrary state overrides (e.g. required_auth_level
    # from H2).  Only whitelisted keys are propagated to prevent
    # malformed plans from corrupting critical state fields.
    _STATE_DELTA_ALLOWED_KEYS = frozenset({
        "required_auth_level",
        "auth_status",   # H2 sets PENDING to signal auth is in progress
    })
    if plan.state_delta:
        for key, value in plan.state_delta.items():
            if key in _STATE_DELTA_ALLOWED_KEYS:
                result[key] = value

    return result
