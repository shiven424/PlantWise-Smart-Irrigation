"""Supervisor v1 – central orchestration agent.

The supervisor replaces static graph routing with LLM-driven decisions.
Each turn it:

1. Checks if the supervisor loop has exceeded the iteration limit.
2. Builds a state summary via ``build_summary()``.
3. Evaluates deterministic hard rules (H1-H8) – these ALWAYS take
   priority over any LLM decision.
4. If no hard rule fires, asks the LLM which specialist agents should
   run next (or whether to synthesize a response).
5. If the LLM fails, falls back to deterministic policy routing.
6. Writes routing decisions into ``scratch`` for the graph router.

Write-ownership:
    current_action_plan, escalation_context, escalation_requested,
    policy_path, planner_reasoning, slot_gap, validation_status (reset only),
    retry_count (increment), correction_count (increment), hitl (pending flag),
    scratch (supervisor_route, supervisor_completed, supervisor_iteration)
"""

from __future__ import annotations

from agents.base import BaseAgent
from agents.supervisor.v1.hard_rules import evaluate_hard_rules
from agents.supervisor.v1.policy import apply_routing_policy
from agents.supervisor.v1.state_mutations import apply_state_mutations
from agents.supervisor.v1.summary import build_summary
from agents.supervisor.v1.prompt import SYSTEM_PROMPT, build_user_prompt
from agents.supervisor.v1.schema import SupervisorDecision, _SupervisorLLMRaw
from config import settings
from graph.state import GraphState, get_active_intent
from observability.logger import log
from observability.tracer import trace_agent
from schemas.enums import ActionType, AuthLevel, AuthStatus, MessageDomain
from schemas.primitives import ActionPlan, AuthState, ResponseDirective

try:
    from llm.client import call_llm
except ImportError:  # pragma: no cover – missing SDK in dev/test venvs
    call_llm = None  # type: ignore[assignment]


# Specialist agents the supervisor is allowed to dispatch to.
# Anything not in this set is rejected to prevent prompt injection
# from tricking the LLM into invoking unexpected agents.
_ALLOWED_AGENTS = frozenset({
    "intent_agent",
    "entity_extraction",
    "rag_agent",
    "auth_agent",
    "entity_validator",
})

# Default max iterations before forcing policy fallback.
_DEFAULT_MAX_ITERATIONS = 6


class SupervisorAgent(BaseAgent):
    name    = "supervisor"
    version = "1.0.0"

    @trace_agent("supervisor")
    def run(self, state: GraphState) -> dict:
        scratch = dict(state.get("scratch") or {})
        session = state.get("session")
        session_id = str(session.session_id) if session else "unknown"

        # — Read loop state from scratch ————————————————————————————
        completed: list[str] = list(scratch.get("supervisor_completed", []))
        iteration: int = scratch.get("supervisor_iteration", 0)

        max_iter = getattr(settings, "supervisor_max_iterations", _DEFAULT_MAX_ITERATIONS)

        # — Iteration guard ——————————————————————————————————————————
        if iteration >= max_iter:
            log.warning(
                "supervisor_max_iterations",
                iteration=iteration,
                max=max_iter,
                session_id=session_id,
            )
            return self._finalize_with_policy(state, scratch, completed, iteration, session_id)

        # — Build state summary ——————————————————————————————————————
        summary = build_summary(state)

        # — Hard rules – deterministic, always first ————————————————
        plan = evaluate_hard_rules(state, summary)
        if plan is not None:
            hard_rule = plan.hard_rule_fired
            log.info(
                "supervisor_hard_rule",
                rule=hard_rule,
                session_id=session_id,
            )
            return self._build_synthesize_result(
                plan, summary, state, scratch, completed, iteration,
                policy_path=hard_rule,
                reasoning=f"hard_rule:{hard_rule}",
            )

        # — Auth-in-progress override —————————————————————————————————
        # When auth has been initiated (required level > SESSION) but the
        # current level still falls short, run auth_agent INLINE here so we
        # can issue (or evaluate) the challenge and synthesize the response
        # in a single supervisor invocation.  The graph round-trip via a
        # dispatcher node loses scratch state intermittently, so doing it
        # inline is the deterministic fix.
        auth_state_obj: AuthState = state.get("auth_state") or AuthState()
        required_level: AuthLevel = (
            state.get("required_auth_level") or AuthLevel.SESSION
        )
        auth_in_progress = (
            required_level > AuthLevel.SESSION
            and auth_state_obj.current_level < required_level
        )

        if auth_in_progress and "auth_agent" not in completed:
            # Lazy-import to avoid the circular dependency between
            # agents.registry (which imports SupervisorAgent) and this module.
            from agents.registry import AGENT_REGISTRY

            log.info(
                "supervisor_auth_inline_run",
                required=required_level.name,
                current=auth_state_obj.current_level.name,
                session_id=session_id,
            )

            try:
                auth_result = AGENT_REGISTRY["auth_agent"].run(state)
            except Exception as exc:
                log.error(
                    "supervisor_auth_inline_error",
                    error=str(exc),
                    session_id=session_id,
                )
                auth_result = {}

            # Merge auth_agent's scratch update (e.g. pending_auth_challenge)
            # into our local scratch so the synthesizer can read it.
            for key, value in (auth_result.get("scratch") or {}).items():
                if value is None:
                    scratch.pop(key, None)
                else:
                    scratch[key] = value

            new_auth_state = auth_result.get("auth_state", auth_state_obj)
            new_auth_status = auth_result.get(
                "auth_status", state.get("auth_status")
            )
            new_current_level = getattr(
                new_auth_state, "current_level", auth_state_obj.current_level
            )

            # Escalation path (locked account, max retries, etc.)
            if auth_result.get("escalation_requested"):
                return {
                    "auth_state": new_auth_state,
                    "auth_status": new_auth_status,
                    "scratch": scratch,
                    "escalation_requested": True,
                    "escalation_context": auth_result.get("escalation_context"),
                    "planner_reasoning": "auth:escalation",
                    "slot_gap": summary.slot_gap,
                }

            completed = completed + ["auth_agent"]
            iteration = iteration + 1
            scratch["supervisor_completed"] = completed
            scratch["supervisor_iteration"] = iteration

            if new_current_level < required_level:
                # Still pending — present the challenge if one was issued,
                # otherwise re-prompt INITIATE_AUTH.
                action = (
                    ActionType.AUTH_CHALLENGE
                    if scratch.get("pending_auth_challenge")
                    else ActionType.INITIATE_AUTH
                )
                auth_plan = ActionPlan(
                    action_type=action,
                    response_directive=ResponseDirective(tone="PROFESSIONAL"),
                )
                result = self._build_synthesize_result(
                    auth_plan, summary, state, scratch, completed, iteration,
                    policy_path="auth_inline",
                    reasoning="auth_pending:synthesize_challenge",
                )
                result["auth_state"] = new_auth_state
                result["auth_status"] = new_auth_status
                return result

            # Auth just completed in this turn — DO NOT return PROCESS_AUTH and
            # leave the user hanging.  Fall through to the normal LLM/policy
            # flow with the updated state so the original transactional intent
            # (e.g. ACCOUNT_BALANCE_INQUIRY) can proceed to validation/execution
            # in the SAME turn.  We re-build the summary so downstream sees
            # the verified auth.  auth_completed_carry is merged into whatever
            # result the LLM/policy paths return below.
            state = {
                **state,
                "auth_state": new_auth_state,
                "auth_status": new_auth_status,
                "scratch": scratch,
            }
            summary = build_summary(state)
            auth_completed_carry: dict = {
                "auth_state": new_auth_state,
                "auth_status": new_auth_status,
            }
        else:
            auth_completed_carry = {}

        # Deterministic guard: every fresh TRANSACTIONAL turn must re-run
        # intent_agent and entity_extraction before anything else.  Without
        # this, the LLM has been observed to skip straight to entity_validator
        # on follow-up messages (e.g. "now I want to withdraw"), leaving the
        # intent stack pinned to the previous transaction and routing the
        # user back to the prior tool (balance_inquiry) regardless of
        # what they actually asked for.
        message_domain = state.get("message_domain")
        is_transactional_msg = (
            message_domain == MessageDomain.TRANSACTIONAL
            if message_domain is not None
            else False
        )
        # When auth_agent just completed inline THIS turn, the user's message
        # was their auth answer (SSN last-4, DOB, OTP, etc.) — NOT a slot
        # answer.  Running entity_extraction on a bare numeric token like
        # "7766" with `slot_gap=['account_type']` has been observed to make
        # the LLM hallucinate a categorical reply (e.g. account_type=BROKERAGE)
        # via the bare-word slot-reply rule in the extractor prompt, which
        # then silently picks an account the user never asked for.  The
        # original transactional intent is already pinned in intent_stack,
        # so skip the force-refresh entirely and let policy render the
        # COLLECT_SLOT prompt for the still-missing slot.
        auth_just_completed = bool(auth_completed_carry)

        if (
            is_transactional_msg
            and iteration == 0
            and "intent_agent" not in completed
            and not auth_just_completed
        ):
            forced_agents = ["intent_agent", "entity_extraction"]
            new_completed = completed + forced_agents
            new_iteration = iteration + 1
            scratch.update({
                "supervisor_route": forced_agents,
                "supervisor_completed": new_completed,
                "supervisor_iteration": new_iteration,
            })
            log.info(
                "supervisor_force_intent_refresh",
                reason="transactional_turn_start",
                agents=forced_agents,
                session_id=session_id,
            )
            result = {
                "scratch": scratch,
                "planner_reasoning": "force:reclassify_transactional_turn",
                "slot_gap": summary.slot_gap,
            }
            result.update(auth_completed_carry)
            return result

        if auth_just_completed and iteration > 0:
            # Iteration was bumped by the inline auth run.  Go straight to
            # policy so we either COLLECT_SLOT or EXECUTE_TRANSACTION based
            # on the post-auth slot_gap — without polluting state by running
            # entity_extraction against the auth-answer message.
            log.info(
                "supervisor_post_auth_skip_extraction",
                reason="auth_answer_is_not_slot_answer",
                slot_gap=list(summary.slot_gap or []),
                session_id=session_id,
            )
            result = self._finalize_with_policy(
                state, scratch, completed, iteration, session_id,
            )
            result.update(auth_completed_carry)
            return result

        # — LLM decision ————————————————————————————————————————————
        decision = self._ask_llm(state, completed, iteration, session_id)

        # Deterministic guard: once the entity_validator has run for a
        # transactional intent, the next step is policy-driven (HITL
        # confirmation or EXECUTE_TRANSACTION → tool_router).  Letting
        # the LLM choose at this point has been observed to invoke rag_agent
        # against a transactional intent, which then triggers low-confidence
        # H8 escalation — the customer's actual request never executes.
        active_intent = get_active_intent(state)
        if (
            active_intent is not None
            and active_intent.is_transactional
            and "entity_validator" in completed
        ):
            log.info(
                "supervisor_force_policy_after_validation",
                reason="transactional_post_validation",
                intent=active_intent.sub_intent,
                session_id=session_id,
            )
            result = self._finalize_with_policy(
                state, scratch, completed, iteration, session_id,
            )
            result.update(auth_completed_carry)
            return result

        if decision is not None and decision.next_step == "invoke_agents":
            # Validate agents – reject any not in the allow-list
            safe_agents = [a for a in decision.agents if a in _ALLOWED_AGENTS]

            # Deterministic guard: rag_agent is for informational intents
            # only.  During a transactional flow it produces wasted latency
            # and, on low-confidence answers, trips the H8 escalation rule —
            # killing a request the customer could have completed.
            slot_gap_now = list(summary.slot_gap or [])
            transactional_with_gap = (
                active_intent is not None
                and active_intent.is_transactional
                and bool(slot_gap_now)
            )
            if transactional_with_gap and "rag_agent" in safe_agents:
                log.info(
                    "supervisor_rag_skipped",
                    reason="transactional_intent_with_slot_gap",
                    slot_gap=slot_gap_now,
                    intent=active_intent.sub_intent,
                    session_id=session_id,
                )
                safe_agents = [a for a in safe_agents if a != "rag_agent"]
            elif (
                active_intent is not None
                and active_intent.is_transactional
                and "rag_agent" in safe_agents
            ):
                # Even with all slots filled, RAG has no role in a
                # transactional flow — compliance text comes from the
                # intent's compliance_tail_ids, not the knowledge base.
                log.info(
                    "supervisor_rag_skipped",
                    reason="transactional_intent",
                    intent=active_intent.sub_intent,
                    session_id=session_id,
                )
                safe_agents = [a for a in safe_agents if a != "rag_agent"]

            if not safe_agents:
                log.warning(
                    "supervisor_no_valid_agents",
                    raw_agents=decision.agents,
                    session_id=session_id,
                )
                return self._finalize_with_policy(
                    state, scratch, completed, iteration, session_id,
                )

            # Remove agents that already ran (unless LLM explicitly re-requested)
            log.info(
                "supervisor_invoke",
                agents=safe_agents,
                parallelize=decision.parallelize,
                reasoning=decision.reasoning,
                iteration=iteration,
                session_id=session_id,
            )

            new_completed = completed + safe_agents
            new_iteration = iteration + 1

            scratch_updates = {
                "supervisor_route": safe_agents[0] if len(safe_agents) == 1 else safe_agents,
                "supervisor_completed": new_completed,
                "supervisor_iteration": new_iteration,
            }
            scratch.update(scratch_updates)

            result = {
                "scratch": scratch,
                "planner_reasoning": decision.reasoning,
                "slot_gap": summary.slot_gap,
            }
            result.update(auth_completed_carry)
            return result

        # — LLM said "synthesize" or LLM failed → policy fallback ———
        result = self._finalize_with_policy(state, scratch, completed, iteration, session_id)
        result.update(auth_completed_carry)
        return result

    # ═══════════════════════════════════════════════════════════════
    # Private helpers
    # ═══════════════════════════════════════════════════════════════

    def _ask_llm(
        self,
        state: GraphState,
        completed: list[str],
        iteration: int,
        session_id: str,
    ) -> SupervisorDecision | None:
        """Call the LLM for an orchestration decision.

        Returns ``None`` on any failure – caller falls back to policy.
        """
        if call_llm is None:
            log.warning("supervisor_llm_unavailable", session_id=session_id)
            return None

        user_prompt = build_user_prompt(state, completed, iteration)

        fallback_raw = _SupervisorLLMRaw(next_step="synthesize", reasoning="")
        fallback_raw._is_fallback = True

        model = getattr(settings, "supervisor_model", None)
        temperature = getattr(settings, "supervisor_temperature", 0.0)

        raw: _SupervisorLLMRaw = call_llm(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=user_prompt,
            response_model=_SupervisorLLMRaw,
            fallback=fallback_raw,
            model=model,
            temperature=temperature,
        )

        # If fallback was used (LLM failure), _is_fallback will still
        # be True – treat that as None so caller uses policy.
        if raw._is_fallback:
            log.warning("supervisor_llm_fallback", session_id=session_id)
            return None

        # Coerce into strict model – reject bad next_step values
        try:
            decision = SupervisorDecision(
                next_step=raw.next_step,
                agents=raw.agents,
                parallelize=raw.parallelize,
                reasoning=raw.reasoning,
            )
        except Exception:
            log.warning(
                "supervisor_llm_parse_error",
                raw_next_step=raw.next_step,
                session_id=session_id,
            )
            return None

        return decision

    def _finalize_with_policy(
        self,
        state: GraphState,
        scratch: dict,
        completed: list[str],
        iteration: int,
        session_id: str,
    ) -> dict:
        """Use deterministic policy to produce an ActionPlan and route to synthesizer."""
        summary = build_summary(state)
        plan = apply_routing_policy(state, summary)

        log.info(
            "supervisor_policy_fallback",
            action_type=plan.action_type.value,
            session_id=session_id,
        )

        # VALIDATE_ENTITIES is the policy's signal that the entity_validator
        # specialist must run.  Routing to the synthesizer would emit a
        # "verifying the details" placeholder forever, because the validation
        # state never advances.  Dispatch the validator instead — but only
        # once per turn, to prevent an infinite supervisor↔validator loop if
        # validation_status fails to settle.
        if (
            plan.action_type == ActionType.VALIDATE_ENTITIES
            and "entity_validator" not in completed
        ):
            new_completed = completed + ["entity_validator"]
            new_iteration = iteration + 1
            scratch.update({
                "supervisor_route": "entity_validator",
                "supervisor_completed": new_completed,
                "supervisor_iteration": new_iteration,
            })
            log.info(
                "supervisor_dispatch_validator",
                reason="policy_validate_entities",
                iteration=new_iteration,
                session_id=session_id,
            )
            return {
                "scratch": scratch,
                "planner_reasoning": f"policy:{plan.action_type.value}",
                "slot_gap": summary.slot_gap,
            }

        return self._build_synthesize_result(
            plan, summary, state, scratch, completed, iteration,
            policy_path=plan.action_type.value,
            reasoning=f"policy:{plan.action_type.value}",
        )

    def _build_synthesize_result(
        self,
        plan,
        summary,
        state: GraphState,
        scratch: dict,
        completed: list[str],
        iteration: int,
        policy_path: str,
        reasoning: str,
    ) -> dict:
        """Build the state dict for routing to the synthesizer."""
        mutations = apply_state_mutations(plan, state)

        scratch.update({
            "supervisor_route": "synthesizer",
            "supervisor_completed": completed,
            "supervisor_iteration": iteration,
        })

        result: dict = {
            "current_action_plan": plan,
            "policy_path": policy_path,
            "planner_reasoning": reasoning,
            "slot_gap": summary.slot_gap,
            "scratch": scratch,
        }
        result.update(mutations)
        return result

    # — Health check ————————————————————————————————————————————————

    def health_check(self) -> bool:
        # M2: Warn if LLM is unavailable – supervisor still works via
        # deterministic policy fallback, but LLM-driven routing is lost.
        if call_llm is None:
            log.warning(
                "supervisor_health_no_llm",
                message="LLM client unavailable – supervisor will use "
                        "deterministic policy fallback only",
            )
        return True
