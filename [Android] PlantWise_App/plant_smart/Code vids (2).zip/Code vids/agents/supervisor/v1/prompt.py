"""Supervisor v1 – LLM prompts for orchestration decisions.

The supervisor is called once per iteration of the supervisor loop.
It decides whether to invoke specialist agents or proceed to response
synthesis.  These prompts give the LLM enough context to make that
decision while keeping the token budget small.

The system prompt is constant; the user prompt is rebuilt each
iteration with the current conversation state summary.
"""

from __future__ import annotations

from enum import Enum
from graph.state import GraphState, get_active_intent
from schemas.enums import AuthLevel, AuthStatus, MessageDomain


def _enum_value(obj: object) -> str:
    """Consistently extract .value from an enum, or str() for non-enums."""
    return obj.value if isinstance(obj, Enum) else str(obj)


# ═══════════════════════════════════════════════════════════════════
# System prompt – constant across all turns
# ═══════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = """\
You are the Supervisor of a multi-agent contact center AI for retirement \
and investment services.

Your job: decide which specialist agents should run NEXT to handle the \
customer's current message, OR decide that enough information has been \
gathered and the system should synthesize a response.

## Available Specialist Agents

| Agent             | Purpose                                                    | When to call
|-------------------|------------------------------------------------------------|---------------------------------------------------------
| intent_agent      | Classifies user intent and manages the intent stack        | When intent is unknown, may have changed, or is ambiguous
| entity_extraction | Extracts slot values (amounts, dates, account info) from msg | When there is a transactional intent with unfilled slots
| rag_agent         | Retrieves answers from the GENERIC knowledge base (plan rules, IRS regs, product explanations) | For informational questions about general policy / regulation. NEVER for personal account data (balance, RMD, contributions, beneficiaries) — that lives in the account API and is fetched by the appropriate tool after auth.
| auth_agent        | Verifies user identity via challenge-response              | When auth_status is not VERIFIED and a transactional intent requires higher auth
| entity_validator  | Validates entities against regulatory rules                | When all required slots are filled and validation has not run

## Rules

1. Do NOT call agents that have already run this turn unless their input has changed (e.g. new entities extracted).
2. For INFORMATIONAL messages: usually only intent_agent + rag_agent are needed.
2a. NEVER call rag_agent for questions about the user's PERSONAL account state
    (balance, RMD amount, vested %, YTD contributions, beneficiaries on file,
    outstanding loan balance, account number, plan name, etc.).  These are
    transactional account-data lookups and must flow through intent_agent ->
    auth_agent -> entity_validator -> EXECUTE_TRANSACTION (the matching
    tool calls the account API).  RAG would return generic plan-document
    text that does NOT reflect the user's actual account.
3. For TRANSACTIONAL messages: intent_agent + entity_extraction are needed first. Add rag_agent ONLY when no slots are missing AND regulatory context is genuinely needed for the response. NEVER call rag_agent while there is still a slot_gap — collecting the missing slot is the single next step.
4. For CHITCHAT messages: no agents needed – synthesize immediately.
5. Set parallelize=true when agents are independent (e.g. intent_agent + entity_extraction + rag_agent).
6. Set parallelize=false when one agent depends on another's output (e.g. entity_validator needs entity_extraction first).
7. Call auth_agent ONLY when auth is insufficient – never speculatively.
8. Call entity_validator ONLY when all required slots are filled (slot_gap is empty) and validation_status is null.
9. When all needed information is collected, set next_step to "synthesize". When the only thing missing is a slot value, also set next_step to "synthesize" so the system can ask the customer for it — do NOT loop through more agents.
10. You MUST NOT give financial, tax, or investment advice. If the user asks for personalized advice, synthesize immediately (hard rules will handle escalation).

## Response Format

Respond ONLY with valid JSON. No preamble, no markdown, no explanation outside the JSON.

{
  "next_step": "invoke_agents" | "synthesize",
  "agents": ["agent_name", ...],
  "parallelize": true | false,
  "reasoning": "Brief explanation of your decision"
}\
"""


# ═══════════════════════════════════════════════════════════════════
# User prompt – rebuilt each supervisor iteration
# ═══════════════════════════════════════════════════════════════════

def build_user_prompt(
    state: GraphState,
    completed_agents: list[str],
    iteration: int,
) -> str:
    """Build the user-prompt for the supervisor LLM call.

    Provides a compact state summary so the LLM can decide which
    agents to invoke.  Keeps token count low by including only the
    fields that influence the routing decision.
    """
    parts: list[str] = []

    # — Last user message ————————————————————————————————————————————
    history = state.get("message_history", [])
    last_msg = history[-1].get("content", "") if history else ""
    parts.append(f'Customer message: "{last_msg}"')

    # — Classifier output ————————————————————————————————————————————
    domain = state.get("message_domain")
    confidence = state.get("classifier_confidence", 0.0)
    domain_str = _enum_value(domain)
    parts.append(f"Message domain: {domain_str} (confidence: {confidence:.2f})")

    # — Intent state ————————————————————————————————————————————————
    active_intent = get_active_intent(state)
    if active_intent:
        parts.append(
            f"Active intent: {active_intent.sub_intent} "
            f"(domain: {active_intent.service_domain.value}, "
            f"transactional: {active_intent.is_transactional})"
        )
    else:
        parts.append("Active intent: None (not yet classified)")

    # — Slot gap ————————————————————————————————————————————————————
    slot_gap = state.get("slot_gap", [])
    if slot_gap:
        parts.append(f"Missing slots: {', '.join(slot_gap)}")
    elif active_intent and active_intent.required_slots:
        parts.append("Missing slots: none (all filled)")

    # — Auth state ——————————————————————————————————————————————————
    auth_state = state.get("auth_state")
    if auth_state:
        level_str = _enum_value(auth_state.current_level)
        parts.append(
            f"Auth: level={level_str}, "
            f"locked={auth_state.is_locked}"
        )
    auth_status = state.get("auth_status")
    if auth_status:
        status_str = _enum_value(auth_status)
        parts.append(f"Auth status: {status_str}")

    # — Validation state ————————————————————————————————————————————
    validation_status = state.get("validation_status")
    if validation_status is not None:
        val_str = _enum_value(validation_status)
        parts.append(f"Validation: {val_str}")
    else:
        parts.append("Validation: not run")

    # — RAG state ————————————————————————————————————————————————————
    rag_answer = state.get("rag_answer")
    rag_confidence = state.get("rag_confidence")
    rag_error = state.get("rag_error")
    if rag_error:
        parts.append(f"RAG: error ({rag_error})")
    elif rag_answer is not None:
        parts.append(f"RAG: answer available (confidence: {rag_confidence:.2f})")
    else:
        parts.append("RAG: not run")

    # — HITL state ——————————————————————————————————————————————————
    hitl = state.get("hitl")
    if hitl and hitl.pending:
        parts.append("HITL: pending (awaiting user confirmation)")
    elif hitl and hitl.last_confirmed is True:
        parts.append("HITL: approved by user")
    elif hitl and hitl.last_confirmed is False:
        if hitl.last_corrections:
            parts.append("HITL: user requested corrections")
        else:
            parts.append("HITL: denied by user")

    # — Completed agents this turn ——————————————————————————————————
    if completed_agents:
        parts.append(f"Agents already run this turn: {', '.join(completed_agents)}")
    else:
        parts.append("Agents already run this turn: none")

    # — Iteration ————————————————————————————————————————————————————
    parts.append(f"Supervisor iteration: {iteration}")

    # — User profile (cross-session context) ————————————————————————
    profile = state.get("user_profile", {})
    if profile:
        from user_profile.base import sanitize_profile_field
        profile_parts: list[str] = []
        name = sanitize_profile_field(profile.get("display_name"))
        if name:
            profile_parts.append(f"name={name}")
        recent = profile.get("recent_intents", [])
        if recent:
            safe_intents = [sanitize_profile_field(i, max_len=40) for i in recent[:5]]
            profile_parts.append(f"recent_intents=[{', '.join(safe_intents)}]")
        txn_count = profile.get("past_transaction_count", 0)
        if txn_count > 0:
            profile_parts.append(f"prior_transactions={txn_count}")
        if profile_parts:
            parts.append(f"User profile: {', '.join(profile_parts)}")

    return "\n".join(parts)
