"""
Summary builder – extracts AgentOutputSummary from GraphState.

Used by the supervisor agent to build a compact state snapshot before
evaluating hard rules and policy routing.

Usage:
    from agents.supervisor.v1.summary import build_summary
    summary = build_summary(state)
"""

from __future__ import annotations

from graph.state import GraphState, compute_slot_gap, get_active_intent
from schemas.enums import (
    AuthLevel,
    AuthStatus,
    MessageDomain,
    ValidationSeverity,
)
from schemas.primitives import AgentOutputSummary


def build_summary(state: GraphState) -> AgentOutputSummary:
    """Build AgentOutputSummary from the merged post-parallel state.

    This is the single source of truth for summarising upstream agent
    outputs into a compact object that hard_rules.py and policy.py
    consume.
    """
    active_intent = get_active_intent(state)

    # Recompute slot_gap from canonical source (not stale state["slot_gap"])
    slot_gap = compute_slot_gap(state)

    # Classification
    classifier_domain = state.get("message_domain") or MessageDomain.INFORMATIONAL
    classifier_confidence = state.get("classifier_confidence", 0.0)
    classifier_escalation = state.get("classifier_escalation_flag", False)

    # Intent
    intent_id = active_intent.intent_id if active_intent else None
    intent_escalation = active_intent.escalation_flag if active_intent else False

    # Auth
    auth_state = state.get("auth_state")
    auth_level = auth_state.current_level if auth_state else AuthLevel.SESSION
    auth_locked = auth_state.is_locked if auth_state else False
    auth_status = state.get("auth_status", AuthStatus.PENDING)

    # Validation
    validation_status = state.get("validation_status")
    violations = state.get("violations", [])
    has_blocking = any(
        v.severity == ValidationSeverity.BLOCKING for v in violations
    )

    # RAG
    rag_confidence = state.get("rag_confidence")
    rag_answer_available = state.get("rag_answer") is not None

    # HITL
    hitl = state.get("hitl")
    hitl_pending = hitl.pending if hitl else False

    # Counters
    correction_count = state.get("correction_count", 0)
    retry_count = state.get("retry_count", 0)

    # Message
    history = state.get("message_history", [])
    last_message = history[-1].get("content", "") if history else ""

    # Contradictions
    contradictions = state.get("contradictions", [])

    return AgentOutputSummary(
        classifier_domain=classifier_domain,
        classifier_confidence=classifier_confidence,
        classifier_escalation=classifier_escalation,
        intent_id=intent_id,
        intent_escalation=intent_escalation,
        slot_gap=slot_gap,
        auth_level=auth_level,
        auth_locked=auth_locked,
        auth_status=auth_status,
        validation_status=validation_status,
        has_blocking_violations=has_blocking,
        violations=violations,
        rag_confidence=rag_confidence,
        rag_answer_available=rag_answer_available,
        hitl_pending=hitl_pending,
        last_message=last_message,
        correction_count=correction_count,
        retry_count=retry_count,
        contradictions=contradictions,
    )
