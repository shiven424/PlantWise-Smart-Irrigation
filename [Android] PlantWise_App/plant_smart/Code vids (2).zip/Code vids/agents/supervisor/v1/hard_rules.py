"""
H1-H8: Unconditional deterministic Python rules.
Evaluated in ORDER.  First rule that fires returns an ActionPlan immediately.
NO LLM call is made when a hard rule fires.
These rules CANNOT be overridden by any LLM output.

Originally in ``agents/action_planner/v1/hard_rules.py``; moved here
when the supervisor agent absorbed the action planner.
"""

from __future__ import annotations

import re
from typing import Optional

from config import settings
from graph.state import GraphState, get_active_intent
from auth.predicates import is_auth_verification_turn
from observability.metrics import metrics
from schemas.enums import (
    ActionType,
    AuthLevel,
    AuthStatus,
    EscalationReason,
    MessageDomain,
)
from schemas.escalation_utils import keyword_to_escalation_reason
from schemas.primitives import (
    ActionPlan,
    AgentOutputSummary,
    AuthState,
    EscalationContext,
    ResponseDirective,
)


def evaluate_hard_rules(
    state: GraphState,
    summary: AgentOutputSummary,
) -> Optional[ActionPlan]:
    """
    Evaluate H1-H8 in priority order.

    Returns an ActionPlan if any rule fires, ``None`` if all pass
    (proceed to the policy layer).
    """

    # — H1: Escalation Supremacy ————————————————————————————————————
    # Trigger: classifier or explicit escalation flag set in state.
    # Intent-based escalation (escalation_flag on IntentRecord) is
    # handled separately by H7 so it gets the correct
    # EscalationReason.FINANCIAL_ADVICE instead of falling through
    # to the generic classifier reason mapper.
    #
    # Auth-verification guard: when the user is mid-challenge (live
    # pending_auth_challenge + PENDING + level still below required +
    # verification_input populated), the classifier-flag branch is
    # SUPPRESSED.  The classifier can hallucinate an escalation signal
    # on bare verification tokens like "4321"; allowing H1 to fire here
    # would short-circuit the auth state machine before the answer is
    # evaluated.  Explicit ``escalation_requested=True`` (set
    # deterministically by other code, e.g. a BLOCKING violation) still
    # fires unconditionally — we never want auth to be a black hole.
    auth_verifying = is_auth_verification_turn(state)
    classifier_escalation_active = (
        summary.classifier_escalation and not auth_verifying
    )
    if (
        classifier_escalation_active
        or state.get("escalation_requested", False)
    ):
        ctx = state.get("escalation_context")
        if ctx is None:
            reason_str = state.get("classifier_escalation_reason") or ""
            ctx = EscalationContext(
                reason=_classifier_reason_to_enum(reason_str),
                triggered_by="supervisor.H1",
            )
        metrics.record_escalation(ctx.reason.value, ctx.triggered_by)
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="EMPATHETIC"),
            escalation_context=ctx,
            hard_rule_fired="H1",
        )

    active_intent = get_active_intent(state)
    auth_state = state.get("auth_state") or AuthState()

    # — H2: Authentication Gate ————————————————————————————————————
    # H2b: session locked (2+ auth failures) → escalate immediately.
    if auth_state.is_locked:
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="EMPATHETIC"),
            escalation_context=EscalationContext(
                reason=EscalationReason.AUTH_LOCKED,
                triggered_by="supervisor.H2b",
            ),
            hard_rule_fired="H2",
        )

    # H2a: transactional intent with insufficient auth level (not locked).
    if (
        active_intent
        and active_intent.is_transactional
        and auth_state.current_level < active_intent.requires_auth_level
    ):
        # Only fire INITIATE_AUTH on the FIRST encounter (when required_auth_level
        # is still at the default SESSION level).  On subsequent turns the required
        # level is already elevated, meaning we already told the user auth is needed.
        # Returning None lets the LLM supervisor dispatch auth_agent to issue or
        # evaluate the actual challenge, instead of repeating "verify your identity"
        # every turn and never asking a specific question.
        already_initiated = (
            state.get("required_auth_level", AuthLevel.SESSION) > AuthLevel.SESSION
        )
        if already_initiated:
            return None

        return ActionPlan(
            action_type=ActionType.INITIATE_AUTH,
            response_directive=ResponseDirective(tone="PROFESSIONAL"),
            hard_rule_fired="H2",
            # state_delta sets required_auth_level so auth_agent knows which
            # challenge tier to issue, and auth_status=PENDING so the LLM
            # supervisor knows auth is not yet complete on the next turn.
            state_delta={
                "required_auth_level": active_intent.requires_auth_level,
                "auth_status": AuthStatus.PENDING,
            },
        )

    # — H3: Validation Before HITL ————————————————————————————————
    # Trigger: HITL is pending but validation has not been run yet.
    # Forces validation before presenting confirmation screen.
    if (
        summary.hitl_pending
        and state.get("validation_status") is None
        and active_intent
        and active_intent.is_transactional
    ):
        return ActionPlan(
            action_type=ActionType.VALIDATE_ENTITIES,
            response_directive=ResponseDirective(tone="PROFESSIONAL"),
            hard_rule_fired="H3",
        )

    # — H4: One Question Per Turn ————————————————————————————————
    # NOT a separate branch – enforced structurally in policy layer:
    # policy always picks slot_gap[0] only (first missing slot).
    # No explicit return here – falls through to policy layer.

    # — H5: Clarification Retry Limit ————————————————————————————
    # Trigger: retry_count has reached max_clarification_retries.
    # Prevents infinite slot-collection loops.
    if state.get("retry_count", 0) >= settings.max_clarification_retries:
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="GENTLE"),
            escalation_context=EscalationContext(
                reason=EscalationReason.MAX_RETRIES,
                triggered_by="supervisor.H5",
            ),
            hard_rule_fired="H5",
        )

    # — H6: HITL Correction Limit ————————————————————————————————
    # Trigger: correction_count has reached max_hitl_corrections.
    # Prevents client from endlessly correcting values at the HITL screen.
    if state.get("correction_count", 0) >= settings.max_hitl_corrections:
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="GENTLE"),
            escalation_context=EscalationContext(
                reason=EscalationReason.MAX_CORRECTIONS,
                triggered_by="supervisor.H6",
            ),
            hard_rule_fired="H6",
        )

    # — H7: No Personalised Financial / Tax Advice ——————————————
    # Trigger: intent_agent flagged the intent as requiring personal advice.
    # Uses the intent agent's escalation_context (if available) for an
    # accurate EscalationReason instead of defaulting to FINANCIAL_ADVICE.
    if active_intent and active_intent.escalation_flag:
        ctx = state.get("escalation_context") or EscalationContext(
            reason=EscalationReason.FINANCIAL_ADVICE,
            triggered_by="supervisor.H7",
        )
        return ActionPlan(
            action_type=ActionType.ESCALATE,
            response_directive=ResponseDirective(tone="PROFESSIONAL"),
            escalation_context=ctx,
            hard_rule_fired="H7",
        )

    # — H8: No Fabrication / Low RAG Confidence ——————————————————
    # Trigger: RAG ran on an informational query but confidence < threshold,
    # OR the RAG pipeline itself failed (rag_error is set).
    # Prevents hallucinated regulatory information from reaching the client.
    # Does NOT fire for transactional queries that don't use RAG.
    rag_confidence = summary.rag_confidence
    rag_error = state.get("rag_error")
    if summary.classifier_domain == MessageDomain.INFORMATIONAL:
        if rag_error:
            # KB pipeline failed – escalate with operational context
            return ActionPlan(
                action_type=ActionType.ESCALATE,
                response_directive=ResponseDirective(
                    tone="PROFESSIONAL",
                    content_hints=[
                        "Knowledge base is temporarily unavailable. "
                        "Connecting to a specialist who can assist."
                    ],
                ),
                escalation_context=EscalationContext(
                    reason=EscalationReason.LOW_RAG_CONFIDENCE,
                    triggered_by="supervisor.H8",
                    client_message="Our knowledge system is temporarily unavailable. "
                                   "Let me connect you with a specialist.",
                ),
                hard_rule_fired="H8",
            )
        if (
            rag_confidence is not None
            and rag_confidence < settings.min_rag_confidence
        ):
            return ActionPlan(
                action_type=ActionType.ESCALATE,
                response_directive=ResponseDirective(tone="PROFESSIONAL"),
                escalation_context=EscalationContext(
                    reason=EscalationReason.LOW_RAG_CONFIDENCE,
                    triggered_by="supervisor.H8",
                ),
                hard_rule_fired="H8",
            )

    return None  # no hard rule fired – proceed to policy layer


# — Classifier reason mapping (used by H1) ——————————————————————————
# Fix H3: Use the canonical keyword_to_escalation_reason() from
# escalation_utils (already imported at top). Removes the duplicate
# _CLASSIFIER_REASON_MAP that had already diverged (missing 2 keywords).

def _classifier_reason_to_enum(reason_str: str) -> EscalationReason:
    """Map classifier_escalation_reason string to an EscalationReason enum.

    Delegates to the single source of truth in schemas.escalation_utils
    to prevent silent divergence when keywords are added/removed.
    """
    return keyword_to_escalation_reason(reason_str)
