"""Entity Extraction v1 — extracts structured entities from user messages."""

from __future__ import annotations

import re
from uuid import uuid4

from pydantic import BaseModel, Field

from agents.base import BaseAgent
from agents.entity_extraction.v1.entity_types import (
    get_allowed_values,
    lookup_entity_type,
    lookup_slot,
)
from agents.entity_extraction.v1.prompt import SYSTEM_PROMPT, build_user_prompt
from config import settings
from graph.state import GraphState, compute_slot_gap, get_active_intent
from llm.client import call_llm
from observability.logger import log
from observability.tracer import trace_agent
from schemas.enums import EntityType, EscalationReason, PII_ENTITY_TYPES
from schemas.primitives import EntityRecord, EscalationContext
from vault.client import vault_client


# — Internal LLM response model ——————————————————————————————————————————————

class _LLMEntity(BaseModel):
    entity_type: str = ""
    slot_name: str | None = None
    ambient_key: str | None = None
    display_value: str | None = None
    raw_value: str | None = None
    confidence: float = 0.0


class _LLMExtractionResponse(BaseModel):
    entities: list[_LLMEntity] = Field(default_factory=list)
    contradiction_notes: list[str] = Field(default_factory=list)


# — Agent ————————————————————————————————————————————————————————————————————

class EntityExtractionAgent(BaseAgent):
    name    = "entity_extraction"
    version = "1.0.0"

    @trace_agent("entity_extraction")
    def run(self, state: GraphState) -> dict:
        history = state.get("message_history", [])
        current_msg = history[-1].get("content", "") if history else ""
        current_turn: int = state.get("current_turn", 0)
        session = state.get("session")
        session_id: str = str(session.session_id) if session else "unknown"

        existing_entities: dict[str, EntityRecord] = state.get("entity_memory", {})

        # Determine required slots from active intent
        active_intent = get_active_intent(state)
        required_slots: list[str] = list(active_intent.required_slots) if active_intent else []

        # Use the SAME slot-gap semantics as ``entity_validator`` / policy
        # (graph.state.compute_slot_gap), NOT entity_memory-only diffs:
        #
        # For PLAN_LOAN_REQUEST, ``plan_type`` is auto-treated as resolved when the
        # participant has at most one loan-eligible workplace plan — even when
        # there is NO plan_type EntityRecord in memory yet.  Extracting gaps from
        # memory alone falsely leaves ``plan_type`` "missing"; the LLM then reads
        # HITL compliance text mentioning IRA and overwrites categorical slots.
        #
        # During parallel_dispatch, intent_agent may change intent_stack; both
        # this node and compute_slot_gap read the PRE-merge state snapshot.
        slot_gap = compute_slot_gap(state)

        # POST /hitl corrections apply slot patches without a fresh user utterance,
        # so chat history[-1] is often stale vs entity_memory but history[-2] is an
        # HITL / compliance bubble that mentions IRA, 403(b), tax copy, etc.  When all
        # required slots are already filled (`slot_gap` empty), invoking the extractor
        # LLM repeatedly mis-reads that boilerplate and overwrites categorical slots
        # (plan_type→IRA).  `main.hitl_resume` sets scratch flag for this boundary only.
        scratch = state.get("scratch") or {}
        suppress_ambient = bool(
            scratch.get("suppress_ambient_entity_llm_when_slot_gap_empty")
        )
        if (
            suppress_ambient
            and active_intent
            and required_slots
            and not slot_gap
        ):
            log.info(
                "entity_extraction_skip_no_slot_gap_hitl_correction",
                session_id=session_id,
                turn=current_turn,
                sub_intent=active_intent.sub_intent,
            )
            # Do not clear scratch.suppress_* here: supervisor may invoke this node
            # multiple times in one graph.invoke; clearing after the first skip lets
            # a later pass call the LLM with stale history + HITL compliance text.
            return {
                "entity_memory": {},
                "contradictions": [],
            }

        # Call LLM for entity extraction
        default_entities = state.get("user_profile", {}).get("default_entities")
        last_requested_slot = state.get("last_requested_slot")
        # Pass the previous assistant message so the LLM has context to
        # resolve bare affirmations ("yes", "ok") to the correct slot value.
        # e.g. user says "yes" to "Is your 401(k) correct?" → plan_type=401K.
        prev_assistant_msg = (
            history[-2].get("content", "") if len(history) >= 2 else ""
        )
        llm_result = self._llm_extract(
            current_msg, slot_gap, existing_entities, default_entities,
            last_requested_slot=last_requested_slot,
            prev_assistant_msg=prev_assistant_msg,
        )

        # Process each extracted entity
        new_entities: dict[str, EntityRecord] = {}
        contradiction_flags: list[str] = []
        vault_failure_count: int = 0

        for raw_entity in llm_result.entities:
            record = self._build_entity_record(
                raw_entity, current_turn, session_id, existing_entities
            )
            if record is None:
                # Fix 83: _build_entity_record returns None for both
                # unknown entity types AND vault tokenization failures.
                # Count PII types that would have required vaulting so
                # we can still trigger escalation below.
                try:
                    etype = EntityType(raw_entity.entity_type)
                    if etype in PII_ENTITY_TYPES:
                        vault_failure_count += 1
                except ValueError:
                    pass
                continue

            # Store by slot_name (preferred) or ambient_key or entity_id
            key = record.slot_name or record.ambient_key or str(record.entity_id)

            # Check for contradictions with existing entities
            if key in existing_entities and existing_entities[key].is_confirmed:
                old = existing_entities[key]
                if old.display_value != record.display_value:
                    record = EntityRecord(
                        entity_id=record.entity_id,
                        entity_type=record.entity_type,
                        is_pii=record.is_pii,
                        slot_name=record.slot_name,
                        ambient_key=record.ambient_key,
                        raw_value=record.raw_value,
                        display_value=record.display_value,
                        vault_token=record.vault_token,
                        confidence=record.confidence,
                        turn_confirmed=None,
                        is_confirmed=False,
                        source_text=record.source_text,
                        contradicts=old.entity_id,
                    )
                    contradiction_flags.append(str(old.entity_id))
                    log.info(
                        "entity_contradiction_detected",
                        slot=key,
                        old_value=old.display_value,
                        new_value=record.display_value,
                        session_id=session_id,
                    )

            new_entities[key] = record

        # Add contradiction notes from LLM
        for note in llm_result.contradiction_notes:
            log.info("entity_contradiction_note", note=note, session_id=session_id)

        # Compute slots_filled and slots_still_missing
        all_entities = {**existing_entities, **new_entities}
        filled_slots = {
            e.slot_name for e in all_entities.values()
            if e.slot_name and e.slot_name in required_slots
        }
        slots_still_missing = [s for s in required_slots if s not in filled_slots]

        result: dict = {
            "entity_memory": new_entities,
            "contradictions": contradiction_flags,
        }

        # H3 / Fix 83: If any PII entity was dropped due to vault failure
        # or has a missing vault_token, escalate so the system doesn't
        # silently proceed with partial / unvaulted data.
        # Fix C3: Also check that raw_value was cleared after vaulting —
        # the EntityExtractionResponse validator (all_pii_must_be_vaulted)
        # is never invoked at runtime because agents return dicts, not
        # Pydantic models.  This inline check replaces that dead code.
        vault_failures_in_state = [
            e for e in new_entities.values()
            if e.is_pii and (not e.vault_token or e.raw_value is not None)
        ]
        total_vault_failures = len(vault_failures_in_state) + vault_failure_count
        if total_vault_failures:
            log.error(
                "entity_extraction_vault_escalation",
                failed_count=total_vault_failures,
                session_id=session_id,
            )
            result["escalation_requested"] = True
            result["escalation_context"] = EscalationContext(
                reason=EscalationReason.SYSTEM_ERROR,
                triggered_by="entity_extraction",
                client_message="We encountered a technical issue securing your information. "
                               "Please hold while we connect you to a specialist.",
            )

        return result

    def _llm_extract(
        self,
        message: str,
        required_slots: list[str],
        existing_entities: dict[str, EntityRecord],
        default_entities: dict | None = None,
        last_requested_slot: str | None = None,
        prev_assistant_msg: str | None = None,
    ) -> _LLMExtractionResponse:
        fallback = _LLMExtractionResponse(entities=[], contradiction_notes=[])
        return call_llm(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=build_user_prompt(
                message, required_slots, existing_entities, default_entities,
                last_requested_slot=last_requested_slot,
                prev_assistant_msg=prev_assistant_msg,
            ),
            response_model=_LLMExtractionResponse,
            fallback=fallback,
            cacheable=True,
        )

    def _build_entity_record(
        self,
        raw: _LLMEntity,
        current_turn: int,
        session_id: str,
        existing: dict[str, EntityRecord],
    ) -> EntityRecord | None:
        """Convert an LLM-extracted entity into an EntityRecord, vaulting PII."""
        # Validate entity_type
        try:
            entity_type = EntityType(raw.entity_type)
        except ValueError:
            # Defense in depth: the LLM occasionally returns a category
            # label (e.g. "Financial") instead of a canonical EntityType.
            # If a slot_name is provided and maps to a known entity type,
            # recover it rather than dropping the entity (which would
            # leave the slot unfilled and produce a COLLECT_SLOT loop).
            recovered = None
            if raw.slot_name:
                slot_def = lookup_slot(raw.slot_name)
                if slot_def is not None:
                    recovered = slot_def.entity_type
            if recovered is None:
                log.warning(
                    "entity_extraction_unknown_type",
                    entity_type=raw.entity_type,
                    slot_name=raw.slot_name,
                    session_id=session_id,
                )
                return None
            log.info(
                "entity_extraction_type_recovered_from_slot",
                bad_type=raw.entity_type,
                slot_name=raw.slot_name,
                recovered_type=recovered.value,
                session_id=session_id,
            )
            entity_type = recovered

        # Numeric-amount guard: when the LLM extracts an amount-typed entity
        # but the raw value contains no digits (e.g. user said "withdraw
        # money" -> LLM emits withdrawal_amount="money"), drop the entity.
        # Otherwise compute_slot_gap considers the slot filled and the user
        # is never asked for the actual amount, leading to HITL screens
        # showing "Withdrawal Amount: unspecified".
        _AMOUNT_TYPES = {
            EntityType.DOLLAR_AMOUNT,
            EntityType.WITHDRAWAL_AMOUNT,
            EntityType.ROLLOVER_AMOUNT,
            EntityType.LOAN_AMOUNT,
            EntityType.CONTRIBUTION_AMOUNT,
            EntityType.PERCENTAGE,
            EntityType.BENEFICIARY_PERCENTAGE,
            EntityType.WITHHOLDING_PERCENT,
        }
        if entity_type in _AMOUNT_TYPES:
            combined = f"{raw.raw_value or ''} {raw.display_value or ''}"
            if not re.search(r"\d", combined):
                log.info(
                    "entity_extraction_amount_without_digits_dropped",
                    entity_type=entity_type.value,
                    slot_name=raw.slot_name,
                    raw_value=raw.raw_value,
                    session_id=session_id,
                )
                return None

        # Categorical-from-digits guard: when the LLM extracts a categorical
        # slot value (ACCOUNT_TYPE, PLAN_TYPE, DISTRIBUTION_TYPE, etc.) but
        # the user's raw_value contains ONLY digits / whitespace, drop the
        # entity.  Symptom: user types "7766" (last-4 SSN auth answer) on a
        # turn where slot_gap=['account_type'] — the prompt's bare-word rule
        # makes the LLM hallucinate display_value="BROKERAGE" with raw_value
        # "7766", which then silently picks an account the user never asked
        # for.  Categorical labels are never digit-only.
        _CATEGORICAL_TYPES = {
            EntityType.ACCOUNT_TYPE,
            EntityType.PLAN_TYPE,
            EntityType.DISTRIBUTION_TYPE,
            EntityType.ROLLOVER_TYPE,
            EntityType.DOCUMENT_TYPE,
            EntityType.DELIVERY_METHOD,
            EntityType.WITHHOLDING_TYPE,
            EntityType.ORDER_TYPE,
            EntityType.BENEFICIARY_RELATION,
            EntityType.BENEFICIARY_TYPE,
            EntityType.RISK_TOLERANCE,
            EntityType.REBALANCE_FREQUENCY,
            EntityType.REINVEST_OPTION,
            EntityType.DISTRIBUTION_FREQUENCY,
        }
        if entity_type in _CATEGORICAL_TYPES:
            raw_text = (raw.raw_value or "").strip()
            if raw_text and not re.search(r"[A-Za-z]", raw_text):
                log.info(
                    "entity_extraction_categorical_from_digits_dropped",
                    entity_type=entity_type.value,
                    slot_name=raw.slot_name,
                    raw_value=raw.raw_value,
                    display_value=raw.display_value,
                    session_id=session_id,
                )
                return None

            # Allowed-values guard: if the LLM produced a categorical
            # value that is NOT in the slot's canonical set (e.g. user
            # said "calculate my RMD" -> LLM emits PLAN_TYPE
            # display_value="RMD"), drop it.  Without this guard
            # compute_slot_gap treats the slot as filled, the validator
            # has no rule that rejects it, and the HITL card surfaces
            # nonsense like "Plan Type: RMD" while the tool runs on an
            # arbitrary account.
            #
            # SCOPE: PLAN_TYPE and ACCOUNT_TYPE only.  Other categoricals
            # (BENEFICIARY_RELATION accepting "daughter"/"son",
            # DISTRIBUTION_TYPE accepting various phrasings, etc.) are
            # handled by downstream resolvers and have rich user
            # vocabularies that the canonical sets do not enumerate;
            # rejecting them here would break legitimate inputs.
            _GUARDED_CATEGORICALS = {
                EntityType.PLAN_TYPE,
                EntityType.ACCOUNT_TYPE,
            }
            if entity_type in _GUARDED_CATEGORICALS and raw.slot_name:
                allowed = get_allowed_values(raw.slot_name)
                if allowed:
                    def _norm_cat(v: str) -> str:
                        # Upper, strip parens, collapse spaces/hyphens
                        # to underscores so "401(k)", "401-K", "401 K"
                        # all match canonical "401K"; "Traditional IRA"
                        # matches "TRADITIONAL_IRA"; etc.
                        s = (v or "").upper().strip()
                        s = re.sub(r"[\(\)\.]", "", s)
                        s = re.sub(r"[\s\-]+", "_", s)
                        return s.strip("_")

                    candidate = _norm_cat(raw.display_value or raw.raw_value or "")
                    allowed_norm = {_norm_cat(v) for v in allowed}
                    if candidate and candidate not in allowed_norm:
                        log.info(
                            "entity_extraction_categorical_not_in_allowed_values_dropped",
                            entity_type=entity_type.value,
                            slot_name=raw.slot_name,
                            display_value=raw.display_value,
                            normalised=candidate,
                            allowed_count=len(allowed),
                            session_id=session_id,
                        )
                        return None

        is_pii = entity_type in PII_ENTITY_TYPES

        # Secondary regex guard: catch PII the LLM failed to classify
        if not is_pii and raw.raw_value:
            _pii_patterns = [
                r"\d{3}-\d{2}-\d{4}",                          # SSN (formatted)
                r"(?<!\d)\d{9}(?!\d)",                          # SSN (plain 9 digits)
                r"\d{3}[-.\s]\d{3}[-.\s]\d{4}",  # phone (formatted)
                r"(?<!\d)\d{10}(?!\d)",                         # phone (plain 10 digits)
                r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",  # email
            ]
            for pat in _pii_patterns:
                if re.search(pat, raw.raw_value):
                    log.warning(
                        "entity_pii_pattern_override",
                        entity_type=entity_type.value,
                        session_id=session_id,
                    )
                    is_pii = True
                    break

        vault_token: str | None = None
        raw_value = raw.raw_value

        # Vault PII entities
        if is_pii and raw_value:
            # Fix 25: Clean up old vault token before creating a new one
            # to prevent orphaned PII when entities are re-extracted
            # during HITL correction flows.
            key = raw.slot_name or raw.ambient_key
            if key and key in existing:
                old_token = getattr(existing[key], "vault_token", None)
                if old_token:
                    try:
                        vault_client.delete(old_token)
                    except Exception as exc:
                        log.warning(
                            "vault_old_token_cleanup_failed",
                            slot=key,
                            token_prefix=old_token[:8] if old_token else "",
                            error=str(exc),
                        )

            try:
                vault_token = vault_client.tokenize(
                    entity_type=entity_type.value,
                    raw_value=raw_value,
                    session_id=session_id,
                )
                raw_value = None  # Clear after vaulting
            except Exception as e:
                log.error(
                    "entity_vault_tokenize_failed",
                    entity_type=entity_type.value,
                    error=str(e),
                    session_id=session_id,
                )
                # Fix 83: PII entity with failed vaulting must not enter
                # state — raw_value is cleared (no PII leak) but vault_token
                # is also None, making the record unusable downstream.
                # Return None so the caller skips this entity; escalation is
                # triggered separately by the vault_failures check.
                return None

        return EntityRecord(
            entity_id=uuid4(),
            entity_type=entity_type,
            is_pii=is_pii,
            slot_name=raw.slot_name,
            ambient_key=raw.ambient_key,
            raw_value=raw_value,
            display_value=raw.display_value,
            vault_token=vault_token,
            confidence=raw.confidence,
            turn_confirmed=None,
            is_confirmed=False,
            source_text=None,
        )

    def health_check(self) -> bool:
        return bool(settings.anthropic_api_key or settings.openai_api_key)
