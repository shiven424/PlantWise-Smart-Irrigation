from __future__ import annotations

"""
Entity Type Definitions
-----------------------
Canonical registry mapping every ``EntityType`` enum member to its extraction
and display metadata.  This module is the **single source of truth** for:

 - Which ``EntityType`` maps to which taxonomy slot name(s)
 - Whether the entity is PII (triggers vault tokenisation)
 - How raw text is parsed to a normalised value
 - How display masking works for PII
 - What categorical values are valid for enumeration-type entities
 - Which entities the LLM prompt should describe to the extraction model

Consumers:
 - ``agents/entity_extraction/v1/agent.py``   — builds LLM prompt
 - ``agents/entity_extraction/v1/prompt.py``  — renders entity schema for LLM
 - ``agents/entity_validator/v1/rules/``      — validation rules read entity dicts
 - ``vault/tokenizer.py``                     — PII tokenisation / masking
 - ``graph/state.py``                         — ``compute_slot_gap()``
"""

from dataclasses import dataclass, field
from enum import Enum

from schemas.enums import EntityType, PII_ENTITY_TYPES


# ==============================================================================
# Parsing strategy enum
# ==============================================================================

class ParseStrategy(str, Enum):
    """How the raw user text should be normalised for a given entity type."""
    DOLLAR    = "DOLLAR"    # strip $, commas → float
    PERCENT   = "PERCENT"   # strip % → float
    INTEGER   = "INTEGER"   # int()
    FLOAT     = "FLOAT"     # float()
    ISO_DATE  = "ISO_DATE"  # YYYY-MM-DD
    YEAR      = "YEAR"      # 4-digit year
    CATEGORY  = "CATEGORY"  # must match allowed_values
    FREE_TEXT = "FREE_TEXT"  # no normalisation, pass through
    COMPOSITE = "COMPOSITE"  # structured dict/JSON (e.g. portfolio_allocation)


# ==============================================================================
# Entity type definition dataclass
# ==============================================================================

@dataclass(frozen=True, slots=True)
class EntityTypeDef:
    """Immutable metadata for one ``EntityType`` enum member."""

    entity_type:     EntityType
    slot_names:      tuple[str, ...]          # taxonomy slot names this type satisfies
    parse_strategy:  ParseStrategy
    description:     str                      # human-readable, used in LLM prompt
    examples:        tuple[str, ...] = ()     # example user utterances / values
    allowed_values:  tuple[str, ...] = ()     # valid set for CATEGORY parse strategy
    display_mask:    str             = ""     # Python format pattern for PII masking
    is_pii:          bool            = False
    aliases:         tuple[str, ...] = ()     # alternate user phrasings the LLM should recognise

    @property
    def primary_slot(self) -> str | None:
        """First slot name, or ``None`` if the entity is ambient (no slot)."""
        return self.slot_names[0] if self.slot_names else None


# ==============================================================================
# PII Entity Definitions
# ==============================================================================

_PII_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.FULL_NAME,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Full legal name of the account holder",
        examples=("John A. Smith", "Mary Jane Watson"),
        display_mask="{value}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.SSN,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Social Security Number (9 digits)",
        examples=("123-45-6789", "123456789"),
        display_mask="***-**-{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.DATE_OF_BIRTH,
        slot_names=("date_of_birth",),
        parse_strategy=ParseStrategy.ISO_DATE,
        description="Account holder date of birth",
        examples=("1965-03-15", "March 15, 1965"),
        display_mask="{value}",
        is_pii=True,
        aliases=("birthday", "DOB", "born on"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ADDRESS,
        slot_names=("new_address",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Mailing or residential address",
        examples=("123 Main St, Anytown, CA 90210",),
        display_mask="{value}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.PHONE_NUMBER,
        slot_names=("new_phone",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Phone number",
        examples=("555-123-4567", "(555) 123-4567"),
        display_mask="(XXX) XXX-{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.EMAIL_ADDRESS,
        slot_names=("new_email",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Email address",
        examples=("john.smith@example.com",),
        display_mask="{first_char}***@{domain}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.TAX_ID,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Tax identification number (EIN or ITIN)",
        examples=("12-3456789",),
        display_mask="**-*****{last2}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.ACCOUNT_NUMBER,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Account number",
        examples=("401K001234", "IRA-98765"),
        display_mask="****{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.BANK_ACCOUNT_NUMBER,
        slot_names=("bank_account_number",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="External bank account number",
        examples=("98765432",),
        display_mask="****{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.BANK_ROUTING_NUMBER,
        slot_names=("bank_routing_number",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Bank ABA routing transit number (9 digits)",
        examples=("021000021",),
        display_mask="****{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.BENEFICIARY_NAME,
        slot_names=("beneficiary_name",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Name of a beneficiary",
        examples=("Jane Smith", "The Smith Family Trust"),
        display_mask="{value}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.BENEFICIARY_DOB,
        slot_names=(),
        parse_strategy=ParseStrategy.ISO_DATE,
        description="Beneficiary date of birth",
        examples=("1990-06-01",),
        display_mask="{value}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.POLICY_NUMBER,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Insurance or annuity policy number",
        examples=("POL-2024-001234",),
        display_mask="****{last4}",
        is_pii=True,
    ),
    EntityTypeDef(
        entity_type=EntityType.EMPLOYER_NAME,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Employer or plan sponsor name",
        examples=("Acme Corporation", "EY LLP"),
        display_mask="{value}",
        is_pii=True,
    ),
)


# ==============================================================================
# Financial / Numeric Entity Definitions
# ==============================================================================

_FINANCIAL_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.DOLLAR_AMOUNT,
        slot_names=(),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Generic dollar amount when no specific slot is matched",
        examples=("$20,000", "20000", "$5,000.50"),
        aliases=("amount", "dollars",),
    ),
    EntityTypeDef(
        entity_type=EntityType.LOAN_AMOUNT,
        slot_names=("loan_amount",),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Dollar amount requested for a plan loan",
        examples=("$25,000", "$50,000"),
        aliases=("loan for", "borrow"),
    ),
    EntityTypeDef(
        entity_type=EntityType.WITHDRAWAL_AMOUNT,
        slot_names=("withdrawal_amount",),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Dollar amount to withdraw or distribute",
        examples=("$10,000", "$75,000"),
        aliases=("withdraw", "take out", "distribute"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ROLLOVER_AMOUNT,
        slot_names=("rollover_amount",),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Dollar amount to roll over or convert",
        examples=("$50,000", "all", "entire balance"),
        aliases=("roll over", "transfer", "move"),
    ),
    EntityTypeDef(
        entity_type=EntityType.CONTRIBUTION_AMOUNT,
        slot_names=("contribution_amount",),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Dollar amount or percentage of salary to contribute",
        examples=("$23,500", "10%", "$500 per paycheck"),
        aliases=("contribute", "put in", "defer"),
    ),
    EntityTypeDef(
        entity_type=EntityType.PERCENTAGE,
        slot_names=(),
        parse_strategy=ParseStrategy.PERCENT,
        description="Generic percentage value",
        examples=("15%", "0.15", "fifty percent"),
    ),
    EntityTypeDef(
        entity_type=EntityType.BENEFICIARY_PERCENTAGE,
        slot_names=("beneficiary_percentage",),
        parse_strategy=ParseStrategy.PERCENT,
        description="Percentage share for a beneficiary designation",
        examples=("50%", "100%", "33.33%"),
        aliases=("share", "split"),
    ),
    EntityTypeDef(
        entity_type=EntityType.WITHHOLDING_PERCENT,
        slot_names=("withholding_percentage",),
        parse_strategy=ParseStrategy.PERCENT,
        description="Federal or state tax withholding percentage",
        examples=("20%", "10%", "22%"),
        aliases=("withhold", "tax rate"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ORDER_QUANTITY,
        slot_names=("order_quantity",),
        parse_strategy=ParseStrategy.FLOAT,
        description="Number of shares or units for a trade order",
        examples=("100", "50.5", "250 shares"),
        aliases=("shares", "units", "quantity"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ORDER_PRICE,
        slot_names=("order_price",),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Limit price per share for a trade order",
        examples=("$150.00", "$32.50", "market"),
        aliases=("price", "limit price", "at"),
    ),
    EntityTypeDef(
        entity_type=EntityType.COVERAGE_AMOUNT,
        slot_names=(),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Insurance coverage or benefit amount",
        examples=("$500,000", "$1,000,000"),
    ),
    EntityTypeDef(
        entity_type=EntityType.PREMIUM_AMOUNT,
        slot_names=(),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Insurance premium payment amount",
        examples=("$250/month", "$3,000/year"),
    ),
    EntityTypeDef(
        entity_type=EntityType.VESTED_BALANCE,
        slot_names=(),
        parse_strategy=ParseStrategy.DOLLAR,
        description="Vested account balance amount",
        examples=("$125,000",),
    ),
)


# ==============================================================================
# Date / Time Entity Definitions
# ==============================================================================

_DATE_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.DATE,
        slot_names=(),
        parse_strategy=ParseStrategy.ISO_DATE,
        description="A specific calendar date",
        examples=("2025-01-15", "January 15, 2025", "01/15/2025"),
    ),
    EntityTypeDef(
        entity_type=EntityType.DATE_RANGE,
        slot_names=("date_range", "statement_period"),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="A period defined by start and end dates, or a named period",
        examples=("Q1 2025", "Jan 2025 – Mar 2025", "last 90 days"),
        aliases=("period", "quarter", "from … to"),
    ),
    EntityTypeDef(
        entity_type=EntityType.TAX_YEAR,
        slot_names=("tax_year",),
        parse_strategy=ParseStrategy.YEAR,
        description="Tax filing year (4-digit)",
        examples=("2024", "2025"),
        aliases=("for year", "tax year"),
    ),
    EntityTypeDef(
        entity_type=EntityType.AGE,
        slot_names=(),
        parse_strategy=ParseStrategy.INTEGER,
        description="A person's age in years",
        examples=("59", "72", "65"),
    ),
    EntityTypeDef(
        entity_type=EntityType.TERM_MONTHS,
        slot_names=("repayment_term",),
        parse_strategy=ParseStrategy.INTEGER,
        description="Loan repayment or payment term in months",
        examples=("60", "36", "5 years"),
        aliases=("term", "repayment period", "months"),
    ),
    EntityTypeDef(
        entity_type=EntityType.REPAYMENT_TERM,
        slot_names=(),
        parse_strategy=ParseStrategy.INTEGER,
        description="Repayment term in months (alias for TERM_MONTHS)",
        examples=("60", "120"),
    ),
    EntityTypeDef(
        entity_type=EntityType.RMD_AGE,
        slot_names=(),
        parse_strategy=ParseStrategy.INTEGER,
        description="Age at which Required Minimum Distributions must begin",
        examples=("73",),
    ),
    EntityTypeDef(
        entity_type=EntityType.CONTRIBUTION_YEAR,
        slot_names=(),
        parse_strategy=ParseStrategy.YEAR,
        description="Year a contribution is applied to",
        examples=("2025", "2024"),
    ),
)


# ==============================================================================
# Categorical (Enumeration) Entity Definitions
# ==============================================================================

# -- Plan / account identifiers ------------------------------------------------

PLAN_TYPE_VALUES: tuple[str, ...] = (
    "401K", "TRADITIONAL_IRA", "ROTH_IRA", "403B", "457B",
    "PENSION", "PROFIT_SHARING", "SIMPLE_IRA", "SEP_IRA",
    "ROTH_401K", "ROTH_403B",
    # Bare colloquial forms the prompt is contractually allowed to
    # emit when the user says "ira" / "roth" without qualification.
    # Downstream resolvers in balance_inquiry / rmd_calculator do
    # fuzzy substring matching against the participant's accounts
    # (e.g. bare "IRA" picks the IRA-family account on file).
    "IRA", "ROTH",
)

ACCOUNT_TYPE_VALUES: tuple[str, ...] = PLAN_TYPE_VALUES + (
    "BROKERAGE", "TRUST", "CUSTODIAL", "JOINT",
)

# -- Distribution / rollover ---------------------------------------------------

DISTRIBUTION_TYPE_VALUES: tuple[str, ...] = (
    "NORMAL", "EARLY", "HARDSHIP", "RMD", "SEPP",
    "LUMP_SUM", "INSTALLMENT", "IN_SERVICE",
)

ROLLOVER_TYPE_VALUES: tuple[str, ...] = ("DIRECT", "INDIRECT")

DISTRIBUTION_FREQUENCY_VALUES: tuple[str, ...] = (
    "MONTHLY", "QUARTERLY", "SEMI_ANNUAL", "ANNUAL",
)

# -- Beneficiary ---------------------------------------------------------------

BENEFICIARY_TYPE_VALUES: tuple[str, ...] = ("INDIVIDUAL", "TRUST", "CHARITY", "ESTATE")

BENEFICIARY_RELATION_VALUES: tuple[str, ...] = (
    "SPOUSE", "CHILD", "PARENT", "SIBLING", "GRANDCHILD", "OTHER",
)

# -- Investment ----------------------------------------------------------------

ORDER_TYPE_VALUES: tuple[str, ...] = ("BUY", "SELL")

RISK_TOLERANCE_VALUES: tuple[str, ...] = (
    "CONSERVATIVE", "MODERATELY_CONSERVATIVE", "MODERATE",
    "MODERATELY_AGGRESSIVE", "AGGRESSIVE",
)

REBALANCE_FREQUENCY_VALUES: tuple[str, ...] = (
    "MONTHLY", "QUARTERLY", "SEMI_ANNUAL", "ANNUAL", "NEVER",
)

REINVEST_OPTION_VALUES: tuple[str, ...] = ("REINVEST", "CASH",)

# -- Tax -----------------------------------------------------------------------

DOCUMENT_TYPE_VALUES: tuple[str, ...] = (
    "1099-R", "1099-DIV", "1099-B", "1099-INT", "5498", "W-2",
)

DELIVERY_METHOD_VALUES: tuple[str, ...] = ("MAIL", "ELECTRONIC", "BOTH")

WITHHOLDING_TYPE_VALUES: tuple[str, ...] = ("FEDERAL", "STATE", "BOTH")

# -- US states (2-letter) ------------------------------------------------------

US_STATE_CODES: tuple[str, ...] = (
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
    "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
    "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
    "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
    "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",
    "DC", "PR", "VI", "GU", "AS",
)


_CATEGORICAL_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.PLAN_TYPE,
        slot_names=("plan_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Retirement plan type",
        examples=("401k", "Traditional IRA", "Roth IRA", "403b"),
        allowed_values=PLAN_TYPE_VALUES,
        aliases=("plan", "account type"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ACCOUNT_TYPE,
        slot_names=("account_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Account type (retirement, brokerage, trust, etc.)",
        examples=("401k", "brokerage", "trust", "Roth IRA"),
        allowed_values=ACCOUNT_TYPE_VALUES,
        aliases=("account", "my account"),
    ),
    EntityTypeDef(
        entity_type=EntityType.DISTRIBUTION_TYPE,
        slot_names=("distribution_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Type of distribution or withdrawal",
        examples=("normal", "early", "hardship", "RMD", "lump sum"),
        allowed_values=DISTRIBUTION_TYPE_VALUES,
        aliases=("distribution", "withdrawal type"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ROLLOVER_TYPE,
        slot_names=("rollover_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Direct (trustee-to-trustee) or indirect (60-day) rollover",
        examples=("direct", "indirect", "trustee-to-trustee"),
        allowed_values=ROLLOVER_TYPE_VALUES,
        aliases=("rollover method",),
    ),
    EntityTypeDef(
        entity_type=EntityType.BENEFICIARY_TYPE,
        slot_names=("beneficiary_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Type of beneficiary entity",
        examples=("individual", "trust", "charity"),
        allowed_values=BENEFICIARY_TYPE_VALUES,
        aliases=("type of beneficiary",),
    ),
    EntityTypeDef(
        entity_type=EntityType.BENEFICIARY_RELATION,
        slot_names=("beneficiary_relation",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Relationship of beneficiary to account holder",
        examples=("spouse", "child", "parent", "sibling"),
        allowed_values=BENEFICIARY_RELATION_VALUES,
        aliases=("relationship", "relation"),
    ),
    EntityTypeDef(
        entity_type=EntityType.ORDER_TYPE,
        slot_names=("order_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Buy or sell order direction",
        examples=("buy", "sell"),
        allowed_values=ORDER_TYPE_VALUES,
    ),
    EntityTypeDef(
        entity_type=EntityType.RISK_TOLERANCE,
        slot_names=("risk_tolerance",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Investor risk tolerance level",
        examples=("conservative", "moderate", "aggressive"),
        allowed_values=RISK_TOLERANCE_VALUES,
        aliases=("risk level", "risk profile"),
    ),
    EntityTypeDef(
        entity_type=EntityType.REBALANCE_FREQUENCY,
        slot_names=("rebalance_frequency",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="How often to automatically rebalance the portfolio",
        examples=("quarterly", "annually", "monthly"),
        allowed_values=REBALANCE_FREQUENCY_VALUES,
        aliases=("rebalance schedule",),
    ),
    EntityTypeDef(
        entity_type=EntityType.DELIVERY_METHOD,
        slot_names=(),
        parse_strategy=ParseStrategy.CATEGORY,
        description="How documents or statements should be delivered",
        examples=("mail", "electronic", "email"),
        allowed_values=DELIVERY_METHOD_VALUES,
    ),
    EntityTypeDef(
        entity_type=EntityType.WITHHOLDING_TYPE,
        slot_names=(),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Whether withholding applies to federal, state, or both",
        examples=("federal", "state", "both"),
        allowed_values=WITHHOLDING_TYPE_VALUES,
    ),
    EntityTypeDef(
        entity_type=EntityType.STATE,
        slot_names=(),
        parse_strategy=ParseStrategy.CATEGORY,
        description="US state (2-letter code)",
        examples=("CA", "NY", "TX", "FL"),
        allowed_values=US_STATE_CODES,
        aliases=("state of residence",),
    ),
    EntityTypeDef(
        entity_type=EntityType.INVESTMENT_PRODUCT,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Name or type of investment product",
        examples=("mutual fund", "ETF", "money market", "target-date fund"),
        aliases=("fund type", "product"),
    ),
)


# ==============================================================================
# Instrument / Fund Entity Definitions
# ==============================================================================

_INSTRUMENT_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.FUND_NAME,
        slot_names=("fund_name", "source_fund", "destination_fund"),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Mutual fund, ETF, or investment vehicle name",
        examples=("Vanguard 500 Index", "Fidelity Contrafund", "VTSAX"),
        aliases=("fund", "investment"),
    ),
    EntityTypeDef(
        entity_type=EntityType.TICKER_SYMBOL,
        slot_names=("ticker_symbol",),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Stock or ETF ticker symbol (1-5 uppercase letters)",
        examples=("AAPL", "VTSAX", "SPY", "BRK.B"),
        aliases=("ticker", "symbol", "stock"),
    ),
    EntityTypeDef(
        entity_type=EntityType.PORTFOLIO_ALLOCATION,
        slot_names=("portfolio_allocation",),
        parse_strategy=ParseStrategy.COMPOSITE,
        description="Target portfolio allocation as fund-to-percentage mapping",
        examples=("60% stocks / 40% bonds", "80% equities, 20% fixed income"),
        aliases=("allocation", "target mix"),
    ),
    EntityTypeDef(
        entity_type=EntityType.LOT_SELECTION_METHOD,
        slot_names=(),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Method for selecting tax lots when selling",
        examples=("FIFO", "LIFO", "specific lot", "highest cost"),
        allowed_values=("FIFO", "LIFO", "HIFO", "SPECIFIC_LOT", "AVG_COST"),
    ),
    EntityTypeDef(
        entity_type=EntityType.TRUST_NAME,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Legal name of a trust entity",
        examples=("The Smith Family Trust",),
        aliases=("trust",),
    ),
    EntityTypeDef(
        entity_type=EntityType.INVESTMENT_HORIZON,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Time horizon for investment goals",
        examples=("10 years", "until retirement", "short-term"),
        aliases=("time horizon", "investment period"),
    ),
    EntityTypeDef(
        entity_type=EntityType.COUNTRY,
        slot_names=(),
        parse_strategy=ParseStrategy.FREE_TEXT,
        description="Country name or ISO code",
        examples=("US", "United States"),
    ),
)


# ==============================================================================
# Slot-only entities (no dedicated EntityType enum — mapped via
# the generic types above, but need explicit slot registration)
# ==============================================================================

# These slots are satisfied by specific entity types already defined:
#   distribution_frequency  → CATEGORY (uses DISTRIBUTION_FREQUENCY_VALUES)
#   reinvest_option         → CATEGORY (uses REINVEST_OPTION_VALUES)
#   document_type           → CATEGORY (uses DOCUMENT_TYPE_VALUES)
#
# We define lightweight EntityTypeDefs that reference the existing
# EntityType enum but bind to specific slot names.

_SLOT_ALIAS_ENTITIES: tuple[EntityTypeDef, ...] = (
    EntityTypeDef(
        entity_type=EntityType.DISTRIBUTION_FREQUENCY,
        slot_names=("distribution_frequency",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="How often to distribute (monthly, quarterly, etc.)",
        examples=("monthly", "quarterly", "annually"),
        allowed_values=DISTRIBUTION_FREQUENCY_VALUES,
        aliases=("frequency", "schedule", "how often"),
    ),
    EntityTypeDef(
        entity_type=EntityType.DOCUMENT_TYPE,
        slot_names=("document_type",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Type of tax document requested (1099-R, 5498, etc.)",
        examples=("1099-R", "5498", "1099-DIV"),
        allowed_values=DOCUMENT_TYPE_VALUES,
        aliases=("form", "tax form", "document"),
    ),
    EntityTypeDef(
        entity_type=EntityType.REINVEST_OPTION,
        slot_names=("reinvest_option",),
        parse_strategy=ParseStrategy.CATEGORY,
        description="Whether dividends should be reinvested or paid as cash",
        examples=("reinvest", "cash", "pay me cash"),
        allowed_values=REINVEST_OPTION_VALUES,
        aliases=("dividend option",),
    ),
)


# ==============================================================================
# Master registry & indexes
# ==============================================================================

_ALL_DEFS: tuple[EntityTypeDef, ...] = (
    _PII_ENTITIES
    + _FINANCIAL_ENTITIES
    + _DATE_ENTITIES
    + _CATEGORICAL_ENTITIES
    + _INSTRUMENT_ENTITIES
    + _SLOT_ALIAS_ENTITIES
)

# EntityType → EntityTypeDef  (first registration wins)
ENTITY_TYPE_INDEX: dict[EntityType, EntityTypeDef] = {}
for _d in _ALL_DEFS:
    ENTITY_TYPE_INDEX.setdefault(_d.entity_type, _d)

# slot_name → EntityTypeDef  (enables O(1) lookup from taxonomy required_slots)
SLOT_TO_ENTITY: dict[str, EntityTypeDef] = {}
for _d in _ALL_DEFS:
    for _sn in _d.slot_names:
        SLOT_TO_ENTITY.setdefault(_sn, _d)

# All PII entity type defs (convenience subset)
PII_ENTITY_DEFS: tuple[EntityTypeDef, ...] = tuple(
    d for d in _ALL_DEFS if d.is_pii
)


# ==============================================================================
# Public helpers
# ==============================================================================

def lookup_entity_type(entity_type: EntityType) -> EntityTypeDef | None:
    """Return the ``EntityTypeDef`` for an ``EntityType`` enum, or ``None``."""
    return ENTITY_TYPE_INDEX.get(entity_type)


def lookup_slot(slot_name: str) -> EntityTypeDef | None:
    """
    Return the ``EntityTypeDef`` that satisfies a taxonomy slot name.

    Returns ``None`` if the slot has no registered entity type — which
    means extraction should fall back to free-text capture.
    """
    return SLOT_TO_ENTITY.get(slot_name)


def is_pii(entity_type: EntityType) -> bool:
    """Check if an ``EntityType`` is classified as PII."""
    return entity_type in PII_ENTITY_TYPES


def get_allowed_values(slot_name: str) -> tuple[str, ...]:
    """
    Return the allowed categorical values for a slot, or empty tuple if
    the slot is not categorical.
    """
    defn = SLOT_TO_ENTITY.get(slot_name)
    if defn is None or defn.parse_strategy != ParseStrategy.CATEGORY:
        return ()
    return defn.allowed_values


def all_entity_type_defs() -> list[EntityTypeDef]:
    """Return all registered ``EntityTypeDef`` instances (de-duplicated)."""
    seen: set[EntityType] = set()
    result: list[EntityTypeDef] = []
    for d in _ALL_DEFS:
        if d.entity_type not in seen:
            seen.add(d.entity_type)
            result.append(d)
    return result


def slot_names_covered() -> frozenset[str]:
    """Return the set of all taxonomy slot names that have a registered entity type."""
    return frozenset(SLOT_TO_ENTITY.keys())


# ==============================================================================
# Categorical value quick-reference maps (for normalisation)
# ==============================================================================

CATEGORICAL_SLOT_VALUES: dict[str, tuple[str, ...]] = {
    "plan_type":               PLAN_TYPE_VALUES,
    "account_type":            ACCOUNT_TYPE_VALUES,
    "distribution_type":       DISTRIBUTION_TYPE_VALUES,
    "rollover_type":           ROLLOVER_TYPE_VALUES,
    "beneficiary_type":        BENEFICIARY_TYPE_VALUES,
    "beneficiary_relation":    BENEFICIARY_RELATION_VALUES,
    "order_type":              ORDER_TYPE_VALUES,
    "risk_tolerance":          RISK_TOLERANCE_VALUES,
    "rebalance_frequency":     REBALANCE_FREQUENCY_VALUES,
    "distribution_frequency":  DISTRIBUTION_FREQUENCY_VALUES,
    "reinvest_option":         REINVEST_OPTION_VALUES,
    "document_type":           DOCUMENT_TYPE_VALUES,
    "withholding_percentage":  (),    # numeric, not categorical
    "statement_period":        (),    # free text date range
    "date_range":              (),    # free text date span
}
