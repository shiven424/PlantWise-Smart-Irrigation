"""Auth Agent v1 — handles identity verification via challenge-response.

Deterministic state machine. The LLM is NOT used here.

Flow per turn:
  1. Already verified at >= required_level AND verified_at within
     auth_reverify_ttl_seconds → VERIFIED.
  2. Expedited path (SOFT only): if user_profile shows recent verification
     within 24 h AND fraud signals are clean AND device matches → VERIFIED.
  3. Locked → return LOCKED + EscalationContext(AUTH_LOCKED).
  4. SESSION required → trivially VERIFIED.
  5. Pending challenge in scratch:
        - expired → FAILED (reason EXPIRED), drop pending so a fresh one is
          issued next turn; do NOT increment failed_attempts.
        - no user input → re-present (PENDING).
        - input → evaluate; on success VERIFIED, on failure FAILED, on
          exceeded retries LOCKED.
  6. No pending → issue a new challenge. For ONE_TIME_CODE the agent asks
     the OtpChannel to generate + (in prod) deliver a code; the hash + an
     expires_at are stored on the AuthChallenge. For other types, the
     expected hash comes from the AuthSecretsProvider, keyed by the
     server-trusted user_id. Missing secret → LOCKED + AUTH_MISCONFIGURED.

The agent reads the user's typed answer from `state["verification_input"]`
(set by main.py at turn start when an auth challenge is pending) and falls
back to message_history only if the last entry has role == "user".

Result is built as an `AuthAgentResponse` (so its model invariants run) and
then returned as a state dict the LangGraph reducers expect.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from agents.auth_agent.v1.evaluator import evaluate, hash_answer
from agents.auth_agent.v1.prompt import get_challenge_prompt
from agents.base import BaseAgent
from config import settings
from graph.state import GraphState
from observability.logger import log
from observability.tracer import trace_agent
from schemas.agent_io import AuthAgentResponse
from schemas.enums import (
    AuthLevel,
    AuthStatus,
    ChallengeType,
    EscalationReason,
)
from schemas.primitives import AuthChallenge, AuthState, EscalationContext


# Challenge types ordered by auth level requirement.
_CHALLENGE_FOR_LEVEL: dict[AuthLevel, ChallengeType] = {
    AuthLevel.SOFT: ChallengeType.ZIP_CODE,
    AuthLevel.STRONG: ChallengeType.LAST_4_SSN,
    AuthLevel.ENHANCED: ChallengeType.ONE_TIME_CODE,
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _to_dict(response: AuthAgentResponse, **extra: Any) -> dict[str, Any]:
    """Convert the typed response to the dict shape LangGraph callers expect."""
    out: dict[str, Any] = {
        "auth_state": response.updated_auth_state,
        "auth_status": response.status,
    }
    if response.escalation_context is not None:
        out["escalation_requested"] = True
        out["escalation_context"] = response.escalation_context
    out.update(extra)
    return out


class AuthAgent(BaseAgent):
    name = "auth_agent"
    version = "1.0.0"

    @trace_agent("auth_agent")
    def run(self, state: GraphState) -> dict:
        auth_state: AuthState = state.get("auth_state") or AuthState()
        required_level: AuthLevel = (
            state.get("required_auth_level") or AuthLevel.SESSION
        )
        session = state.get("session")
        session_id: str = str(session.session_id) if session else "unknown"
        user_id: str | None = getattr(session, "user_id", None) if session else None

        # 1) Already verified — but enforce re-verification TTL.
        if auth_state.current_level >= required_level and not auth_state.is_locked:
            if self._verification_still_fresh(auth_state):
                log.info(
                    "auth_already_verified",
                    current=auth_state.current_level.name,
                    required=required_level.name,
                    session_id=session_id,
                )
                return _to_dict(
                    AuthAgentResponse(
                        status=AuthStatus.VERIFIED,
                        updated_auth_state=AuthState(
                            current_level=auth_state.current_level,
                            is_locked=False,
                            failed_attempts=auth_state.failed_attempts,
                            last_challenge_type=auth_state.last_challenge_type,
                            verified_at=auth_state.verified_at or _now(),
                        ),
                    ),
                    verification_input=None,
                )
            log.info(
                "auth_reverify_ttl_expired",
                ttl_seconds=settings.auth_reverify_ttl_seconds,
                session_id=session_id,
            )
            # Fall through to issue a fresh challenge.

        # 2) Expedited path (SOFT only) gated on fraud + device.
        if (
            required_level == AuthLevel.SOFT
            and auth_state.current_level < required_level
            and self._expedited_eligible(state)
        ):
            log.info(
                "auth_expedited_from_profile",
                required=required_level.name,
                session_id=session_id,
            )
            return _to_dict(
                AuthAgentResponse(
                    status=AuthStatus.VERIFIED,
                    updated_auth_state=AuthState(
                        current_level=required_level,
                        is_locked=False,
                        failed_attempts=0,
                        verified_at=_now(),
                    ),
                ),
                verification_input=None,
            )

        # 3) Locked.
        if auth_state.is_locked:
            log.warning("auth_locked_reached_agent", session_id=session_id)
            return self._locked_result(
                auth_state, session_id, EscalationReason.AUTH_LOCKED
            )

        # 4) SESSION level needs no challenge.
        if required_level == AuthLevel.SESSION:
            return _to_dict(
                AuthAgentResponse(
                    status=AuthStatus.VERIFIED,
                    updated_auth_state=auth_state,
                ),
                verification_input=None,
            )

        challenge_type = _CHALLENGE_FOR_LEVEL.get(required_level)
        if challenge_type is None:
            log.error(
                "auth_unmapped_level",
                level=required_level.name,
                session_id=session_id,
            )
            raise ValueError(
                f"No challenge type mapping for AuthLevel.{required_level.name}. "
                f"Update _CHALLENGE_FOR_LEVEL in auth_agent."
            )

        # 5) Pending challenge?
        pending_challenge = self._get_pending_challenge(state)
        if pending_challenge:
            # Expiry check first — never count expired against the user.
            if self._challenge_expired(pending_challenge):
                log.info(
                    "auth_challenge_expired",
                    challenge_type=pending_challenge.challenge_type.value,
                    session_id=session_id,
                )
                return {
                    "auth_state": AuthState(
                        current_level=auth_state.current_level,
                        is_locked=False,
                        failed_attempts=auth_state.failed_attempts,
                        last_challenge_type=pending_challenge.challenge_type.value,
                    ),
                    "auth_status": AuthStatus.FAILED,
                    "scratch": {"pending_auth_challenge": {}},
                    "verification_input": None,
                }

            verification_input = self._extract_verification_input(state)
            if verification_input:
                return self._evaluate_response(
                    auth_state=auth_state,
                    pending_challenge=pending_challenge,
                    verification_input=verification_input,
                    required_level=required_level,
                    session_id=session_id,
                )
            log.info(
                "auth_challenge_re_presented",
                challenge_type=pending_challenge.challenge_type.value,
                session_id=session_id,
                reason="empty_verification_input",
            )
            return {
                "auth_state": auth_state,
                "auth_status": AuthStatus.PENDING,
                "scratch": {
                    "pending_auth_challenge": pending_challenge.model_dump(
                        mode="json"
                    )
                },
                "verification_input": None,
            }

        # 6) No pending → issue a new challenge.
        return self._issue_challenge(
            auth_state=auth_state,
            challenge_type=challenge_type,
            required_level=required_level,
            session_id=session_id,
            user_id=user_id,
        )

    # ----- helpers -----------------------------------------------------------

    def _verification_still_fresh(self, auth_state: AuthState) -> bool:
        if auth_state.verified_at is None:
            # No timestamp recorded — treat as fresh to preserve back-compat
            # for sessions that were verified before this field was tracked.
            return True
        ttl = settings.auth_reverify_ttl_seconds
        return (_now() - auth_state.verified_at).total_seconds() < ttl

    def _expedited_eligible(self, state: GraphState) -> bool:
        profile = state.get("user_profile") or {}
        last_verified = profile.get("last_verified_at")
        last_level = profile.get("last_verified_level")
        if not last_verified or not last_level:
            return False
        try:
            verified_dt = datetime.fromisoformat(last_verified)
        except (ValueError, TypeError):
            return False
        if (_now() - verified_dt).total_seconds() / 3600 > 24:
            return False
        try:
            if AuthLevel[last_level] < AuthLevel.SOFT:
                return False
        except KeyError:
            return False

        # Block when fraud risk is high.
        fraud = float(state.get("fraud_risk_score") or 0.0)
        if fraud >= settings.auth_fraud_block_threshold:
            log.info("auth_expedited_blocked_fraud", score=fraud)
            return False

        # Block when device fingerprint mismatches the profile's last device.
        cur_device = state.get("device_fingerprint")
        prof_device = profile.get("last_device_fingerprint")
        if cur_device and prof_device and cur_device != prof_device:
            log.info("auth_expedited_blocked_device_mismatch")
            return False
        return True

    def _challenge_expired(self, challenge: AuthChallenge) -> bool:
        if challenge.expires_at is None:
            return False
        return _now() >= challenge.expires_at

    def _extract_verification_input(self, state: GraphState) -> str:
        """Prefer the typed verification_input slot; fall back to history."""
        typed = state.get("verification_input")
        if isinstance(typed, str) and typed.strip():
            return typed.strip()
        history = state.get("message_history") or []
        if history:
            last = history[-1]
            if isinstance(last, dict) and last.get("role") == "user":
                return (last.get("content") or "").strip()
        return ""

    def _get_pending_challenge(
        self, state: GraphState
    ) -> AuthChallenge | None:
        scratch = state.get("scratch") or {}
        challenge_data = scratch.get("pending_auth_challenge")
        if isinstance(challenge_data, AuthChallenge):
            return challenge_data
        if challenge_data and isinstance(challenge_data, dict):
            try:
                return AuthChallenge(**challenge_data)
            except Exception as exc:
                log.warning(
                    "auth_challenge_deserialize_failed",
                    error=str(exc),
                    error_type=type(exc).__name__,
                    keys=list(challenge_data.keys()),
                )
        return None

    def _issue_challenge(
        self,
        auth_state: AuthState,
        challenge_type: ChallengeType,
        required_level: AuthLevel,
        session_id: str,
        user_id: str | None,
    ) -> dict:
        """Issue a new authentication challenge."""
        # Lazy import — avoids circular imports during module init.
        from auth.client import otp_channel, secrets_provider

        if not user_id:
            log.error(
                "auth_no_user_id",
                challenge_type=challenge_type.value,
                session_id=session_id,
            )
            return self._locked_result(
                auth_state, session_id, EscalationReason.AUTH_MISCONFIGURED
            )

        prompt_text = get_challenge_prompt(challenge_type.value)
        expected_hash = ""
        expires_at: datetime | None = None

        if challenge_type == ChallengeType.ONE_TIME_CODE:
            try:
                code, ttl = otp_channel().issue_otp(user_id, channel="sms")
            except Exception as exc:
                log.error(
                    "auth_otp_issue_failed",
                    error=str(exc),
                    session_id=session_id,
                )
                return self._locked_result(
                    auth_state, session_id, EscalationReason.AUTH_MISCONFIGURED
                )
            expected_hash = hash_answer(challenge_type.value, code)
            expires_at = _now() + timedelta(seconds=ttl)
        else:
            expected_hash = (
                secrets_provider().get_expected_hash(user_id, challenge_type) or ""
            )
            if not expected_hash:
                log.error(
                    "auth_misconfigured_no_expected_hash",
                    challenge_type=challenge_type.value,
                    user_id=user_id,
                    session_id=session_id,
                )
                return self._locked_result(
                    auth_state, session_id, EscalationReason.AUTH_MISCONFIGURED
                )

        challenge = AuthChallenge(
            challenge_type=challenge_type,
            prompt_text=prompt_text,
            expected_hash=expected_hash,
            max_attempts=settings.max_auth_retries,
            expires_at=expires_at,
        )

        log.info(
            "auth_challenge_issued",
            challenge_type=challenge_type.value,
            required_level=required_level.name,
            session_id=session_id,
        )

        return {
            "auth_state": AuthState(
                current_level=auth_state.current_level,
                is_locked=False,
                failed_attempts=auth_state.failed_attempts,
                last_challenge_type=challenge_type.value,
            ),
            "auth_status": AuthStatus.PENDING,
            "scratch": {
                "pending_auth_challenge": challenge.model_dump(mode="json"),
            },
            "verification_input": None,
        }

    def _evaluate_response(
        self,
        auth_state: AuthState,
        pending_challenge: AuthChallenge,
        verification_input: str,
        required_level: AuthLevel,
        session_id: str,
    ) -> dict:
        challenge_type = pending_challenge.challenge_type.value
        passed = evaluate(
            challenge_type=challenge_type,
            response=verification_input,
            session_id=session_id,
            expected_hash=pending_challenge.expected_hash,
        )

        if passed:
            log.info(
                "auth_challenge_passed",
                challenge_type=challenge_type,
                new_level=required_level.name,
                session_id=session_id,
            )
            return {
                "auth_state": AuthState(
                    current_level=required_level,
                    is_locked=False,
                    failed_attempts=0,
                    last_challenge_type=challenge_type,
                    verified_at=_now(),
                ),
                "auth_status": AuthStatus.VERIFIED,
                "scratch": {"pending_auth_challenge": {}},
                "verification_input": None,
            }

        new_failed = auth_state.failed_attempts + 1
        max_retries = settings.max_auth_retries
        if new_failed >= max_retries:
            log.warning(
                "auth_max_retries_reached",
                attempts=new_failed,
                max=max_retries,
                session_id=session_id,
            )
            return self._locked_result(
                AuthState(
                    current_level=auth_state.current_level,
                    is_locked=True,
                    failed_attempts=new_failed,
                    last_challenge_type=challenge_type,
                ),
                session_id,
                EscalationReason.AUTH_LOCKED,
            )

        log.info(
            "auth_challenge_failed",
            challenge_type=challenge_type,
            attempt=new_failed,
            max=max_retries,
            session_id=session_id,
        )
        return {
            "auth_state": AuthState(
                current_level=auth_state.current_level,
                is_locked=False,
                failed_attempts=new_failed,
                last_challenge_type=challenge_type,
            ),
            "auth_status": AuthStatus.FAILED,
            "scratch": {
                "pending_auth_challenge": pending_challenge.model_dump(mode="json"),
            },
            "verification_input": None,
        }

    def _locked_result(
        self,
        auth_state: AuthState,
        session_id: str,
        reason: EscalationReason,
    ) -> dict:
        locked_state = AuthState(
            current_level=auth_state.current_level,
            is_locked=True,
            failed_attempts=auth_state.failed_attempts,
            last_challenge_type=auth_state.last_challenge_type,
        )
        return {
            "auth_state": locked_state,
            "auth_status": AuthStatus.LOCKED,
            "escalation_requested": True,
            "escalation_context": EscalationContext(
                reason=reason,
                triggered_by="auth_agent",
            ),
            "scratch": {"pending_auth_challenge": {}},
            "verification_input": None,
        }

    def health_check(self) -> bool:
        for level in AuthLevel:
            if level == AuthLevel.SESSION:
                continue
            if level not in _CHALLENGE_FOR_LEVEL:
                log.error(
                    "auth_health_missing_mapping",
                    level=level.name,
                )
                return False
        return True
