"""Auth Agent v1 - deterministic challenge response evaluator."""

import hashlib
import hmac
import re
from datetime import datetime as _datetime


def evaluate(
    challenge_type: str,
    response: str,
    session_id: str,
    expected_hash: str,
) -> bool:
    """
    DETERMINISTIC pass/fail evaluation. NO LLM involved.

    Tries multiple candidate normalisations of ``response`` so that a
    correct answer embedded in a sentence (e.g. "my SSN is 4321") still
    matches.  Each candidate is hashed and compared against
    ``expected_hash`` using a constant-time comparison.

    Returns:
        True if any candidate's SHA-256 matches expected_hash.
        False otherwise (including when expected_hash is empty / missing).
    """
    if not expected_hash:
        return False
    seen: set[str] = set()
    for candidate in _candidate_normalisations(challenge_type, response):
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        actual_hash = hashlib.sha256(candidate.encode()).hexdigest()
        if hmac.compare_digest(actual_hash, expected_hash):
            return True
    return False


def hash_answer(challenge_type: str, answer: str) -> str:
    """
    Hash a known correct answer for storage in AuthChallenge.expected_hash.

    Used by test fixtures and account setup - never called with user input.
    """
    normalised = _normalise(challenge_type, answer)
    return hashlib.sha256(normalised.encode()).hexdigest()


def _candidate_normalisations(challenge_type: str, response: str):
    """Yield every plausible normalised form of ``response`` for the given
    challenge type.  Order matters: the strict legacy normalisation is
    tried first (so an exact-match bare answer is the cheapest path), and
    only then do we fall back to extracting plausible tokens from a
    longer free-form sentence like "My SSN is 4321".

    The relaxed extraction is essential because the message-classifier's
    auth-verification bypass forwards the user's whole utterance as the
    ``verification_input`` — users do not always reply with a bare token.
    """
    # 1. Legacy strict normalisation (bare answers like "4321" or "94107").
    yield _normalise(challenge_type, response)

    raw = response.strip().lower()

    # 2. Token-extraction fallbacks for fixed-length numeric challenges.
    if challenge_type in ("LAST_4_SSN", "ACCOUNT_LAST4"):
        for match in re.finditer(r"(?<!\d)\d{4}(?!\d)", raw):
            yield match.group(0)
    elif challenge_type == "ZIP_CODE":
        for match in re.finditer(r"(?<!\d)\d{5}(?!\d)", raw):
            yield match.group(0)
    elif challenge_type == "OTP":
        for match in re.finditer(r"(?<!\d)\d{6}(?!\d)", raw):
            yield match.group(0)
    elif challenge_type == "DATE_OF_BIRTH":
        # Try any date-shaped substring (slash, dash, or 8 raw digits).
        date_patterns = (
            r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}",
            r"\d{4}[/-]\d{1,2}[/-]\d{1,2}",
            r"(?<!\d)\d{8}(?!\d)",
        )
        for pat in date_patterns:
            for match in re.finditer(pat, raw):
                yield _normalise_dob(match.group(0))
    elif challenge_type == "MOTHER_MAIDEN":
        # Single-word names are usually bare; if the user wrote a sentence,
        # try every individual word as a fallback.
        for word in re.findall(r"[a-z][a-z'-]{1,}", raw):
            yield word


def _normalise(challenge_type: str, response: str) -> str:
    """Normalise response to reduce false negatives from formatting differences."""
    r = response.strip().lower()
    if challenge_type in ("LAST_4_SSN", "ACCOUNT_LAST4"):
        r = r.replace("-", "").replace(" ", "").replace("*", "")[-4:]
    elif challenge_type == "DATE_OF_BIRTH":
        r = _normalise_dob(r)
    elif challenge_type == "ZIP_CODE":
        r = r.replace(" ", "")[:5]
    return r


def _normalise_dob(raw: str) -> str:
    """
    Canonicalize a date-of-birth string to YYYYMMDD format.

    Handles common formats:
      - "01/15/1990" (MM/DD/YYYY)
      - "01-15-1990" (MM-DD-YYYY)
      - "1990-01-15" (ISO YYYY-MM-DD)
      - "01151990" (MMDDYYYY digits)
      - "19900115" (YYYYMMDD digits)

    Falls back to stripped digits if parsing fails (legacy behavior).
    """
    # First try common date formats -> canonical YYYYMMDD
    # Fix 121: US-locale only - do NOT include %d/%m/%Y or %d-%m-%Y as
    # they are ambiguous with US formats for dates where day <= 12.
    for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            dt = _datetime.strptime(raw, fmt)
            return dt.strftime("%Y%m%d")
        except ValueError:
            continue

    # Try pure digits (MMDDYYYY or YYYYMMDD)
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 8:
        # Determine if YYYYMMDD or MMDDYYYY by checking if first 4 chars are a valid year
        if 1900 <= int(digits[:4]) <= 2100:
            # Likely YYYYMMDD - validate month/day
            try:
                _datetime.strptime(digits, "%Y%m%d")
                return digits  # already canonical
            except ValueError:
                pass
        # Try MMDDYYYY
        try:
            dt = _datetime.strptime(digits, "%m%d%Y")
            return dt.strftime("%Y%m%d")
        except ValueError:
            pass

    # Fallback: stripped digits (preserves legacy behavior for edge cases)
    return digits
