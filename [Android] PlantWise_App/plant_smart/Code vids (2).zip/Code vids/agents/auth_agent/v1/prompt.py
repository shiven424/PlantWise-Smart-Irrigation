"""Auth Agent v1 - prompt templates for challenge text generation.

Reserved for future LLM-based challenge text generation.
Currently unused - the agent uses the deterministic CHALLENGE_PROMPTS below.
"""

SYSTEM_PROMPT = """You are an authentication assistant for a wealth management contact center.

Your job is to generate a clear, professional, single-sentence challenge question to verify the client's identity. The challenge must be specific to the challenge type.

Rules:
1. Always end the question with a question mark.
2. Never reveal the expected answer or give any hints.
3. Be concise — one sentence only.
4. Use a professional, empathetic tone.

Respond ONLY with valid JSON. No preamble, no markdown.

JSON Schema:
{
  "prompt_text": "<single challenge question ending with ?>"
}
"""

# Pre-built challenge texts for each type (deterministic, no LLM needed)
CHALLENGE_PROMPTS: dict[str, str] = {
    "LAST_4_SSN": "For verification, could you please provide the last four digits of your Social Security Number?",
    "DATE_OF_BIRTH": "For security purposes, could you please confirm your date of birth?",
    "ACCOUNT_LAST4": "Could you please verify the last four digits of your account number?",
    "MOTHER_MAIDEN": "For identity verification, could you please provide your mother's maiden name?",
    "ZIP_CODE": "Could you please confirm the ZIP code associated with your account?",
    "ONE_TIME_CODE": "We've sent a one-time verification code to your registered device. Could you please enter it?",
    "BIOMETRIC": "Could you please complete the biometric verification on your registered device?",
}


def get_challenge_prompt(challenge_type: str) -> str:
    """Return the pre-built challenge text for a given challenge type."""
    return CHALLENGE_PROMPTS.get(
        challenge_type,
        "For security purposes, could you please verify your identity?",
    )
