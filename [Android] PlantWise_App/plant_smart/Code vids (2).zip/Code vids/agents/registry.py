"""
Agent registry – the ONLY file you edit to swap an agent.

Change the version in config.py → registry picks it up automatically.
The graph builder reads exclusively from AGENT_REGISTRY.
"""

from __future__ import annotations

import importlib

from config import settings

_AGENT_CLASS_MAP: dict[str, str] = {
    "message_classifier":  "MessageClassifierAgent",
    "intent_agent":        "IntentAgent",
    "entity_extraction":   "EntityExtractionAgent",
    "rag_agent":           "RAGAgent",
    "auth_agent":          "AuthAgent",
    "entity_validator":    "EntityValidatorAgent",
    "supervisor":          "SupervisorAgent",
    "response_synthesizer": "ResponseSynthesizerAgent",
}


def _versioned_path(package: str, agent_name: str) -> str:
    """Build full dotted module path using configured version."""
    version = settings.agent_versions.get(agent_name)
    if version is None:
        import logging
        logging.getLogger("contact_center").warning(
            "[agent_registry] No version configured for agent '%s' "
            "in settings.agent_versions – defaulting to 'v1'.",
            agent_name,
        )
        version = "v1"
    return f"{package}.{version}.agent"


def _load_agent(agent_name: str, module_path: str):
    class_name = _AGENT_CLASS_MAP.get(agent_name)
    if not class_name:
        raise RuntimeError(
            f"No class name mapping for agent '{agent_name}' in _AGENT_CLASS_MAP. "
            f"Add '{agent_name}': 'YourClassName' before registering."
        )
    try:
        module = importlib.import_module(module_path)
    except (ModuleNotFoundError, ImportError) as e:
        raise RuntimeError(
            f"Cannot import agent '{agent_name}' from '{module_path}'.\n"
            f"  Verify the file exists and has no import errors.\n"
            f"  Error: {e}"
        ) from e
    try:
        cls = getattr(module, class_name)
    except AttributeError:
        raise RuntimeError(
            f"Module '{module_path}' has no class '{class_name}'.\n"
            f"  Expected: class {class_name}(BaseAgent)"
        )
    try:
        return cls()
    except Exception as e:
        raise RuntimeError(
            f"Cannot instantiate '{class_name}' from '{module_path}'.\n"
            f"  Error: {e}"
        ) from e


def _build_registry() -> dict:
    """
    Lazy registry builder.

    Attempts to load each agent from its configured module path.
    Every skip is logged at WARNING level so real bugs (syntax errors,
    bad imports) are visible in the build log and not silently hidden.
    """
    from observability.logger import log
    registry: dict = {}
    agent_paths = {
        "message_classifier":  _versioned_path("agents.message_classifier", "message_classifier"),
        "intent_agent":        _versioned_path("agents.intent_agent", "intent_agent"),
        "entity_extraction":   _versioned_path("agents.entity_extraction", "entity_extraction"),
        "rag_agent":           _versioned_path("agents.rag_agent", "rag_agent"),
        "auth_agent":          _versioned_path("agents.auth_agent", "auth_agent"),
        "entity_validator":    _versioned_path("agents.entity_validator", "entity_validator"),
        "supervisor":          _versioned_path("agents.supervisor", "supervisor"),
        # synthesizer lives at synthesizer/v1/agent.py – NOT under agents/
        "response_synthesizer": _versioned_path("synthesizer", "response_synthesizer"),
    }
    for agent_name, module_path in agent_paths.items():
        try:
            registry[agent_name] = _load_agent(agent_name, module_path)
        except RuntimeError as exc:
            log.warning(
                "agent_registry_skip",
                agent=agent_name,
                module=module_path,
                reason=str(exc).split("\n")[0],  # first line only
            )
    return registry


AGENT_REGISTRY: dict = _build_registry()
