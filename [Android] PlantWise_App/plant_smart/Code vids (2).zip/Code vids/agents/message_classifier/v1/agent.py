"""Message Classifier v1 – first node on every turn."""

from pydantic import BaseModel, Field

from agents.base import BaseAgent
from auth.predicates import is_auth_verification_turn
from graph.state import GraphState
from agents.message_classifier.v1.schema import MessageClassifierResponse
from agents.message_classifier.v1.prompt import SYSTEM_PROMPT, build_user_prompt
from schemas.enums import MessageDomain
from llm.client import call_llm
from config import settings
from observability.logger import log
from observability.tracer import trace_agent


# — Safety-critical distress keyword scan —
# Only UNAMBIGUOUS distress/self-harm phrases are kept as a pre-LLM safety net.
# These bypass the LLM entirely for zero-latency escalation on crisis signals.
#
# All other escalation categories (legal threats, financial advice requests,
# human-agent requests) are classified by the LLM, which considers full
# conversational context and avoids false positives (e.g. "courtesy" ≠ "court",
# "I can't go on vacation" ≠ distress).

# Distress keywords that are unambiguous — escalate immediately, no LLM check.
_DISTRESS_KEYWORDS_IMMEDIATE = [
    "kill myself", "suicide", "suicidal", "self harm",
    "want to die", "hurt myself",
]

# Distress keywords that are ambiguous — require LLM confirmation to avoid
# false positives (e.g. "can't go on vacation" or "end it all and start fresh").
_DISTRESS_KEYWORDS_AMBIGUOUS = [
    "can't go on", "end it all", "end my life",
    "no reason to live", "harm myself",
]

# Combined list for backward-compatible exports (used by tests)
_DISTRESS_KEYWORDS = _DISTRESS_KEYWORDS_IMMEDIATE + _DISTRESS_KEYWORDS_AMBIGUOUS


# — LLM distress confirmation —
_DISTRESS_CONFIRMATION_PROMPT = """You are a safety-critical classifier for a financial services contact center.

A keyword scan flagged the customer message below as a possible distress signal.
Your job: decide whether the customer is GENUINELY expressing emotional distress,
self-harm, or suicidal ideation — or whether the flagged phrase is a common
financial-context idiom or figure of speech.

Default to NOT genuine distress if the message ALSO contains any concrete
financial action, product, or topic (rollover, loan, withdrawal, premium,
premium payment, contribution, balance, beneficiary, RMD, IRA, 401k,
deposit, transfer, etc.). In that case the flagged phrase is almost
certainly metaphorical.

Only mark is_genuine_distress=true when the message expresses unambiguous
personal suffering, hopelessness about life, or intent to self-harm with NO
overriding financial action context.

Examples (NOT genuine distress — metaphorical):
  - "Let's end it all and start a clean rollover"             (action: rollover)
  - "I can't go on vacation until my loan funds"              (action: loan)
  - "My policy is going to die if I don't pay the premium"    (action: premium)
  - "I want to end my old 401k and open a new IRA"            (action: account close)

Examples (GENUINE distress):
  - "I just can't go on, nothing matters anymore"
  - "There's no reason to live"
  - "I want to end it all, I'm done"

Respond ONLY with valid JSON. No preamble, no markdown.

JSON Schema:
{
  "is_genuine_distress": true/false,
  "reasoning": "<brief explanation>"
}
"""


class _DistressConfirmation(BaseModel):
    """LLM response model for distress keyword confirmation."""
    is_genuine_distress: bool = True  # fail-safe default: treat as distress
    reasoning: str = ""


class _LLMClassifierRaw(BaseModel):
    """Permissive internal model for parsing LLM classification output.

    Fix C1: The public MessageClassifierResponse uses StrictBase
    (extra="forbid"). LLMs sometimes return extra JSON keys
    (e.g. "raw_reasoning", "model_version") which would cause
    a ValidationError and silently degrade to the fallback.
    This model uses the default extra="ignore" so unknown keys
    are silently dropped, then we map to the strict contract.
    """
    domain: MessageDomain = MessageDomain.INFORMATIONAL
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    escalation_flag: bool = False
    escalation_reason: str | None = None
    reasoning: str | None = None


class MessageClassifierAgent(BaseAgent):
    name = "message_classifier"
    version = "1.0.0"

    @trace_agent("message_classifier")
    def run(self, state: GraphState) -> dict:
        session = state.get("session")
        session_id = str(session.session_id) if session else "unknown"
        history = state.get("message_history", [])
        current_msg = history[-1].get("content", "") if history else ""

        # M9: Guard against empty messages — skip LLM call, default to
        # CHITCHAT so the synthesizer can prompt the user to continue.
        if not current_msg.strip():
            log.warning(
                "classifier_empty_message",
                session_id=session_id,
            )
            return {
                "message_domain": MessageDomain.CHITCHAT,
                "classifier_confidence": 1.0,
                "classifier_escalation_flag": False,
            }

        # Step 1: Safety-critical distress keyword scan (zero-latency path)
        if self._is_distress(current_msg):
            # For ambiguous distress phrases, ask the LLM before escalating
            if self._is_ambiguous_distress(current_msg):
                if not self._confirm_distress(current_msg):
                    log.info(
                        "distress_keyword_false_positive",
                        message_length=len(current_msg),
                        session_id=session_id,
                    )
                    # Fall through to normal LLM classification
                else:
                    return self._distress_result(state)
            else:
                return self._distress_result(state)

        # Step 1b: Auth-verification bypass.
        # When the previous turn issued a live auth challenge and the
        # current user input is its answer (typically a bare token like
        # "4321", a 6-digit OTP, or a ZIP), we MUST NOT route it through
        # the LLM classifier — the LLM can hallucinate an escalation
        # signal on short numeric inputs, which would let H1 short-circuit
        # the auth state machine.  Distress keywords were already checked
        # above so safety still wins over verification flow.
        if is_auth_verification_turn(state):
            log.info(
                "classifier_auth_bypass",
                session_id=session_id,
                message_length=len(current_msg),
            )
            return {
                "message_domain": MessageDomain.TRANSACTIONAL,
                "classifier_confidence": 1.0,
                "classifier_escalation_flag": False,
                "classifier_escalation_reason": None,
            }

        # Step 2: LLM classification
        response = self._llm_classify(current_msg, history[-6:])

        # Step 3: Confidence-based safety net
        # - ESCALATE / CHITCHAT: never override
        # - TRANSACTIONAL: only override at very low confidence
        # - Other domains: override below default threshold
        if response.domain not in (MessageDomain.ESCALATE, MessageDomain.CHITCHAT):
            if response.domain == MessageDomain.TRANSACTIONAL:
                threshold = settings.classifier_transactional_threshold
            else:
                threshold = settings.classifier_default_threshold

            if response.confidence < threshold:
                log.info(
                    "classifier_confidence_downgrade",
                    original_domain=response.domain.value,
                    confidence=response.confidence,
                    threshold=threshold,
                    session_id=session_id,
                )
                response.domain = MessageDomain.INFORMATIONAL

        return {
            "message_domain": response.domain,
            "classifier_confidence": response.confidence,
            "classifier_escalation_flag": response.escalation_flag,
            "classifier_escalation_reason": response.escalation_reason,
        }

    # — Distress helpers —

    @staticmethod
    def _is_distress(message: str) -> bool:
        """Return True if the message contains any distress keyword."""
        msg_lower = message.lower()
        return any(kw in msg_lower for kw in _DISTRESS_KEYWORDS)

    @staticmethod
    def _is_ambiguous_distress(message: str) -> bool:
        """Return True if the distress match was on an ambiguous phrase only."""
        msg_lower = message.lower()

        if any(kw in msg_lower for kw in _DISTRESS_KEYWORDS_IMMEDIATE):
            return False

        return True

    @staticmethod
    def _confirm_distress(message: str) -> bool:
        """Ask the LLM whether the message is genuinely distress. Fail-safe: True."""
        result = call_llm(
            system_prompt=_DISTRESS_CONFIRMATION_PROMPT,
            user_prompt=f"Customer message: \"{message}\"",
            response_model=_DistressConfirmation,
            fallback=_DistressConfirmation(
                is_genuine_distress=True,
                reasoning="llm_fallback_fail_safe",
            ),
            max_tokens=150,
        )
        return result.is_genuine_distress

    @staticmethod
    def _distress_result(state: GraphState) -> dict:
        """Build the escalation result for a confirmed distress signal."""
        session = state.get("session")
        log.warning(
            "escalation_keyword_detected",
            reason="distress_signal",
            session_id=str(session.session_id) if session else "unknown",
        )
        return {
            "message_domain": MessageDomain.ESCALATE,
            "classifier_confidence": 1.0,
            "classifier_escalation_flag": True,
            "classifier_escalation_reason": "distress_signal",
        }

    # — LLM classification —

    def _llm_classify(self, message: str, history: list[dict]) -> MessageClassifierResponse:
        # Fix C1: Use a permissive internal model for LLM parsing.
        fallback = _LLMClassifierRaw(
            domain=MessageDomain.INFORMATIONAL,
            confidence=0.50,
            reasoning="llm_fallback",
        )
        raw = call_llm(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=build_user_prompt(message, history),
            response_model=_LLMClassifierRaw,
            fallback=fallback,
        )
        result = MessageClassifierResponse(
            domain=raw.domain,
            confidence=raw.confidence,
            escalation_flag=raw.escalation_flag,
            escalation_reason=raw.escalation_reason,
            reasoning=raw.reasoning,
        )
        if result.reasoning == "llm_fallback":
            log.warning(
                "classifier_llm_fallback",
                message_length=len(message),
            )
        return result

    def health_check(self) -> bool:
        return bool(settings.anthropic_api_key or settings.openai_api_key)
    