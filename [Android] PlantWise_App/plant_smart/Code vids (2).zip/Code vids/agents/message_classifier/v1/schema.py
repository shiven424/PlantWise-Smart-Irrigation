"""Message Classifier v1 - schema re-exports.

The canonical request/response contracts live in schemas.agent_io.
This module re-exports them so version-local imports work consistently.
"""

from schemas.agent_io import MessageClassifierRequest, MessageClassifierResponse

__all__ = ["MessageClassifierRequest", "MessageClassifierResponse"]
