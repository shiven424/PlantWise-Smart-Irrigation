from __future__ import annotations

"""
Retirement-specific validation rules.

All rules reference IRS Internal Revenue Code (IRC) sections and are
enforced deterministically — no LLM involvement in the pass/fail decision.
"""

from datetime import date, timedelta
from typing import Optional

from agents.entity_validator.v1.rules.base_rule import BaseRule
from regulatory.irs_limits import IRS_LIMITS
from schemas.enums import ValidationSeverity
from schemas.primitives import ValidationViolation


def _get_owner_age(account_context: dict, default: float = 0.0) -> float:
    """Retrieve owner age from account_context.

    Checks ``owner_age_years`` first (tool convention), then falls
    back to ``owner_age`` (legacy / entity-validator tests).  Returns
    *default* when neither key is present.
    """
    raw = account_context.get("owner_age_years") or account_context.get("owner_age")
    if raw is not None:
        return float(raw)
    return default


# — Rule 1: IRC 72(p) Loan Limit ————————————————————————————————————————————

class IRC72PLoanLimitRule(BaseRule):
    """
    IRC Section 72(p)(2)(A) — Plan loan limit.

    Maximum loan = lesser of:
    | A) $50,000 minus the highest outstanding balance in the prior 12 months
    | B) 50% of the participant's vested account balance

    BLOCKING — client must reduce loan amount to proceed.
    """
    rule_id        = "IRS_72P_LOAN_LIMIT"
    regulatory_ref = "IRC Section 72(p)(2)(A)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        loan_entity = entities.get("loan_amount")
        if not loan_entity:
            return True, None

        vested_balance   = float(account_context.get("vested_balance", 0))
        outstanding_loans = float(account_context.get("outstanding_loan_balance", 0))
        prior_12mo_high   = float(account_context.get("highest_loan_balance_prior_12mo", outstanding_loans))

        # IRC 72(p)(2)(A)(i): $50K ceiling reduced by the EXCESS of the
        # highest 12-month outstanding balance OVER the current balance.
        excess    = max(0.0, prior_12mo_high - outstanding_loans)
        limit_a   = IRS_LIMITS["401K_LOAN_MAX"] - excess
        # IRC 72(p)(2)(A)(ii): 50% of vested balance, with $10K floor.
        limit_b   = max(vested_balance * 0.50, 10_000)
        max_permissible = max(0.0, min(limit_a, limit_b)) - outstanding_loans

        requested = _parse_dollars(loan_entity.display_value)

        if requested > max_permissible:
            return False, self._violation(
                violated_entity=str(loan_entity.entity_id),
                suggested_fix=f"${int(max_permissible):,}",
                correctable=True,
            )
        return True, None


# — Rule 2: IRC 72(p) Repayment Term ————————————————————————————————————————

class IRC72PRepaymentTermRule(BaseRule):
    """
    IRC Section 72(p)(2)(B) — Plan loan must be repaid within 5 years
    (60 months) unless used to acquire the participant's principal residence.

    BLOCKING — term must be reduced.
    """
    rule_id        = "IRS_72P_REPAYMENT_TERM"
    regulatory_ref = "IRC Section 72(p)(2)(B)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    MAX_TERM_GENERAL = 60   # months
    MAX_TERM_HOME    = 360  # months (30 years for home purchase)

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        term_entity = entities.get("repayment_term")
        if not term_entity:
            return True, None

        term_months = _safe_int(term_entity.display_value)
        if term_months <= 0:
            return False, self._violation(
                violated_entity=str(term_entity.entity_id),
                suggested_fix="Enter a numeric repayment term in months",
                correctable=True,
            )
        is_home_loan = account_context.get("loan_purpose", "").upper() == "PRIMARY_RESIDENCE"
        max_term     = self.MAX_TERM_HOME if is_home_loan else self.MAX_TERM_GENERAL

        if term_months > max_term:
            return False, self._violation(
                violated_entity=str(term_entity.entity_id),
                suggested_fix=str(max_term),
                correctable=True,
            )
        return True, None


# — Rule 3: IRC 72(t) Early Withdrawal Penalty —————————————————————————————

class IRC72TEarlyWithdrawalRule(BaseRule):
    """
    IRC Section 72(t)(1) — 10% additional tax on early distributions
    from qualified retirement plans if owner is under age 59½.

    WARNING (not BLOCKING) — client can acknowledge and proceed.
    Certain exemptions apply (disability, death, SEPP, medical, etc.)
    """
    rule_id        = "IRS_72T_EARLY_PENALTY"
    regulatory_ref = "IRC Section 72(t)(1)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.WARNING

    EARLY_EXEMPTIONS = {
        "DISABILITY", "DEATH", "SEPP", "MEDICAL", "HIGHER_EDUCATION",
        "FIRST_HOME", "IRS_LEVY", "MILITARY", "DISASTER",
    }

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        dist_type_entity = entities.get("distribution_type")
        if not dist_type_entity:
            return True, None

        owner_age = _get_owner_age(account_context, default=100.0)
        dist_type = (dist_type_entity.display_value or "").upper()

        if owner_age >= 59.5:
            return True, None  # no penalty

        if dist_type == "RMD":
            return True, None  # RMDs are never early withdrawals

        if dist_type in self.EARLY_EXEMPTIONS:
            return True, None  # exempt

        if dist_type in ("EARLY", "NORMAL", "HARDSHIP"):
            return False, self._violation(
                violated_entity=str(dist_type_entity.entity_id),
                correctable=False,
            )
        return True, None


# — Rule 4: IRC 401(a)(9) RMD Requirement ——————————————————————————————————

class RMDRequirementRule(BaseRule):
    """
    IRC Section 401(a)(9) + SECURE Act 2.0 — Required Minimum Distributions
    must begin by April 1 of the year following the year the participant
    reaches age 73 (changed from 72 by SECURE Act 2.0, effective 2023).

    Penalty: 25% excise tax on the shortfall (IRC Section 4974).
    Reduced to 10% if corrected within a 2-year window.

    INFORMATIONAL — advisory notice only.
    """
    rule_id        = "RMD_START_AGE"
    regulatory_ref = "IRC Section 401(a)(9); SECURE Act 2.0 Section 107"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.INFORMATIONAL

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        owner_age     = _get_owner_age(account_context)
        rmd_start_age = IRS_LIMITS["RMD_START_AGE"]

        if owner_age >= rmd_start_age:
            return False, self._violation(correctable=False)
        return True, None


# — Rule 5: IRC 402(g) 401(k) Contribution Limit ——————————————————————————

class IRC402GContributionLimitRule(BaseRule):
    """
    IRC Section 402(g) — Annual elective deferral limit.
    Age 50+ catch-up: additional $7,500 (IRC 414(v)).

    BLOCKING — contribution amount must be reduced.
    """
    rule_id        = "IRC_402G_CONTRIBUTION_LIMIT"
    regulatory_ref = "IRC Section 402(g); IRC Section 414(v)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        contrib_entity = entities.get("contribution_amount")
        if not contrib_entity:
            return True, None

        owner_age   = _get_owner_age(account_context)
        ytd_contrib = float(account_context.get("ytd_contributions", 0.0))

        base_limit = IRS_LIMITS["401K_CONTRIBUTION_LIMIT"]
        if 60 <= owner_age <= 63:
            catchup = IRS_LIMITS["401K_CATCHUP_LIMIT_60_63"]
        elif owner_age >= 50:
            catchup = IRS_LIMITS["401K_CATCHUP_LIMIT"]
        else:
            catchup = 0
        total_limit = base_limit + catchup
        remaining   = total_limit - ytd_contrib

        # Fix H2: Handle percentage-based contributions.
        # If the display_value contains "%", resolve against
        # annual_compensation from account_context.
        raw_value = (contrib_entity.display_value or "").strip()
        if "%" in raw_value:
            pct_str = raw_value.replace("%", "").strip()
            try:
                pct = float(pct_str)
            except (ValueError, AttributeError):
                pct = 0.0
            annual_comp = float(account_context.get("annual_compensation", 0.0))
            requested   = pct / 100.0 * annual_comp
        else:
            requested = _parse_dollars(raw_value)

        if requested > remaining:
            return False, self._violation(
                violated_entity=str(contrib_entity.entity_id),
                suggested_fix=f"${int(remaining):,}",
                correctable=True,
            )
        return True, None


# — Rule 6: IRA Rollover Once-Per-Year Rule ————————————————————————————————

class IRARolloverOncePerYearRule(BaseRule):
    """
    IRC Section 408(d)(3)(B) — An individual can make only ONE indirect
    (60-day) IRA-to-IRA rollover within any 12-month period.
    Direct (trustee-to-trustee) rollovers are NOT subject to this limit.

    BLOCKING for indirect rollovers when prior rollover is within 12 months.
    """
    rule_id        = "IRA_ROLLOVER_ONCE_PER_YEAR"
    regulatory_ref = "IRC Section 408(d)(3)(B); IRS Rev. Rul. 2014-9"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        rollover_type_entity = entities.get("rollover_type")
        if not rollover_type_entity:
            return True, None

        if (rollover_type_entity.display_value or "").upper() != "INDIRECT":
            return True, None  # rule only applies to indirect rollovers

        last_rollover_date = account_context.get("last_indirect_rollover_date")
        if not last_rollover_date:
            return True, None  # no prior rollover

        from datetime import datetime
        if isinstance(last_rollover_date, str):
            try:
                last_rollover_date = datetime.fromisoformat(last_rollover_date).date()
            except ValueError:
                # Unparseable date — BLOCK to prevent rule evasion.
                # A corrupted or malicious date must not silently bypass
                # the once-per-year IRA rollover restriction.
                return False, self._violation(
                    correctable=True,
                    suggested_fix=(
                        "Unable to verify prior rollover date. "
                        "Please contact a specialist to confirm eligibility."
                    ),
                )

        days_since = (current_date - last_rollover_date).days
        if days_since < 365:
            return False, self._violation(
                violated_entity=str(rollover_type_entity.entity_id),
                correctable=True,
                suggested_fix="DIRECT",    # switch to direct rollover — no limit
            )
        return True, None


# — Rule 7: 60-Day Rollover Deadline ———————————————————————————————————————

class RolloverSixtyDayRule(BaseRule):
    """
    IRC Section 402(c)(3) / 408(d)(3) — Indirect rollover must be completed
    within 60 days of receiving the distribution.

    BLOCKING — deadline cannot be extended (rare IRS waivers exist but are
    not handled by this system).
    """
    rule_id        = "ROLLOVER_60_DAY"
    regulatory_ref = "IRC Section 402(c)(3); IRC Section 408(d)(3)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        rollover_type_entity = entities.get("rollover_type")
        if not rollover_type_entity:
            return True, None
        if (rollover_type_entity.display_value or "").upper() != "INDIRECT":
            return True, None

        distribution_date = account_context.get("distribution_date")
        if not distribution_date:
            return True, None

        from datetime import datetime
        if isinstance(distribution_date, str):
            try:
                distribution_date = datetime.fromisoformat(distribution_date).date()
            except ValueError:
                # Unparseable date — BLOCK to prevent rule evasion.
                # A corrupted or malicious date must not silently bypass
                # the 60-day rollover deadline restriction.
                return False, self._violation(
                    correctable=False,
                    suggested_fix=(
                        "Unable to verify distribution date. "
                        "Please contact a specialist to confirm eligibility."
                    ),
                )

        # Reject future dates — a negative days_since would
        # incorrectly pass the > 60 check, bypassing the deadline.
        if distribution_date > current_date:
            return False, self._violation(
                correctable=False,
                suggested_fix="Distribution date cannot be in the future.",
            )

        days_since = (current_date - distribution_date).days

        if days_since > 60:
            return False, self._violation(
                correctable=False,
                suggested_fix="DIRECT rollover (no 60-day limit)",
            )
        return True, None


# — Rule 8: IRC 415(c) Total Annual Additions Limit ————————————————————————

class IRC415TotalLimitRule(BaseRule):
    """
    IRC Section 415(c) — Total annual additions to a defined contribution plan
    (employee + employer contributions) cannot exceed the lesser of:
    | A) $70,000 (2025), or
    | B) 100% of the participant's compensation

    BLOCKING.
    """
    rule_id        = "IRC_415_TOTAL_LIMIT"
    regulatory_ref = "IRC Section 415(c)"
    category       = "RETIREMENT"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        contrib_entity = entities.get("contribution_amount")
        if not contrib_entity:
            return True, None

        annual_compensation  = float(account_context.get("annual_compensation", 999_999))
        ytd_total_additions  = float(account_context.get("ytd_total_additions", 0.0))

        limit_a   = IRS_LIMITS["401K_TOTAL_LIMIT"]
        limit_b   = annual_compensation
        max_total = min(limit_a, limit_b)
        remaining = max_total - ytd_total_additions

        requested = _parse_dollars(contrib_entity.display_value)
        if requested > remaining:
            return False, self._violation(
                violated_entity=str(contrib_entity.entity_id),
                suggested_fix=f"${int(max(0, remaining)):,}",
                correctable=True,
            )
        return True, None


# — Utility ——————————————————————————————————————————————————————————————————

def _parse_dollars(value_str: str | None) -> float:
    """Parse '$20,000' or '20000' into a float.  Returns 0.0 on failure."""
    if not value_str:
        return 0.0
    try:
        return float(value_str.replace("$", "").replace(",", "").strip())
    except (ValueError, AttributeError):
        return 0.0


def _safe_int(value_str: str | None, default: int = 0) -> int:
    """Parse a display_value string into an int.  Returns *default* on failure.

    Strips common time-unit words so that LLM display values like "12 months",
    "5 years", or "60 mo" all parse correctly to their numeric component.
    """
    if not value_str:
        return default
    try:
        cleaned = value_str.lower()
        for unit in ("months", "month", "years", "year", "mo"):
            cleaned = cleaned.replace(unit, "")
        return int(float(cleaned.replace(",", "").strip()))
    except (ValueError, AttributeError):
        return default
