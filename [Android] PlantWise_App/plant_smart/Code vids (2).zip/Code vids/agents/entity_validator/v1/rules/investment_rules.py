from __future__ import annotations

"""
Investment-specific validation rules.

Rules reference SEC Regulation D, FINRA Rule 2111 (Suitability),
and SEC Regulation Best Interest (Reg BI).
"""

from typing import Optional

from agents.entity_validator.v1.rules.base_rule import BaseRule
from schemas.enums import ValidationSeverity
from schemas.primitives import ValidationViolation


class AccreditedInvestorRule(BaseRule):
    """
    SEC Regulation D — Certain investment products are restricted to
    accredited investors only (net worth > $1M excluding primary residence,
    OR annual income > $200k individual / $300k joint).

    BLOCKING — non-accredited investors cannot proceed with restricted products.
    """
    rule_id        = "SEC_ACCREDITED_INVESTOR"
    regulatory_ref = "SEC Regulation D, Rule 501(a)"
    category       = "INVESTMENT"
    severity       = ValidationSeverity.BLOCKING

    RESTRICTED_PRODUCTS = {
        "HEDGE_FUND", "PRIVATE_EQUITY", "PRIVATE_PLACEMENT",
        "REGULATION_D", "STRUCTURED_PRODUCT", "ALTERNATIVE_INVESTMENT",
    }

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        product_entity = entities.get("investment_product")
        if not product_entity:
            return True, None

        product = (product_entity.display_value or "").upper()
        if product not in self.RESTRICTED_PRODUCTS:
            return True, None

        is_accredited = account_context.get("is_accredited_investor", False)
        if not is_accredited:
            return False, self._violation(
                violated_entity=str(product_entity.entity_id),
                correctable=False,
            )
        return True, None


class ConcentrationRiskRule(BaseRule):
    """
    FINRA Rule 2111 (Suitability) — Single security concentration above 25%
    of total portfolio value triggers a suitability advisory.

    WARNING — advisory shown at HITL, client can acknowledge.
    """
    rule_id        = "FINRA_CONCENTRATION_RISK"
    regulatory_ref = "FINRA Rule 2111; SEC Reg BI"
    category       = "INVESTMENT"
    severity       = ValidationSeverity.WARNING

    MAX_SINGLE_CONCENTRATION = 0.25  # 25%

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        order_qty   = entities.get("order_quantity")
        order_price = entities.get("order_price")
        if not order_qty or not order_price:
            return True, None

        total_portfolio = float(account_context.get("total_portfolio_value", 0))
        if total_portfolio == 0:
            return True, None

        try:
            qty   = float((order_qty.display_value or "0").replace(",", ""))
            price = float((order_price.display_value or "0").replace("$", "").replace(",", ""))
        except (ValueError, AttributeError):
            return False, self._violation(
                violated_entity=str(order_qty.entity_id or order_price.entity_id),
                suggested_fix="Enter numeric values for order quantity and price",
                correctable=True,
            )
        order_value   = qty * price
        concentration = order_value / total_portfolio

        if concentration > self.MAX_SINGLE_CONCENTRATION:
            return False, self._violation(
                correctable=True,
                suggested_fix=f"Reduce to max ${total_portfolio * self.MAX_SINGLE_CONCENTRATION:.0f}",
            )
        return True, None


class SuitabilityCheckRule(BaseRule):
    """
    SEC Reg BI (Regulation Best Interest) + FINRA Rule 2111 —
    Investment recommendations must align with client's risk tolerance
    and investment horizon.

    WARNING — advisory. Triggers human review.
    """
    rule_id        = "REG_BI_SUITABILITY"
    regulatory_ref = "SEC Regulation Best Interest (Reg BI); FINRA Rule 2111"
    category       = "INVESTMENT"
    severity       = ValidationSeverity.WARNING

    RISK_PRODUCT_MAP = {
        "CONSERVATIVE": {"LOW", "BOND", "TREASURY", "CD", "MONEY_MARKET"},
        "MODERATE":     {"LOW", "MEDIUM", "BOND", "BALANCED", "INDEX"},
        "AGGRESSIVE":   {"LOW", "MEDIUM", "HIGH", "EQUITY", "GROWTH", "INTERNATIONAL"},
    }

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        risk_entity    = entities.get("risk_tolerance")
        product_entity = entities.get("investment_product")
        if not risk_entity or not product_entity:
            return True, None

        risk    = (risk_entity.display_value or "").upper()
        product = (product_entity.display_value or "").upper()
        allowed = self.RISK_PRODUCT_MAP.get(risk, set())

        if not any(keyword in product for keyword in allowed):
            return False, self._violation(
                violated_entity=str(product_entity.entity_id),
                correctable=True,
            )
        return True, None
