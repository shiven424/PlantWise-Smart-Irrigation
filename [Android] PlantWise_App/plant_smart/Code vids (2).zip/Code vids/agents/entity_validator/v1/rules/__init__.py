"""
Rule registry for the Entity Validator.

Exports:
 - ALL_RULES:        dict[str, BaseRule] - every instantiated rule by rule_id
 - INTENT_RULE_MAP:  dict[str, list[str]] - intent -> applicable rule IDs
 - get_rules_for_intent() - convenience lookup
"""

from agents.entity_validator.v1.rules.retirement_rules import (
    IRC72PLoanLimitRule,
    IRC72PRepaymentTermRule,
    IRC72TEarlyWithdrawalRule,
    RMDRequirementRule,
    IRC402GContributionLimitRule,
    IRARolloverOncePerYearRule,
    RolloverSixtyDayRule,
    IRC415TotalLimitRule,
)

from agents.entity_validator.v1.rules.investment_rules import (
    AccreditedInvestorRule,
    ConcentrationRiskRule,
    SuitabilityCheckRule,
)

from agents.entity_validator.v1.rules.estate_rules import (
    BeneficiaryPercentageRule,
    ERISASpousalConsentRule,
    TrustEINRule,
)

from agents.entity_validator.v1.rules.tax_rules import (
    WithholdingElectionRule,
    TaxAdviceDetectionRule,
    StateWithholdingRule,
)

# Intent -> applicable rule IDs mapping.
# Entity Validator uses the active intent to pick which rules to evaluate.
INTENT_RULE_MAP: dict[str, list[str]] = {
    "ACCOUNT_BALANCE_INQUIRY": [],  # Read-only inquiry: auth gate is sufficient; no entity rules needed
    "PLAN_LOAN_REQUEST": ["IRS_72P_LOAN_LIMIT", "IRS_72P_REPAYMENT_TERM"],
    "WITHDRAWAL_REQUEST": ["IRS_72T_EARLY_PENALTY", "IRC_3405_WITHHOLDING", "STATE_WITHHOLDING"],
    "HARDSHIP_WITHDRAWAL": ["IRS_72T_EARLY_PENALTY", "IRC_3405_WITHHOLDING"],
    "IRA_ROLLOVER": ["IRA_ROLLOVER_ONCE_PER_YEAR", "ROLLOVER_60_DAY", "IRC_3405_WITHHOLDING"],
    "ROTH_CONVERSION": ["IRC_3405_WITHHOLDING", "TAX_ADVICE_PROHIBITED"],
    "CONTRIBUTION_UPDATE": ["IRC_402G_CONTRIBUTION_LIMIT", "IRC_415_TOTAL_LIMIT"],
    "BENEFICIARY_UPDATE": ["BENEFICIARY_PERCENT_SUM", "ERISA_SPOUSAL_CONSENT", "TRUST_EIN_REQUIRED"],
    "BENEFICIARY_DESIGNATION": ["BENEFICIARY_PERCENT_SUM", "ERISA_SPOUSAL_CONSENT", "TRUST_EIN_REQUIRED"],
    "TRADE_REQUEST": ["SEC_ACCREDITED_INVESTOR", "FINRA_CONCENTRATION_RISK", "REG_BI_SUITABILITY"],
    "ALLOCATION_CHANGE": ["REG_BI_SUITABILITY"],
    "RMD_CALCULATION": ["RMD_START_AGE"],
    "RMD_SETUP": ["RMD_START_AGE", "IRC_3405_WITHHOLDING"],
    "WITHHOLDING_UPDATE": ["IRC_3405_WITHHOLDING", "STATE_WITHHOLDING"],
    "TRUST_DISTRIBUTION": ["IRC_3405_WITHHOLDING"],
    "TOD_UPDATE": ["BENEFICIARY_PERCENT_SUM"],
    "REBALANCING_REQUEST": ["REG_BI_SUITABILITY"],
    "FUND_SWITCH": ["REG_BI_SUITABILITY"],
    "RISK_PROFILE_UPDATE": ["REG_BI_SUITABILITY"],
    "DIVIDEND_REINVEST_UPDATE": [],
    "TAX_DOCUMENT_REQUEST": [],
    "ADDRESS_UPDATE": [],
    "PHONE_UPDATE": [],
    "EMAIL_UPDATE": [],
    "STATEMENT_REQUEST": [],
    "LINKED_BANK_UPDATE": [],
}

# All rule instances keyed by rule_id.
ALL_RULES: dict[str, object] = {
    "IRS_72P_LOAN_LIMIT": IRC72PLoanLimitRule(),
    "IRS_72P_REPAYMENT_TERM": IRC72PRepaymentTermRule(),
    "IRS_72T_EARLY_PENALTY": IRC72TEarlyWithdrawalRule(),
    "RMD_START_AGE": RMDRequirementRule(),
    "IRC_402G_CONTRIBUTION_LIMIT": IRC402GContributionLimitRule(),
    "IRA_ROLLOVER_ONCE_PER_YEAR": IRARolloverOncePerYearRule(),
    "ROLLOVER_60_DAY": RolloverSixtyDayRule(),
    "IRC_415_TOTAL_LIMIT": IRC415TotalLimitRule(),
    "SEC_ACCREDITED_INVESTOR": AccreditedInvestorRule(),
    "FINRA_CONCENTRATION_RISK": ConcentrationRiskRule(),
    "REG_BI_SUITABILITY": SuitabilityCheckRule(),
    "BENEFICIARY_PERCENT_SUM": BeneficiaryPercentageRule(),
    "ERISA_SPOUSAL_CONSENT": ERISASpousalConsentRule(),
    "TRUST_EIN_REQUIRED": TrustEINRule(),
    "IRC_3405_WITHHOLDING": WithholdingElectionRule(),
    "TAX_ADVICE_PROHIBITED": TaxAdviceDetectionRule(),
    "STATE_WITHHOLDING": StateWithholdingRule(),
}


def get_rules_for_intent(sub_intent: str) -> list:
    """Return instantiated rule objects for the given sub-intent.

    Returns an empty list for intents with no mapped rules
    (e.g. informational queries).
    """
    rule_ids = INTENT_RULE_MAP.get(sub_intent, [])
    return [ALL_RULES[rid] for rid in rule_ids if rid in ALL_RULES]
