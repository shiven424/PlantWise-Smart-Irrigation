from __future__ import annotations

"""
Tax-specific validation rules.

Rules reference IRC Section 3405 (withholding), IRS Circular 230,
FINRA Rule 2010, and state withholding requirements.
"""

from typing import Optional

from agents.entity_validator.v1.rules.base_rule import BaseRule
from schemas.enums import ValidationSeverity
from schemas.primitives import ValidationViolation


class WithholdingElectionRule(BaseRule):
    """
    IRC Section 3405(c) — Eligible rollover distributions are subject to
    mandatory 20% federal income tax withholding unless the distribution is
    paid directly to an eligible retirement plan (direct rollover).

    For non-periodic distributions: 10% default withholding (can be waived).

    WARNING — inform client before proceeding.
    """
    rule_id        = "IRC_3405_WITHHOLDING"
    regulatory_ref = "IRC Section 3405(c)"
    category       = "TAX"
    severity       = ValidationSeverity.WARNING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        dist_type_entity = entities.get("distribution_type")
        rollover_type    = entities.get("rollover_type")

        if not dist_type_entity:
            return True, None

        dist_type = (dist_type_entity.display_value or "").upper()
        if dist_type not in ("NORMAL", "EARLY", "HARDSHIP", "LUMP_SUM", "INSTALLMENT"):
            return True, None  # RMDs, SEPPs handled separately

        # Direct rollover — withholding does NOT apply
        if rollover_type and (rollover_type.display_value or "").upper() == "DIRECT":
            return True, None

        withholding_entity = entities.get("withholding_percent")
        if not withholding_entity:
            # No withholding election provided — notify client
            return False, self._violation(correctable=True, suggested_fix="20%")

        try:
            pct = float((withholding_entity.display_value or "").replace("%", "").strip())
        except (ValueError, AttributeError):
            return False, self._violation(
                violated_entity=str(withholding_entity.entity_id),
                suggested_fix="Enter a numeric withholding percentage",
                correctable=True,
            )
        if pct < 10.0:
            return False, self._violation(
                violated_entity=str(withholding_entity.entity_id),
                suggested_fix="10% minimum",
                correctable=True,
            )
        return True, None


class TaxAdviceDetectionRule(BaseRule):
    """
    Detects if the requested action constitutes personalised tax advice
    which this system is not permitted to provide.

    BLOCKING — must escalate to licensed tax professional.
    """
    rule_id        = "TAX_ADVICE_PROHIBITED"
    regulatory_ref = "IRS Circular 230; FINRA Rule 2010"
    category       = "TAX"
    severity       = ValidationSeverity.BLOCKING

    TAX_ADVICE_INTENTS = {
        "TAX_MINIMIZATION", "TAX_STRATEGY", "TAX_BRACKET_ADVICE",
        "ROTH_CONVERSION_ADVICE",
    }

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        intent_id = account_context.get("intent_id", "")
        for advice_intent in self.TAX_ADVICE_INTENTS:
            if advice_intent in intent_id.upper():
                return False, self._violation(correctable=False)
        return True, None


class StateWithholdingRule(BaseRule):
    """
    Many states require income tax withholding on retirement distributions.
    State-specific rates and opt-out rules vary.
    If the participant's state is known, flag if no state withholding election
    is present for mandatory-withholding states.

    WARNING — advisory.
    """
    rule_id        = "STATE_WITHHOLDING"
    regulatory_ref = "State-specific income tax withholding requirements"
    category       = "TAX"
    severity       = ValidationSeverity.WARNING

    # States with mandatory withholding on retirement distributions
    MANDATORY_STATES = {
        "CA", "CT", "DC", "DE", "GA", "IA", "IN", "KS", "KY",
        "MA", "ME", "MI", "MN", "MO", "NC", "NE", "NJ", "NY",
        "OH", "OR", "PA", "RI", "SC", "VA", "VT", "WI",
    }

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        state_entity = entities.get("state")
        dist_type    = entities.get("distribution_type")
        if not state_entity or not dist_type:
            return True, None

        state = (state_entity.display_value or "").upper().strip()[:2]
        if not state or state not in self.MANDATORY_STATES:
            return True, None

        state_withholding_elected = account_context.get("state_withholding_elected")
        if not state_withholding_elected:
            return False, self._violation(correctable=True)
        return True, None
