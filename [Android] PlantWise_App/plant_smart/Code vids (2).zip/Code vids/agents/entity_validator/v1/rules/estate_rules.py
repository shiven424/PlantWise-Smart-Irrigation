from __future__ import annotations

"""
Estate & Trust validation rules.

Rules reference ERISA Section 205, IRC Form 5500 reporting,
and IRS Section 645 (Trust EIN requirements).
"""

from typing import Optional

from agents.entity_validator.v1.rules.base_rule import BaseRule
from schemas.enums import ValidationSeverity
from schemas.primitives import ValidationViolation


class BeneficiaryPercentageRule(BaseRule):
    """
    All primary beneficiary percentages must sum to exactly 100%.
    All contingent beneficiary percentages (if any) must also sum to exactly 100%.

    BLOCKING.
    """
    rule_id        = "BENEFICIARY_PERCENT_SUM"
    regulatory_ref = "ERISA Section 205; IRS Form 5500 reporting requirements"
    category       = "ESTATE"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        primary_total   = 0.0
        contingent_total = 0.0
        has_contingent  = False

        # Fix H1: The primary/contingent designation class is a
        # different semantic axis from BENEFICIARY_TYPE (entity kind:
        # INDIVIDUAL/TRUST/CHARITY/ESTATE).  We use two strategies:
        #   1. Look for a BENEFICIARY_DESIGNATION entity whose display_value
        #      is "PRIMARY" or "CONTINGENT".
        #   2. Fall back to account_context["beneficiary_designation"] keyed
        #      by the slot suffix (e.g. "beneficiary_designation_1").
        #   3. Default to "PRIMARY" if no designation found.
        designation_by_slot: dict[str, str] = {}
        for _k, e in entities.items():
            if "designation" in (_k or "").lower():
                designation_by_slot[e.slot_name or _k or ""] = (e.display_value or "PRIMARY").upper()

        for key, entity in entities.items():
            if "beneficiary_percent" in key.lower() or entity.entity_type.value == "BENEFICIARY_PERCENTAGE":
                slot = entity.slot_name or key
                # Strategy 1: Correlated BENEFICIARY_DESIGNATION entity
                desig_slot = slot.replace("beneficiary_percentage", "beneficiary_designation")
                designation = designation_by_slot.get(desig_slot)
                if designation is None:
                    # Strategy 2: Key-based lookup
                    desig_key = key.replace("beneficiary_percentage", "beneficiary_designation")
                    desig_entity = entities.get(desig_key)
                    designation = (
                        (desig_entity.display_value or "PRIMARY").upper()
                        if desig_entity else None
                    )
                if designation is None:
                    # Strategy 3: account_context fallback
                    designation = (
                        account_context.get("beneficiary_designation", "PRIMARY")
                    ).upper()

                try:
                    pct = float((entity.display_value or "").replace("%", "").strip())
                except (ValueError, AttributeError):
                    pct = 0.0
                if designation == "CONTINGENT":
                    contingent_total += pct
                    has_contingent    = True
                else:
                    primary_total += pct

        if abs(primary_total - 100.0) > 0.01:
            return False, self._violation(
                suggested_fix="Primary beneficiary percentages must sum to 100%",
                correctable=True,
            )
        if has_contingent and abs(contingent_total - 100.0) > 0.01:
            return False, self._violation(
                suggested_fix="Contingent beneficiary percentages must sum to 100%",
                correctable=True,
            )

        return True, None


class ERISASpousalConsentRule(BaseRule):
    """
    ERISA Section 205 — For ERISA-covered plans (401k, 403b, 457b, pension),
    a married participant must obtain written spousal consent before naming
    a non-spouse as primary beneficiary.

    BLOCKING — cannot proceed without spousal consent on ERISA plans.
    """
    rule_id        = "ERISA_SPOUSAL_CONSENT"
    regulatory_ref = "ERISA Section 205; IRC Section 401(a)(11)"
    category       = "ESTATE"
    severity       = ValidationSeverity.BLOCKING

    ERISA_PLANS = {"401K", "403B", "457B", "PENSION", "PROFIT_SHARING"}

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        plan_type_entity = entities.get("plan_type")
        if not plan_type_entity:
            return True, None

        plan_type = (plan_type_entity.display_value or "").upper()
        if plan_type not in self.ERISA_PLANS:
            return True, None  # non-ERISA plan — no spousal consent required

        is_married               = account_context.get("marital_status", "").upper() == "MARRIED"
        spousal_consent_obtained = account_context.get("spousal_consent_obtained", False)
        bene_relation_entity     = entities.get("beneficiary_relation")

        if not is_married:
            return True, None  # not married — no consent needed

        if bene_relation_entity:
            relation = (bene_relation_entity.display_value or "").upper()
            if relation == "SPOUSE":
                return True, None  # naming spouse — no other consent needed

        if not spousal_consent_obtained:
            return False, self._violation(correctable=False)
        return True, None


class TrustEINRule(BaseRule):
    """
    A trust named as beneficiary must have a valid EIN (Employer Identification
    Number) on file before the designation can be processed.

    BLOCKING.
    """
    rule_id        = "TRUST_EIN_REQUIRED"
    regulatory_ref = "IRC Section 645; IRS Form SS-4 requirements"
    category       = "ESTATE"
    severity       = ValidationSeverity.BLOCKING

    def evaluate(self, entities, account_context, current_date) -> tuple[bool, Optional[ValidationViolation]]:
        bene_relation = entities.get("beneficiary_relation")
        if not bene_relation:
            return True, None
        if (bene_relation.display_value or "").upper() != "TRUST":
            return True, None

        trust_ein = account_context.get("trust_ein")
        if not trust_ein:
            return False, self._violation(
                violated_entity=str(bene_relation.entity_id),
                correctable=False,
                suggested_fix="Provide the Trust EIN (employer identification number).",
            )
        return True, None
