from __future__ import annotations

"""
Base class for all entity validation rules.

Every rule subclass must define:
  - rule_id:        str   (matches key in ALL_RULES registry)
  - regulatory_ref: str   (citation for audit trail)
  - category:       str   ("RETIREMENT", "INVESTMENT", "ESTATE", "TAX")
  - severity:       ValidationSeverity
  - evaluate()      method
"""

from abc import ABC, abstractmethod
from datetime import date
from typing import Optional

from schemas.enums import ValidationSeverity
from schemas.primitives import HITLDisclosureItem, ValidationViolation


class BaseRule(ABC):
    rule_id:        str
    regulatory_ref: str
    category:       str
    severity:       ValidationSeverity

    @abstractmethod
    def evaluate(
        self,
        entities: dict,
        account_context: dict,
        current_date: date,
    ) -> tuple[bool, Optional[ValidationViolation]]:
        """
        Evaluate this rule against the provided entities and account context.

        Returns:
            (passed, violation)
            If passed=True  -> violation must be None.
            If passed=False -> violation must be populated.
            The violation.customer_message is left empty here —
            the LLM fills it in entity_validator/agent.py.
        """
        ...

    def _disclosure(
        self,
        disclosure_id: str,
        text: str,
        category: str = "",
    ) -> HITLDisclosureItem:
        return HITLDisclosureItem(
            disclosure_id=disclosure_id,
            category=category or self.category,
            display_text=text,
        )

    def _violation(
        self,
        violated_entity: str = "",
        suggested_fix: str = "",
        correctable: bool = False,
    ) -> ValidationViolation:
        return ValidationViolation(
            rule_id=self.rule_id,
            regulatory_ref=self.regulatory_ref,
            severity=self.severity,
            category=self.category,
            violated_entity=violated_entity or None,
            customer_message="",        # filled by LLM in entity_validator/agent.py
            suggested_fix=suggested_fix or None,
            correctable=correctable,
        )
