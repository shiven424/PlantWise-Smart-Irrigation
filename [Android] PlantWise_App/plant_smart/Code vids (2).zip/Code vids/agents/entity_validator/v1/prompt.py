"""Entity Validator v1 — LLM prompts for customer-facing violation messages.

The Entity Validator is deterministic: rules decide pass/fail.
The LLM is only used here to convert dry regulatory references into
short, empathetic customer-facing text.
"""

from __future__ import annotations

from schemas.primitives import EntityRecord, ValidationViolation


VIOLATION_MSG_SYSTEM_PROMPT = (
    "You are a compliance message writer for a retirement and investment "
    "contact center. Given a regulatory rule violation, produce a SHORT, "
    "clear, empathetic customer-facing message (1-2 sentences, max ~250 "
    "characters).\n\n"
    "REQUIREMENTS:\n"
    "  - State WHAT field/amount/value is the problem (e.g. 'loan amount', "
    "'repayment term', 'beneficiary percentages', 'withholding rate').\n"
    "  - If a `Suggested fix` is provided, state it explicitly in the "
    "message (the dollar value, the percent, the action like 'switch to a "
    "direct rollover').\n"
    "  - Use the rule context hints to ground your wording: prefer concrete "
    "domain terms (e.g. 'loan limit', '60-day window', 'concentration', "
    "'penalty', 'accredited investor', 'Trust EIN', 'state withholding').\n\n"
    "FORBIDDEN:\n"
    "  - Do NOT mention internal rule IDs, IRC / ERISA / FINRA / SEC section "
    "numbers, regulatory citations, or the literal word 'regulatory'. Speak "
    "in plain terms.\n"
    "  - Do NOT give legal or tax advice — just describe the issue and the fix.\n"
    "  - No JSON, no quotes, no preamble. Output the message text ONLY."
)


# Concrete topic hints per rule, keyed by rule_id. These are appended to the
# user prompt so the LLM does not have to guess which financial concept the
# rule covers.
_RULE_TOPIC_HINTS: dict[str, str] = {
    "IRS_72P_LOAN_LIMIT":
        "This is the 401(k) loan limit. The requested loan amount is too "
        "high. Tell the customer the loan amount exceeds what is allowed and "
        "offer the suggested reduced amount.",
    "IRS_72P_REPAYMENT_TERM":
        "This is the loan repayment term limit (5 years / 60 months for "
        "general loans). Tell the customer the repayment term is too long "
        "and suggest a shorter term in months/years.",
    "IRS_72T_EARLY_PENALTY":
        "This is the 10% early-withdrawal additional tax that applies to "
        "distributions taken before age 59½. Mention the 10% penalty and "
        "the 59½ age threshold.",
    "RMD_START_AGE":
        "This is a Required Minimum Distribution (RMD) reminder. Inform the "
        "customer they have reached the age where RMDs must begin.",
    "IRC_402G_CONTRIBUTION_LIMIT":
        "This is the annual elective deferral (contribution) limit. The "
        "customer's contribution exceeds the annual limit; suggest reducing "
        "to the remaining allowed amount.",
    "IRA_ROLLOVER_ONCE_PER_YEAR":
        "This is the once-per-12-months indirect IRA rollover restriction. "
        "Tell the customer they can only do one indirect rollover per "
        "12-month period and suggest switching to a direct rollover.",
    "ROLLOVER_60_DAY":
        "This is the 60-day rollover deadline. Tell the customer the 60-day "
        "window to complete the indirect rollover has passed.",
    "IRC_415_TOTAL_LIMIT":
        "This is the total annual contributions cap (employee + employer). "
        "The total exceeds the annual limit; suggest the reduced amount.",
    "SEC_ACCREDITED_INVESTOR":
        "This product is restricted to accredited / qualified investors. "
        "Tell the customer they are not currently eligible for this product.",
    "FINRA_CONCENTRATION_RISK":
        "This is a portfolio concentration warning — a single position would "
        "exceed 25% of the portfolio. Mention concentration / "
        "diversification.",
    "REG_BI_SUITABILITY":
        "This is a suitability mismatch between the customer's risk profile "
        "and the chosen product. Mention suitability or risk profile.",
    "BENEFICIARY_PERCENT_SUM":
        "Beneficiary percentages must add up to exactly 100%. Tell the "
        "customer their beneficiary allocation does not total 100%.",
    "ERISA_SPOUSAL_CONSENT":
        "Spousal consent is required to name a non-spouse as primary "
        "beneficiary on this plan. Tell the customer spousal consent is "
        "needed.",
    "TRUST_EIN_REQUIRED":
        "A Trust EIN (tax identification number) is required when naming a "
        "trust as beneficiary. Ask the customer to provide the trust's EIN.",
    "IRC_3405_WITHHOLDING":
        "This is a federal tax withholding election issue. Tell the customer "
        "the withholding amount is below the 10% minimum (or missing).",
    "TAX_ADVICE_PROHIBITED":
        "We cannot provide personalised tax advice. Tell the customer their "
        "request requires a licensed tax professional.",
    "STATE_WITHHOLDING":
        "The customer's state requires a state income-tax withholding "
        "election. Tell them a state withholding election is needed.",
}


def build_violation_msg_user_prompt(
    violation: ValidationViolation,
    entity: EntityRecord | None = None,
) -> str:
    """Build the user-prompt sent to the LLM for a single violation.

    *entity* is the offending EntityRecord (when the rule pointed at one),
    used only to surface its slot name and display value to the LLM so the
    response can name the field rather than say "your account".
    """
    parts = [
        f"Severity: {violation.severity.value}",
        f"Category: {violation.category}",
    ]
    topic = _RULE_TOPIC_HINTS.get(violation.rule_id)
    if topic:
        parts.append(f"Topic: {topic}")
    if entity is not None:
        if entity.slot_name:
            parts.append(f"Affected field: {entity.slot_name}")
        if entity.display_value:
            parts.append(f"Customer-provided value: {entity.display_value}")
    if violation.suggested_fix:
        parts.append(
            f"Suggested fix (mention this in your message): "
            f"{violation.suggested_fix}"
        )
    if violation.correctable:
        parts.append("This is correctable by the customer.")
    else:
        parts.append(
            "This cannot be corrected by the customer and may require escalation."
        )
    return "\n".join(parts)
