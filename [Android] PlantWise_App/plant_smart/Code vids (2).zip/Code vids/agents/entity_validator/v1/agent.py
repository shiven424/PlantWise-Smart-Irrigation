"""Entity Validator v1 — deterministic rule evaluation with LLM-generated messages.

This agent is PURE PYTHON for all pass/fail decisions — the LLM is only
invoked to produce customer-friendly text on violations.  Every regulatory
rule is implemented as a ``BaseRule`` subclass and stored in the rule
registry (``rules/__init__.py``).

Write-ownership:
    validation_status, violations, validated_entities, hitl_disclosures, slot_gap
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from agents.base import BaseAgent
from agents.entity_validator.v1.prompt import (
    VIOLATION_MSG_SYSTEM_PROMPT,
    build_violation_msg_user_prompt,
)
from agents.entity_validator.v1.rules import ALL_RULES, get_rules_for_intent
from config import settings
from graph.state import GraphState, compute_slot_gap, get_active_intent
from llm.client import call_llm_text
from observability.logger import log
from observability.tracer import trace_agent
from schemas.enums import ValidationSeverity, ValidationStatus
from schemas.primitives import (
    EntityRecord,
    HITLDisclosureItem,
    ValidationViolation,
)


class EntityValidatorAgent(BaseAgent):
    name    = "entity_validator"
    version = "1.0.0"

    # — Main entry point ——————————————————————————————————————————————————————

    @trace_agent("entity_validator")
    def run(self, state: GraphState) -> dict:
        session        = state.get("session")
        session_id     = str(session.session_id) if session else "unknown"
        current_turn: int = state.get("current_turn", 0)
        entities: dict[str, EntityRecord] = dict(state.get("entity_memory", {}))
        account_ctx: dict = state.get("account_context", {})

        # Resolve active intent → pick applicable rules
        active_intent = get_active_intent(state)
        if not active_intent:
            log.warning("entity_validator_no_intent", session_id=session_id)
            # M3: Without an active intent we cannot determine which rules
            # apply.  Mark validation INCOMPLETE so the action planner
            # re-routes through slot collection / clarification instead of
            # letting unvalidated entities flow through to tools.
            return {
                "validation_status": ValidationStatus.INCOMPLETE,
                "violations": [],
                "validated_entities": entities,
                "hitl_disclosures": [],
                "slot_gap": [],
            }

        sub_intent = active_intent.sub_intent
        rules      = get_rules_for_intent(sub_intent)

        if not rules:
            log.info(
                "entity_validator_no_rules",
                sub_intent=sub_intent,
                session_id=session_id,
            )
            return self._pass_all(entities, state)

        # Inject intent_id for rules that reference it (e.g. TaxAdviceDetection)
        ctx   = {**account_ctx, "intent_id": sub_intent}
        today = datetime.now(timezone.utc).date()

        # — Evaluate every applicable rule ————————————————————————————————————
        violations: list[ValidationViolation]  = []
        disclosures: list[HITLDisclosureItem]  = []

        for rule in rules:
            passed, violation = rule.evaluate(entities, ctx, today)
            if passed or violation is None:
                continue

            # Generate customer-facing message via LLM
            violation = self._fill_customer_message(violation, entities, session_id)
            violations.append(violation)

            # WARNING / INFORMATIONAL violations → HITL disclosure
            if rule.severity in (
                ValidationSeverity.WARNING,
                ValidationSeverity.INFORMATIONAL,
            ):
                disclosures.append(
                    HITLDisclosureItem(
                        disclosure_id=f"DISC_{rule.rule_id}_{current_turn}",
                        category=rule.category,
                        display_text=violation.customer_message,
                        requires_ack=rule.severity == ValidationSeverity.WARNING,
                    )
                )

            log.info(
                "entity_validator_violation",
                rule_id=rule.rule_id,
                severity=rule.severity.value,
                session_id=session_id,
            )

        # — Determine overall validation status ———————————————————————————————
        has_blocking = any(
            v.severity == ValidationSeverity.BLOCKING for v in violations
        )
        has_warning = any(
            v.severity == ValidationSeverity.WARNING for v in violations
        )
        slot_gap = compute_slot_gap(state)

        if has_blocking:
            status = ValidationStatus.FAILED
        elif slot_gap:
            status = ValidationStatus.INCOMPLETE
        elif has_warning:
            status = ValidationStatus.WARNING
        else:
            status = ValidationStatus.PASSED

        # — Build validated_entities ——————————————————————————————————————————
        # Entities referenced by a BLOCKING violation are excluded.
        blocked_entity_ids = {
            v.violated_entity
            for v in violations
            if v.severity == ValidationSeverity.BLOCKING and v.violated_entity
        }
        validated: dict[str, EntityRecord] = {
            key: entity
            for key, entity in entities.items()
            if str(entity.entity_id) not in blocked_entity_ids
        }

        log.info(
            "entity_validator_complete",
            status=status.value,
            violation_count=len(violations),
            validated_count=len(validated),
            session_id=session_id,
        )

        return {
            "validation_status": status,
            "violations": violations,
            "validated_entities": validated,
            "hitl_disclosures": disclosures,
            "slot_gap": slot_gap,
        }

    # — Helpers ———————————————————————————————————————————————————————————————

    def _pass_all(self, entities: dict[str, EntityRecord], state: GraphState) -> dict:
        """Shortcut: PASSED with all entities validated (no rules fired)."""
        return {
            "validation_status": ValidationStatus.PASSED,
            "violations": [],
            "validated_entities": dict(entities),
            "hitl_disclosures": [],
            "slot_gap": compute_slot_gap(state),
        }

    def _fill_customer_message(
        self,
        violation: ValidationViolation,
        entities: dict[str, EntityRecord],
        session_id: str,
    ) -> ValidationViolation:
        """Use LLM to generate a customer-friendly customer_message."""
        # Resolve the violated entity (if any) so the LLM can mention
        # the actual slot name and value rather than an opaque UUID.
        ctx_entity = None
        if violation.violated_entity:
            for rec in entities.values():
                if str(rec.entity_id) == violation.violated_entity:
                    ctx_entity = rec
                    break
        fallback = self._static_fallback(violation)
        try:
            msg = call_llm_text(
                system_prompt=VIOLATION_MSG_SYSTEM_PROMPT,
                user_prompt=build_violation_msg_user_prompt(violation, ctx_entity),
                fallback=fallback,
                max_tokens=200,
            ).strip()
            if not msg:
                msg = fallback
        except Exception:
            log.warning(
                "entity_validator_llm_fallback",
                rule_id=violation.rule_id,
                session_id=session_id,
            )
            msg = fallback

        return violation.model_copy(update={"customer_message": msg})

    @staticmethod
    def _static_fallback(v: ValidationViolation) -> str:
        """Deterministic fallback when LLM is unavailable."""
        base = f"Regulatory requirement {v.regulatory_ref} applies."
        if v.suggested_fix:
            base += f" Suggested action: {v.suggested_fix}."
        return base

    def health_check(self) -> bool:
        return len(ALL_RULES) > 0
