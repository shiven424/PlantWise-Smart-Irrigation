"""
Boot-time health check for agent and tool registries.
Call validate_registry() in main.py BEFORE graph.compile().
"""

from __future__ import annotations

import threading

HEALTH_CHECK_TIMEOUT_SECONDS = 10


class _HealthCheckTimeout(Exception):
    pass


def _run_with_timeout(fn, timeout_seconds: int):
    """Run fn() in a thread; raise _HealthCheckTimeout if it exceeds the limit."""
    result_box: list = []
    error_box: list = []

    def _target():
        try:
            result_box.append(fn())
        except Exception as e:
            error_box.append(e)

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join(timeout=timeout_seconds)

    if t.is_alive():
        raise _HealthCheckTimeout(
            f"health_check() timed out after {timeout_seconds}s. "
            f"Remove blocking calls from health_check()."
        )
    if error_box:
        raise error_box[0]
    return result_box[0] if result_box else None


def validate_registry(registry: dict, registry_name: str = "Agent") -> None:
    """
    Validates every entry in a registry and fails fast if anything is wrong.

    Checks (in order):
      1. Inherits BaseAgent or BaseTool
      2. name attribute is a non-empty string
      3. version attribute is a non-empty string
      4. agent.name matches the registry key
      5. run() is callable
      6. health_check() is callable
      7. health_check() returns True within HEALTH_CHECK_TIMEOUT_SECONDS
    """
    print(f"\n{'=' * 55}")
    print(f"  {registry_name} Registry Validation  ({len(registry)} entries)")
    print(f"{'=' * 55}")
    errors: list[tuple[str, Exception]] = []

    for registry_key, agent in registry.items():
        try:
            from agents.base import BaseAgent as _Base
            try:
                from tools.base import BaseTool as _SubBase
                valid_bases = (_Base, _SubBase)
            except ImportError:
                valid_bases = (_Base,)

            if not isinstance(agent, valid_bases):
                raise TypeError(f"Must inherit BaseAgent or BaseTool. Got {type(agent)}")

            if not hasattr(agent, "name") or not isinstance(agent.name, str) or not agent.name:
                raise AttributeError(
                    f"Missing or empty 'name'. Add: name = '{registry_key}' to class."
                )

            if not hasattr(agent, "version") or not isinstance(agent.version, str) or not agent.version:
                raise AttributeError("Missing or empty 'version'. Add: version = '1.0.0'")

            if agent.name != registry_key:
                raise ValueError(
                    f"agent.name={agent.name!r} does not match registry_key={registry_key!r}. "
                    f"Fix: set name = '{registry_key}' in the class."
                )

            if not callable(getattr(agent, "run", None)):
                raise AttributeError("run() missing or not callable.")
            if not callable(getattr(agent, "health_check", None)):
                raise AttributeError("health_check() missing or not callable.")

            try:
                healthy = _run_with_timeout(agent.health_check, HEALTH_CHECK_TIMEOUT_SECONDS)
            except _HealthCheckTimeout as e:
                raise TimeoutError(str(e)) from e
            except Exception as e:
                raise RuntimeError(f"health_check() raised: {e}") from e

            if healthy is not True:
                raise RuntimeError(f"health_check() returned {healthy!r}, expected True.")

            print(f"  + {registry_key:<35} v{agent.version}")

        except Exception as e:
            errors.append((registry_key, e))
            print(f"  X {registry_key:<35} FAILED: {e}")

    print(f"{'=' * 55}")
    if errors:
        print(f"\n  {len(errors)} failure(s):")
        for key, err in errors:
            print(f"    [{key}] {err}")
        raise RuntimeError(
            f"{registry_name} registry validation failed with {len(errors)} error(s)."
        )
    print(f"  All {len(registry)} {registry_name.lower()}(s) healthy.\n")
