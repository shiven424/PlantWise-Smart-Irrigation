from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar


class BaseAgent(ABC):
    """
    Every agent MUST inherit from this class.

    Contract:
    - run()          -> takes full GraphState dict, returns PARTIAL state dict
    - health_check() -> called at boot; must return True within 10 seconds
    - name           -> CLASS-LEVEL str, must match registry key exactly
    - version        -> CLASS-LEVEL semver string e.g. "1.0.0"

    __init_subclass__ enforces name/version at CLASS DEFINITION TIME.
    A concrete class missing either attribute raises TypeError immediately
    when Python imports the module.
    """

    name:    ClassVar[str]
    version: ClassVar[str]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        # Skip check for abstract classes – detect by scanning for @abstractmethod
        # in the class's own dict (since ABCMeta hasn't set __abstractmethods__ yet)
        has_abstract = any(
            getattr(v, "__isabstractmethod__", False)
            for v in vars(cls).values()
        ) or getattr(cls, "__abstractmethods__", None)
        if has_abstract:
            return
        if not hasattr(cls, "name") or not isinstance(cls.name, str) or not cls.name:
            raise TypeError(
                f"Concrete agent class '{cls.__name__}' must define:\n"
                f"    name = 'your_agent_name'  (string, must match registry key)"
            )
        if not hasattr(cls, "version") or not isinstance(cls.version, str) or not cls.version:
            raise TypeError(
                f"Concrete agent class '{cls.__name__}' must define:\n"
                f"    version = '1.0.0'  (semver string)"
            )

    @abstractmethod
    def run(self, state: dict) -> dict:
        """
        Main agent logic.

        Args:
            state: Full GraphState (read-only for this agent's non-owned fields)

        Returns:
            Partial state dict. LangGraph merges this into GraphState.
            Return ONLY the fields this agent owns.
        """
        ...

    @abstractmethod
    def health_check(self) -> bool:
        """
        Called by validate_registry() before graph.compile().
        Must return True within 10 seconds.
        """
        ...

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name!r} version={self.version!r}>"
