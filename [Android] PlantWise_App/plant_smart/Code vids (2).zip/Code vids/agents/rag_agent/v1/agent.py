"""RAG Agent v1 - full pipeline orchestrator.

Runs the 8-step dense-only RAG pipeline:

    1. query_rewriter → 1-3 retrieval queries
    2. vector_store.search (dense) → top-20 candidates
    3. reranker → top-5 reranked
    4. grounded_gen → raw answer + citations
    5. consistency check → verification_passed
    6. freshness check → freshness_warning
    7. confidence calibration → rag_confidence [0.0 – 1.0]
    8. caveats → required compliance tail IDs

This agent runs in **parallel dispatch** alongside intent_agent and
entity_extraction.  All three converge at the supervisor.

State contract:
    Reads:  session, message_history, last_user_message, entity_memory,
            intent_stack, active_intent_id, current_turn
    Writes: rag_answer, rag_citations, rag_confidence, rag_caveats,
            rag_verification_passed, rag_freshness_warning
"""

from __future__ import annotations

import threading
from datetime import date, datetime, timezone

from agents.base import BaseAgent
from agents.rag_agent.v1.prompt import (
    build_entity_context,
    extract_question,
    extract_service_domain,
)
from agents.rag_agent.v1.retrieval.retriever import retrieve
from agents.rag_agent.v1.generation.grounded_gen import generate
from agents.rag_agent.v1.generation.consistency import check as consistency_check
from agents.rag_agent.v1.generation.freshness import check as freshness_check
from agents.rag_agent.v1.generation.confidence import calibrate
from agents.rag_agent.v1.generation.caveats import generate as generate_caveats
from graph.state import GraphState
from knowledge_base.embedder import Embedder
from knowledge_base.vector_store import ChromaVectorStore
from observability.logger import log
from observability.metrics import metrics
from observability.tracer import trace_agent


# — Lazy singletons — initialised on first run() ————————————————————————————
_embedder: Embedder | None = None
_vector_store: ChromaVectorStore | None = None
_init_lock = threading.Lock()


def _get_embedder() -> Embedder:
    global _embedder
    if _embedder is None:
        with _init_lock:
            if _embedder is None:
                _embedder = Embedder()
    return _embedder


def _get_vector_store() -> ChromaVectorStore:
    global _vector_store
    if _vector_store is None:
        with _init_lock:
            if _vector_store is None:
                _vector_store = ChromaVectorStore()
    return _vector_store


# — Safe result when pipeline can't run ————————————————————————————————————

def _empty_result(error: str | None = None) -> dict:
    """Return neutral RAG state.

    Always sets rag_confidence to 0.0 so H8 can fire for INFORMATIONAL
    intents — regardless of whether RAG failed (error set) or simply
    had no question to answer.  A ``None`` confidence would bypass H8's
    ``rag_confidence is not None`` guard and leave the user with no
    answer and no escalation.
    """
    return {
        "rag_answer": None,
        "rag_citations": [],
        "rag_confidence": 0.0,
        "rag_caveats": [],
        "rag_verification_passed": False,
        "rag_freshness_warning": False,
        "rag_error": error,
    }


# — Agent ————————————————————————————————————————————————————————————————————

class RAGAgent(BaseAgent):
    name    = "rag_agent"
    version = "1.0.0"

    @trace_agent("rag_agent")
    def run(self, state: GraphState) -> dict:
        session = state.get("session")
        session_id = str(session.session_id) if session else "unknown"

        # — Extract inputs from graph state ————————————————————————————
        question = extract_question(state)
        if not question:
            log.warning("rag_agent_no_question", session_id=session_id)
            return _empty_result()

        entity_context = build_entity_context(state)
        service_domain = extract_service_domain(state)
        current_date = datetime.now(timezone.utc).date()

        log.info(
            "rag_agent_start",
            session_id=session_id,
            question=question[:80],
            service_domain=service_domain,
            entity_keys=list(entity_context.keys()),
        )

        # — Step 1-3: Retrieval pipeline ———————————————————————————————
        try:
            embedder = _get_embedder()
            vector_store = _get_vector_store()
        except Exception as exc:
            log.error(
                "rag_agent_kb_init_failed",
                session_id=session_id,
                error=str(exc),
            )
            return _empty_result(error="kb_init_failed")

        chunks = retrieve(
            question=question,
            embedder=embedder,
            vector_store=vector_store,
            entity_context=entity_context,
            service_domain=service_domain,
        )

        if not chunks:
            log.warning(
                "rag_agent_no_chunks",
                session_id=session_id,
                question=question[:80],
            )
            return {
                "rag_answer": None,
                "rag_citations": [],
                "rag_confidence": 0.0,
                "rag_caveats": generate_caveats(service_domain),
                "rag_verification_passed": False,
                "rag_freshness_warning": False,
                "rag_error": None,
            }

        # — Step 4: Grounded generation ————————————————————————————————
        answer, citations = generate(
            question=question,
            chunks=chunks,
            entity_context=entity_context,
        )

        # — Step 5: Consistency check ——————————————————————————————————
        verification_passed = False
        if answer:
            verification_passed = consistency_check(answer, chunks)

        # — Step 6: Freshness check ————————————————————————————————————
        freshness_warning = freshness_check(citations, current_date)

        # — Step 7: Confidence calibration ————————————————————————————
        if answer is None:
            # No usable answer — force low confidence so H8 can escalate
            rag_confidence = 0.0
        else:
            avg_retrieval_score = (
                sum(c.score for c in chunks) / len(chunks) if chunks else 0.0
            )
            rag_confidence = calibrate(
                retrieval_score=avg_retrieval_score,
                verification_passed=verification_passed,
                freshness_warning=freshness_warning,
                num_citations=len(citations),
            )

        # — Step 8: Caveats ————————————————————————————————————————————
        intent_id = self._extract_intent_id(state)
        caveats = generate_caveats(service_domain, intent_id)

        log.info(
            "rag_agent_complete",
            session_id=session_id,
            answer_len=len(answer) if answer else 0,
            citations=len(citations),
            confidence=rag_confidence,
            verification_passed=verification_passed,
            freshness_warning=freshness_warning,
            caveats=len(caveats),
        )
        metrics.record_rag_confidence(rag_confidence, service_domain or "unknown")

        return {
            "rag_answer": answer,
            "rag_citations": citations,
            "rag_confidence": rag_confidence,
            "rag_caveats": caveats,
            "rag_verification_passed": verification_passed,
            "rag_freshness_warning": freshness_warning,
            "rag_error": None,
        }

    def health_check(self) -> bool:
        """Verify the KB layer is operational."""
        try:
            store = _get_vector_store()
            store.count()
            return True
        except Exception:
            return False

    # — Private helpers ————————————————————————————————————————————————

    @staticmethod
    def _extract_intent_id(state: GraphState) -> str | None:
        """Get the active intent's sub_intent ID, if available."""
        stack = state.get("intent_stack", [])
        if not stack:
            return None
        active_id = state.get("active_intent_id")
        if active_id:
            for intent in stack:
                if intent.intent_id == active_id:
                    return intent.sub_intent
        return stack[0].sub_intent
