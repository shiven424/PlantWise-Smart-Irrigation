from __future__ import annotations

"""
Query rewriter — decomposes complex user questions into 1-3 retrieval queries.

Simple questions pass through as a single-element list.
Compound questions (e.g., "What is my RMD and when do I have to take it?")
are decomposed into separate, focused retrieval queries.

Entity context (plan_type, age, account_type, etc.) is injected into
queries for more precise retrieval when available.
"""

from pydantic import BaseModel, Field

from llm.client import call_llm
from observability.logger import log


# — LLM response schema ————————————————————————————————————————————————————

class _RewrittenQueries(BaseModel):
    queries: list[str] = Field(
        min_length=1,
        max_length=3,
        description="1-3 focused retrieval queries derived from the original question.",
    )
    reasoning: str = Field(
        default="",
        description="Brief explanation of why the question was (or was not) decomposed.",
    )


# — System prompt ——————————————————————————————————————————————————————————

_SYSTEM_PROMPT = """\
You are a query rewriting assistant for a financial services knowledge base.
Your job is to take a customer's question and produce 1 to 3 focused retrieval
queries optimized for dense vector search over regulatory and product documents.

Rules:
1. If the question is simple and self-contained, return it as a single query.
2. If the question is compound (asks about multiple topics), decompose it into
   separate queries — one per distinct topic.  Maximum 3 queries.
3. Rephrase questions to be self-contained — replace pronouns with specific
   terms when entity context is provided.
4. Include relevant regulatory references when the question implies them
   (e.g., "early withdrawal penalty" → include "IRC 72(t)" in the query).
5. Do NOT answer the question.  Only produce search queries.
6. Keep each query concise — under 100 words.

Respond ONLY with valid JSON matching this schema:
{
  "queries": ["query 1", "query 2"],
  "reasoning": "brief explanation"
}"""


# — Public API ————————————————————————————————————————————————————————————

def rewrite(question: str, entity_context: dict | None = None) -> list[str]:
    """Rewrite a user question into 1-3 retrieval queries.

    Parameters
    ----------
    question : str
        The customer's original question.
    entity_context : dict | None
        Extracted entity slots (plan_type, age, account_type, etc.) that
        can be injected for more precise retrieval.

    Returns
    -------
    list[str]
        1-3 retrieval queries.  Falls back to ``[question]`` on LLM failure.
    """
    context_block = ""
    if entity_context:
        pairs = ", ".join(f"{k}={v}" for k, v in entity_context.items() if v)
        if pairs:
            context_block = f"\nEntity context: {pairs}"

    user_prompt = f"Customer question: \"{question}\"{context_block}"

    fallback = _RewrittenQueries(queries=[question], reasoning="llm_fallback")

    result = call_llm(
        system_prompt=_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        response_model=_RewrittenQueries,
        fallback=fallback,
        max_tokens=300,
        temperature=0.0,
    )

    log.info(
        "query_rewriter",
        original=question,
        rewritten_count=len(result.queries),
        reasoning=result.reasoning,
    )

    return result.queries
