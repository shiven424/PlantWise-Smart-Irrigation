from __future__ import annotations

"""
Retriever — orchestrates the full retrieval pipeline.

Pipeline steps (per the simplified dense-only architecture):

    1. query_rewriter.rewrite(question, entity_context) → 1-3 queries
    2. For each query: embed → vector_store.search(top_k=20) → collect
    3. Deduplicate across all query results
    4. reranker.rerank(question, candidates, top_k=5) → final chunks

This module ties together the embedder, vector store, query rewriter,
and reranker into a single ``retrieve()`` call used by the RAG agent.
"""

import logging
from typing import Any

from knowledge_base.base import ChunkResult
from knowledge_base.embedder import Embedder
from knowledge_base.vector_store import ChromaVectorStore

from agents.rag_agent.v1.retrieval.query_rewriter import rewrite
from agents.rag_agent.v1.retrieval.reranker import rerank

logger = logging.getLogger(__name__)

# — Defaults ——————————————————————————————————————————————————————————————
_DENSE_TOP_K = 20      # candidates per query from vector store
_RERANK_TOP_K = 5      # final results after cross-encoder reranking


def _build_metadata_filter(
    service_domain: str | None = None,
) -> dict[str, Any] | None:
    """Build a ChromaDB ``where`` filter from optional domain constraint.

    ChromaDB ``where`` filters use the format ``{"field": "value"}``
    for equality or ``{"field": {"$in": [...]}}`` for multi-value.

    Each chunk stores one metadata key per service domain it belongs to,
    e.g. ``{"domain__RETIREMENT_SERVICES": "1", ...}``.  We filter
    using ``$eq`` on the matching flag key.
    """
    if not service_domain:
        return None
    # Each chunk has a "domain__<NAME>" metadata key set to "1".
    # ChromaDB $eq on this key selects only chunks that belong to
    # the requested domain.
    from knowledge_base.base import DOMAIN_KEY_FORMAT
    return {DOMAIN_KEY_FORMAT.format(service_domain): {"$eq": "1"}}


def retrieve(
    question: str,
    embedder: Embedder,
    vector_store: ChromaVectorStore,
    entity_context: dict | None = None,
    service_domain: str | None = None,
    dense_top_k: int = _DENSE_TOP_K,
    rerank_top_k: int = _RERANK_TOP_K,
) -> list[ChunkResult]:
    """Run the full retrieval pipeline.

    Parameters
    ----------
    question : str
        The user's original question.
    embedder : Embedder
        Embedding model instance for query encoding.
    vector_store : ChromaVectorStore
        Vector store to search.
    entity_context : dict | None
        Extracted entity slots for query rewriting context.
    service_domain : str | None
        Optional service domain to filter retrieval (e.g. "RETIREMENT_SERVICES").
    dense_top_k : int
        Number of candidates to retrieve per query from the vector store.
    rerank_top_k : int
        Number of final results to return after cross-encoder reranking.

    Returns
    -------
    list[ChunkResult]
        Top reranked chunks, sorted by cross-encoder relevance score.
        Returns empty list if no results are found.
    """
    # Step 1: Rewrite the question into 1-3 retrieval queries
    queries = rewrite(question, entity_context)
    logger.info("Retrieval queries: %d from original question", len(queries))

    # Step 2: Dense retrieval for each query
    metadata_filter = _build_metadata_filter(service_domain)
    seen_ids: set[str] = set()
    all_candidates: list[ChunkResult] = []

    for query in queries:
        query_embedding = embedder.embed_single(query)
        results = vector_store.search(
            query_embedding=query_embedding,
            top_k=dense_top_k,
            metadata_filter=metadata_filter,
        )
        # Step 3: Deduplicate across queries
        for chunk in results:
            if chunk.chunk_id not in seen_ids:
                seen_ids.add(chunk.chunk_id)
                all_candidates.append(chunk)

    logger.info(
        "Dense retrieval: %d unique candidates from %d queries",
        len(all_candidates),
        len(queries),
    )

    if not all_candidates:
        return []

    # Step 4: Cross-encoder reranking
    reranked = rerank(
        question=question,
        candidates=all_candidates,
        top_k=rerank_top_k,
    )

    logger.info(
        "Reranked to %d results (top score=%.4f)",
        len(reranked),
        reranked[0].score if reranked else 0.0,
    )

    return reranked
