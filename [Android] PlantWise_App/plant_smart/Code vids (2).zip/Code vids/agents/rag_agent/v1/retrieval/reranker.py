from __future__ import annotations

"""
Reranker — rescores retrieval candidates for relevance.

Supports two providers (set via ``config.settings.reranker_provider``):

* ``"openai"`` (default) — uses the LLM (via ``call_llm``) to score each
  (question, chunk) pair on a 0-10 relevance scale, then returns the top-k
  highest-scoring candidates.  This is an LLM-as-a-judge approach that
  provides cross-attention-level accuracy without needing a local model.

* ``"local"`` — uses a cross-encoder model
  (``cross-encoder/ms-marco-MiniLM-L-6-v2``) loaded locally via
  ``sentence-transformers``.  Fast and free but requires torch + ~400 MB RAM.

The model / LLM is loaded / called lazily and cached for the process
lifetime.
"""

import logging
from typing import Any

from pydantic import BaseModel, Field

from config import settings
from knowledge_base.base import ChunkResult

logger = logging.getLogger(__name__)

# -- Local cross-encoder defaults --------------------------------------------
_DEFAULT_LOCAL_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"

_cross_encoder = None
_cross_encoder_model_name: str | None = None


def _get_cross_encoder(model_name: str = _DEFAULT_LOCAL_MODEL):
    """Load the cross-encoder model once and cache it."""
    global _cross_encoder, _cross_encoder_model_name
    if _cross_encoder is not None and _cross_encoder_model_name == model_name:
        return _cross_encoder

    from sentence_transformers import CrossEncoder
    _cross_encoder = CrossEncoder(model_name)
    _cross_encoder_model_name = model_name
    logger.info("Cross-encoder loaded: %s", model_name)
    return _cross_encoder


# -- LLM-based reranker schema -----------------------------------------------

class _ChunkScore(BaseModel):
    index: int = Field(description="Zero-based index of the chunk")
    score: float = Field(description="Relevance score from 0.0 to 10.0")


class _RerankedResult(BaseModel):
    rankings: list[_ChunkScore] = Field(
        default_factory=list,
        description="Relevance scores for each chunk, sorted by score descending.",
    )


_RERANKER_SYSTEM_PROMPT = """\
You are a relevance scoring assistant for a financial services knowledge base.
Your job is to score how relevant each retrieved text chunk is to the user's question.

Rules:
1. Score each chunk on a scale of 0.0 to 10.0 where:
   - 10.0 = perfectly relevant, directly answers the question
   - 7.0-9.0 = highly relevant, contains key information
   - 4.0-6.0 = somewhat relevant, related but not directly answering
   - 1.0-3.0 = marginally relevant, only tangentially related
   - 0.0 = completely irrelevant
2. Consider both topical relevance and information quality.
3. Score based on how well the chunk would help answer the question, not just keyword overlap.
4. Be precise — differentiate between chunks that are close in relevance.

Respond ONLY with valid JSON matching this schema:
{
  "rankings": [
    {"index": 0, "score": 8.5},
    {"index": 1, "score": 3.2}
  ]
}"""


# -- Public API ---------------------------------------------------------------

def rerank(
    question: str,
    candidates: list[ChunkResult],
    top_k: int = 5,
    model_name: str = _DEFAULT_LOCAL_MODEL,
) -> list[ChunkResult]:
    """Rerank retrieval candidates and return the top-k most relevant.

    Dispatches to the OpenAI LLM-based reranker or the local cross-encoder
    based on ``settings.reranker_provider``.

    Parameters
    ----------
    question : str
        The user's query (or rewritten retrieval query).
    candidates : list[ChunkResult]
        Chunks from dense retrieval, each with ``.text`` and ``.score``.
    top_k : int
        Number of top results to return after reranking.
    model_name : str
        HuggingFace model ID for the local cross-encoder (ignored when
        provider is ``"openai"``).

    Returns
    -------
    list[ChunkResult]
        Top-k candidates sorted by reranker score (descending).
        Each chunk's ``.score`` is replaced with the reranker score.
    """
    if len(candidates) <= 1:
        return candidates[:top_k]

    provider = settings.reranker_provider

    if provider == "openai":
        return _rerank_openai(question, candidates, top_k)
    return _rerank_local(question, candidates, top_k, model_name)


# -- OpenAI LLM-based reranking ----------------------------------------------

def _rerank_openai(
    question: str,
    candidates: list[ChunkResult],
    top_k: int,
) -> list[ChunkResult]:
    """Use the LLM to score each chunk's relevance to the question."""
    from llm.client import call_llm

    # Build numbered chunk listing (truncate each to 300 chars for context window)
    chunk_lines: list[str] = []
    for i, c in enumerate(candidates):
        truncated = c.text[:300].replace("\n", " ")
        chunk_lines.append(f"[{i}] {truncated}")
    chunks_block = "\n\n".join(chunk_lines)

    user_prompt = (
        f"Question: \"{question}\"\n\n"
        f"Chunks to score:\n{chunks_block}"
    )

    fallback = _RerankedResult(rankings=[])

    result = call_llm(
        system_prompt=_RERANKER_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        response_model=_RerankedResult,
        fallback=fallback,
        max_tokens=500,
        temperature=0.0,
    )

    if not result.rankings:
        # LLM failed — return candidates in original order, truncated
        logger.warning("LLM reranker returned no rankings — returning dense-only results.")
        return candidates[:top_k]

    # Build index → score map from LLM response
    score_map: dict[int, float] = {}
    for r in result.rankings:
        if 0 <= r.index < len(candidates):
            score_map[r.index] = r.score

    # Score all candidates; unscored ones get -1 so they sort last
    scored: list[ChunkResult] = []
    for i, chunk in enumerate(candidates):
        ce_score = score_map.get(i, -1.0)
        scored.append(
            ChunkResult(
                chunk_id=chunk.chunk_id,
                text=chunk.text,
                score=round(float(ce_score), 4),
                metadata=chunk.metadata,
            )
        )

    scored.sort(key=lambda c: c.score, reverse=True)

    logger.info(
        "LLM reranked %d candidates → top %d (best=%.4f, worst=%.4f)",
        len(candidates),
        min(top_k, len(scored)),
        scored[0].score if scored else 0.0,
        scored[min(top_k, len(scored)) - 1].score if scored else 0.0,
    )

    return scored[:top_k]


# -- Local cross-encoder reranking --------------------------------------------

def _rerank_local(
    question: str,
    candidates: list[ChunkResult],
    top_k: int,
    model_name: str,
) -> list[ChunkResult]:
    """Use a local cross-encoder to rerank candidates."""
    try:
        encoder = _get_cross_encoder(model_name)
    except Exception:
        logger.warning("Cross-encoder unavailable — returning dense-only results.")
        return candidates[:top_k]

    pairs = [(question, c.text) for c in candidates]

    try:
        scores = encoder.predict(pairs)
    except Exception:
        logger.warning("Cross-encoder prediction failed — returning dense-only results.")
        return candidates[:top_k]

    scored: list[ChunkResult] = []
    for chunk, ce_score in zip(candidates, scores):
        scored.append(
            ChunkResult(
                chunk_id=chunk.chunk_id,
                text=chunk.text,
                score=round(float(ce_score), 4),
                metadata=chunk.metadata,
            )
        )

    scored.sort(key=lambda c: c.score, reverse=True)

    logger.info(
        "Local reranked %d candidates → top %d (best=%.4f, worst=%.4f)",
        len(candidates),
        min(top_k, len(scored)),
        scored[0].score if scored else 0.0,
        scored[min(top_k, len(scored)) - 1].score if scored else 0.0,
    )

    return scored[:top_k]
