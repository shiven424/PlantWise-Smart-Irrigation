from __future__ import annotations

"""
Grounded generation — LLM generates an answer grounded in retrieved chunks.

The prompt instructs the model to:
  - Answer ONLY from the provided context chunks
  - Cite the source document and section for every claim
  - Say "I don't have enough information" if chunks don't cover the question
  - Never fabricate regulatory references or dollar amounts

Returns a tuple of (answer_text, list[SourceCitation]).
"""

from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from knowledge_base.base import ChunkResult
from llm.client import call_llm
from observability.logger import log
from schemas.primitives import SourceCitation


# — LLM response schema ————————————————————————————————————————————————————

class _CitationEntry(BaseModel):
    document_name: str = ""
    section: str = ""
    page: int | None = None
    snippet: str = ""

    # The structured-output LLM occasionally emits ``null`` for the string
    # citation fields (especially ``section`` when a chunk doesn't carry a
    # heading).  Pydantic v2 rejects ``None`` for ``str`` and the entire
    # RAG response is dropped — leaving the user with an empty answer and
    # confidence=0.  Coerce ``None`` → ``""`` so generation still succeeds.
    @field_validator("document_name", "section", "snippet", mode="before")
    @classmethod
    def _none_to_empty_string(cls, value):
        return "" if value is None else value


class _GroundedAnswer(BaseModel):
    answer: str = Field(
        default="",
        description="The answer grounded exclusively in the provided context.",
    )
    citations: list[_CitationEntry] = Field(
        default_factory=list,
        description="One citation per claim, referencing the source chunk.",
    )
    has_sufficient_context: bool = Field(
        default=True,
        description="False if the provided chunks do not contain enough information.",
    )


# — System prompt ——————————————————————————————————————————————————————————

_SYSTEM_PROMPT = """\
You are a grounded-answer generator for a financial services contact center.
You MUST answer ONLY using the context chunks provided below.

Rules — follow ALL of them strictly:
1. Answer the customer's question using ONLY the information in the context chunks.
2. For every factual claim, cite the source using the chunk's document_name and section.
3. If the chunks do not contain enough information to fully answer the question,
   set has_sufficient_context to false and state what information is missing.
4. NEVER fabricate regulatory references, section numbers, dollar amounts, or dates.
5. NEVER use information from your training data — only from the provided chunks.
6. If specific dollar amounts or limits are mentioned in the chunks, quote them exactly.
7. Keep the answer professional, concise, and directly responsive to the question.

Respond ONLY with valid JSON matching this schema:
{
  "answer": "Your grounded answer here.",
  "citations": [
    {"document_name": "doc.txt", "section": "Section 3", "page": null, "snippet": "relevant excerpt"}
  ],
  "has_sufficient_context": true
}"""


# — Public API ————————————————————————————————————————————————————————————

def generate(
    question: str,
    chunks: list[ChunkResult],
    entity_context: dict | None = None,
) -> tuple[str | None, list[SourceCitation]]:
    """Generate an answer grounded exclusively in the provided chunks.

    Parameters
    ----------
    question : str
        The customer's original question.
    chunks : list[ChunkResult]
        Top-k chunks from the retrieval+reranking pipeline.
    entity_context : dict | None
        Extracted entity slots for additional context.

    Returns
    -------
    tuple[str | None, list[SourceCitation]]
        (answer_text, citations).  answer_text is None if the model
        determines it has insufficient context.
    """
    if not chunks:
        log.info("grounded_gen_no_chunks", question=question[:80])
        return None, []

    # Build context block from chunks
    context_lines: list[str] = []
    for i, chunk in enumerate(chunks, 1):
        doc = chunk.metadata.get("document_name", "unknown")
        context_lines.append(
            f"--- Chunk {i} (document: {doc}, score: {chunk.score}) ---\n"
            f"{chunk.text}\n"
        )
    context_block = "\n".join(context_lines)

    # Build user prompt
    entity_block = ""
    if entity_context:
        pairs = ", ".join(f"{k}={v}" for k, v in entity_context.items() if v)
        if pairs:
            entity_block = f"\nCustomer context: {pairs}"

    user_prompt = (
        f"Context chunks:\n{context_block}\n\n"
        f"Customer question: \"{question}\"{entity_block}"
    )

    fallback = _GroundedAnswer(
        answer="",
        citations=[],
        has_sufficient_context=False,
    )

    result = call_llm(
        system_prompt=_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        response_model=_GroundedAnswer,
        fallback=fallback,
        max_tokens=800,
        temperature=0.0,
    )

    # Convert to SourceCitation objects — skip citations the LLM fabricated
    citations: list[SourceCitation] = []
    for cite in result.citations:
        # Find the matching chunk to pull metadata
        matching_chunk = _find_chunk_by_doc(chunks, cite.document_name)
        if matching_chunk is None:
            log.warning(
                "grounded_gen_fabricated_citation",
                document_name=cite.document_name,
                question=question[:80],
            )
            continue  # discard citations that don't map to a real chunk

        freshness_str = matching_chunk.metadata.get("freshness_date", "")
        freshness_dt = _parse_freshness_date(freshness_str)

        citations.append(
            SourceCitation(
                document_name=cite.document_name,
                section=cite.section,
                page=cite.page,
                snippet=cite.snippet[:200] if cite.snippet else None,
                chunk_id=matching_chunk.chunk_id,
                relevance_score=matching_chunk.score,
                freshness_date=freshness_dt,
            )
        )

    answer = result.answer if result.has_sufficient_context and result.answer else None

    log.info(
        "grounded_gen",
        question=question[:80],
        answer_len=len(result.answer) if result.answer else 0,
        citations=len(citations),
        sufficient_context=result.has_sufficient_context,
    )

    return answer, citations


# — Helpers ————————————————————————————————————————————————————————————————

def _find_chunk_by_doc(
    chunks: list[ChunkResult], document_name: str
) -> ChunkResult | None:
    """Find the first chunk whose metadata matches the document_name."""
    for chunk in chunks:
        if chunk.metadata.get("document_name", "") == document_name:
            return chunk
    return None


def _parse_freshness_date(date_str: str) -> datetime | None:
    """Parse a YYYY-MM-DD date string into a datetime, or None."""
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        return None
