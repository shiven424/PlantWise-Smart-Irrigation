from __future__ import annotations

"""
Confidence calibrator — combines retrieval and generation signals into a
single confidence score in [0.0, 1.0].

Scoring formula (from Plan2.md §27):
    base = min(1.0, avg_retrieval_score)
    if not verification_passed: base *= 0.70   (30% penalty for inconsistency)
    if freshness_warning:       base *= 0.85   (15% penalty for stale sources)
    if num_citations == 0:      base *= 0.50   (50% penalty for no citations)

Threshold: Action Planner H8 escalates if rag_confidence < 0.70.

This is a pure-logic module — no LLM call required.
"""

from observability.logger import log


def calibrate(
    retrieval_score: float,
    verification_passed: bool,
    freshness_warning: bool,
    num_citations: int,
) -> float:
    """Combine retrieval and generation signals into a single confidence score.

    Parameters
    ----------
    retrieval_score : float
        Average relevance score from the top-k reranked chunks.
    verification_passed : bool
        Whether the consistency check passed.
    freshness_warning : bool
        Whether any cited documents are potentially outdated.
    num_citations : int
        Number of source citations produced by grounded generation.

    Returns
    -------
    float
        Confidence score in [0.0, 1.0], rounded to 3 decimal places.
    """
    base = min(1.0, max(0.0, retrieval_score))

    if not verification_passed:
        base *= 0.70

    if freshness_warning:
        base *= 0.85

    if num_citations == 0:
        base *= 0.50

    score = round(base, 3)

    log.info(
        "confidence_calibrated",
        retrieval_score=round(retrieval_score, 4),
        verification_passed=verification_passed,
        freshness_warning=freshness_warning,
        num_citations=num_citations,
        final_confidence=score,
    )

    return score
