from __future__ import annotations

"""
Freshness checker — flags citations whose source documents may be outdated.

Compares each citation's ``freshness_date`` against the current regulatory
year.  If any cited document's freshness date is older than January 1 of
the current year, the checker returns True (warning), indicating the source
may not reflect the latest regulatory rules or limits.

This is a pure-logic module — no LLM call required.
"""

from datetime import date, datetime, timezone

from observability.logger import log
from schemas.primitives import SourceCitation


def check(citations: list[SourceCitation], current_date: date | None = None) -> bool:
    """Check if any cited documents are potentially outdated.

    Parameters
    ----------
    citations : list[SourceCitation]
        Citations produced by grounded generation.
    current_date : date | None
        Reference date for freshness comparison.  Defaults to today.

    Returns
    -------
    bool
        True (warning) if any citation's freshness_date is older than
        January 1 of the current year.  False if all citations are
        current or have no freshness_date.
    """
    if not citations:
        return False

    ref_date = current_date or datetime.now(timezone.utc).date()
    current_year_start = date(ref_date.year, 1, 1)
    stale_docs: list[str] = []

    for citation in citations:
        if citation.freshness_date is None:
            continue

        # SourceCitation.freshness_date is datetime; compare as date
        if isinstance(citation.freshness_date, datetime):
            cite_date = citation.freshness_date.date()
        else:
            cite_date = citation.freshness_date

        if cite_date < current_year_start:
            stale_docs.append(
                f"{citation.document_name} ({cite_date.isoformat()})"
            )

    if stale_docs:
        log.warning(
            "freshness_warning",
            stale_count=len(stale_docs),
            stale_docs=stale_docs[:5],
            reference_year=ref_date.year,
        )
        return True

    log.info("freshness_check_passed", citation_count=len(citations))
    return False
