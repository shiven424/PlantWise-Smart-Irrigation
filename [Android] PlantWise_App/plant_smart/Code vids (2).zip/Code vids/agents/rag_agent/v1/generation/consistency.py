from __future__ import annotations

"""
Consistency checker — verifies the generated answer against source chunks.

Uses an LLM to check that key claims in the answer can be traced back to the
provided chunks and that no claim contradicts the source material.

Returns True if consistent, False if any claim is unsupported or contradicted.
"""

from pydantic import BaseModel, Field

from knowledge_base.base import ChunkResult
from llm.client import call_llm
from observability.logger import log


# — LLM response schema ————————————————————————————————————————————————————

class _ConsistencyResult(BaseModel):
    is_consistent: bool = Field(
        default=True,
        description="True if all claims are supported by the chunks.",
    )
    contradictions: list[str] = Field(
        default_factory=list,
        description="List of specific claims that contradict or are unsupported by the chunks.",
    )
    reasoning: str = Field(
        default="",
        description="Brief explanation of the consistency assessment.",
    )


# — System prompt ——————————————————————————————————————————————————————————

_SYSTEM_PROMPT = """\
You are a consistency verification assistant for a financial services knowledge base.
Your job is to verify that a generated answer is fully consistent with the source
context chunks it claims to be based on.

Rules:
1. Check every factual claim in the answer against the provided context chunks.
2. A claim is "consistent" if it is directly stated or clearly implied by the chunks.
3. A claim is "contradicted" if the chunks state something different.
4. A claim is "unsupported" if it contains specific facts (dollar amounts, dates,
   regulatory references, percentages) not found in any chunk.
5. General knowledge paraphrasing is acceptable if it does not change the meaning.
6. Set is_consistent to false if ANY claim is contradicted or contains fabricated
   regulatory references, dollar amounts, or section numbers not in the chunks.

Respond ONLY with valid JSON matching this schema:
{
  "is_consistent": true,
  "contradictions": [],
  "reasoning": "brief explanation"
}"""


# — Public API ————————————————————————————————————————————————————————————

def check(answer: str, chunks: list[ChunkResult]) -> bool:
    """Verify the generated answer is consistent with source chunks.

    Parameters
    ----------
    answer : str
        The generated answer to verify.
    chunks : list[ChunkResult]
        The source chunks the answer was generated from.

    Returns
    -------
    bool
        True if the answer is consistent, False otherwise.
    """
    if not answer or not chunks:
        return False

    # Build context block
    context_lines: list[str] = []
    for i, chunk in enumerate(chunks, 1):
        doc = chunk.metadata.get("document_name", "unknown")
        context_lines.append(
            f"--- Chunk {i} (document: {doc}) ---\n{chunk.text}\n"
        )
    context_block = "\n".join(context_lines)

    user_prompt = (
        f"Source chunks:\n{context_block}\n\n"
        f"Generated answer to verify:\n\"{answer}\""
    )

    fallback = _ConsistencyResult(
        is_consistent=False,
        contradictions=["Unable to verify — LLM fallback"],
        reasoning="llm_fallback",
    )

    result = call_llm(
        system_prompt=_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        response_model=_ConsistencyResult,
        fallback=fallback,
        max_tokens=400,
        temperature=0.0,
    )

    if not result.is_consistent:
        log.warning(
            "consistency_check_failed",
            contradictions=result.contradictions[:3],
            reasoning=result.reasoning,
        )
    else:
        log.info("consistency_check_passed", reasoning=result.reasoning)

    return result.is_consistent
