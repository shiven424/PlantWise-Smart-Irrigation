"""RAG generation pipeline — grounded generation, consistency, confidence."""

from agents.rag_agent.v1.generation.grounded_gen import generate
from agents.rag_agent.v1.generation.consistency import check as consistency_check
from agents.rag_agent.v1.generation.freshness import check as freshness_check
from agents.rag_agent.v1.generation.confidence import calibrate
from agents.rag_agent.v1.generation.caveats import generate as generate_caveats

__all__ = [
    "generate",
    "consistency_check",
    "freshness_check",
    "calibrate",
    "generate_caveats",
]
