from __future__ import annotations

"""
Caveats generator — maps service domains to required compliance tail IDs.

The Response Synthesizer uses these IDs to look up verbatim disclosure text
from the compliance library JSON files.  This module NEVER generates or
modifies disclosure text — it only selects which disclosures apply.

Domain → caveat mapping (from Plan2.md §27):
    RETIREMENT_SERVICES    → ["RETIREMENT_GENERAL", "CIRCULAR_230"]
    INVESTMENT_MANAGEMENT  → ["FINRA_SUITABILITY", "REG_BI_DISCLOSURE"]
    TAX_PLANNING           → ["TAX_CONSEQUENCE", "CIRCULAR_230"]
    ESTATE_AND_TRUST       → ["ESTATE_TAX_DISCLAIMER"]

Additional intent-specific caveats are appended when the intent_id matches
known high-risk intents (e.g., early withdrawals, margin trading).

This is a pure-logic module — no LLM call required.
"""

from observability.logger import log


# — Domain → base caveats ——————————————————————————————————————————————————

_DOMAIN_CAVEATS: dict[str, list[str]] = {
    "RETIREMENT_SERVICES": [
        "RETIREMENT_GENERAL",
        "CIRCULAR_230",
    ],
    "INVESTMENT_MANAGEMENT": [
        "FINRA_SUITABILITY",
        "REG_BI_DISCLOSURE",
    ],
    "TAX_PLANNING": [
        "TAX_CONSEQUENCE",
        "CIRCULAR_230",
    ],
    "ESTATE_AND_TRUST": [
        "ESTATE_TAX_DISCLAIMER",
    ],
    "INSURANCE_AND_ANNUITY": [
        "RETIREMENT_GENERAL",
    ],
    "BROKERAGE_AND_TRADING": [
        "FINRA_SUITABILITY",
    ],
    "FINANCIAL_PLANNING": [
        "RETIREMENT_GENERAL",
    ],
    "ACCOUNT_ADMINISTRATION": [],
    "COMPLIANCE_REGULATORY": [],
    "CROSS_DOMAIN": [
        "RETIREMENT_GENERAL",
    ],
}


# — Intent → additional caveats ————————————————————————————————————————————

_INTENT_CAVEATS: dict[str, list[str]] = {
    # Retirement — high-risk intents
    "WITHDRAWAL_REQUEST": ["EARLY_WITHDRAWAL_PENALTY"],
    "HARDSHIP_WITHDRAWAL": ["EARLY_WITHDRAWAL_PENALTY"],
    "RMD_CALCULATION": ["RMD_PENALTY_WARNING"],
    "RMD_SETUP": ["RMD_PENALTY_WARNING"],
    "PLAN_LOAN_REQUEST": ["LOAN_DEFAULT_WARNING"],
    "PLAN_LOAN_STATUS": ["LOAN_DEFAULT_WARNING"],
    "IRA_ROLLOVER": ["ROLLOVER_60_DAY"],
    "CONTRIBUTION_INQUIRY": ["CONTRIBUTION_LIMIT_NOTICE"],
    "SEPP_INQUIRY": ["SEPP_72T_NOTICE"],
    "ROTH_CONVERSION": ["ROTH_CONVERSION_NOTICE"],

    # Investment — high-risk intents
    "TRADE_REQUEST": ["MARGIN_RISK_DISCLOSURE"],
    "REBALANCING_REQUEST": ["FINRA_CONCENTRATION_RISK"],

    # Estate — high-risk intents
    "BENEFICIARY_UPDATE": ["BENEFICIARY_CHANGE", "ERISA_SPOUSAL_CONSENT"],

    # Tax — high-risk intents
    "WITHHOLDING_UPDATE": ["WITHHOLDING_ELECTION_NOTICE", "STATE_WITHHOLDING_NOTICE"],
    "TAX_DOCUMENT_REQUEST": ["FORM_1099R_NOTICE", "FORM_5498_NOTICE"],
}


# — Public API ————————————————————————————————————————————————————————————

def generate(service_domain: str | None, intent_id: str | None = None) -> list[str]:
    """Generate required regulatory caveat IDs based on domain and intent.

    Parameters
    ----------
    service_domain : str | None
        The service domain from intent classification (e.g. "RETIREMENT_SERVICES").
    intent_id : str | None
        The specific intent ID (e.g. "WITHDRAWAL_REQUEST") for intent-level caveats.

    Returns
    -------
    list[str]
        Deduplicated list of compliance tail IDs.  The Response Synthesizer
        uses these to look up verbatim disclosure text from the compliance
        library JSON files.
    """
    caveats: list[str] = []

    # Domain-level caveats
    if service_domain:
        domain_caveats = _DOMAIN_CAVEATS.get(service_domain, [])
        caveats.extend(domain_caveats)

    # Intent-level caveats
    if intent_id:
        intent_caveats = _INTENT_CAVEATS.get(intent_id, [])
        caveats.extend(intent_caveats)

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for caveat in caveats:
        if caveat not in seen:
            seen.add(caveat)
            unique.append(caveat)

    log.info(
        "caveats_generated",
        service_domain=service_domain,
        intent_id=intent_id,
        caveat_count=len(unique),
        caveat_ids=unique,
    )

    return unique
