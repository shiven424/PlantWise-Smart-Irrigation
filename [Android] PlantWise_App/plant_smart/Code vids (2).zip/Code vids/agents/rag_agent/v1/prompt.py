from __future__ import annotations

"""
RAG Agent v1 - prompt templates.

The grounded generation prompts live in ``generation/grounded_gen.py``
to keep them co-located with the LLM call.  The query rewriter prompt
lives in ``retrieval/query_rewriter.py`` for the same reason.

This module provides shared prompt-building helpers used by the RAG
agent orchestrator to prepare inputs for the pipeline.
"""


def build_entity_context(state: dict) -> dict[str, str]:
    """Extract a serialisable entity-context dict from GraphState.

    Converts entity_memory → ``{slot_name: display_value}`` for passing
    into the query rewriter and grounded generator.  Skips entities
    without a display_value.
    """
    context: dict[str, str] = {}
    for entity in state.get("entity_memory", {}).values():
        if entity.slot_name and entity.display_value:
            context[entity.slot_name] = entity.display_value
    return context


def extract_question(state: dict) -> str:
    """Extract the customer's latest question from message history.

    Falls back to ``last_user_message`` if message_history is empty.
    Returns an empty string (never None) so downstream never crashes.
    """
    history = state.get("message_history", [])
    if history:
        # Walk backwards to find the last user message
        for msg in reversed(history):
            if msg.get("role") == "user":
                return msg.get("content", "")
    return state.get("last_user_message") or ""


def extract_service_domain(state: dict) -> str | None:
    """Extract the service_domain from the active intent, if available.

    Returns the string value (e.g. "RETIREMENT_SERVICES") or None.
    The intent stack may not be populated yet when the RAG agent runs
    in parallel with the intent agent.
    """
    stack = state.get("intent_stack", [])
    if not stack:
        return None
    active_id = state.get("active_intent_id")
    if active_id:
        for intent in stack:
            if intent.intent_id == active_id:
                return intent.service_domain.value
    # Fallback to head of stack
    return stack[0].service_domain.value if stack else None
