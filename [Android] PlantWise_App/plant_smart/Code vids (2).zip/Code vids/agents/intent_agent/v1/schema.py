"""Intent Agent v1 - schema re-exports.

The canonical request/response contracts live in schemas.agent_io.
This module re-exports them so version-local imports work consistently.
"""
from schemas.agent_io import IntentAgentRequest, IntentAgentResponse

__all__ = ["IntentAgentRequest", "IntentAgentResponse"]
