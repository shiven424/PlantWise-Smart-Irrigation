"""Intent Agent v1 - classifies user intent from the taxonomy."""

from pydantic import BaseModel

from agents.base import BaseAgent
from config import settings
from graph.state import GraphState, compute_slot_gap
from agents.intent_agent.v1.schema import IntentAgentResponse
from agents.intent_agent.v1.prompt import SYSTEM_PROMPT, build_user_prompt
from agents.intent_agent.v1.taxonomy import (
    lookup_intent,
    ESCALATION_INTENTS,
    IntentDefinition,
)
from llm.client import call_llm
from observability.logger import log
from observability.tracer import trace_agent
from schemas.enums import (
    EscalationReason,
    IntentChangeType,
    MessageDomain,
    ServiceDomain,
)
from schemas.escalation_utils import (
    keyword_to_escalation_reason,
    SUB_INTENT_REASON_MAP,
)
from schemas.graph_state import DELETE
from schemas.primitives import EscalationContext, IntentRecord


# — Internal LLM response model ————————————————————————————————————————————

class _LLMIntentFallback(BaseModel):
    """Internal model for parsing LLM JSON output for intent classification."""
    intent_id: str = ""
    service_domain: str = ""
    sub_intent: str = ""
    confidence: float = 0.0
    change_type: str = "NEW"
    required_slots: list[str] = []
    is_transactional: bool = False
    requires_auth_level: int = 1
    escalation_flag: bool = False
    escalation_reason: str | None = None
    reasoning: str = ""


class IntentAgent(BaseAgent):
    name    = "intent_agent"
    version = "1.0.0"

    @trace_agent("intent_agent")
    def run(self, state: GraphState) -> dict:
        history = state.get("message_history", [])
        current_msg = history[-1].get("content", "") if history else ""
        current_intents: list[IntentRecord] = state.get("intent_stack", [])
        entity_context: dict = {
            k: v.display_value
            for k, v in state.get("entity_memory", {}).items()
            if v.display_value
        }
        current_turn: int = state.get("current_turn", 0)
        recent_intents: list[str] = state.get("user_profile", {}).get("recent_intents", [])

        last_requested_slot: str | None = state.get("last_requested_slot")
        slot_gap_in: list[str] = list(state.get("slot_gap") or [])

        # Call LLM for intent classification
        llm_result = self._llm_classify(
            current_msg, current_intents, entity_context, recent_intents,
            last_requested_slot=last_requested_slot,
            slot_gap=slot_gap_in,
        )

        # Validate the LLM's sub_intent against the taxonomy
        sub_intent_id = llm_result.get("sub_intent", "")
        defn = lookup_intent(sub_intent_id)

        if defn is None:
            # LLM returned an unknown intent — fall back to safe default
            log.warning(
                "intent_agent_unknown_sub_intent",
                sub_intent=sub_intent_id,
                session_id=self._session_id(state),
            )
            return self._fallback_result(current_intents, current_turn)

        # Check for escalation intents
        escalation_flag = defn.escalation_flag or llm_result.get("escalation_flag", False)
        escalation_reason = llm_result.get("escalation_reason")

        if defn.sub_intent_id in ESCALATION_INTENTS and not escalation_reason:
            escalation_reason = f"escalation_intent_{defn.sub_intent_id.lower()}"

        # Build the IntentRecord from taxonomy (source of truth) + LLM confidence
        change_type_str = llm_result.get("change_type", "NEW")
        try:
            change_type = IntentChangeType(change_type_str)
        except ValueError:
            change_type = IntentChangeType.NEW

        new_record = IntentRecord(
            intent_id=defn.intent_id,
            service_domain=defn.domain,
            sub_intent=defn.sub_intent_id,
            confidence=max(0.0, min(1.0, llm_result.get("confidence", 0.0))),
            change_type=change_type,
            requires_auth_level=defn.auth_level,
            is_transactional=defn.is_transactional,
            escalation_flag=escalation_flag,
            required_slots=list(defn.required_slots),
            turn_number=current_turn,
        )

        # Build the updated intent stack
        intent_stack = self._build_stack(new_record, current_intents, change_type, current_turn)

        # Compute slot_gap from the updated state
        updated_state = dict(state)
        updated_state["intent_stack"] = intent_stack
        updated_state["active_intent_id"] = intent_stack[0].intent_id
        slot_gap = compute_slot_gap(updated_state)

        result: dict = {
            "intent_stack": intent_stack,
            "active_intent_id": intent_stack[0].intent_id,
            "slot_gap": slot_gap,
        }

        # When a NEW or PIVOT intent enters as the active intent, clear it
        # from completed_intent_ids so the supervisor policy will execute
        # it again on this turn.  Without this, re-issuing the same request
        # ("what's my 401k balance?" twice in one session) would be silently
        # short-circuited as already-fulfilled.
        #
        # We also trigger this same purge when the active intent is *already*
        # in ``completed_intent_ids`` even if the classifier returned
        # REFINEMENT/RESUME — that case is "user re-runs a finished
        # transactional intent with a different categorical value"
        # (e.g. asks for 401k balance, then asks for IRA balance, then
        # asks for brokerage balance back-to-back).  Without the purge,
        # the stale ``account_type`` from the previous run would leak in
        # because the extractor's "do not re-extract already-confirmed"
        # rule suppresses the new value.
        prior_completed_ids = list(state.get("completed_intent_ids", []) or [])
        repeat_completed_intent = defn.intent_id in prior_completed_ids
        should_purge = (
            change_type in (IntentChangeType.NEW, IntentChangeType.PIVOT)
            or repeat_completed_intent
        )
        if should_purge:
            if repeat_completed_intent:
                result["completed_intent_ids"] = [
                    iid for iid in prior_completed_ids if iid != defn.intent_id
                ]

            # Bug fix: also purge stale, non-PII, slot-bound entities from
            # entity_memory so the new intent instance starts with a fresh
            # slate.  Without this, a multi-account user who first asked
            # for their BROKERAGE balance and then asks "what's my 401k
            # balance?" silently re-runs the previous BROKERAGE selection
            # because account_type=BROKERAGE persists in entity_memory and
            # the extractor's "do not re-extract confirmed entities" rule
            # suppresses the new value.
            #
            # Safe to drop:
            #   - non-PII categorical/numeric slot values
            #     (account_type, distribution_type, dollar_amount, …)
            #   - non-PII ambient categorical entries left over from the
            #     prior intent (e.g. ACCOUNT_TYPE captured during a
            #     balance-inquiry "401k and brokerage" turn that the LLM
            #     emitted as ambient_key rather than slot_name).  These
            #     are request-scoped to the prior intent and would
            #     otherwise leak into the new intent's HITL/tool inputs.
            # Must KEEP:
            #   - PII vault-tokenised entities (SSN, DOB, …) — purging
            #     them would force the user to re-authenticate on every
            #     follow-up request.
            #   - truly contextual entries with neither slot_name nor
            #     ambient_key (rare; treated as session-global).
            existing_em = state.get("entity_memory") or {}
            to_delete: dict = {}
            for key, ent in existing_em.items():
                slot_name = getattr(ent, "slot_name", None) or (
                    ent.get("slot_name") if isinstance(ent, dict) else None
                )
                ambient_key = getattr(ent, "ambient_key", None) or (
                    ent.get("ambient_key") if isinstance(ent, dict) else None
                )
                is_pii = getattr(ent, "is_pii", False) or (
                    ent.get("is_pii", False) if isinstance(ent, dict) else False
                )
                if (slot_name or ambient_key) and not is_pii:
                    to_delete[key] = DELETE
            if to_delete:
                result["entity_memory"] = to_delete
                # Recompute slot_gap on the post-purge state so the
                # supervisor doesn't see phantom-filled slots from the
                # entities we just dropped.
                purged_state = dict(updated_state)
                purged_state["entity_memory"] = {
                    k: v for k, v in existing_em.items() if k not in to_delete
                }
                result["slot_gap"] = compute_slot_gap(purged_state)
                log.info(
                    "intent_agent_entity_memory_purged_on_intent_change",
                    change=change_type.value,
                    new_intent=defn.sub_intent_id,
                    dropped=len(to_delete),
                    session_id=self._session_id(state),
                )

        # If escalation detected at intent level, set escalation context
        if escalation_flag:
            log.warning(
                "intent_agent_escalation",
                sub_intent=defn.sub_intent_id,
                reason=escalation_reason,
                session_id=self._session_id(state),
            )
            # Set escalation_context but NOT escalation_requested.
            # H7 in the action planner reads active_intent.escalation_flag
            # and uses this context for the correct EscalationReason.
            result["escalation_context"] = EscalationContext(
                reason=self._map_escalation_reason(defn, escalation_reason),
                triggered_by="intent_agent",
            )

        return result

    def _llm_classify(
        self,
        message: str,
        current_intents: list[IntentRecord],
        entity_context: dict,
        recent_intents: list[str] | None = None,
        last_requested_slot: str | None = None,
        slot_gap: list[str] | None = None,
    ) -> dict:
        """Call LLM and return parsed dict. Returns empty dict on failure."""
        fallback_response = _LLMIntentFallback(
            intent_id="",
            service_domain="",
            sub_intent="",
            confidence=0.0,
            change_type="NEW",
            required_slots=[],
            is_transactional=False,
            requires_auth_level=1,
            escalation_flag=False,
            escalation_reason=None,
            reasoning="llm_fallback",
        )

        result = call_llm(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=build_user_prompt(
                message, current_intents, entity_context, recent_intents,
                last_requested_slot=last_requested_slot,
                slot_gap=slot_gap,
            ),
            response_model=_LLMIntentFallback,
            fallback=fallback_response,
            cacheable=True,
        )
        return result.model_dump()

    def _build_stack(
        self,
        new_record: IntentRecord,
        current_intents: list[IntentRecord],
        change_type: IntentChangeType,
        current_turn: int,
    ) -> list[IntentRecord]:
        """Build the updated intent stack based on the change type."""
        if change_type == IntentChangeType.NEW or not current_intents:
            # Fresh start — new record becomes the stack
            return [new_record]

        if change_type == IntentChangeType.REFINEMENT:
            # Replace the head with the refined version, keep paused intents
            return [new_record] + current_intents[1:]

        if change_type == IntentChangeType.CORRECTION:
            # Same as refinement — replace head with corrected version
            return [new_record] + current_intents[1:]

        if change_type == IntentChangeType.PIVOT:
            # Push old head to paused (with paused_at_turn), new becomes head
            paused_head = IntentRecord(
                intent_id=current_intents[0].intent_id,
                service_domain=current_intents[0].service_domain,
                sub_intent=current_intents[0].sub_intent,
                confidence=current_intents[0].confidence,
                change_type=current_intents[0].change_type,
                requires_auth_level=current_intents[0].requires_auth_level,
                is_transactional=current_intents[0].is_transactional,
                escalation_flag=current_intents[0].escalation_flag,
                required_slots=current_intents[0].required_slots,
                paused_at_turn=current_turn,
                turn_number=current_intents[0].turn_number,
            )
            return [new_record, paused_head] + current_intents[1:]

        if change_type == IntentChangeType.RESUME:
            # Find the paused intent matching new_record and bring it to head
            resumed = None
            remaining = []
            for intent in current_intents:
                if intent.sub_intent == new_record.sub_intent and resumed is None:
                    resumed = new_record  # use fresh record with updated confidence
                else:
                    remaining.append(intent)
            if resumed:
                return [resumed] + remaining
            # M7: If not found in paused, treat as REFINEMENT (replace head)
            return [new_record] + current_intents[1:]

        # Fallback — treat as NEW
        return [new_record]

    def _fallback_result(self, current_intents: list[IntentRecord], current_turn: int) -> dict:
        """Return a safe fallback when LLM output is invalid."""
        if current_intents:
            # Keep the existing stack unchanged
            return {
                "intent_stack": current_intents,
                "active_intent_id": current_intents[0].intent_id,
                "slot_gap": [],
            }
        # No existing intents — signal escalation so the action planner
        # can ask for clarification or escalate rather than proceeding with
        # an invalid intent record.
        return {
            "intent_stack": [],
            "active_intent_id": None,
            "slot_gap": [],
        }

    def _map_escalation_reason(
        self, defn: IntentDefinition, reason_str: str | None
    ) -> EscalationReason:
        """Map intent-level escalation to an EscalationReason enum.

        Priority: reason_str keywords > sub_intent_id mapping > OUT_OF_SCOPE.
        Uses shared keyword_to_escalation_reason (schemas/escalation_utils.py).
        """
        if reason_str:
            result = keyword_to_escalation_reason(
                reason_str,
                default=None,
                word_boundary=False,
            )
            if result is not None:
                return result
        return SUB_INTENT_REASON_MAP.get(defn.sub_intent_id, EscalationReason.OUT_OF_SCOPE)

    def health_check(self) -> bool:
        return bool(settings.anthropic_api_key or settings.openai_api_key)

    @staticmethod
    def _session_id(state: GraphState) -> str:
        session = state.get("session")
        return str(session.session_id) if session else "unknown"
