from __future__ import annotations

"""
Intent Taxonomy
---------------

Canonical registry of every recognised sub-intent in the system.

Each intent is an ``IntentDefinition`` dataclass (frozen, slotted).  The
taxonomy is the **single source of truth** for:

  - Sub-intent identification                (Intent Agent)
  - Required slot lists                      (Entity Extraction, ``compute_slot_gap``)
  - Authentication level requirements        (Auth Agent, Action Planner H2)
  - Transactional vs informational           (Action Planner policy layer)
  - Compliance disclosure tails              (Action Planner, Response Synthesizer)
  - Escalation flags                         (Action Planner H1/H7)

Consumers:
  - ``agents/intent_agent/v1/prompt.py``    — renders taxonomy text for the LLM
  - ``agents/intent_agent/v1/agent.py``     — validates LLM output via ``lookup_intent()``
  - ``agents/supervisor/v1/policy.py``      — reads ``compliance_tails`` per intent
  - ``agents/entity_validator/v1/rules/``  — ``INTENT_RULE_MAP`` keys align with sub_intent_id
  - ``graph/state.py``                      — ``get_required_slots()`` for slot-gap computation
"""

from dataclasses import dataclass

from schemas.enums import AuthLevel, ServiceDomain


# ==============================================================================
# IntentDefinition
# ==============================================================================

@dataclass(frozen=True, slots=True)
class IntentDefinition:
    """Immutable definition of a single sub-intent."""

    sub_intent_id:    str                      # e.g. "PLAN_LOAN_REQUEST"
    domain:           ServiceDomain            # enum — service domain this intent belongs to
    description:      str                      # human-friendly description for LLM prompt
    required_slots:   tuple[str, ...]          # slot names the entity extractor must fill
    auth_level:       AuthLevel                # minimum authentication level required
    is_transactional: bool                     # True → HITL confirmation → tool execution
    escalation_flag:  bool = False             # True → always escalate, regardless of classifier
    compliance_tails: tuple[str, ...] = ()    # compliance disclosure IDs for synthesizer Layer 3

    @property
    def intent_id(self) -> str:
        """Canonical intent ID: ``DOMAIN_VALUE.SUB_INTENT_ID``."""
        return f"{self.domain.value}.{self.sub_intent_id}"


# ==============================================================================
# Retirement Services  (17 intents)
# ==============================================================================

_RETIREMENT: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="ACCOUNT_BALANCE_INQUIRY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description=(
            "Check current account balance, vested balance, or YTD contributions "
            "for the user's account (401(k), IRA, brokerage, trust, etc.)"
        ),
        # account_type is "soft-required": needed only when the user has
        # more than one account.  ``compute_slot_gap`` in graph/state.py
        # treats it as filled when account_context["accounts"] has a
        # single entry (or none), so single-account users never get
        # asked "which account?".  Multi-account users do.
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_INFORMATIONAL_VIEW",),
    ),
    IntentDefinition(
        sub_intent_id="PLAN_LOAN_REQUEST",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Request a 401(k) plan loan under IRC 72(p)",
        required_slots=("plan_type", "loan_amount", "repayment_term"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "LOAN_DEFAULT_WARNING"),
    ),
    IntentDefinition(
        sub_intent_id="PLAN_LOAN_STATUS",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Check existing plan loan balance, repayment schedule, or payoff amount",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_INFORMATIONAL_VIEW",),
    ),
    IntentDefinition(
        sub_intent_id="PLAN_LOAN_ELIGIBILITY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Check eligibility for a new plan loan including maximum borrowable amount",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_INFORMATIONAL_VIEW", "LOAN_DEFAULT_WARNING"),
    ),
    IntentDefinition(
        sub_intent_id="IRA_ROLLOVER",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Roll over retirement account (direct or indirect, traditional or Roth)",
        required_slots=("plan_type", "rollover_type", "rollover_amount"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "ROLLOVER_60_DAY", "PLAN_TRANSFER_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="WITHDRAWAL_REQUEST",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Withdraw funds from a retirement account (normal, early, or in-service)",
        required_slots=("plan_type", "distribution_type", "withdrawal_amount"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "FORM_1099R_NOTICE", "STATE_WITHHOLDING_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="HARDSHIP_WITHDRAWAL",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Request a hardship distribution under plan-specific safe-harbor rules",
        required_slots=("plan_type", "distribution_type", "withdrawal_amount", "exemption_type"),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "EARLY_WITHDRAWAL_PENALTY", "HARDSHIP_DISTRIBUTION"),
    ),
    IntentDefinition(
        sub_intent_id="RMD_INQUIRY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Ask about Required Minimum Distribution rules, deadlines, or penalties",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("RETIREMENT_GENERAL", "RMD_PENALTY_WARNING"),
    ),
    IntentDefinition(
        sub_intent_id="RMD_CALCULATION",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Calculate exact RMD amount using Uniform Lifetime Table",
        required_slots=("plan_type", "date_of_birth"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_INFORMATIONAL_VIEW", "RMD_PENALTY_WARNING"),
    ),
    IntentDefinition(
        sub_intent_id="RMD_SETUP",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Set up automatic Required Minimum Distributions",
        required_slots=("plan_type", "date_of_birth", "distribution_frequency"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "RMD_PENALTY_WARNING", "TAX_CONSEQUENCE", "FORM_1099R_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="CONTRIBUTION_INQUIRY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Ask about annual contribution limits, catch-up eligibility, or YTD contributions",
        required_slots=("plan_type",),
        auth_level=AuthLevel.SOFT,
        is_transactional=False,
        compliance_tails=("RETIREMENT_GENERAL",),
    ),
    IntentDefinition(
        sub_intent_id="CONTRIBUTION_UPDATE",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Change contribution amount, percentage, or pre-tax/Roth allocation",
        required_slots=("plan_type", "contribution_amount"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "CONTRIBUTION_LIMIT_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="BENEFICIARY_INQUIRY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="View current primary and contingent beneficiary designations",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("RETIREMENT_GENERAL",),
    ),
    IntentDefinition(
        sub_intent_id="BENEFICIARY_UPDATE",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Add, change, or remove beneficiaries on a retirement plan",
        required_slots=(
            "plan_type",
            "beneficiary_name",
            "beneficiary_relation",
            "beneficiary_percentage",
            "beneficiary_type",
        ),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "BENEFICIARY_CHANGE", "ERISA_SPOUSAL_CONSENT"),
    ),
    IntentDefinition(
        sub_intent_id="SEPP_INQUIRY",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Ask about IRC 72(t) Substantially Equal Periodic Payments",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("RETIREMENT_GENERAL", "EARLY_WITHDRAWAL_PENALTY", "SEPP_72T_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="ROTH_CONVERSION",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Convert traditional IRA or 401(k) funds to a Roth account",
        required_slots=("plan_type", "rollover_amount"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE", "ROTH_CONVERSION_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="DISTRIBUTION_OPTIONS",
        domain=ServiceDomain.RETIREMENT_SERVICES,
        description="Ask what distribution options are available (lump sum, installments, annuity, in-service)",
        required_slots=("plan_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("RETIREMENT_GENERAL", "TAX_CONSEQUENCE"),
    ),
)


# ==============================================================================
# Investment Management  (9 intents)
# ==============================================================================

_INVESTMENT: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="PORTFOLIO_REVIEW",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Review current portfolio holdings, performance, or asset allocation",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("FINRA_SUITABILITY", "REG_BI_DISCLOSURE"),
    ),
    IntentDefinition(
        sub_intent_id="REBALANCING_REQUEST",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Rebalance portfolio to target allocation or model portfolio",
        required_slots=("account_type", "rebalance_frequency"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY", "REBALANCING_DISCLOSURE"),
    ),
    IntentDefinition(
        sub_intent_id="FUND_INQUIRY",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Ask about a specific fund, ETF, or investment vehicle",
        required_slots=("fund_name",),
        auth_level=AuthLevel.SOFT,
        is_transactional=False,
        compliance_tails=("FINRA_SUITABILITY", "MUTUAL_FUND_DISCLOSURE"),
    ),
    IntentDefinition(
        sub_intent_id="FUND_SWITCH",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Switch holdings from one fund to another within the same account",
        required_slots=("account_type", "source_fund", "destination_fund"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY",),
    ),
    IntentDefinition(
        sub_intent_id="TRADE_REQUEST",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Place a buy or sell order for a security",
        required_slots=(
            "account_type",
            "ticker_symbol",
            "order_type",
            "order_quantity",
            "order_price",
        ),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY", "REG_BI_DISCLOSURE"),
    ),
    IntentDefinition(
        sub_intent_id="ALLOCATION_CHANGE",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Change portfolio asset allocation percentages",
        required_slots=("account_type", "portfolio_allocation"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY", "REG_BI_DISCLOSURE"),
    ),
    IntentDefinition(
        sub_intent_id="RISK_PROFILE_INQUIRY",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="View current risk tolerance setting or investor profile",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("FINRA_SUITABILITY",),
    ),
    IntentDefinition(
        sub_intent_id="RISK_PROFILE_UPDATE",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Update risk tolerance or investor profile questionnaire responses",
        required_slots=("account_type", "risk_tolerance"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY",),
    ),
    IntentDefinition(
        sub_intent_id="DIVIDEND_REINVEST_UPDATE",
        domain=ServiceDomain.INVESTMENT_MANAGEMENT,
        description="Turn dividend reinvestment on or off for an account or specific holding",
        required_slots=("account_type", "reinvest_option"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("FINRA_SUITABILITY", "DIVIDEND_REINVESTMENT_NOTICE"),
    ),
)


# ==============================================================================
# Estate & Trust  (5 intents)
# ==============================================================================

_ESTATE: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="TRUST_INQUIRY",
        domain=ServiceDomain.ESTATE_AND_TRUST,
        description="Ask about trust account status, terms, or beneficiaries",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("BENEFICIARY_CHANGE",),
    ),
    IntentDefinition(
        sub_intent_id="BENEFICIARY_DESIGNATION",
        domain=ServiceDomain.ESTATE_AND_TRUST,
        description="Add, update, or remove beneficiary designations on an estate/trust account",
        required_slots=(
            "account_type",
            "beneficiary_name",
            "beneficiary_type",
            "beneficiary_percentage",
        ),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
        compliance_tails=("BENEFICIARY_CHANGE", "ERISA_SPOUSAL_CONSENT"),
    ),
    IntentDefinition(
        sub_intent_id="TRUST_DISTRIBUTION",
        domain=ServiceDomain.ESTATE_AND_TRUST,
        description="Request a distribution from a trust account",
        required_slots=("account_type", "distribution_type", "withdrawal_amount"),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
        compliance_tails=("BENEFICIARY_CHANGE", "TAX_CONSEQUENCE", "TRUST_DISTRIBUTION_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="TOD_INQUIRY",
        domain=ServiceDomain.ESTATE_AND_TRUST,
        description="View current Transfer on Death (TOD) beneficiary designations",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("BENEFICIARY_CHANGE", "TOD_REGISTRATION_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="TOD_UPDATE",
        domain=ServiceDomain.ESTATE_AND_TRUST,
        description="Add, change, or remove Transfer on Death beneficiary designations",
        required_slots=("account_type", "beneficiary_name", "beneficiary_percentage"),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
        compliance_tails=("BENEFICIARY_CHANGE", "TOD_REGISTRATION_NOTICE"),
    ),
)


# ==============================================================================
# Tax Planning  (4 intents)
# ==============================================================================

_TAX: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="TAX_DOCUMENT_REQUEST",
        domain=ServiceDomain.TAX_PLANNING,
        description="Request a tax document such as 1099-R, 1099-DIV, 1099-B, or 5498",
        required_slots=("document_type", "tax_year"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("TAX_CONSEQUENCE", "FORM_1099R_NOTICE", "FORM_5498_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="WITHHOLDING_INQUIRY",
        domain=ServiceDomain.TAX_PLANNING,
        description="View current federal or state tax withholding election",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("TAX_CONSEQUENCE", "WITHHOLDING_ELECTION_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="WITHHOLDING_UPDATE",
        domain=ServiceDomain.TAX_PLANNING,
        description="Change federal or state income tax withholding percentage or election",
        required_slots=("account_type", "withholding_percentage"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("TAX_CONSEQUENCE", "WITHHOLDING_ELECTION_NOTICE"),
    ),
    IntentDefinition(
        sub_intent_id="COST_BASIS_INQUIRY",
        domain=ServiceDomain.TAX_PLANNING,
        description="View cost basis, unrealized gains/losses, or lot-level details for a holding",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=False,
        compliance_tails=("TAX_CONSEQUENCE", "COST_BASIS_NOTICE"),
    ),
)


# ==============================================================================
# Account Administration  (6 intents)
# ==============================================================================

_ACCOUNT_ADMIN: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="ADDRESS_UPDATE",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="Update mailing or residential address on file",
        required_slots=("new_address",),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
    ),
    IntentDefinition(
        sub_intent_id="PHONE_UPDATE",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="Update phone number on file",
        required_slots=("new_phone",),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
    ),
    IntentDefinition(
        sub_intent_id="EMAIL_UPDATE",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="Update email address on file",
        required_slots=("new_email",),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
    ),
    IntentDefinition(
        sub_intent_id="STATEMENT_REQUEST",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="Request account statement for a specific period or quarter",
        required_slots=("account_type", "statement_period"),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
    ),
    IntentDefinition(
        sub_intent_id="TRANSACTION_HISTORY_INQUIRY",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="View recent posted transactions on a retirement / brokerage account.",
        required_slots=("account_type",),
        auth_level=AuthLevel.STRONG,
        is_transactional=True,
        compliance_tails=("RETIREMENT_INFORMATIONAL_VIEW",),
    ),
    IntentDefinition(
        sub_intent_id="LINKED_BANK_UPDATE",
        domain=ServiceDomain.ACCOUNT_ADMINISTRATION,
        description="Add, verify, or remove a linked external bank account for transfers",
        required_slots=("bank_routing_number", "bank_account_number"),
        auth_level=AuthLevel.ENHANCED,
        is_transactional=True,
    ),
)


# ==============================================================================
# Escalation  (6 intents — always set escalation_flag=True)
# ==============================================================================

_ESCALATION: tuple[IntentDefinition, ...] = (
    IntentDefinition(
        sub_intent_id="PERSONALISED_ADVICE",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client requests specific investment, tax, or financial recommendation",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
    IntentDefinition(
        sub_intent_id="COMPLAINT",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client complaint, dissatisfaction, or request to speak with a supervisor",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
    IntentDefinition(
        sub_intent_id="TAX_STRATEGY_ADVICE",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client requests personalized tax planning strategy or tax optimization advice",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
    IntentDefinition(
        sub_intent_id="ESTATE_PLANNING_ADVICE",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client requests personalized estate planning or trust structuring advice",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
    IntentDefinition(
        sub_intent_id="FRAUD_REPORT",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client reports suspected fraud, unauthorized activity, or identity theft",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
    IntentDefinition(
        sub_intent_id="RETIREMENT_PLANNING",
        domain=ServiceDomain.CROSS_DOMAIN,
        description="Client requests personalized retirement income plan, readiness assessment, or Social Security strategy",
        required_slots=(),
        auth_level=AuthLevel.SESSION,
        is_transactional=False,
        escalation_flag=True,
    ),
)


# ==============================================================================
# Master registry  (47 intents total)
# ==============================================================================

INTENT_TAXONOMY: dict[str, tuple[IntentDefinition, ...]] = {
    "RETIREMENT_SERVICES":    _RETIREMENT,
    "INVESTMENT_MANAGEMENT":  _INVESTMENT,
    "ESTATE_AND_TRUST":       _ESTATE,
    "TAX_PLANNING":           _TAX,
    "ACCOUNT_ADMINISTRATION": _ACCOUNT_ADMIN,
    "_ESCALATE":              _ESCALATION,
}

ESCALATION_INTENTS: frozenset[str] = frozenset(
    defn.sub_intent_id for defn in _ESCALATION
)


# ==============================================================================
# Derived lookup index (built once at import time)
# ==============================================================================

_INTENT_INDEX: dict[str, IntentDefinition] = {}
for _group in INTENT_TAXONOMY.values():
    for _defn in _group:
        _INTENT_INDEX[_defn.sub_intent_id] = _defn


# ==============================================================================
# Public helpers
# ==============================================================================

def lookup_intent(sub_intent_id: str) -> IntentDefinition | None:
    """
    Look up a sub-intent by its ID.

    Returns the ``IntentDefinition`` or ``None`` if not found.
    """
    return _INTENT_INDEX.get(sub_intent_id)


def all_sub_intent_ids() -> list[str]:
    """Return every valid sub_intent_id sorted alphabetically."""
    return sorted(_INTENT_INDEX.keys())


def get_required_slots(sub_intent_id: str) -> list[str]:
    """
    Return required_slots for a sub-intent as a mutable list,
    or empty list if the sub-intent is unknown.

    Used by ``graph/state.py  compute_slot_gap()`` and Entity Extraction.
    """
    defn = _INTENT_INDEX.get(sub_intent_id)
    if defn is None:
        return []
    return list(defn.required_slots)


def get_compliance_tails(sub_intent_id: str) -> list[str]:
    """
    Return compliance tail IDs for a sub-intent as a mutable list.

    Used by Action Planner policy layer and Response Synthesizer.
    This is the **single source of truth** for compliance disclosures —
    ``policy.py`` delegates here instead of maintaining its own mapping.
    """
    defn = _INTENT_INDEX.get(sub_intent_id)
    if defn is None:
        return []
    return list(defn.compliance_tails)
