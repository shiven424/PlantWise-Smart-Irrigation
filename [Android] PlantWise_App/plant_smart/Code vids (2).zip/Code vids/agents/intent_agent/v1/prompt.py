"""Intent Agent v1 - prompt templates."""

import json
from agents.intent_agent.v1.taxonomy import INTENT_TAXONOMY


def _build_taxonomy_text() -> str:
    lines = []
    for domain, intents in INTENT_TAXONOMY.items():
        lines.append(f"\n{domain}:")
        for defn in intents:
            tx = "TRANSACTIONAL" if defn.is_transactional else "INFORMATIONAL"
            lines.append(f"  - {defn.sub_intent_id}: {defn.description} [{tx}, auth={defn.auth_level.name}]")
            if defn.required_slots:
                lines.append(f"    required_slots: {', '.join(defn.required_slots)}")
    return "\n".join(lines)


SYSTEM_PROMPT = f"""You are an intent classifier for a wealth management contact center.

Map the client message to the most specific intent from the taxonomy below.

INTENT TAXONOMY:
{_build_taxonomy_text()}

CHANGE TYPE DEFINITIONS:
- NEW: No prior intent exists, or client is starting a completely different topic
- REFINEMENT: Client is adding detail or clarifying the active intent
- PIVOT: Client is switching to a new intent mid-conversation (do not lose the old one)
- CORRECTION: Client is correcting a previously stated value (e.g. "actually $15,000 not $10,000")
- RESUME: Client is returning to a paused intent after a PIVOT

SLOT-ANSWER PRIORITY (CRITICAL):
When LAST_REQUESTED_SLOT is set, the assistant's previous turn explicitly asked the
client for that slot's value. The client's CURRENT MESSAGE is therefore most likely a
direct answer to that question, NOT a new intent.

Default rules when LAST_REQUESTED_SLOT is set:
- Treat the message as REFINEMENT to the ACTIVE INTENT, even if the message contains
  tokens (account types, plan types, amounts) that resemble keywords for a different
  intent. Those tokens are the slot value being supplied.
- Do NOT classify as PIVOT/RESUME/NEW unless the client EXPLICITLY abandons or
  changes the topic with phrases like "actually never mind, I want to...", "instead,
  let's do...", "forget that, can you...", or asks an unrelated question.
- Examples (CRITICAL — follow these patterns):
  - LAST_REQUESTED_SLOT=plan_type, ACTIVE=RMD_CALCULATION,
    MESSAGE="both IRA and 401k"  -> REFINEMENT to RMD_CALCULATION
    (the client is naming the plan_type(s) for the RMD calculation, NOT asking for
    a balance — even though "IRA" and "401k" are also balance-inquiry keywords)
  - LAST_REQUESTED_SLOT=account_type, ACTIVE=ACCOUNT_BALANCE_INQUIRY,
    MESSAGE="my Roth"             -> REFINEMENT to ACCOUNT_BALANCE_INQUIRY
  - LAST_REQUESTED_SLOT=distribution_type, ACTIVE=WITHDRAWAL_REQUEST,
    MESSAGE="rmd"                 -> REFINEMENT to WITHDRAWAL_REQUEST
    (client is naming the distribution_type, NOT requesting an RMD calculation)
  - LAST_REQUESTED_SLOT=plan_type, ACTIVE=RMD_CALCULATION,
    MESSAGE="actually never mind, what's my balance?"
                                  -> PIVOT to ACCOUNT_BALANCE_INQUIRY
    (explicit topic abandonment)

ESCALATION TRIGGERS — set escalation_flag=true ONLY when the client is asking
for an OPINION or RECOMMENDATION, not when issuing an explicit instruction:
- Requests for specific investment recommendations ("should I buy X?", "what's a good fund for me?")
- Requests for personalised tax advice ("what's better for my tax situation?")
- Requests that imply fiduciary advice ("what would you do with my money?")

DO NOT set escalation_flag on explicit instructions to ACT. The presence of a
ticker, an order quantity, or an unambiguous buy/sell verb means the client is
placing an order, NOT asking for advice. Examples:
- "Buy 100 shares of VTI at market"           -> TRADE_REQUEST,    escalation_flag=false
- "Sell my entire AAPL position"              -> TRADE_REQUEST,    escalation_flag=false
- "Roll my old 401k to an IRA"                -> IRA_ROLLOVER,     escalation_flag=false
- "Withdraw $5000 from my IRA"                -> WITHDRAWAL_REQUEST, escalation_flag=false
- "Convert $50k from traditional IRA to Roth" -> ROTH_CONVERSION,  escalation_flag=false
- "Should I buy VTI?"                         -> PERSONALISED_ADVICE, escalation_flag=true

Respond ONLY with valid JSON. No preamble, no markdown.

JSON Schema:
{{
  "intent_id": "<DOMAIN.SUB_INTENT>",
  "service_domain": "<domain string>",
  "sub_intent": "<sub_intent string>",
  "confidence": <float 0.0-1.0>,
  "change_type": "NEW|REFINEMENT|PIVOT|CORRECTION|RESUME",
  "required_slots": ["slot1", "slot2"],
  "is_transactional": <bool>,
  "requires_auth_level": <int 1-4>,
  "escalation_flag": <bool>,
  "escalation_reason": "<string or null>",
  "reasoning": "<one sentence>"
}}"""


def build_user_prompt(
    message: str,
    current_intents: list,
    entity_context: dict,
    recent_intents: list[str] | None = None,
    last_requested_slot: str | None = None,
    slot_gap: list[str] | None = None,
) -> str:
    active = current_intents[0].model_dump() if current_intents else None
    paused = [i.model_dump() for i in current_intents[1:]] if len(current_intents) > 1 else []

    parts = [
        f"ACTIVE INTENT: {json.dumps(active, default=str) if active else 'None'}",
        f"PAUSED INTENTS: {json.dumps(paused, default=str) if paused else 'None'}",
        f"ENTITY CONTEXT (extracted so far): {json.dumps(entity_context)}",
    ]

    # Mid-slot-collection context.  When the previous turn asked the
    # client for a specific slot value, the LLM MUST treat the current
    # message as that slot's answer (REFINEMENT) rather than a new
    # intent — see SLOT-ANSWER PRIORITY in the system prompt.
    if last_requested_slot:
        parts.append(
            f"LAST_REQUESTED_SLOT: {last_requested_slot}\n"
            f"The assistant's previous turn asked the client for "
            f"'{last_requested_slot}'. The CURRENT MESSAGE is most likely "
            f"the client's answer to that question. Apply SLOT-ANSWER "
            f"PRIORITY: classify as REFINEMENT to the ACTIVE INTENT unless "
            f"the client explicitly abandons the topic."
        )

    if slot_gap:
        parts.append(f"REMAINING SLOTS TO COLLECT: {slot_gap}")

    if recent_intents:
        parts.append(
            f"USER HISTORY (frequently used intents from prior sessions): "
            f"{', '.join(recent_intents[:5])}"
        )

    parts.append(f"CLIENT MESSAGE: {message}")

    return "\n\n".join(parts)
