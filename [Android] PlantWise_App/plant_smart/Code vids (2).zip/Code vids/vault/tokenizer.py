"""
High-level PII tokenization helpers.

Usage (entity extraction agent):
    from vault.tokenizer import tokenize_entity
    vault_token = tokenize_entity(entity_type="SSN", raw_value="123-45-6789",
                                  session_id="abc")

These helpers delegate to the singleton *vault_client* and handle
masking so callers don't need to know the provider implementation.
"""
from __future__ import annotations

from schemas.enums import EntityType, PII_ENTITY_TYPES

# Masking patterns per PII type. Keys that are absent get the generic mask.
_MASK_PATTERNS: dict[EntityType, int] = {
    EntityType.SSN: 4,  # show last 4
    EntityType.ACCOUNT_NUMBER: 4,
    EntityType.BANK_ACCOUNT_NUMBER: 4,
    EntityType.BANK_ROUTING_NUMBER: 4,
    EntityType.PHONE_NUMBER: 4,
    EntityType.DATE_OF_BIRTH: 0,  # fully masked
    EntityType.TAX_ID: 4,
    EntityType.POLICY_NUMBER: 4,
}


def mask_value(entity_type: EntityType, raw_value: str) -> str:
    """
    Return a display-safe masked representation of *raw_value*.

    Examples:
        SSN  "123-45-6789"  ->  "****6789"
        DOB  "1985-03-14"   ->  "*****"
        FULL_NAME "John"    ->  "J***"
    """
    if not raw_value:
        return "*****"

    show_last = _MASK_PATTERNS.get(entity_type)

    if show_last is None:
        # Generic mask: strip formatting, show first character only
        cleaned = raw_value.replace("-", "").replace(" ", "")
        if len(cleaned) <= 1:
            return "*****"
        return cleaned[0] + "****"

    if show_last == 0:
        return "*****"

    # Strip formatting characters for the visible suffix
    digits = raw_value.replace("-", "").replace(" ", "")

    # Guard: if the cleaned value is too short, mask everything
    # to avoid exposing the full value.
    if len(digits) <= show_last:
        return "*****"

    return "****" + digits[-show_last:]


def tokenize_entity(
    entity_type: str,
    raw_value: str,
    session_id: str,
) -> str:
    """
    Tokenize a raw PII value through the vault.

    Returns the opaque vault token string.
    Delegates to the singleton ``vault_client``.
    """
    from vault.client import vault_client  # deferred to avoid circular import
    return vault_client.tokenize(entity_type, raw_value, session_id)


def is_pii_entity_type(entity_type: EntityType) -> bool:
    """Check whether an entity type is classified as PII."""
    return entity_type in PII_ENTITY_TYPES