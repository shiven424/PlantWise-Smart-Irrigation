"""
High-level PII dereferencing helpers.

Usage (tools):
    from vault.dereferencer import dereference_token, dereference_entity

Tools call these to retrieve raw PII for external API calls,
then MUST delete the raw value from local scope immediately after use.
"""

from __future__ import annotations

from schemas.primitives import EntityRecord


def dereference_token(vault_token: str, auth_token: str) -> str:
    """
    Resolve a single vault token to its raw PII value.

    Args:
        vault_token: Opaque token returned by ``tokenize_entity``.
        auth_token: Session auth token for access control.

    Returns:
        The original plaintext PII value.

    Raises:
        KeyError: if the token does not exist in the vault.
        PermissionError: if *auth_token* is invalid (provider-dependent).
    """

    from vault.client import vault_client  # deferred to avoid circular import
    from observability.logger import log

    log.info(
        "pii_dereference",
        vault_token=vault_token[:8] + "...",
        auth_token_present=bool(auth_token),
    )

    return vault_client.dereference(vault_token, auth_token)


def dereference_entity(entity: EntityRecord, auth_token: str) -> str:
    """
    Convenience wrapper: resolve an EntityRecord's vault_token.

    Raises:
        ValueError: if the entity has no vault_token.
    """
    if not entity.vault_token:
        raise ValueError(
            f"Entity {entity.entity_type.value} (slot={entity.slot_name!r}) "
            f"has no vault_token - cannot dereference."
        )

    from observability.logger import log

    log.info(
        "pii_dereference_entity",
        entity_type=entity.entity_type.value,
        slot_name=entity.slot_name,
    )

    return dereference_token(entity.vault_token, auth_token)


def delete_token(vault_token: str) -> bool:
    """
    Delete a PII value from the vault (session cleanup).

    Returns True on success.
    """
    from vault.client import vault_client

    return vault_client.delete(vault_token)
