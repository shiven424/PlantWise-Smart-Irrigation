"""
AWS Secrets Manager provider.

Requires:
    pip install boto3
    AWS_REGION and AWS_SECRET_PREFIX in .env / settings.
"""

from __future__ import annotations

import json
import uuid

import boto3
from botocore.exceptions import ClientError

from config import settings
from observability.logger import log
from vault.base import BaseVaultClient


class AWSSecretsVaultClient(BaseVaultClient):
    """Store / retrieve PII via AWS Secrets Manager."""

    def __init__(self) -> None:
        self.client = boto3.client("secretsmanager", region_name=settings.aws_region)
        self.prefix = settings.aws_secret_prefix.rstrip("/")

    def _secret_name(self, session_id: str, token: str) -> str:
        return f"{self.prefix}/{session_id}/{token}"

    def tokenize(self, entity_type: str, raw_value: str, session_id: str) -> str:
        token_id = uuid.uuid4().hex
        secret_name = self._secret_name(session_id, token_id)
        self.client.create_secret(
            Name=secret_name,
            SecretString=json.dumps({
                "entity_type": entity_type,
                "raw_value": raw_value,
            }),
        )
        # Encode session_id into the token so dereference can reconstruct the
        # full secret name without scanning.
        return f"vault:{session_id}/{token_id}"

    def dereference(self, vault_token: str, auth_token: str) -> str:
        if not auth_token:
            raise PermissionError(
                "auth_token is required to dereference PII. "
                "Ensure the session is authenticated before accessing vault secrets."
            )

        parts = vault_token.removeprefix("vault:").split("/", 1)
        if len(parts) != 2:
            raise KeyError(
                f"Vault token {vault_token!r} has unexpected format. "
                f"Expected 'vault:{session_id}/{token_id}'."
            )

        session_id, token_id = parts
        secret_name = self._secret_name(session_id, token_id)
        resp = self.client.get_secret_value(SecretId=secret_name)
        try:
            data = json.loads(resp["SecretString"])
        except (json.JSONDecodeError, TypeError) as exc:
            raise KeyError(
                f"Secret '{secret_name}' contains invalid JSON. "
                f"Cannot dereference vault token: {exc}"
            ) from exc
        if "raw_value" not in data:
            raise KeyError(
                f"Secret '{secret_name}' is malformed - missing 'raw_value' key. "
                f"Found keys: {list(data.keys())}"
            )
        return data["raw_value"]

    def delete(self, vault_token: str) -> bool:
        parts = vault_token.removeprefix("vault:").split("/", 1)
        if len(parts) != 2:
            return False
        session_id, token_id = parts
        secret_name = self._secret_name(session_id, token_id)
        try:
            self.client.delete_secret(
                SecretId=secret_name,
                ForceDeleteWithoutRecovery=True,
            )
            return True
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code in ("ResourceNotFoundException", "AccessDeniedException"):
                log.warning(
                    "vault_delete_expected_error",
                    vault_token=vault_token,
                    error=str(exc),
                )
                return False
            log.exception(
                "vault_delete_unexpected_error",
                vault_token=vault_token,
            )
            raise
        except Exception:
            log.exception(
                "vault_delete_unexpected_error",
                vault_token=vault_token,
            )
            raise
