"""
HashiCorp Vault KV v2 provider.

Requires:
    pip install hvac
    HASHICORP_VAULT_URL and HASHICORP_VAULT_TOKEN in .env / settings.
"""

from __future__ import annotations

import uuid

import hvac

from config import settings
from observability.logger import log
from vault.base import BaseVaultClient


class HashiCorpVaultClient(BaseVaultClient):
    """Store / retrieve PII via HashiCorp Vault KV v2 engine."""

    def __init__(self) -> None:
        self.client = hvac.Client(
            url=settings.hashicorp_vault_url,
            token=settings.hashicorp_vault_token,
        )

    def tokenize(self, entity_type: str, raw_value: str, session_id: str) -> str:
        token_id = uuid.uuid4().hex
        path = f"pii/{session_id}/{token_id}"
        self.client.secrets.kv.v2.create_or_update_secret(
            path=path,
            secret={
                "entity_type": entity_type,
                "raw_value": raw_value,
            },
        )
        return f"vault:{session_id}/{token_id}"

    def _parse_token(self, vault_token: str) -> str:
        """Validate and parse vault token into a secret path."""
        raw = vault_token.removeprefix("vault:")
        parts = raw.split("/", 1)
        if len(parts) != 2 or not parts[0] or not parts[1]:
            raise KeyError(
                f"Vault token {vault_token!r} has unexpected format. "
                f"Expected 'vault:{{session_id}}/{{token_id}}'."
            )

        return f"pii/{raw}"

    def dereference(self, vault_token: str, auth_token: str) -> str:
        if not auth_token:
            raise PermissionError(
                "auth_token is required to dereference PII. "
                "Ensure the session is authenticated before accessing vault secrets."
            )
        path = self._parse_token(vault_token)
        secret = self.client.secrets.kv.v2.read_secret_version(path=path)
        try:
            raw_value = secret["data"]["data"]["raw_value"]
        except (KeyError, TypeError) as exc:
            raise KeyError(
                f"Secret at '{path}' has invalid structure. "
                f"Expected nested 'data.data.raw_value'. Got keys: "
                f"{list(secret.get('data', {}).get('data', {}).keys()) if isinstance(secret.get('data', {}).get('data', {}), dict) else 'N/A'}"
            ) from exc
        return raw_value

    def delete(self, vault_token: str) -> bool:
        path = self._parse_token(vault_token)
        try:
            self.client.secrets.kv.v2.delete_metadata_and_all_versions(path=path)
            return True
        except (hvac.exceptions.InvalidPath, hvac.exceptions.Forbidden) as exc:
            log.warning(
                "vault_delete_expected_error",
                vault_token=vault_token,
                error=str(exc),
            )
            return False
        except Exception:
            log.exception(
                "vault_delete_unexpected_error",
                vault_token=vault_token,
            )
            raise
