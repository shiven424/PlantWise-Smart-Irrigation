from __future__ import annotations

"""
In-memory mock vault provider for development and testing.

This is the default provider (config.vault_provider = "mock").
It stores PII in a plain dict — DO NOT use in production.
"""

import threading
import uuid

from vault.base import BaseVaultClient


class MockVaultClient(BaseVaultClient):
    """Thread-safe in-memory vault — development and tests only."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._store: dict[str, dict[str, str]] = {}

    def tokenize(self, entity_type: str, raw_value: str, session_id: str) -> str:
        token = f"vault:{uuid.uuid4().hex}"
        with self._lock:
            self._store[token] = {
                "entity_type": entity_type,
                "raw_value": raw_value,
                "session_id": session_id,
            }
        return token

    def dereference(self, vault_token: str, auth_token: str) -> str:
        if not auth_token:
            raise PermissionError(
                "auth_token is required to dereference PII. "
                "Ensure the session is authenticated before accessing vault secrets."
            )
        with self._lock:
            entry = self._store.get(vault_token)
            if entry is None:
                raise KeyError(f"Vault token {vault_token!r} not found in mock store")
            return entry["raw_value"]

    def delete(self, vault_token: str) -> bool:
        with self._lock:
            return self._store.pop(vault_token, None) is not None

    def clear(self) -> None:
        """Test helper: wipe the entire store."""
        with self._lock:
            self._store.clear()

    def __len__(self) -> int:
        """Test helper: number of stored secrets."""
        with self._lock:
            return len(self._store)