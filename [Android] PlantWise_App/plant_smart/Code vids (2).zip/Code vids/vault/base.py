"""Abstract base class for all vault providers."""
from __future__ import annotations

from abc import ABC, abstractmethod


class BaseVaultClient(ABC):
    """Every vault provider must implement these three operations."""

    @abstractmethod
    def tokenize(self, entity_type: str, raw_value: str, session_id: str) -> str:
        """Store raw PII, return an opaque vault token."""
        ...

    @abstractmethod
    def dereference(self, vault_token: str, auth_token: str) -> str:
        """Retrieve original PII value.  Requires *auth_token* for access control."""
        ...

    @abstractmethod
    def delete(self, vault_token: str) -> bool:
        """Delete PII from the vault (session cleanup).  Returns True on success."""
        ...
