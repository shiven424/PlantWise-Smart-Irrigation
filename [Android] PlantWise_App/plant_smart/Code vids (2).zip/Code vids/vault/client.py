"""Vault client factory – lazy singleton.

Usage:
    from vault.client import vault_client

Never instantiate a vault client inside an agent.
The client is created lazily on first attribute access to avoid
crashing the entire application at import time if the vault
provider is unreachable.
"""
from __future__ import annotations

import logging
import threading

from config import settings
from vault.base import BaseVaultClient


_logger = logging.getLogger("contact_center")
_vault_lock = threading.Lock()


def _get_vault_client() -> BaseVaultClient:
    """Instantiate the vault provider selected in config."""
    provider = settings.vault_provider

    if provider == "hashicorp":
        from vault.providers.hashicorp import HashiCorpVaultClient
        return HashiCorpVaultClient()

    if provider == "aws_secrets":
        from vault.providers.aws_secrets import AWSSecretsVaultClient
        return AWSSecretsVaultClient()

    if provider == "mock":
        from vault.providers.mock import MockVaultClient
        return MockVaultClient()

    raise ValueError(
        f"Unknown vault_provider={provider!r}. "
        f"Valid options: 'hashicorp', 'aws_secrets', 'mock'."
    )


class _LazyVaultClient:
    """Proxy that defers vault client creation until first use."""

    def __init__(self) -> None:
        self._client: BaseVaultClient | None = None

    def _ensure_client(self) -> BaseVaultClient:
        if self._client is None:
            with _vault_lock:
                if self._client is None:        # double-check inside lock
                    self._client = _get_vault_client()
                    _logger.info("Vault client initialised: %s", type(self._client).__name__)
        return self._client

    def __getattr__(self, name: str) -> object:
        return getattr(self._ensure_client(), name)


vault_client: BaseVaultClient = _LazyVaultClient()  # type: ignore[assignment]
