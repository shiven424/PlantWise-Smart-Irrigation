# Plan: Migrate Demo Accounts JSON → PostgreSQL (v3)

2

3  ## TL;DR
4  Introduce a new async `accounts_store/` module (mirroring `conversation_store/`) plus a sync-pool
`PostgresAuthSecretsProvider`, so all demo user, auth-secret, account-context, balance, beneficiary, **loan**,
and audit data lives in Postgres. The existing legacy `account_context` dict shape is preserved byte-for-byte
(zero changes to tool internals). New forward-compatible fields (`accounts_by_id`, `account_options`,
`selected_account_id`) are added without deprecating anything. Tool write paths (rollover, beneficiary updates,
debits/credits, loan initiation) actually persist via new `PostgresAccountAPI` and `PostgresLoanAPI`. Ownership
enforced at **both** HTTP and repository layers (closes the [mock_services/account_service/auth.py](mock_services/account_service/auth.py#L55) no-op — OWASP A01). State refreshed via the **invoker** (single
chokepoint) gated by a `mutates_account_state` flag. Realism tables (holdings, transactions, elections,
linked-bank, statements, tax-docs) **deferred to Phase 7**. No "query→SQL" agent. Login/logout protocol
unchanged; logout stays client-side for the demo.

5

6  ---

7

8  ## Phase 1 — Foundations (parallel-safe)

9

10  1. **Add config knobs** in [config.py](config.py#L88-L116)
11     - `accounts_store_backend: Literal["memory","postgres"] = "postgres"`
12     - `accounts_store_postgres_url: str` (defaults to same DSN as `conversation_store_postgres_url`)
13     - Widen `auth_secrets_provider: Literal["memory","postgres"] = "postgres"`
14     - Widen `tool_api_provider: Literal["mock","http","postgres","real"] = "postgres"`

15

16  2. **Author v1 schema** at `accounts_store/schema.sql` (idempotent `CREATE TABLE IF NOT EXISTS`, `TIMESTAMPTZ`,
   partial/functional indexes, matching [conversation_store/schema.sql](conversation_store/schema.sql) style).
   **v1 tables only — see Schema section.**

17

18  3. **Create module skeleton** under `accounts_store/`
19     - `base.py` — `BaseAccountStore` ABC (async)
20     - `models.py` — dataclasses: `DemoUser`, `AccountRow`, `BalanceRow`, `BeneficiaryRow`, `LoanRow`,
   `AccountContextDict`
21     - `memory.py` — in-memory backend (re-uses today's JSON load; keeps unit tests fast)
22     - `postgres.py` — `PostgresAccountStore` (async psycopg3 + `AsyncConnectionPool`, `dict_row`)
23     - `client.py` — `_LazyStore` proxy + `_build_store()` switch on backend (mirror [conversation_store/client.py](conversation_store/client.py))
24     - `seed.py` — `seed_if_empty(json_path)` reads JSON, idempotent `INSERT … ON CONFLICT DO NOTHING`, hashes
   via `agents.auth_agent.v1.evaluator.hash_answer`
25     - `seed_supplemental.py` — **generates** loans/audit rows deterministically from a seeded RNG keyed by
   `user_id` (reproducible)
26     - `__init__.py` — re-exports

28  4. **Author richer demo dataset** in [demo_data/accounts.json](demo_data/accounts.json) — additive (~15-20
   personas). See **Expanded Demo Data** section.

29

30  ---

31

32  ## Phase 2 — Auth Migration (depends on Phase 1)

33

34  5. **Implement `auth/providers/postgres.py::PostgresAuthSecretsProvider`**
35     - **Sync** (matches [auth/base.py](auth/base.py) `AuthSecretsProvider` ABC).
36     - Owns its own small **sync** `psycopg_pool.ConnectionPool` — avoids sync→async bridging on the hot login
   path.
37     - Implements `get_expected_hash`, `verify_password` (case-insensitive username, `hmac.compare_digest`),
   `get_account_context` (sync-cursor variant of the same SQL aggregation used by the async store).

38

39  6. **Wire it** in [auth/client.py](auth/client.py#L18-L34) `_build_secrets_provider()` — add `"postgres"`
   branch. Keep `"memory"` for tests and local parity.

40

41  7. **Keep `MemoryOtpChannel` unchanged** — OTPs are short-lived; no DB write needed.

42

43  ---

44

45  ## Phase 3 — Tool API Migration (depends on Phase 1; parallel with Phase 2)

46

47  8. **Implement `tools/clients/postgres/account_api.py::PostgresAccountAPI`**
48     - Same surface as `MockAccountAPI` ([mock_services/inprocess/account_api.py](mock_services/inprocess/account_api.py)) — `get_balance`, `get_prior_year_end_balance`, `get_account_details`, `get_beneficiaries`,
   `update_beneficiaries`, `debit_balance`, `credit_balance`, `initiate_rollover`.
49     - **Every method takes `user_id`** and includes it in the `WHERE` clause** (defense-in-depth ownership
   enforcement at the repo layer; not just the HTTP boundary).
50     - Backed by `accounts_store` via the app's main asyncio loop captured at startup. Sync-tool callers bridge
   via `asyncio.run_coroutine_threadsafe(coro, app.state.loop).result(timeout=…)`.
51     - Atomicity for `initiate_rollover`: `async with conn.transaction()` + `SELECT … FOR UPDATE` on both source
   and dest `account_balances` rows.
52     - Last-4 alias: `WHERE user_id = $1 AND (account_number = $2 OR RIGHT(account_number,4) = $2)` — **scoped to
   user** to avoid cross-user collisions.
53     - Every mutation writes a row to `account_balance_audit`.

54

55  9. **Implement `tools/clients/postgres/loan_api.py::PostgresLoanAPI`**
56     - Mirrors `MockLoanAPI` surface (`get_loan_eligibility`, `list_loans_by_account`, `get_loan_status`,
   `initiate_loan`).
57     - Backed by `account_loans` table. Same sync-bridge + ownership pattern as `PostgresAccountAPI`.

58

59  10. **Add `"postgres"` branches** in [tools/api_factory.py](tools/api_factory.py) `create_account_api()` AND
   `create_loan_api()`. `create_disbursement_api()` stays on existing paths (deferred).

60

61  ---

62

63  ## Phase 4 — App Wiring + Ownership Hardening (depends on Phases 1-3)

64

65  11. **Update lifespan** in [main.py](main.py#L388-L440)
66      - After `conversation_store.setup()`: `await accounts_store.setup()` then `await accounts_store.
   seed_if_empty(settings.auth_demo_accounts_path)`.
67      - Capture `app.state.loop = asyncio.get_running_loop()` for sync→async bridge.
68      - Shutdown: `await accounts_store.close()`.

69

70  12. **Refactor `_seed_demo_accounts()`** in [main.py](main.py#L280-L388)
71      - When `tool_api_provider == "postgres"`: **no-op AND skip booting `mock_services/account_service` HTTP
   server entirely** (no point running a parallel mock when tools talk to Postgres directly).
72      - When `tool_api_provider == "mock"`: replace hardcoded user list with `await accounts_store.
   list_demo_user_ids()`. Keep last-4 alias seeding behavior.

73

74  13. **Update mock HTTP service seed** in [mock_services/account_service/store.py](mock_services/account_service/store.py)
75      - Add `seed_from_db()` alongside `seed_from_demo_data()`; `_bootstrap()` picks based on `settings.
   accounts_store_backend`.

76

77  14. **Replace ownership no-op** in [mock_services/account_service/auth.py](mock_services/account_service/auth.py#L55)
78      - `assert_user_owns_account(user_id, account_number)` does a real `SELECT 1 FROM accounts WHERE user_id =
   $1 AND account_number = $2`.
79      - Apply at every account route (read **and** write) in [routes/accounts.py](mock_services/account_service/routes/accounts.py), [routes/loans.py](mock_services/account_service/routes/loans.py), [routes/
   disbursements.py](mock_services/account_service/routes/disbursements.py).
80      - Repository methods in `PostgresAccountStore` / `PostgresLoanAPI` *also* enforce via WHERE clause —
   defense-in-depth.

81

82  15. **Login endpoint and conversation start/resume unchanged** ([main.py](main.py#L953-L970), [main.py](main.py#L1036-L1044), [main.py](main.py#L1773-L1783)) — `secrets_provider().verify_password()` and `.
   get_account_context()` already abstract over backend; the new provider slots in transparently.

83

84  ---

85

86  ## Phase 5 — Invoker State Refresh (depends on Phase 3)

87

88  16. **Declarative mutation flag** on the tool registry: add `mutates_account_state: bool = False` to the tool
   descriptor in [tools/registry.py](tools/registry.py). Set `True` for: balance debit/credit paths, beneficiary
   updates, rollover, loan initiation.

89

90  17. **Refresh in invoker only** ([tools/invoker.py](tools/invoker.py#L44))
91      - After a successful tool execution where `mutates_account_state=True`, re-read `account_context` via
   `secrets_provider().get_account_context(user_id)` and merge into `state["account_context"]`.
92      - **Single chokepoint**: can't be forgotten when adding new mutating tools.
93      - Keeps `PostgresAccountAPI` / `PostgresLoanAPI` as pure data-access layers (no `state` coupling, easily
   unit-testable).

94

95  ---

96

97  ## Phase 6 — Frontend (small)

98

99  18. **Update DEV-only `DEMO_ACCOUNTS`** in [frontend/src/components/Login.tsx](frontend/src/components/Login.tsx) to include new personas.

100

101  19. **No login/logout changes**:
102      - Login: `POST /auth/login` returns `{user_id, access_token, expires_in, token_type}` — identical contract.
103      - Logout: [frontend/src/api/auth.ts](frontend/src/api/auth.ts) `clearAuth()` clears `localStorage`. JWTs
   expire naturally (TTL 900s).
104      - Multi-tab logout, 401 auto-logout, per-conversation `session_token` (separate from JWT) — all unchanged.

105

106  20. **Multi-account picker — recommend defer**. Tools already iterate `accounts_map`; supervisor disambiguates
   via clarifying questions. The new `account_options` field on `account_context` is the data contract for a
   future picker.

107

108  ---

109

110  ## Phase 7 — Realism Enrichment (POST-MIGRATION, separate ship)

111

112  Ship after Phases 1-6 are stable. **Tables without consumers are dead weight; add when a feature needs them.**

113

114  21. New tables: `account_holdings`, `account_transactions`, `contribution_elections`, `linked_bank_accounts`,
   `statements`, `tax_documents`.
115  22. Generated deterministically by `seed_supplemental.py` (RNG seeded by `user_id` → reproducible).
116  23. New read-only repository methods + (optional) new tools to surface the data (e.g., `holdings_summary`,
   `recent_transactions`).

117

118  ---

119

120  ## Phase 8 — Tests & Verification

121

122  24. **Unit tests**
123      - `tests/accounts_store/test_postgres.py` — schema setup, seed idempotency, `get_account_context` shape
   parity with memory provider, multi-account aggregation, rollover atomicity (`FOR UPDATE`), ownership
   enforcement (foreign user → empty result).
124      - `tests/auth/test_postgres_provider.py` — mirrors [tests/auth/test_memory_provider.py](tests/auth/test_memory_provider.py).
125      - `tests/tools/clients/test_postgres_account_api.py` and `test_postgres_loan_api.py` — sync-bridge
   correctness, ownership enforcement, last-4 alias resolution.
126      - `tests/tools/test_invoker_refresh.py` — assert `account_context` is re-fetched only when
   `mutates_account_state=True`.

127

128  25. **Parity tests** — extend [tests/mock_services/test_parity.py](tests/mock_services/test_parity.py) with
   mock-vs-postgres pairs for both account and loan APIs.

129

130  26. **Auth ownership tests** — new `tests/mock_services/account_service/test_ownership.py`: assert that user
   A's JWT cannot read or mutate user B's account (HTTP 403 / empty result).

131

132  27. **E2E** — keep `tests/e2e/` on `memory`+`mock` defaults; add a CI integration job with
   `AUTH_SECRETS_PROVIDER=postgres ACCOUNTS_STORE_BACKEND=postgres TOOL_API_PROVIDER=postgres`.

133

134  28. **Manual verification**
135      - Boot logs show `phase=accounts_store_ready`, `seed_completed users=NN`. Restart → no duplicate seeds.
136      - Login as `alex` (single-account) and a multi-account persona. Run balance inquiry, update beneficiaries,
   perform IRA rollover, initiate plan loan. Restart → confirm persistence.
137      - Cross-user attack: get `alex`'s JWT, try `GET /v1/accounts/{jordans-account}/balance` → must 403.
138      - Verify `state["account_context"]` reflects the new balance after a debit (i.e., invoker refresh fired).
139      - `/demo/last_otp/{user_id}` still works.

140

141  ---

142

143  ## Required Schema — v1 (must-have)

144

145  `accounts_store/schema.sql`:

146

147  1. **`demo_users`** — `user_id TEXT PK`, `username CITEXT UNIQUE NOT NULL`, `email`, `display_name`, `status
   TEXT DEFAULT 'active'`, `password_hash TEXT NOT NULL`, `password_hash_algo TEXT DEFAULT 'sha256'`,
   `created_at`, `updated_at`. Functional index on `LOWER(username)`. *(Named `demo_users` not `users` — signals
   seeded demo data, avoids collision with future SSO/IDP `users` table.)*

148

149  2. **`user_auth_secrets`** — composite PK `(user_id, challenge_type)`, `secret_hash TEXT NOT NULL`,
   FK→demo_users CASCADE.

150

151  3. **`user_account_context`** — 1:1 with user. `primary_account_type`, `available_account_types TEXT[]`,
   `owner_age_years NUMERIC`, `owner_dob DATE`, `marital_status`, `spousal_consent_obtained BOOL`, optional RMD
   fields (`ytd_distributions NUMERIC`, `rmd_deadline_passed BOOL`, `rmd_correction_window BOOL`), `updated_at`.

152

153  4. **`accounts`** — `account_id BIGSERIAL PK` (**stable surrogate** — used by `accounts_by_id`),
   `account_number TEXT UNIQUE NOT NULL` (vault token, may rotate), FK `user_id`, `account_type`, `plan_type`,
   `plan_name`, `plan_allows_loans/hardship/rollovers_in BOOL`, `is_active`, `is_frozen`, `account_age_days INT`.
   Indexes: `(user_id)`, `(user_id, account_type)`, **functional index on `RIGHT(account_number, 4)` scoped via
   user_id at query time**.

154

155  5. **`account_balances`** — 1:1 with `accounts` (FK `account_id`, separate row to isolate hot UPDATE path).
   `total_balance`, `vested_balance`, `unvested_balance`, `prior_year_end_balance`, `ytd_contributions`,
   `ytd_employer_match`, `annual_match_max`, `outstanding_loan_balance`, `highest_loan_balance_12m`, `as_of
   TIMESTAMPTZ`.

156

157  6. **`beneficiaries`** — `id BIGSERIAL PK`, FK `account_id`, `name`, `relationship`, `percentage NUMERIC(5,2)`,
   `beneficiary_type`, `date_of_birth DATE`, `ssn_last4`. Index on `account_id`.

158

159  7. **`account_loans`** — `loan_id BIGSERIAL PK`, FK `account_id`, `principal NUMERIC`, `outstanding_balance
   NUMERIC`, `interest_rate NUMERIC`, `term_months INT`, `origination_date DATE`, `status TEXT` (`active|paid|
   defaulted`), `last_payment_date DATE`. Index on `account_id`. *(Powers [tools/plan_loan/v1/agent.py](tools/plan_loan/v1/agent.py) — included in v1 because we're shipping `PostgresLoanAPI`.)*

160

161  8. **`account_balance_audit`** — `id BIGSERIAL PK`, FK `account_id`, `delta NUMERIC NOT NULL`, `reason TEXT NOT
   NULL` (`debit|credit|rollover_out|rollover_in|loan_origination|...`), `actor_user_id TEXT`, `correlation_id
   TEXT` (e.g., session_id), `created_at TIMESTAMPTZ`. Powers transaction-history demos and audit/forensics.

162

163  9. **`auth_audit_log`** — `id BIGSERIAL PK`, `user_id TEXT NULL` (NULL for failed lookups), `event TEXT NOT
   NULL` (`login_success|login_failure|kba_challenge_issued|kba_success|kba_failure|token_issued`),
   `failure_reason TEXT NULL` (category only — never the attempted password/answer), `client_ip INET`, `user_agent
   TEXT`, `created_at TIMESTAMPTZ`. **Schema comment**: "purge > 90 days" (not enforced in demo).

164

165  ### Deferred to Phase 7
166  `account_holdings`, `account_transactions`, `contribution_elections`, `linked_bank_accounts`, `statements`,
   `tax_documents`.

167

168  ### How `get_account_context()` rebuilds the dict shape
169  A single async query joins `accounts ⋈ account_balances ⋈ beneficiaries ⋈ account_loans` for the user and uses
`json_object_agg(account_type, json_build_object(...))` for the legacy `accounts` map. Python then:
170  1. Flattens the **primary** account's fields onto the top level (legacy "flat mirror" — keeps tools that
   haven't migrated working).
171  2. Builds **new forward-compat fields** (see below).

172

173  ---

174

175  ## Forward-Compat Fields (locked semantics)

176

177  Augment `account_context` *without* deprecating the existing `accounts` map:

178

179  - **`accounts_by_id: dict[str(account_id), Account]`** — keyed by stable surrogate `account_id` (BIGSERIAL from
   `accounts` table), **not** by `account_number` (vault token, may rotate).
180  - **`account_options: list[{account_id, account_type, label, last4}]`** — UI/picker payload. **No balance
   fields** (don't leak balances when the picker only needs labels).
181  - **`selected_account_id: str | None`** — the currently active account. Tools that operate on a single account
   default to this when present, else fall back to `primary_account_type` lookup.

182

183  The legacy `accounts` (keyed by type) and flat-mirror fields stay **forever** — no deprecation.

184

185  ---

186

187  ## Multi-Account Handling

188

189  - 1:N `accounts` rows per user → aggregated to legacy `account_context["accounts"]` (keyed by type) **and** new
`accounts_by_id` (keyed by stable surrogate).
190  - `primary_account_type` on `user_account_context` controls which account is flat-mirrored at the top level.
191  - Tools already iterate `accounts_map` ([tools/balance_inquiry/v1/agent.py](tools/balance_inquiry/v1/agent.py)); supervisor disambiguates ambiguous requests via clarifying questions.
192  - Last-4 alias **scoped to `(user_id, RIGHT(account_number,4))`** — collision-safe in expanded dataset.
193  - Vault tokens stay per-account; no `vault/` schema change.

194

195  ---

196

197  ## Auth Secrets Post-Migration

198

199  - Stored in `user_auth_secrets`, pre-hashed via `hash_answer(challenge_type, value)` from [agents/auth_agent/v1/evaluator.py](agents/auth_agent/v1/evaluator.py). **Plaintext exists only in seed JSON; never stored after
   import.**
200  - `PostgresAuthSecretsProvider.get_expected_hash` = single PK select. Verification uses `hmac.compare_digest`.
201  - KBA flow ([agents/auth_agent/v1/agent.py](agents/auth_agent/v1/agent.py#L352)) is **unchanged** — same
   provider contract.
202  - `AUTH_JWT_SECRET` stays in `.env` / Vault — **never** in the accounts DB. Empty → [auth/jwt_utils.py](auth/jwt_utils.py#L19) generates an ephemeral runtime secret (tokens die on restart).
203  - **OTPs** stay in `MemoryOtpChannel` (5-min TTL, no durability needed).

204

205  ---

206

207  ## Login & Logout Post-Migration

208

209  **Login** (protocol unchanged):
210  1. `POST /auth/login` with `{username, password}` → `secrets_provider().verify_password()` (Postgres-backed) →
   `issue_token()` (HS256, TTL 900s).
211  2. Returns `{user_id, access_token, expires_in, token_type}`.
212  3. Frontend stores in `localStorage` ([frontend/src/api/auth.ts](frontend/src/api/auth.ts)).
213  4. New: `auth_audit_log` row written for `login_success`/`login_failure`/`token_issued`.

214

215  **Logout** (client-side, demo scope):
216  - `clearAuth()` clears `localStorage`; JWTs expire naturally.
217  - **No server `/auth/logout` endpoint** in v1.
218  - **Production-style immediate logout** (out of scope): add `jti` claim + `auth_sessions` / `revoked_jwts`
   table + backend logout endpoint. Optionally rotate `auth_jwt_secret` on a schedule with `kid` claim.

219

220  ---

221

222  ## Why No "Query→SQL" Agent

223

224  Every account-data access is a bounded set of well-known operations. Best as parameterized SQL in a thin
   repository (same pattern as [conversation_store/postgres.py](conversation_store/postgres.py)). LLM-generated
   SQL would introduce SQL-injection / data-exfiltration risk (OWASP A03), non-determinism, latency, and cost —
   for zero functional gain in this bounded domain.

225

226  ---

227

228  ## Expanded Demo Data ([demo_data/accounts.json](demo_data/accounts.json))

229

230  Grow 6 → ~15-20 personas (additive; existing user_ids preserved):

231

232  | Persona | Accounts | Coverage |
233  |---|---|---|
234  | Recent grad | 1× ROTH_IRA | vested = total, no employer match |
235  | Mid-career single 401k | 1× 401K | outstanding loan + recent contributions |
236  | Pre-retiree (58) | 401K + TRADITIONAL_IRA + BROKERAGE + ROTH_IRA | 4-account aggregation; in-service
   withdrawal |
237  | RMD-age widow | TRADITIONAL_IRA + INHERITED_IRA | inherited IRA rules |
238  | Self-employed | SEP_IRA + SOLO_401K + BROKERAGE | new plan_types |
239  | HNW | 401K + ROTH_IRA + BROKERAGE + 529 + HSA | stress-test multi-account |
240  | Frozen account | 1× 401K (`is_frozen=true`) | negative-path |
241  | Beneficiary-heavy | 1× IRA, 4 beneficiaries (60/20/10/10) | beneficiary CRUD |
242  | Recent rollover-in | 401K + TRADITIONAL_IRA | audit trail demo |
243  | Loan-defaulted | 1× 401K, outstanding = vested | loan eligibility |

244

245  Realistic `beneficiaries` arrays on every account; DOB spread 1948-2002; balances $5k-$2.5M;
   `ytd_contributions` capped per [regulatory/irs_limits.py](regulatory/irs_limits.py); plan names like "Acme Corp
   401(k) Plan". All passwords stay `demo123`. Loans/audit rows generated by `seed_supplemental.py` (deterministic
   per-user RNG).

246

247  ---

248

249  ## Relevant Files

250

251  **New**
252  - `accounts_store/__init__.py`, `base.py`, `models.py`, `memory.py`, `postgres.py`, `client.py`, `schema.sql`,
   `seed.py`, `seed_supplemental.py`
253  - `auth/providers/postgres.py` — `PostgresAuthSecretsProvider` (sync pool)
254  - `tools/clients/postgres/__init__.py`, `account_api.py`, `loan_api.py`
255  - Tests: `tests/accounts_store/test_postgres.py`, `tests/auth/test_postgres_provider.py`, `tests/tools/clients/
   test_postgres_account_api.py`, `test_postgres_loan_api.py`, `tests/tools/test_invoker_refresh.py`, `tests/
   mock_services/account_service/test_ownership.py`

256

257  **Modified**
258  - [config.py](config.py#L88-L116) — new env vars; widen literal types
259  - [auth/client.py](auth/client.py#L18-L34) — `"postgres"` branch in `_build_secrets_provider`
260  - [main.py](main.py#L388-L440) — lifespan setup/seed/close + capture `app.state.loop`
261  - [main.py](main.py#L280-L388) — `_seed_demo_accounts` reads from store; full skip in postgres mode
262  - [tools/api_factory.py](tools/api_factory.py) — `"postgres"` branches for `create_account_api()` AND
   `create_loan_api()`
263  - [tools/invoker.py](tools/invoker.py#L44) — refresh `account_context` after `mutates_account_state=True` tools
264  - [tools/registry.py](tools/registry.py) — add `mutates_account_state` field; mark mutating tools
265  - [mock_services/account_service/auth.py](mock_services/account_service/auth.py#L55) — real ownership check
266  - [mock_services/account_service/store.py](mock_services/account_service/store.py) — `seed_from_db()` alongside
   `seed_from_demo_data()`
267  - [mock_services/account_service/routes/accounts.py](mock_services/account_service/routes/accounts.py), `routes/
   loans.py`, `routes/disbursements.py` — call ownership check on every account-scoped route
268  - [demo_data/accounts.json](demo_data/accounts.json) — expanded personas (additive)
269  - [frontend/src/components/Login.tsx](frontend/src/components/Login.tsx) — extend DEV `DEMO_ACCOUNTS`

270

271  **Unchanged**
272  - [auth/base.py](auth/base.py), [auth/jwt_utils.py](auth/jwt_utils.py), [auth/predicates.py](auth/predicates.py)
273  - [schemas/graph_state.py](schemas/graph_state.py) — `account_context: dict[str, Any]` keeps loose typing
274  - All tool agents under `tools/**/agent.py` — read paths unchanged (legacy dict shape preserved)
275  - `vault/`, frontend auth context / API client / multi-tab logout

276

277  ---

278

279  ## Verification

280

281  1. `pytest tests/accounts_store/ tests/auth/test_postgres_provider.py tests/tools/clients/ tests/tools/
   test_invoker_refresh.py tests/mock_services/account_service/test_ownership.py`
282  2. `pytest tests/mock_services/test_parity.py` — extended mock-vs-postgres parity
283  3. `pytest tests/e2e/` (default `memory`+`mock`) — regression
284  4. CI integration job: Postgres container, `AUTH_SECRETS_PROVIDER=postgres ACCOUNTS_STORE_BACKEND=postgres
   TOOL_API_PROVIDER=postgres`
285  5. Manual: log lines `phase=accounts_store_ready`, `seed_completed users=NN`; restart→no dup seeds; cross-user
   403; balance refresh after debit; psql spot-checks on `account_balances`, `account_balance_audit`,
   `auth_audit_log`.

286

287  ---

288

289  ## Decisions

290

291  - **Hybrid sync/async**: sync `ConnectionPool` for auth (hot single-row PK); async `AsyncConnectionPool` for
   accounts store.
292  - **Single Postgres DB** reused across `conversation_store`, checkpointer, `accounts_store` (separate tables).
293  - **Seed source = `demo_data/accounts.json`**; supplemental data generated deterministically. Plaintext never
   persists past import.
294  - **Ownership at TWO layers**: HTTP (route check) + repository (`WHERE user_id = $1`). Tools stay unaware of
   authz.
295  - **State refresh in invoker only**, gated by `mutates_account_state` flag.
296  - **Stable account surrogate**: `account_id BIGSERIAL` for `accounts_by_id`; legacy `account_number` stays the
   vault token.
297  - **In scope (v1)**: 9 tables, `PostgresAccountAPI`, `PostgresLoanAPI`, ownership enforcement, audit logging,
   invoker refresh, expanded JSON personas.
298  - **Out of scope (v1)**: holdings/transactions/elections/linked-bank/statements/tax-docs (Phase 7); OTP
   storage; disbursement persistence; JWT revocation table; multi-instance write coordination; real DB migration
   tooling beyond IF-NOT-EXISTS.

299

300  ---

301

302  ## Further Considerations

303

304  1. **Multi-account UX picker**: A) Defer; supervisor disambiguates — **recommended** (data contract
   `account_options` is ready). B) Ship dropdown setting `selected_account_id` on conversation start. C) Full
   multi-account dashboard panel.
305  2. **Beneficiary write atomicity**: A) `DELETE+INSERT` in transaction — **recommended**, matches mock
   semantics. B) Upsert with generation column for lost-update detection (overkill for demo).
306  3. **Audit log retention**: A) Document "purge > 90 days" in schema comment, no enforcement — **recommended**.
   B) Add a scheduled purge job. C) No retention.
307  4. **Phase 7 trigger**: ship realism tables when (a) a demo script needs them, or (b) a stakeholder explicitly
   asks for "real-bank feel" beyond accounts/loans. Don't pre-build.

308