# Contact Center AI — Setup & Startup Guide

## Architecture Overview

This is a **multi-agent conversational AI** for financial services built on **LangGraph + FastAPI**, with a **Vite/React/TypeScript** frontend.

```mermaid
graph TB
    subgraph Frontend["🖥️ Frontend (Vite + React + Tailwind)"]
        UI["Chat UI :3000"]
    end

    subgraph Backend["⚙️ Backend (FastAPI + LangGraph)"]
        API["FastAPI :8000"]
        subgraph Graph["LangGraph Orchestration"]
            MC["Message Classifier"]
            SV["Supervisor"]
            IA["Intent Agent"]
            EE["Entity Extraction"]
            RA["RAG Agent"]
            AA["Auth Agent"]
            EV["Entity Validator"]
            RS["Response Synthesizer"]
        end
        subgraph Tools["Tool Layer (Transactions)"]
            BI["Balance Inquiry"]
            IR["IRA Rollover"]
            WD["Withdrawal"]
            RMD["RMD Calculator"]
            BM["Beneficiary Manager"]
            PL["Plan Loan"]
        end
    end

    subgraph Data["📦 Data Layer"]
        Chroma["ChromaDB (Vector Store)"]
        Vault["Vault (PII Tokens)"]
        Profile["User Profiles"]
    end

    UI -- "REST API" --> API
    API --> MC --> SV
    SV --> IA & EE & RA & AA & EV
    IA & EE & RA & AA & EV --> SV
    SV --> RS --> Tools
    RA --> Chroma
    API --> Vault
    API --> Profile
```

---

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| **Python** | 3.11+ | For `X \| Y` union syntax and `typing-extensions` |
| **Node.js** | 18+ | For the Vite/React frontend |
| **npm** | 9+ | Comes with Node.js |
| **OpenAI API Key** | — | Required for LLM, embeddings, and reranking |

---

## Step-by-Step Setup

### 1. Clone & Navigate

```bash
cd "d:\Code vids"
```

### 2. Create a Python Virtual Environment

```bash
python -m venv .venv

# Activate (Windows PowerShell)
.\.venv\Scripts\Activate.ps1

# Activate (Windows CMD)
.\.venv\Scripts\activate.bat
```

### 3. Install Python Dependencies

```bash
pip install -r requirements.txt
```

> [!NOTE]
> If using **local** embeddings/reranker (not the default), also install:
> ```bash
> pip install sentence-transformers torch
> ```

### 4. Configure Environment Variables

The [.env](file:///d:/Code%20vids/.env) file at the project root controls all settings. Key variables:

```bash
# === LLM ===
LLM_PROVIDER=openai              # "openai" | "anthropic" | "github"
OPENAI_API_KEY=sk-proj-...       # Your OpenAI API key
LLM_MODEL=gpt-4o-mini            # Model to use
LLM_MAX_TOKENS=1000
LLM_TIMEOUT_SECONDS=30

# === Embeddings ===
EMBEDDING_PROVIDER=openai         # "openai" | "local"
EMBEDDING_MODEL=text-embedding-3-small
EMBEDDING_DIMENSIONS=1536

# === Reranker ===
RERANKER_PROVIDER=openai          # "openai" | "local"

# === Optional overrides (defaults shown) ===
# VAULT_PROVIDER=mock             # "mock" | "hashicorp" | "aws_secrets"
# PROFILE_STORE_PROVIDER=memory   # "memory" | "redis"
# VECTOR_STORE_PROVIDER=chromadb  # "chromadb" | "pinecone"
# TOOL_API_PROVIDER=mock     # "mock" | "real"
# CHROMADB_PATH=./data/chromadb
```

> [!IMPORTANT]
> You **must** set a valid `OPENAI_API_KEY`. All LLM calls, embeddings, and reranking use OpenAI by default.

### 5. Index the Knowledge Base (RAG)

The knowledge base documents live in `knowledge_base/documents/` and are described by `document_metadata.json`. You must index them into ChromaDB before the RAG agent can answer questions:

```bash
python -c "from knowledge_base.indexer import Indexer; stats = Indexer().index_all(); print(stats)"
```

This reads all documents, chunks them (sliding window or structured), embeds via OpenAI, and upserts into a local ChromaDB at `./data/chromadb/`.

### 6. Start the Backend

```bash
python main.py
```

This starts **uvicorn** on `http://localhost:8000` with hot-reload enabled. On startup it:
1. Compiles the LangGraph (loads all 8 agents + 6 tools)
2. Validates agent registries
3. Initializes the MemorySaver checkpointer (in-memory, dev mode)
4. Starts a background task for stale conversation cleanup

> [!TIP]
> Verify the backend is ready:
> - `GET http://localhost:8000/health` → `{"status": "ok"}`
> - `GET http://localhost:8000/ready` → `{"status": "ready"}`

### 7. Start the Frontend

```bash
cd frontend
npm install
npm run dev
```

Opens on `http://localhost:3000`. The Vite dev server **proxies** all API calls (`/conversations`, `/health`, `/ready`) to `http://localhost:8000`, so no CORS issues.

> [!NOTE]
> To override the backend URL, create `frontend/.env`:
> ```
> VITE_BACKEND_URL=http://localhost:8000
> ```

---

## API Endpoints (Backend)

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/auth/login` | Exchange username/password for a short-lived JWT |
| `POST` | `/conversations` | Start a new conversation (requires JWT; returns `session_token`) |
| `POST` | `/conversations/{id}/turns` | Send a user message (requires `session_token`) |
| `POST` | `/conversations/{id}/hitl` | Approve or correct a HITL confirmation |
| `POST` | `/conversations/{id}/end` | End the conversation |
| `GET` | `/conversations/{id}` | Get conversation state snapshot |
| `GET` | `/demo/last_otp/{user_id}` | **Demo only** — fetch the most recent OTP for the JWT user |
| `GET` | `/health` | Liveness probe |
| `GET` | `/ready` | Readiness probe |

`POST /auth/login` returns a JWT (`access_token`) that must be sent as
`Authorization: Bearer <jwt>` on `POST /conversations` and
`GET /demo/last_otp/{user_id}`. Per-conversation endpoints continue to use
the conversation-scoped `session_token` returned by `/conversations`.

**Demo accounts** (`demo_data/accounts.json`): `alex / demo123`,
`morgan / demo123`, `noauth / demo123`. Auth secrets (ZIP, last-4 SSN,
DOB, OTP) are seeded server-side and **never** trusted from request bodies.

---

## Key Configuration Options ([config.py](file:///d:/Code%20vids/config.py))

| Setting | Default | Description |
|---|---|---|
| `llm_provider` | `openai` | LLM backend: `openai`, `anthropic`, `github` |
| `vault_provider` | `mock` | PII vault: `mock`, `hashicorp`, `aws_secrets` |
| `profile_store_provider` | `memory` | User profiles: `memory` (in-process), `redis` |
| `vector_store_provider` | `chromadb` | Vector DB: `chromadb`, `pinecone` |
| `tool_api_provider` | `mock` | Transaction APIs: `mock` (dev), `real` (production) |
| `idle_session_ttl_seconds` | `1800` | Auto-purge idle conversations after 30 min |
| `graph_invoke_timeout` | `55` | Timeout per graph invocation (seconds) |

---

## Project Structure

```
d:\Code vids\
├── main.py                    # FastAPI entry point (uvicorn :8000)
├── config.py                  # Pydantic Settings (reads .env)
├── .env                       # Environment variables
├── requirements.txt           # Python dependencies
│
├── graph/                     # LangGraph orchestration
│   ├── builder.py             # Graph construction & compilation
│   ├── state.py               # GraphState helpers & initial_state()
│   ├── router.py              # Conditional edge routing logic
│   └── checkpointer.py        # MemorySaver factory (swap for production)
│
├── agents/                    # Core agents (8 total)
│   ├── message_classifier/    # Classify user intent domain
│   ├── intent_agent/          # Resolve specific intent + required slots
│   ├── entity_extraction/     # Extract entities from user messages
│   ├── rag_agent/             # RAG retrieval + answer synthesis
│   ├── auth_agent/            # Authentication challenges
│   ├── entity_validator/      # Validate extracted entities
│   ├── supervisor/            # Orchestration loop controller
│   ├── action_planner/        # (internal) policy → action plan
│   └── registry.py            # Agent registry
│
├── tools/                # Transaction tools (3 total)
│   ├── balance_inquiry/
│   ├── rmd_calculator/
│   ├── plan_loan/
│   └── registry.py
│
├── knowledge_base/            # RAG pipeline
│   ├── documents/             # Source documents (txt/pdf)
│   ├── embedder.py            # OpenAI / local embedding
│   ├── indexer.py             # Chunk + embed + upsert to ChromaDB
│   └── vector_store.py        # ChromaDB wrapper
│
├── llm/                       # Centralised LLM client
│   └── client.py              # call_llm() / call_llm_text()
│
├── schemas/                   # Pydantic models & enums
├── vault/                     # PII tokenization (mock/HashiCorp/AWS)
├── user_profile/              # Cross-session user memory
├── synthesizer/               # Response synthesis templates
├── regulatory/                # IRS limits, rollover matrix, etc.
├── observability/             # Structured logging, metrics, tracing
├── tests/                     # Test suite (mocks)
│
└── frontend/                  # Vite + React 18 + TypeScript + Tailwind
    ├── src/
    │   ├── api/client.ts      # Typed fetch wrapper
    │   ├── hooks/             # useConversation state machine
    │   ├── components/        # SessionSetup, ChatWindow, HitlPanel, etc.
    │   ├── App.tsx
    │   └── main.tsx
    ├── package.json
    └── vite.config.ts         # Dev proxy to :8000
```

---

## Quick Start (TL;DR)

```bash
# Terminal 1 — Backend
cd "d:\Code vids"
python -m venv .venv && .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -c "from knowledge_base.indexer import Indexer; Indexer().index_all()"
python main.py               # → http://localhost:8000

# Terminal 2 — Frontend
cd "d:\Code vids\frontend"
npm install
npm run dev                   # → http://localhost:3000
```

---

## Troubleshooting

| Issue | Solution |
|---|---|
| `OPENAI_API_KEY` errors | Ensure `.env` has a valid key, restart backend |
| ChromaDB empty / RAG returns nothing | Run the indexer: `python -c "from knowledge_base.indexer import Indexer; Indexer().index_all()"` |
| Frontend can't reach backend | Ensure backend is running on `:8000` before starting frontend |
| `sentence-transformers` import error | Only needed if `EMBEDDING_PROVIDER=local`; install with `pip install sentence-transformers torch` |
| Port 3000 already in use | Kill the process or change `server.port` in `frontend/vite.config.ts` |
