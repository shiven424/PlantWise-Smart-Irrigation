from __future__ import annotations

import logging
import threading

from config import settings
from user_profile.base import BaseProfileStore

_logger = logging.getLogger("contact_center")
_profile_lock = threading.Lock()


def _get_profile_store() -> BaseProfileStore:
    """Instantiate the profile store provider selected in config."""
    provider = settings.profile_store_provider

    if provider == "memory":
        from user_profile.providers.memory import InMemoryProfileStore

        return InMemoryProfileStore()

    if provider == "redis":
        from user_profile.providers.redis import RedisProfileStore

        return RedisProfileStore(
            url=settings.profile_store_url,
            ttl_days=settings.profile_ttl_days,
        )

    raise ValueError(
        f"Unknown profile_store_provider={provider!r}. "
        "Valid options: 'memory', 'redis'."
    )


class _LazyProfileStore:
    """Proxy that defers profile store creation until first use.

    Fix H2: Provides explicit forwarding methods for the BaseProfileStore
    interface so that type checkers, IDE introspection, and hasattr()
    work correctly without triggering premature store initialization.
    """

    def __init__(self) -> None:
        self._store: BaseProfileStore | None = None

    def _ensure_store(self) -> BaseProfileStore:
        if self._store is None:
            with _profile_lock:
                if self._store is None:  # double-check inside lock
                    self._store = _get_profile_store()
                    _logger.info(
                        "Profile store initialised: %s",
                        type(self._store).__name__,
                    )
        return self._store

    def load(self, user_id: str):
        """Load a user profile by ID."""
        return self._ensure_store().load(user_id)

    def save(self, profile) -> None:
        """Create or overwrite the profile."""
        return self._ensure_store().save(profile)

    def delete(self, user_id: str) -> bool:
        """Delete a user profile."""
        return self._ensure_store().delete(user_id)

    def __getattr__(self, name: str) -> object:
        return getattr(self._ensure_store(), name)


profile_store: BaseProfileStore = _LazyProfileStore()  # type: ignore[assignment]
