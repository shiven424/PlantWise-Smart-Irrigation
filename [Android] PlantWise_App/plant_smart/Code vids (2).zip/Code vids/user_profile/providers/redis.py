"""Redis-backed profile store for production deployments."""

from __future__ import annotations

import logging

from user_profile.base import BaseProfileStore, UserProfile

_logger = logging.getLogger("contact_center")


class RedisProfileStore(BaseProfileStore):
    """Profile persistence via Redis with optional TTL.

    Profiles are stored as JSON strings under the key
    ``user_profile:{user_id}``.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379/0",
        ttl_days: int = 90,
    ) -> None:
        try:
            import redis  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "redis package is required for RedisProfileStore. "
                "Install it with: pip install redis"
            ) from exc

        self._client = redis.Redis.from_url(url, decode_responses=True)
        self._ttl_seconds = ttl_days * 86_400
        _logger.info(
            "RedisProfileStore initialised (url=%s, ttl_days=%d)",
            url,
            ttl_days,
        )

    @staticmethod
    def _key(user_id: str) -> str:
        return f"user_profile:{user_id}"

    def load(self, user_id: str) -> UserProfile | None:
        try:
            raw = self._client.get(self._key(user_id))
        except Exception as exc:
            _logger.warning(
                "RedisProfileStore.load() network error for user_id=%s: %s",
                user_id,
                exc,
            )
            return None
        if raw is None:
            return None
        try:
            return UserProfile.model_validate_json(raw)
        except Exception as exc:
            _logger.warning(
                "RedisProfileStore.load() failed to deserialize profile "
                "for user_id=%s: %s",
                user_id,
                exc,
            )
            return None

    def save(self, profile: UserProfile) -> None:
        key = self._key(profile.user_id)
        try:
            self._client.set(
                key,
                profile.model_dump_json(),
                ex=self._ttl_seconds,
            )
        except Exception as exc:
            _logger.warning(
                "RedisProfileStore.save() network error for user_id=%s: %s",
                profile.user_id,
                exc,
            )

    def delete(self, user_id: str) -> bool:
        try:
            return bool(self._client.delete(self._key(user_id)))
        except Exception as exc:
            _logger.warning(
                "RedisProfileStore.delete() network error for user_id=%s: %s",
                user_id,
                exc,
            )
            return False
