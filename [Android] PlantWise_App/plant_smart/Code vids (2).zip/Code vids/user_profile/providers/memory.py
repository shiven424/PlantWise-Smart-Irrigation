"""In-memory profile store for development and testing."""

from __future__ import annotations

import threading

from user_profile.base import BaseProfileStore, UserProfile


class InMemoryProfileStore(BaseProfileStore):
    """Thread-safe, dict-backed profile store.

    Data lives only in-process and is lost on restart - use for
    dev, unit tests, and integration tests.
    """

    def __init__(self) -> None:
        self._store: dict[str, UserProfile] = {}
        self._lock = threading.Lock()

    def load(self, user_id: str) -> UserProfile | None:
        with self._lock:
            return self._store.get(user_id)

    def save(self, profile: UserProfile) -> None:
        with self._lock:
            self._store[profile.user_id] = profile

    def delete(self, user_id: str) -> bool:
        with self._lock:
            return self._store.pop(user_id, None) is not None

    # -- Test helpers -------------------------------------------------
    def seed(self, profile: UserProfile) -> None:
        """Pre-populate a profile (test convenience)."""
        self.save(profile)

    def clear(self) -> None:
        """Remove all profiles (test teardown)."""
        with self._lock:
            self._store.clear()

    @property
    def count(self) -> int:
        """Number of stored profiles."""
        with self._lock:
            return len(self._store)
