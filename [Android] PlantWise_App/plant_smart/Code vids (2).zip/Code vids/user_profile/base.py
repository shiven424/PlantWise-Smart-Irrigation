"""Abstract base class and data model for the user profile store."""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from datetime import datetime, timezone

from pydantic import BaseModel, Field

# -- Profile field sanitiser
# Strips control characters and truncates before any profile value is
# injected into an LLM prompt, defending against prompt injection via
# compromised profile data.

_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f-\x9f]")


def sanitize_profile_field(value: str | None, max_len: int = 60) -> str:
    """Return a safe, truncated version of a profile field for prompt use."""
    if not value:
        return ""
    clean = _CONTROL_CHARS.sub("", str(value))
    return clean[:max_len]


class UserProfile(BaseModel):
    """Persistent, cross-session profile for a known user.

    Stores only non-sensitive, derived data - never raw PII.
    `display_name` comes from entity_memory display_value (masked),
    not from the vault.
    """

    user_id: str
    display_name: str | None = None
    preferred_greeting: str | None = None
    communication_style: str = "professional"

    # Auth memory - enables expedited re-verification
    last_verified_at: str | None = None
    last_verified_level: str | None = None

    # Interaction history (compact)
    known_accounts: list[str] = Field(default_factory=list)
    default_entities: dict[str, str] = Field(default_factory=dict)
    recent_intents: list[str] = Field(default_factory=list)
    past_transaction_count: int = 0
    last_session_summary: str | None = None

    # Housekeeping
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class BaseProfileStore(ABC):
    """Every profile store provider must implement these three operations."""

    @abstractmethod
    def load(self, user_id: str) -> UserProfile | None:
        """Load a user profile by ID. Returns `None` for unknown users."""
        ...

    @abstractmethod
    def save(self, profile: UserProfile) -> None:
        """Create or overwrite the profile for `profile.user_id`."""
        ...

    @abstractmethod
    def delete(self, user_id: str) -> bool:
        """Delete a user profile. Returns ``True`` if it existed."""
        ...
